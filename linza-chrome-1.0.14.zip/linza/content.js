(()=>{var Qt=o=>typeof o=="string"?o:"",Jt={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:Qt("https://efremen512218-lang.github.io/linza/"),telegram:Qt("https://t.me/linza_odds"),bot:Qt("https://t.me/linza_keys_bot?start=ext")},Ho=Qt("https://185-72-145-3.sslip.io"),In={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var Bn=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function Ie(o){let s=String(o||"").toLowerCase();return Bn.find(a=>a.hosts.some(n=>s===n||s.endsWith(`.${n}`)))||null}var ke={overlay:"picks",theme:"auto",mode:"own",model:In.model,stake:1e3},Be={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",mma:"ММА",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function yt(o){let s=String(o??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(s))return null;let a=parseFloat(s.replace(",","."));return a>=1.001&&a<=1e3?a:null}var De=o=>o.reduce((s,a)=>s+1/a,0);function kt(o){let s=(o||[]).filter(n=>Number.isFinite(n)&&n>1);if(s.length<2||s.length!==(o||[]).length)return{kind:"partial",margin:null,fair:null};let a=De(s);if(a>=.985&&a<=1.3)return{kind:"full",margin:a-1,fair:s.map(n=>1/n/a)};if(s.length===3&&a>=1.97&&a<=2.4){let n=a/2;return{kind:"double",margin:n-1,fair:s.map(p=>Math.min(.995,1/p/n))}}return{kind:"partial",margin:null,fair:null}}function qe(o){let s=(o||[]).map(f=>f||[]).filter(f=>f.length),a=s.flat().filter(Boolean);if(a.length<2)return{sets:[],rest:a};let n=f=>f.length>=2&&f.every(Boolean)&&kt(f.map(h=>h.odd)).kind!=="partial",p=f=>{let h=f.filter(v=>v.some(Boolean));if(!h.length)return null;let y=h.filter(n);if(y.length/h.length<.6)return null;let b=new Set(y.flat());return{sets:y,rest:a.filter(v=>!b.has(v))}},d=f=>{let h=[];for(let y=0;y<s.length;y+=f)h.push(s.slice(y,y+f).flat());return h},u=()=>{let f=[];for(let h=0;h+1<s.length;h+=2){let y=Math.max(s[h].length,s[h+1].length);for(let b=0;b<y;b+=1)f.push([s[h][b]??null,s[h+1][b]??null])}return f},c=[()=>d(1)];s.length>=2&&s.length%2===0&&c.push(u,()=>d(2)),s.length>=3&&s.length%3===0&&c.push(()=>d(3)),s.length>1&&c.push(()=>[s.flat()]);for(let f of c){let h=p(f());if(h)return h}return{sets:[],rest:a}}function Re(o,s=1.13){let a=c=>{let f=De(c.map(h=>h.odd));return f>=.995&&f<=s?!0:c.length===3&&f>=1.99&&f<=s*2},n=c=>Math.abs(c*4-Math.round(c*4))<1e-9,p=[],d=[],u=0;for(;u<o.length;){let c=o.slice(u,u+3),f=o.slice(u,u+2);c.length===3&&a(c)?(p.push(c),u+=3):f.length===2&&a(f)?(p.push(f),u+=2):o[u+2]&&n(o[u+1].odd)&&a([o[u],o[u+2]])?(p.push([o[u],o[u+2]]),d.push(o[u+1]),u+=3):(d.push(o[u]),u+=1)}return{sets:p,rest:d}}function Ge(o){let s=(o||[]).filter(p=>p&&p.odd>1&&p.fair>0&&p.fair<1);if(!s.length)return null;let a=s.reduce((p,d)=>p*d.odd,1),n=s.reduce((p,d)=>p*d.fair,1);return{legs:s.length,odd:a,chance:n,fairOdd:1/n,margin:1-a*n}}function Ue(o,s){return o*s-1}function H(o){return Number.isFinite(o)?o>=100?o.toFixed(0):o>=10?o.toFixed(1):o.toFixed(2):"—"}function wt(o,s=0){if(!Number.isFinite(o))return"—";let a=o*100;return a>0&&a<1&&s===0?"<1%":`${a.toFixed(s)}%`}function we(o){return String(o??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zа-я0-9]/g,"")}var Dn=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function Ve(o){return String(o??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[\u0300-\u036f]/g,"").split(/[^a-zа-я0-9]+/).filter(s=>s.length>=2&&!Dn.has(s))}function Rt(o,s){let a=we(o),n=we(s);if(a.length<2||n.length<2)return 0;if(a===n)return 1;let p=a.length<=n.length?a:n,d=p===a?n:a;if(p.length>=4&&d.includes(p))return .85;let u=Ve(o),c=Ve(s),f=y=>String(y??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[̀-ͯ]/g,"").match(/^\s*([a-zа-я-]{3,})\s+([a-zа-я])\.?\s*$/);for(let[y,b]of[[o,c],[s,u]]){let v=f(y);if(v&&b.length>=2&&b.includes(v[1])&&b.some(k=>k!==v[1]&&k[0]===v[2]))return .8}if(u.length&&c.length){let b=u.filter(v=>c.some(k=>k===v||v.length>=5&&k.startsWith(v.slice(0,5)))).length/Math.max(u.length,c.length);if(b>=.5)return .6+.3*b}let h=0;for(;h<a.length&&h<n.length&&a[h]===n[h];)h+=1;return h>=5?Math.min(.8,.45+h*.04):0}function qn(o){let s=String(o??"").toLowerCase(),a=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(s)&&a.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(s)&&a.push("women"),/\(рез|\(р\)|резерв|reserve/.test(s)&&a.push("reserve"),/люб/.test(s)&&a.push("amateur"),/кибер|esport|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(s)&&a.push("cyber"),a.join("+")}function Tt(o,s){let a=d=>{let u=we(d),c=qn(d);return u.length<2?"":c?`${u}~${c}`:u},n=a(o),p=a(s);return!n||!p?"":[n,p].sort().join("|")}var R=o=>(o?.textContent||"").replace(/[ \s]+/g," ").trim(),$e=o=>o.offsetParent===null&&o.tagName!=="BODY";function Rn(o){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(o||"").trim())}function Gn(o){let s=String(o||"").match(/(\d+)\s*[-‑–]?\s*(?:го|й|м|ой|ий|я|ая|ья|ый)?\s+(период|тайм|сет|четверт|половин|карт|гейм|иннинг)/i);return s?s[0]:""}function Gt(o,s){let a=String(o||"").toLowerCase();return/двойной шанс/.test(a)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(a)?"other":/фор[аы]|гандикап/.test(a)?"handicap":/тотал/.test(a)?"total":/обе забьют/.test(a)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(a)?s===3?"1x2":s===2?"12":"other":"other"}var Un=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/(^|[^а-яёa-z])(мма|mma|ufc|юфс)([^а-яёa-z]|$)|смешанн|единоборств|mixed martial|бои без правил/i,"mma"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function It(...o){let s=o.filter(Boolean).join(" ");for(let[a,n]of Un)if(a.test(s))return n;return""}function Me(o){if(!o)return null;let s=yt(R(o));if(s)return s;let a=R(o).split(" ");return yt(a[a.length-1])}var Vn=0;function Ot({scope:o,title:s,period:a="",line:n="",kind:p,outcomes:d,event:u=null,anchor:c=null,eventKey:f=""}){let h=d.length;return{id:`${o}|${f}|${s}|${a}|${n}|${d.map(y=>y.label).join("/")}`,serial:Vn+=1,scope:o,title:s,period:a,line:n,kind:p||Gt(s,h),main:Rn(a)&&!Gn(s),outcomes:d,event:u,anchor:c||d[0]?.el||null}}var Y=(o,s)=>[...o.querySelectorAll(s)];function Xe(o){return(String(o||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function ze(o){return o.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":o.querySelector(".card")?"list":"other"}var We={win:"В",loose:"П",lose:"П",draw:"Н"};function Ke(o){return Y(o,".competitor-form__value").map(s=>We[[...s.classList].find(a=>We[a])]||R(s).slice(0,1)).filter(Boolean).join("")}function Wn(o){let s=o.querySelector(".marketbook-header--live");if(s){let n=Y(s,".game-scoring__item").map(u=>R(u)),p=Y(s,".game-periods .period").map(u=>{let c=Y(u,"span");return{label:R(u.querySelector("i")),home:R(c[0]),away:R(c[1])}}).filter(u=>u.home!==""&&u.away!==""),d=Y(s,".game-specials > div").map(u=>{let c=Y(u,"span"),f=u.querySelector("i"),h=f?.classList.contains("yellow-card")?"жёлтые":f?.classList.contains("red-card")?"красные":f?.classList.contains("penalty-card")?"угловые":"";return h?{kind:h,home:R(c[0]),away:R(c[1])}:null}).filter(Boolean);return{state:R(s.querySelector(".game-timing-state")),score:n.length===2?n:[],periods:p,extras:d}}let a=o.querySelector(".match-card");if(a&&!a.querySelector(".match-card__timer--prematch")){let n=R(a.querySelector(".match-card__main-score")).replace(/\s/g,""),p=Y(a,".match-card__score").map(u=>R(u)).filter(u=>/^\d{1,2}$/.test(u)),d=Y(o,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(u=>R(u)).filter(u=>/\d\s*:\s*\d/.test(u)).slice(0,5);return{state:R(a.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(n)?n.split(":"):[],rounds:p.length>=2?p.slice(0,2):[],periods:d.map((u,c)=>({label:`${c+1} карта`,raw:u})),extras:[]}}return null}function Ze(o,s){if(ze(o)!=="match")return null;let a=Y(o,".breadcrumbs .breadcrumbs__item").map(h=>R(h)).filter(Boolean),n=R(o.querySelector(".event-breadcrumbs")),p=Y(o,".marketbook-header--prematch .competitor-name").map(h=>R(h));if(p.length<2&&(p=Y(o,".marketbook-header--live .competitors-desc__name").map(h=>R(h))),p.length<2&&(p=Y(o,".match-card .match-card__team-name").map(h=>R(h))),p.length<2||!p[0]||!p[1])return null;let d=It(a[1]&&/киберспорт/i.test(a[0])?a[1]:"",a[0],n),u=/киберспорт/i.test(a[0]||"")?a.slice(2).join(", ")||n.split(",").slice(1).join(",").trim():a.slice(1).join(", "),c=[R(o.querySelector(".prematch-date")),R(o.querySelector(".prematch-time"))].filter(Boolean).join(" ")||R(o.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),f=Wn(o);return{book:"Winline",id:Xe(s?.pathname),key:Tt(p[0],p[1]),home:p[0],away:p[1],sport:d,league:u,start:f?"":c,live:f,form:{home:Ke(o.querySelector(".competitor-form--left")||o.createElement("div")),away:Ke(o.querySelector(".competitor-form--right")||o.createElement("div"))},stats:Qn(Jn(o),p[0],p[1]),url:s?.href||""}}function Kn(o,s){let a=[];for(let n of Y(o,".bet-line")){if($e(n))continue;let p=R(n.querySelector(".bet-line__market-name")),d=R(n.querySelector(".bet-line__period")),u=Y(n,".odd-btn"),c=u.map((h,y)=>{let b=R(h.querySelector(".odd-btn__label")),v=Y(h,"span").map(k=>yt(R(k))).find(Boolean)||null;return v?{el:h,odd:v,label:b||Se(u.length,y,p),locked:!1}:null});if(c.length<2||c.some(h=>!h))continue;let f=R(n.querySelector(".coef-btn")).replace(/\s+/g," ");a.push(Ot({scope:"top",title:p,period:d,line:f,outcomes:c,anchor:n,eventKey:s}))}return a}function Se(o,s,a){return/тотал/i.test(a)?["Меньше","Больше"][s]||"":o===3?["П1","Х","П2"][s]:o===2?["1","2"][s]:String(s+1)}function Zn(o,s){let a=[];for(let n of Y(o,".market")){let p=Y(n,".market__row");if(!p.length)continue;let d=R(n.querySelector(".market-title")),u=p.map(f=>{let h=R(f.querySelector(".market__row-text"));return Y(f,".market-row-btn").map(y=>{let b=yt(R(y.querySelector(".market-row-btn__coef")));if(!b||y.hasAttribute("disabled"))return null;let v=y.getAttribute("title")||R(y.querySelector(".market-row-btn__text"));return{el:y,odd:b,label:v.replace(/\s+/g," ").trim(),rowLabel:h,locked:!1}})}),{sets:c}=qe(u);for(let f of c){let h=[...new Set(f.map(k=>k.rowLabel).filter(Boolean))],y=h.length<=1,b=y?"":(f[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],v=f.map(k=>({el:k.el,odd:k.odd,label:y?k.label:k.rowLabel||k.label,locked:!1}));a.push(Ot({scope:"board",title:d,period:y&&h[0]||"",line:b,kind:Gt(d,v.length),outcomes:v,anchor:n,eventKey:s}))}}return a}var Hn=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function Xn(o){let s=Y(o,".card__competitors .name .name, .half__names .name").map(n=>R(n));if(s.length<2)return null;let a=o.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:Xe(a),key:Tt(s[0],s[1]),home:s[0],away:s[1],href:a,live:/card--live/.test(o.className)||!!o.querySelector(".card__body-live"),time:R(o.querySelector(".header-left__time, .footer__time")),league:R(o.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:o}}function He(o){let s=[];for(let a of Y(o,".card")){if($e(a))continue;let n=Xn(a);if(n){for(let p of Y(a,".card__body")){let d=R(p.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(p.className)?"отрезок":"");for(let u of Y(p,".card__market")){let c=Y(u,".coefficient-button");if(c.length<2)continue;let f=(Hn.find(([y])=>y.test(c[0].className))||[])[1]||"other",h=c.map((y,b)=>{let v=/--is-blank/.test(y.className)?null:Me(y);return v?{el:y,odd:v,label:f==="total"?["Меньше","Больше"][b]:Se(c.length,b,""),locked:/coefficient-button_locked/.test(y.className)}:null});h.some(y=>!y)||s.push(Ot({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[f]||"Рынок",period:/^матч$/i.test(d)?"":d,line:R(u.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:f,outcomes:h,event:n,anchor:a,eventKey:n.key}))}}for(let p of Y(a,".half__coef-buttons")){let d=Y(p,".coef-buttons__button"),u=d.map((c,f)=>{let h=Me(c.querySelector(".button__coef-title")||c);return h?{el:c,odd:h,label:Se(d.length,f,""),locked:!1}:null});u.length<2||u.some(c=>!c)||s.push(Ot({scope:"list",title:u.length===3?"Исход":"Победитель",kind:u.length===3?"1x2":"12",outcomes:u,event:n,anchor:a,eventKey:n.key}))}}}return s}function Yn(o){if(!o?.body)return null;let s=f=>/^\d{1,3}\s?%$/.test(f),a=Y(o,"h4").map(f=>{let h=[...f.nextElementSibling?.children||[]],y=R(h[0]),b=R(h[h.length-1]);return s(y)&&s(b)?{label:R(f),home:y.replace(/\s/g,""),away:b.replace(/\s/g,"")}:null}).filter(Boolean);if(!a.length)return null;let n=(o.body.innerText||o.body.textContent||"").replace(/\s+/g," "),p=[...n.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(f=>Number(f[1])),u=[...(n.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(f=>f[1].replace(/\s/g,""));return{names:R(o.querySelector("h3")).split(/\s+vs\s+/i).map(f=>f.trim()).filter(Boolean),rows:a,samples:p.slice(0,2),form:u.length>=2?{home:u[0],away:u[1]}:null}}function Qn(o,s,a){if(!o||o.names.length<2)return o;let n=Rt(o.names[0],s)+Rt(o.names[1],a);return Rt(o.names[0],a)+Rt(o.names[1],s)<=n?o:{names:[o.names[1],o.names[0]],rows:o.rows.map(d=>({label:d.label,home:d.away,away:d.home})),samples:o.samples.slice().reverse(),form:o.form?{home:o.form.away,away:o.form.home}:null}}function Jn(o){let s=o.querySelector("iframe.stats__iframe");if(!s)return null;try{return Yn(s.contentDocument)}catch{return null}}function to(o){let s=["one","two"].map(d=>o.querySelector(`.event-live-center__team-widget--${d}`));if(!s[0]||!s[1])return null;let a=d=>{let u=d;try{u=d.querySelector("iframe")?.contentDocument?.body||d}catch{u=d}let c=Y(u,'[class*="player"]').filter(h=>!Y(h,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(h.className)),f=[];for(let h of c){let y=R(h).split(" ").filter(Boolean),b=y.find(k=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test(k)&&/[A-Za-z]/.test(k));if(!b||f.some(k=>k.nick===b))continue;let v=y.filter(k=>/^\d{1,3}$/.test(k)).map(Number);f.push({nick:b,numbers:v.slice(0,4)})}return f.slice(0,5)},n=a(s[0]),p=a(s[1]);return n.length<3||p.length<3?null:{home:n,away:p}}var Ye={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:ze,readMatch:Ze,readEsportsWidget:to,observeTargets(o){try{let s=o.querySelector("iframe.stats__iframe")?.contentDocument?.body;return s?[s]:[]}catch{return[]}},collect(o,s){if(ze(o)==="match"){let p=Ze(o,s)?.key||"";return[...Kn(o,p),...Zn(o,p),...He(o)]}return He(o)}};var ee=(o,s)=>{try{return[...o.querySelectorAll(s)]}catch{return[]}};function Qe(o,s){let a=[o];if(s.shadow)for(let n of ee(o,s.shadow))n.shadowRoot&&a.push(n.shadowRoot);return a}var te=o=>(o.defaultView?.innerWidth||0)>0,eo='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function no(o){let s=[],a=o.ownerDocument.createTreeWalker(o,4);for(;a.nextNode();){let n=a.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(n&&s.push(...n.split(" ")),s.length>5)return null}return s}function oo(o,s){if(s.label){let a=o.querySelector(s.label),n=a?a.textContent.replace(/[ \s]+/g," ").trim():"";if(n&&!/^\d{1,3}[.,]\d{1,3}$/.test(n))return n}if(s.cell&&s.headerRow){let a=o.closest(s.cell),n=a?.parentElement,p=n?.parentElement?.querySelector(s.headerRow);if(p&&p!==n){let d=[...n.children].indexOf(a),u=p.children[d]?.textContent.replace(/[ \s]+/g," ").trim()||"";if(u)return u.charAt(0).toUpperCase()+u.slice(1).toLowerCase()}}return""}function so(o,s){if(!s.cell||!s.lineCell)return"";let a=o.closest(s.cell);for(;a&&(a=a.previousElementSibling);){if(!a.matches?.(s.lineCell))continue;let n=a.textContent.replace(/[ \s]+/g," ").trim().match(/([+\-−–]?\d+(?:[.,]\d+)?)\s*\)?\s*$/);return n?n[1].replace(",",".").replace(/[−–]/,"-"):""}return""}function ro(o,s){if(o.disabled||o.hasAttribute?.("disabled"))return null;let a=s.value&&o.querySelector(s.value)||o,n=no(a);if(!n||!n.length||n.join(" ").length>28)return null;let p=n[n.length-1];if(!(s.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(p))return null;let d=yt(p);if(!d||d>500||n.slice(0,-1).some(c=>/^\d{1,3}[.,]\d{1,3}$/.test(c)))return null;let u=n.slice(0,-1).join(" ");return!s.outcome&&/[+−]|^-/.test(u)?null:{odd:d,label:u}}function ao(o,s){let a=[],n=new Set,p=Qe(o,s).flatMap(d=>ee(d,s.outcome||eo));for(let d of p){if(n.has(d)||s.skip&&d.closest(s.skip)||d.closest("#lz-root, #lz-marks"))continue;let u=ro(d,s);if(u){if(!s.outcome&&te(o)){let c=d.getBoundingClientRect();if(c.width<26||c.width>320||c.height<16||c.height>90)continue}n.add(d),a.push({el:d,odd:u.odd,label:u.label||oo(d,s),line:so(d,s),locked:!1})}}return s.outcome?a:a.filter(d=>!a.some(u=>u.el!==d.el&&u.el.contains(d.el)))}function io(o,s,a){if(s.row)return o.closest(s.row);let n=o.parentElement;for(let p=0;p<6&&n&&n!==n.ownerDocument.body;p+=1){let d=a(n);if(d>=2&&d<=16){if(!te(n.ownerDocument))return n;let u=n.getBoundingClientRect();if(u.height<=130&&u.width>=120)return n}if(d>16)break;n=n.parentElement}return null}var Je=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось|окко|okko|матч тв|match tv|кинопоиск|трансляция|видео|статистика|stats)$/i;function lo(o,s){let a=s.length,n=o;for(let y=0;y<7;y+=1){let b=n.parentElement;if(!b||s.some(T=>!b.contains(T.el))||b.querySelectorAll("*").length>400||[...b.querySelectorAll('button, a, td, [role="button"]')].filter(T=>!s.some($=>$.el===T||$.el.contains(T)||T.contains($.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(R(T))).length>a)break;n=b}let p=s[0].el,d=[],u=n.ownerDocument.createTreeWalker(n,4);for(;u.nextNode();){let y=u.currentNode;if(p.contains(y))break;let b=y.textContent.replace(/[ \s]+/g," ").trim();b.length<2||b.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(b)||/\d{1,2}:\d{2}|^\d|['′]$/.test(b)||Je.test(b)||d.push(b)}let c=d.slice(-2),f=d.map(y=>y.split(/\s+[—–-]\s+/)).filter(y=>y.length===2).pop();if(f&&(c=f),c.length<2||c[0]===c[1])return null;let h=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:Tt(c[0],c[1]),home:c[0],away:c[1],href:h,live:!1,time:"",league:"",card:n}}function co(o,s,a){if(!s.names)return lo(o,a);let n=s.event&&o.closest(s.event)||o,p=[...new Set(ee(n,s.names).map(c=>R(c)).filter(Boolean))],d=p;if(p.length===1&&(d=p[0].split(/\s+[—–-]\s+/)),d.length<2||!d[0]||!d[1])return null;let u=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:Tt(d[0],d[1]),home:d[0],away:d[1],href:u,live:!1,time:"",league:"",card:n}}function uo(o){let a=String(o.title||"").replace(/^\s*(ставки на (матч|игру|бой)|матч)\s+/i,"").match(/^(.{2,40}?)\s+(?:[—–-]|x|vs|против)\s+(.{2,40}?)(?=\s*[:,|.(📅]|\s+[—–-]\s|\s+ставк|\s+прогноз|\s+коэффиц|\s+live\b|\s+лайв\b|\s+\d{1,2}(?:[./]\d|\s+[а-я]{3,})|$)/i);if(!a)return null;let n=[a[1].trim(),a[2].trim()];return n.some(p=>/ставк|контор|онлайн|букмекер|прогноз|коэффиц|!$/i.test(p))?null:n}function tn(o,s={}){function a(v,k){return s.matchUrl&&s.matchUrl.test(k?.pathname||"")||s.matchPage&&v.querySelector(s.matchPage)?"match":"list"}function n(v){let k=v.defaultView;if(!k||!te(v))return[];let T=[];for(let $ of v.querySelectorAll("h1, h2, h3, div, span, p, a")){if($.children.length)continue;let O=R($);if(O.length<3||O.length>40||!/[A-Za-zА-Яа-яЁё]{3}/.test(O)||/\d{1,2}[:.]\d{2}/.test(O)||Je.test(O))continue;let B=$.getBoundingClientRect();if(!(B.top<60||B.top>450||B.width<30||parseFloat(k.getComputedStyle($).fontSize)<15)&&(T.includes(O)||T.push(O),T.length===2))break}return T}function p(v,k){if(a(v,k)!=="match")return null;let T=s.matchNames?ee(v,s.matchNames).map(O=>R(O)).filter(Boolean):[];if(T.length===1&&(T=T[0].split(/\s+[—–-]\s+/)),T.length<2&&(T=uo(v)||[]),T.length<2&&(T=n(v)),T.length<2)return null;let $=s.matchLeague?R(v.querySelector(s.matchLeague)):"";return{book:o.name,id:(String(k?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:Tt(T[0],T[1]),home:T[0],away:T[1],sport:It(k?.pathname,$,v.title,R(v.querySelector('[class*="breadcrumb" i], nav[aria-label*="крошк" i]'))),league:$,start:"",live:/(^|\/)live(\/|$)/i.test(k?.pathname||"")?!0:null,form:{home:"",away:""},url:k?.href||""}}function d(v,k){return!v||!k?"":k.startsWith("attr:")?String(v.getAttribute(k.slice(5))||"").trim():R(v.querySelector(k))}function u(v,k){if(!te(k))return[v];let T=v.map(O=>{let B=O.el.getBoundingClientRect();return{cell:O,top:B.top,left:B.left}}).sort((O,B)=>Math.abs(O.top-B.top)>8?O.top-B.top:O.left-B.left),$=[];for(let O of T){let B=$[$.length-1];B&&Math.abs(B.top-O.top)<=8?B.cells.push(O.cell):$.push({top:O.top,cells:[O.cell]})}return $.map(O=>O.cells)}let c=[[/^(п1|1)\/(х|x|ничья)\/(п2|2)$/i,"1x2"],[/^(п1|1)\/(п2|2)$/i,"12"],[/^(1х|1x)\/12\/(х2|x2)$/i,"dc"]],f=v=>(c.find(([k])=>k.test(v.join("/").toLowerCase()))||[])[1]||"other";function h(v,k){let T=a(v,k),$=T==="match"&&s.match?{...s,...s.match}:s;return y(v,k,T,$)}function y(v,k,T,$){let O=ao(v,$);if(O.length<2)return[];let B=new Set(O.map(z=>z.el)),j=z=>{let N=0;for(let C of B)z.contains(C)&&(N+=1);return N},E=new Map;for(let z of O){let N=io(z.el,$,j);N&&(E.has(N)||E.set(N,[]),E.get(N).push(z))}let W=T==="match"?p(v,k):null,F=[];for(let[z,N]of E){let C=T==="match"?null:co(z,$,N),I=$.group?z.closest($.group):null,D=d(I,$.groupTitle),U=d(I,$.groupPeriod),V=$.visualRows?u(N,v):[N],tt=0;for(let Q of V)for(let ot of Re(Q).sets){let J=tt===0,st=ot.length,ht=st===3?["П1","Х","П2"]:["1","2"],St=ot.map((ut,dt)=>({...ut,label:ut.label||ht[dt]||String(dt+1)})),bt=J&&st===3?"Исход":J?"Победитель":`Рынок ${tt+1}`,mt=J?st===3?"1x2":"12":"other";D&&(bt=D,mt=Gt(D,st),mt==="other"&&(mt=f(St.map(ut=>ut.label)))),st===3&&St.every(ut=>/\sили\s/i.test(ut.label))&&(mt="dc"),F.push(Ot({scope:T==="match"?"board":"list",title:bt,period:U,line:ot[0].line&&ot.every(ut=>ut.line===ot[0].line)?ot[0].line:"",kind:mt,outcomes:St,event:C,anchor:z,eventKey:C?.key||W?.key||`row${F.length}`})),tt+=1}}return F}let b=v=>Qe(v,s).slice(1);return{id:o.id,name:o.name,hosts:o.hosts,generic:!0,pageType:a,readMatch:p,collect:h,observeTargets:b,readEsportsWidget:()=>null}}var en={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]',match:{group:'[class*="market-group-box--"]',groupTitle:'[class*="header--"] [class*="text--"]',label:'[class*="text--"]',cell:'[class*="cell--"]',headerRow:'[class*="header-row--"]',lineCell:'[class*="_align-left--"]'}},nn={fonbet:en,pari:en,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd, .dg_euv_stake",value:".dg_euv_stake_factor_new",row:".euv_event_home, .dg_euv_stake_grid",names:".euv_event_name_team",integers:!0,matchUrl:/\/sport\/event-details\//,matchNames:"h1"},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name",matchUrl:/\/su\/betting\/.*vs.*\d{5,}/i},leon:{matchUrl:/\/bets\/.+\/\d{10,}-/},olimp:{matchUrl:/\/line\/[^/]+\/[^/]+-\d{4,}\/[^/]+/,match:{outcome:'[data-testid^="bet-button"]',row:'[data-testid="accordion-content"]',group:'[data-testid="accordion"]',groupTitle:'[class*="title--"]',visualRows:!0}},betcity:{matchUrl:/\/ru\/(live|line)\/[^/]+\/\d+\/\d+/},betboom:{matchUrl:/\/sport\/(?:live\/)?[^/]+\/\d+\/\d+\/\d+/},liga:{matchUrl:/\/sports\/[^/]+\/.+-id-\d+/,match:{outcome:"button[outcomeid]",row:"[data-t-market]",group:"[data-t-market]",groupTitle:"attr:data-t-market",groupPeriod:'[class*="header__description"]',visualRows:!0}}};function on(o){let s=Ie(o);return s?s.id==="winline"?{adapter:Ye,book:s}:{adapter:tn(s,nn[s.id]||{}),book:s}:null}var ne=`/* Цвета, шрифт и радиусы панели — из design/tokens.json (node tools/tokens.mjs). Блоки между метками руками не править. */
:host {
  /* tokens:light */
  --lz-accent: #5b4be6;
  --lz-accent-strong: #4a3bd1;
  --lz-accent-soft: rgba(91, 75, 230, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0b8a4d;
  --lz-pos-soft: rgba(11, 138, 77, 0.14);
  --lz-neg: #c93636;
  --lz-neg-soft: rgba(201, 54, 54, 0.12);
  --lz-warn: #b45309;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6fa;
  --lz-surface-2: #eef0f5;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #555c6b;
  --lz-faint: #666b7f;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  /* /tokens */
  color-scheme: light;
}

:host([data-theme="dark"]) {
  /* tokens:dark */
  --lz-accent: #8f82ff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(143, 130, 255, 0.18);
  --lz-accent-ink: #0f1017;
  --lz-pos: #45d08f;
  --lz-pos-soft: rgba(69, 208, 143, 0.16);
  --lz-neg: #ff7676;
  --lz-neg-soft: rgba(255, 118, 118, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #171a23;
  --lz-surface: #1f2330;
  --lz-surface-2: #272b34;
  --lz-border: #2c3040;
  --lz-text: #eef0f6;
  --lz-muted: #a4a8bb;
  --lz-faint: #8e92a8;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  /* /tokens */
  color-scheme: dark;
}
`;var sn=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}

.tip-foot .pos {
  color: var(--lz-pos);
  font-weight: 600;
}
`;function t(o,s,...a){let[n,...p]=o.split("."),d=document.createElement(n||"div");p.length&&(d.className=p.join(" "));for(let[u,c]of Object.entries(s||{}))if(!(c==null||c===!1))if(u==="class")d.className=[d.className,c].filter(Boolean).join(" ");else if(u==="style")d.style.cssText=c;else if(u==="text")d.textContent=c;else{if(u==="html")throw new Error("html запрещён");u.startsWith("data-")||u.startsWith("aria-")||u==="role"||u==="title"||u==="type"||u==="href"||u==="target"||u==="rel"||u==="placeholder"||u==="value"||u==="for"||u==="name"||u==="maxlength"||u==="autocomplete"||u==="spellcheck"||u==="tabindex"?d.setAttribute(u,c===!0?"":String(c)):u==="disabled"||u==="hidden"||u==="checked"||u==="selected"?d[u]=!!c:d[u]=c}return an(d,a),d}function an(o,s){for(let a of s)a==null||a===!1||(Array.isArray(a)?an(o,a):o.appendChild(a instanceof Node?a:document.createTextNode(String(a))))}var rn="http://www.w3.org/2000/svg";function it(o,s=16){let a=document.createElementNS(rn,"svg");a.setAttribute("viewBox","0 0 20 20"),a.setAttribute("width",s),a.setAttribute("height",s),a.setAttribute("fill","none"),a.setAttribute("stroke","currentColor"),a.setAttribute("stroke-width","1.7"),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),a.setAttribute("aria-hidden","true");for(let n of fo[o]||[]){let p=document.createElementNS(rn,"path");p.setAttribute("d",n),a.appendChild(p)}return a}var fo={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"]};function ln(){let o=document.createElement("div");o.id="lz-marks",o.style.cssText="position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;overflow:hidden!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let s=o.attachShadow({mode:"open"});s.appendChild(t("style",{text:ne+sn}));let a=t("div.layer"),n=t("div.tip");s.append(a,n);let p=new Map,d=new Set,u=0,c=null,f=null,h=new IntersectionObserver(z=>{for(let N of z)N.isIntersecting?d.add(N.target):(d.delete(N.target),p.get(N.target)?.node.classList.remove("on"));b()},{rootMargin:"120px"});function y(){o.isConnected||document.documentElement.appendChild(o)}function b(){u||(u=requestAnimationFrame(()=>{u=0,T()}))}let v=(z,N)=>{for(let C=N;C;C=C.parentNode||C.host)if(C===z)return!0;return!1};function k(z,N){let C=N.left+N.width/2,I=N.top+N.height/2;if(C<0||I<0||C>window.innerWidth||I>window.innerHeight)return!1;let D=document.elementFromPoint(C,I);for(;D?.shadowRoot?.elementFromPoint;){let U=D.shadowRoot.elementFromPoint(C,I);if(!U||U===D)break;D=U}return!!D&&D!==z&&!v(z,D)&&!v(D,z)}function T(){for(let z of d){let N=p.get(z);if(!N)continue;if(!z.isConnected){$(z);continue}let C=z.getBoundingClientRect();if(C.width<6||C.height<6||k(z,C)){N.node.classList.remove("on");continue}let I=Math.round(C.left),D=Math.round(C.top),U=Math.round(C.width),V=Math.round(C.height);(N.x!==I||N.y!==D)&&(N.node.style.transform=`translate3d(${I}px, ${D}px, 0)`,N.x=I,N.y=D),(N.w!==U||N.h!==V)&&(N.node.style.width=`${U}px`,N.node.style.height=`${V}px`,N.w=U,N.h=V,N.node.classList.toggle("small",V<26)),N.node.classList.add("on")}c&&B()}function $(z){let N=p.get(z);N&&(h.unobserve(z),d.delete(z),N.node.remove(),p.delete(z))}function O(z){y();let N=new Map;for(let C of z)C.el?.isConnected&&N.set(C.el,C);for(let C of[...p.keys()])N.has(C)||$(C);for(let[C,I]of N){let D=p.get(C);if(!D){let V=t("div.mark"),tt=parseFloat(getComputedStyle(C).borderTopLeftRadius);V.style.borderRadius=`${Number.isFinite(tt)&&tt>0?Math.min(tt,16):6}px`;let Q=t("span.chip");V.appendChild(Q),a.appendChild(V),D={node:V,chip:Q,sig:""},p.set(C,D),h.observe(C)}let U=`${I.frame?1:0}|${I.selected?1:0}|${I.tone||""}|${I.chip||""}`;U!==D.sig&&(D.sig=U,D.node.classList.toggle("frame",!!I.frame),D.node.classList.toggle("selected",!!I.selected),D.node.classList.toggle("pos",I.tone==="pos"&&!!I.frame),D.chip.hidden=!I.chip,D.chip.textContent=I.chip||"",D.chip.className=`chip${I.tone&&I.tone!=="accent"?" "+I.tone:""}`)}b()}function B(){if(!c?.isConnected)return E();let z=c.getBoundingClientRect(),N=264,C=n.offsetHeight||140,I=z.left+z.width/2-N/2;I=Math.max(8,Math.min(I,window.innerWidth-N-8)),f&&I+N>f.left-8&&I<f.right&&(I=Math.max(8,f.left-N-10));let D=z.bottom+10;D+C>window.innerHeight-8&&(D=z.top-C-10),D<8&&(D=8),n.style.transform=`translate3d(${Math.round(I)}px, ${Math.round(D)}px, 0)`}function j(z,N){y(),c=z,n.replaceChildren(N),B(),n.classList.add("on")}function E(){c=null,n.classList.remove("on")}function W(z){f=z}function F(z){o.setAttribute("data-theme",z)}return window.addEventListener("scroll",b,{capture:!0,passive:!0}),window.addEventListener("resize",b,{passive:!0}),setInterval(()=>{p.size&&!document.hidden&&b()},700),{set:O,schedule:b,showTip:j,hideTip:E,setTheme:F,setAvoid:W,get tipTarget(){return c},count:()=>p.size}}var cn=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 72px minmax(60px, max-content);
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  white-space: nowrap;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.partner { margin-top: 8px; }
.partner-text { font-size: 12px; margin-bottom: 4px; }
.partner-links { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
.partner-links a.btn { text-decoration: none; }
.gain { margin-top: 8px; font-size: 12px; color: var(--lz-text); }
.gain b { color: var(--lz-pos); }
td.name .partner-links { margin-top: 3px; }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.card.update { font-size: 12.5px; }
.card.update b { color: var(--lz-accent); }
/* Строка без номера (факторы модели, факты о составах) занимает обе колонки, иначе текст ломается по словам в узкой. */
.facts li > span:only-child { grid-column: 1 / -1; }
.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  /* 18+ и предупреждение о зависимости должны читаться: не бледный, а обычный второстепенный цвет. */
  color: var(--lz-muted);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;var ae=o=>Math.min(.999,Math.max(.001,o));function _e(o,s,a=0,n=0){let p=Math.ceil(s/2),d=new Map,u=(c,f)=>{if(c>=p)return 1;if(f>=p)return 0;let h=c*16+f;return d.has(h)||d.set(h,o*u(c+1,f)+(1-o)*u(c,f+1)),d.get(h)};return u(a,n)}function ie(o,s){let a=.001,n=.999;for(let p=0;p<50;p++){let d=(a+n)/2;o(d)<s?a=d:n=d}return(a+n)/2}function go(o,s){let a=ae(o);return Math.ceil(s/2)<=1?a:ie(n=>_e(n,s),a)}function se(o,s,a,n=new Map){if(s>=4)return[1,0];if(a>=4)return[0,0];if(s===3&&a===3)return[0,1];let p=s*8+a;if(!n.has(p)){let[d,u]=se(o,s+1,a,n),[c,f]=se(o,s,a+1,n);n.set(p,[o*d+(1-o)*c,o*u+(1-o)*f])}return n.get(p)}function un(o){let[s,a]=se(o,0,0);return s/(1-a)}function oe(o,s,a){if(s=Math.max(0,Math.floor(s)),a=Math.max(0,Math.floor(a)),Math.min(s,a)>=12){let d=Math.floor((Math.min(s,a)-12)/3),u=s-12-3*d,c=a-12-3*d,[f,h]=se(o,u,c);return f+h*un(o)}let n=new Map,p=(d,u)=>{if(d>=13)return 1;if(u>=13)return 0;if(d===12&&u===12)return un(o);let c=d*32+u;return n.has(c)||n.set(c,o*p(d+1,u)+(1-o)*p(d,u+1)),n.get(c)};return p(s,a)}function bo(o){return ie(s=>oe(s,0,0),ae(o))}var xo=24,re=Array.from({length:101},(o,s)=>(s+.5)/101),dn=null;function pn(o,s){let a=re.map(u=>(o-1)*Math.log(u)+(s-1)*Math.log(1-u)),n=Math.max(...a),p=a.map(u=>Math.exp(u-n)),d=p.reduce((u,c)=>u+c,0);return p.map(u=>u/d)}function mn(o,s,a=0,n=0){if(!Number.isFinite(s))return oe(o,a,n);let p=pn(o*s+a,(1-o)*s+n);return!a&&!n?(dn||=re.map(d=>oe(d,0,0)),p.reduce((d,u,c)=>d+u*dn[c],0)):p.reduce((d,u,c)=>d+u*oe(re[c],a,n),0)}function vo(o,s){return Number.isFinite(s)?ie(a=>mn(a,s),ae(o)):bo(o)}var yo={cs:8,dota:1/0};function fn(o,s,a,n=0,p=0){return Number.isFinite(s)?pn(o*s+n,(1-o)*s+p).reduce((u,c,f)=>u+c*_e(re[f],a,n,p),0):_e(o,a,n,p)}function ko(o,s,a){return Number.isFinite(a)?ie(n=>fn(n,a,s),ae(o)):go(o,s)}function wo(o,s){let a=Math.max(o,s),n=Math.min(o,s);return n<12?a>=13:a-12-3*Math.floor((n-12)/3)>=4}function hn({pre:o,bo:s=3,maps:a=[0,0],rounds:n=null,game:p="cs",kappa:d=xo,kappaMap:u=yo[p]??1/0}){let c=Math.ceil(s/2),[f,h]=(a||[0,0]).map(O=>Math.max(0,Number(O)||0));if(f>=c)return{p:1,map:null};if(h>=c)return{p:0,map:null};let y=ko(o,s,u),b=(O,B)=>fn(y,u,s,O,B),[v,k]=Array.isArray(n)&&n.length===2?n.map(Number):[NaN,NaN];if(!Number.isFinite(v)||!Number.isFinite(k)||v===0&&k===0||wo(v,k))return{p:b(f,h),map:null};let T=Number.isFinite(u)?(y*u+f)/(u+f+h):y,$=mn(vo(T,d),d,v,k);return{p:$*b(f+1,h)+(1-$)*b(f,h+1),map:$}}var K=(o,s=0)=>wt(o,s),ft=o=>`${o>0?"+":o<0?"−":""}${Math.abs(o).toFixed(1)}`;function gn({bus:o,actions:s,brand:a}){let n=document.createElement("div");n.id=o.rootId,n.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let p=n.attachShadow({mode:"open"});p.appendChild(t("style",{text:ne+cn}));let d=t("span.dot"),u=t("button.fab",{type:"button","data-act":"toggle",title:`${a.name}: открыть панель`,"aria-label":`${a.name}: открыть панель`},it("lens",18),t("span",{text:a.name}),d),c=t("div.tabs",{role:"tablist"}),f=t("div.body"),h=t("div.foot"),y=t("small"),b=t("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),v=t("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),k=t("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},it("gear")),T=t("div.head",{},t("div.brand",{},t("span.logo",{},it("lens",15)),t("span",{text:a.name}),y),t("span.grow"),v,b,k,t("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},it("close"))),$=t("section.panel",{hidden:!0,role:"dialog","aria-label":a.name},T,c,f,h);p.append(u,$);let O=()=>{n.isConnected||document.documentElement.appendChild(n)};O(),new MutationObserver(O).observe(document.documentElement,{childList:!0});let B="",j=null,E=new Map,W=e=>{for(let r of e.composedPath()){if(r===n)break;if(r?.dataset?.act)return r}return null},F=null;o.on("ui:pointerdown",e=>{if(e.button!==0)return;let r=e.composedPath(),l=r.includes(u),g=r.includes(T)&&!r.some(S=>S?.dataset?.act);if(!l&&!g)return;let x=l?u:$,w=x.getBoundingClientRect();F={target:x,key:l?"fab":"panel",sx:e.clientX,sy:e.clientY,ox:w.left,oy:w.top,moved:!1},o.setDragging(!0)}),o.on("drag:move",e=>{if(!F)return;let r=e.clientX-F.sx,l=e.clientY-F.sy;!F.moved&&Math.hypot(r,l)<5||(F.moved=!0,F.target.classList.add("dragging"),N(F.target,F.ox+r,F.oy+l))}),o.on("drag:end",()=>{if(F){if(o.setDragging(!1),F.target.classList.remove("dragging"),F.moved){let e=F.target.getBoundingClientRect();s.savePosition(F.key,{left:e.left,top:e.top}),z=!0,setTimeout(()=>{z=!1},60)}F=null}});let z=!1;function N(e,r,l){let g=e.offsetWidth||120,x=e.offsetHeight||40,w=Math.max(6,Math.min(r,window.innerWidth-g-6)),S=Math.max(6,Math.min(l,window.innerHeight-Math.min(x,60)-6));e.style.left=`${Math.round(w)}px`,e.style.top=`${Math.round(S)}px`,e.style.right="auto"}o.on("ui:click",e=>{if(z)return;let r=W(e);if(!r||r.disabled)return;e.preventDefault();let l=r.dataset.act;if(l==="toggle")return Ft();if(l==="close")return Nt();let g=s[l];g&&g(r.dataset.arg,r,p)}),o.on("ui:keydown",e=>{if(e.key==="Escape"&&Nt(),e.key==="Enter"){let r=e.composedPath()[0];r?.dataset?.enter&&s[r.dataset.enter]?.(r.value,r,p)}});let C=(e,r)=>t("span.form",{},[...String(e||"")].slice(0,5).map(l=>t(`i${l==="В"?".w":l==="П"?".l":""}`,{text:l,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[l]||""})),r);function I(e){let r=e.live,l=r?t("div.center",{},r.score?.length===2?t("span.score",{text:`${r.score[0]} : ${r.score[1]}`}):null,t("span.badge.live",{text:r.state||"Лайв"})):t("div.center",{},t("span",{text:e.start||"до матча"})),g=r?.periods?.length?t("div.periods",{text:r.periods.map(w=>w.raw?`${w.label} ${w.raw}`:`${/^\d+$/.test(w.label)?`${w.label}-й отрезок`:w.label} ${w.home}:${w.away}`).join(" · ")}):null,x=r?.extras?.length?t("div.periods",{text:r.extras.map(w=>`${w.kind} ${w.home}:${w.away}`).join(" · ")}):null;return t("div.card",{},t("div.league",{text:e.league||e.sportName||"",title:e.league||""}),t("div.teams",{},t("div.team",{},t("b",{text:e.home,title:e.home}),e.form?.home?C(e.form.home):null),l,t("div.team.away",{},t("b",{text:e.away,title:e.away}),e.form?.away?C(e.form.away):null)),g,x)}function D(e){let r=e.rows.some(l=>Number.isFinite(l.model));return t("div.card",{},t("div.kicker",{},t("span",{text:e.title}),Number.isFinite(e.margin)?t("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${K(e.margin,1)}`}):null),e.rows.map(l=>{let g=r&&Number.isFinite(l.model)?(l.model-l.fair)*100:null;return t("div.prob",{},t("span.name",{text:l.name,title:l.name}),t("span.odd",{text:H(l.odd)}),t("span.track",{},t("i",{style:`width:${Math.round((l.fair||0)*100)}%`}),Number.isFinite(l.model)?t("u",{style:`left:${Math.round(l.model*100)}%`}):null),t("span.pct",{},K(r&&Number.isFinite(l.model)?l.model:l.fair),g!=null&&Math.abs(g)>=.05?t(`small${g>0?".pos":".neg"}`,{text:`${ft(g)} п.п.`}):null))}),t("div.legend",{},t("span",{text:"шанс по линии без маржи"}),r?t("span.model",{text:"оценка модели"}):null))}function U(e){let r=e.analysis;if(r.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge.accent",{text:"собираю данные"})),t("div.steps",{},r.steps.map((S,M)=>t(`div.step${M===r.steps.length-1?".now":".done"}`,{},t("span.mark"),t("span",{text:S})))));if(r.status==="error")return t("div.card",{},t("div.note.warn",{},it("alert"),t("span",{text:r.error})),t("div.row",{style:"margin-top:10px"},r.needKey?t("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},it("gear"),"Открыть настройки"):null,t("button.btn.ghost",{type:"button","data-act":"report"},"Сообщить об ошибке")));if(r.status!=="done"||!r.result)return null;let l=r.result,g={home:e.match?.home,away:e.match?.away,draw:"ничья"}[l.lean],x=l.proposed?.lean&&l.proposed.lean!=="none"&&l.lean==="none"?{name:{home:e.match?.home,away:e.match?.away,draw:"ничью"}[l.proposed.lean],by:Math.abs(l.proposed.shift[l.proposed.lean]||0)}:null,w=new Map((l.facts||[]).map(S=>[S.id,S]));return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${l.confidence||"низкая"}`})),t("div.verdict",{text:g?`Данные сдвигают оценку в сторону: ${g}`:x?`Данные слегка склоняют в сторону: ${x.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),x?t("div.note",{style:"margin-bottom:10px"},it("info"),t("span",{text:`Модель предложила сдвиг на ${x.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,l.summary?t("p.summary",{text:l.summary}):null,l.factors?.length?t("ul.factors",{},l.factors.map(S=>t(`li.factor${S.side==="home"?".home":S.side==="away"?".away":""}`,{},t("div",{},t("p",{text:S.text}),t("div.src",{},(S.facts||[]).map(M=>w.get(M)).filter(Boolean).map(M=>t("span.tag",{text:`${M.id} · ${M.source}`,title:M.text}))))))):null,l.scenarios?.length?t("div",{style:"margin-top:10px"},t("div.kicker",{},t("span",{text:"Как может пойти игра"})),t("ul.facts",{},l.scenarios.map(S=>t("li",{},t("span",{text:S.text})," ",t("em",{text:`— ${S.facts.join(", ")}`}))))):null,l.risks?.length?t("div.note",{style:"margin-top:10px"},it("info"),t("span",{text:`Что может сломать вывод: ${l.risks.join(" ")}`})):null,(l.full?.sections||[]).some(S=>S?.lines?.length)?t("details",{"data-key":"full",open:E.get("full")||!1,style:"margin-top:8px"},t("summary",{text:"Показать полностью: итог по всем рынкам, профили, факты"}),(l.full.sections||[]).filter(S=>S?.title&&S.lines?.length).map(S=>t("div",{style:"margin-top:6px"},t("div.kicker",{},t("span",{text:S.title})),t("ul.facts",{},S.lines.map(M=>t("li",{text:M})))))):null,t("div.row",{style:"margin-top:8px"},t("button.btn.ghost.small",{type:"button","data-act":"report",title:"Разбор выглядит неправильно — сообщить разработчику"},"Сообщить об ошибке")),t("details",{"data-key":"facts",open:E.get("facts")||!1},t("summary",{text:`Данные, на которых стоит разбор (${l.facts?.length||0})`}),t("ul.facts",{},(l.facts||[]).map(S=>t("li",{},t("b",{text:S.id}),t("span",{},S.text," ",t("em",{text:`— ${S.source}`})))))),V(l.research),t("div.hint",{style:"margin-top:8px",text:l.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function V(e){return e?e.skipped==="plan"?t("div.hint",{style:"margin-top:8px",text:"Поиск превью, травм и судей в прессе — в тарифах «Макс» и VIP."}):e.sources?.length?t("div.hint",{style:"margin-top:8px"},`${e.note} Прочитано: `,e.sources.map((r,l)=>[l?", ":"",t("a",{href:r.url,target:"_blank",rel:"noopener",text:r.domain})])):e.note?t("div.hint",{style:"margin-top:8px",text:e.note}):null:null}function tt(e){let r=e.compare?.consensus||e.analysis?.result?.consensus||e.consensus;if(!r?.consensus||!e.line?.rows?.length)return null;let l=r.consensus.length===2&&e.line.rows.length===3;if(!l&&e.line.rows.length!==r.consensus.length)return null;let g=l?e.line.overtime:null,x=g?g.rows:l?[e.line.rows[0],e.line.rows[2]].map(M=>({...M,odd:null,fair:null})):e.line.rows,w=e.match?.sport==="mma",S=r.updated?new Date(r.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"";return t("div.card",{},t("div.kicker",{},t("span",{text:l?w?"Прогноз рынка · без ничьей":"Прогноз рынка · с овертаймом":"Прогноз рынка"}),t("span.badge",{text:`${r.count} контор`})),x.map((M,_)=>{let A=r.consensus[_],P=M.odd?M.odd*A-1:0,L=Number.isFinite(M.fair)?(M.fair-A)*100:0;return t("div.prob",{},t("span.name",{text:M.name,title:M.name}),t("span.odd",{text:H(1/A),title:"Кэф без маржи по консенсусу"}),t("span.track",{},t("i",{style:`width:${Math.round(A*100)}%`}),t("u",{style:`left:${Math.round((M.fair||0)*100)}%`,title:"Шанс по линии этой конторы"})),t("span.pct",{},K(A),P>.005?t("small.pos",{text:`кэф выше рынка ${ft(P*100)}%`}):Math.abs(L)>=2?t(`small${L>0?".neg":""}`,{text:`${ft(L)} п.п. к рынку`,title:L>0?"Контора оценивает этот исход выше рынка — кэф ниже":"Контора оценивает этот исход ниже рынка"}):null))}),t("div.legend",{},t("span",{text:"шанс по консенсусу"}),l&&!g?null:t("span.model",{text:g?`шанс по рынку «${g.title}» этой конторы`:"шанс по линии этой конторы"})),t("div.hint",{style:"margin-top:8px",text:`${l&&w?"Ничьи в ММА — доли процента, поэтому рынок двухисходный; ничья этой конторы не сравнивается. ":l?g?"Победитель с учётом овертайма и буллитов: сравнивается с одноимённым рынком этой конторы, а не с трёхисходным. ":"Победитель с учётом овертайма и буллитов; ничья в основное время сюда не входит, поэтому с трёхисходным рынком конторы напрямую не сравнивается. ":""}${r.pinnacle?`Pinnacle ${r.pinnacle.map(H).join(" / ")}. `:""}${r.betfair?`Betfair ${r.betfair.map(H).join(" / ")}. `:""}Цены ${r.count} контор без маржи${S?`, обновлено в ${S}`:""}${r.stale?" (данные старше шести часов)":""}. На проверке 1915 матчей фаворит по консенсусу выиграл 54% — точнее этого прогноза у нас нет.`}))}let Q=new Map;function ot(e,r){let l=e.match?.live;if(!l||!["cs","dota"].includes(r.game)||l.score?.length!==2)return null;let g=l.score.map(Number),x=Number(r.bo)||3;if(g.some(M=>!Number.isFinite(M)||M<0)||Math.max(...g)>=Math.ceil(x/2))return null;let w=r.game==="cs"&&l.rounds?.length===2&&l.rounds.every(M=>/^[0-9]{1,2}$/.test(String(M)))?l.rounds.map(Number):null,S=`${r.p1}|${x}|${g}|${w}`;return Q.has(S)||(Q.size>50&&Q.clear(),Q.set(S,{...hn({pre:r.p1,bo:x,maps:g,rounds:w,game:r.game}),bo:x,maps:g,rounds:w})),Q.get(S)}function J(e){let r=e.compare?.model||e.analysis?.result?.model||e.model;if(!r?.p1||!e.line?.rows?.length)return null;let l=e.line.rows.length===3&&(r.overtime||r.drawless);if(!l&&e.line.rows.length!==2)return null;let g=l?e.line.overtime:null,x=g?g.rows:l?[e.line.rows[0],e.line.rows[2]].map(G=>({...G,fair:null})):e.line.rows,w=ot(e,r),S=w?[w.p,1-w.p]:[r.p1,r.p2],M=r.sport==="tennis"?`Рейтинги Линзы по покрытиям, форме, нагрузке и очным встречам (архив ATP/WTA, ${r.samples} матчей у менее опытного игрока)`:r.sport==="hockey"?`Рейтинги Линзы по матчам КХЛ: атака и оборона команд, дом, усталость (приложение КХЛ, 2023–2026; ${r.samples} игр у менее опытной команды)${r.regulation?`. Основное время: ${Math.round(r.regulation.p1*100)}% / ничья ${Math.round(r.regulation.px*100)}% / ${Math.round(r.regulation.p2*100)}%`:""}`:r.sport==="mma"?`Рейтинги Линзы по боям UFC: Elo с весом досрочных побед, форма, возраст, размах рук, простой (ESPN; ${r.samples} боёв в UFC у менее опытного бойца)`:r.sport==="basketball"?`Рейтинги Линзы по разнице очков, дому и усталости (НБА, Евролига, Еврокубок, АСВ, Серия А, Адриатическая лига, ВТБ, Лига чемпионов FIBA; ${r.samples} игр у менее опытной команды)`:r.game==="dota"?`Рейтинги Линзы по матчам, форме и очным встречам (bo3.gg, ${r.samples} ${vt(r.samples,"матч","матча","матчей")} у менее опытной команды)`:`Рейтинги Линзы по картам, форме и очным встречам (bo3.gg, ${r.samples} ${vt(r.samples,"карта","карты","карт")} у менее опытной команды)`,_=r.backtest,A=(_?.calibration||[]).filter(G=>[60,70,80].includes(G.threshold)),P=_?.labels?.[r.confidence],L=(P?`С подписью «${r.confidence}» на проверке сбывалось ${K(P.hit/100,1)} (${P.n} ${vt(P.n,"матч","матча","матчей")}). `:"")+(A.length?`На проверке ${_.test} сыгранных матчей: ${A.map(G=>`при уверенности ≥${G.threshold}% сбывалось ${G.hit}%`).join(", ")}`:_?`На проверке ${_.test} матчей угадано ${Math.round(_.acc*100)}%`:"Точность ещё измеряется");return t("div.card",{},t("div.kicker",{},t("span",{text:w?`Модель по счёту · bo${w.bo}`:l?r.drawless?"Прогноз модели · без ничьей":"Прогноз модели · с овертаймом":"Прогноз модели"}),t("span.badge",{text:w?`до матча: ${r.confidence}`:`уверенность: ${r.confidence}`})),x.map((G,Z)=>{let X=S[Z],at=Number.isFinite(G.fair)?(X-G.fair)*100:0;return t("div.prob",{},t("span.name",{text:G.name,title:G.name}),t("span.odd",{text:H(1/X),title:"Кэф без маржи по модели"}),t("span.track",{},t("i",{style:`width:${Math.round(X*100)}%`}),t("u",{style:`left:${Math.round((G.fair||0)*100)}%`,title:"Шанс по линии конторы"})),t("span.pct",{},K(X),Math.abs(at)>=3?t(`small${at>0?".pos":".neg"}`,{text:`${ft(at)} п.п. к линии`}):null))}),t("div.legend",{},t("span",{text:w?"шанс серии по счёту":"оценка модели"}),t("span.model",{text:"шанс по линии конторы"})),w?t("div.hint",{style:"margin-top:6px",text:`Счёт по картам ${w.maps.join(":")}${w.rounds?`, на карте ${w.rounds.join(":")} — шанс текущей карты ${K(w.map??.5)}`:""}. До матча модель давала ${K(r.p1)} / ${K(r.p2)}.`}):null,ut(r,x),r.factors?.length?t("ul.facts",{style:"margin-top:8px"},r.factors.slice(0,r.sport==="mma"?12:4).map(G=>t("li",{},t("span",{text:G})))):null,t("div.hint",{style:"margin-top:8px",text:w?`Шанс по ходу матча пересчитывается из прогноза до матча и счёта: выигранные карты${r.game==="cs"?" и раунды":""} уточняют силу команд. ${r.game==="cs"?"Проверка на сыгранных сериях CS: при 1:0 в bo3 модель давала в среднем 82%, сбылось 83% (2 905 серий)":"Проверка на сыгранных сериях Dota: при 1:1 модель давала в среднем 53%, сбылось 55% (516 серий)"}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`:`${M}. ${L}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`}))}function st(e){let[r,l]=e.names,g=["0","15","30","40","Б"],x=e.tiebreak?e.points.join(":"):e.points.map(M=>g[Math.min(4,M)]||M).join(":"),w=e.sets.map(([M,_])=>`${M}:${_}`).concat(`${e.games[0]}:${e.games[1]}`).join(" "),S=e.serving==null?"":` · подаёт ${e.names[e.serving]}`;return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"}),t("span.badge",{text:`${e.score.join(":")} по сетам · ${w} · ${x}${e.tiebreak?" (тай-брейк)":""}`})),e.names.map((M,_)=>{let A=e.probs[_],P=e.book?e.book[_]:null,L=e.compare&&Number.isFinite(P)?(A-P)*100:0;return t("div.prob",{},t("span.name",{text:M,title:M}),t("span.odd",{text:H(1/A),title:"Честный кэф на матч по счёту"}),t("span.track",{},t("i",{style:`width:${Math.round(A*100)}%`}),Number.isFinite(P)?t("u",{style:`left:${Math.round(P*100)}%`,title:"Шанс по цене этой конторы"}):null),t("span.pct",{},K(A),Math.abs(L)>=3?t(`small${L>0?".pos":".neg"}`,{text:`${ft(L)} п.п. к цене`}):null))}),t("div.legend",{},t("span",{text:"шанс матча по счёту"}),e.book?t("span.model",{text:"шанс по цене этой конторы"}):null),t("ul.facts",{style:"margin-top:8px"},t("li",{},t("span",{text:`Текущий сет: ${r} ${K(e.set[0])} (кэф ${H(1/e.set[0])}) · ${l} ${K(e.set[1])} (${H(1/e.set[1])})`})),t("li",{},t("span",{text:`Текущий ${e.tiebreak?"тай-брейк":"гейм"}${S}: ${r} ${K(e.game[0])} · ${l} ${K(e.game[1])}`})),t("li",{},t("span",{text:`Очко на своей подаче (под довоенную силу): ${r} ${e.serve[0]}%, ${l} ${e.serve[1]}%; матч до ${e.bestOf===5?"трёх":"двух"} выигранных сетов.`}))),t("div.hint",{style:"margin-top:8px",text:`Счёт, очки и подача — лайв Fonbet. Довоенная сила: ${e.prior.note}.${e.compare?"":" Без довоенной цены оценка подстроена под текущую цену Fonbet — как сигнал против конторы её не используйте."} Проверено на 10 064 моментах матчей ATP/WTA 2025–2026 (после каждого сета): при оценке 80–85% сбылось 82,9%, 85–90% — 87,8%. Это расчёт, а не обещание.`}))}function ht(e){let[r,l]=e.names,g=P=>P?H(P):"—",x=e.sport==="hockey"?"период":"тайм",w=`${e.minute}' · ${Math.min(e.period,e.periods)}-й ${x}`,S=[r,"Ничья",l],M=P=>P>0?`+${P}`:`${P}`,_=(P,L,G,Z,X,at)=>L?.length?t("details",{"data-key":`live-${P}`,open:E.get(`live-${P}`)||!1},t("summary",{text:P}),t("ul.facts",{},L.map(rt=>t("li",{},t("span",{text:`${X(rt)} — ${g(rt[G])} · ${at(rt)} — ${g(rt[Z])}`}))))):null,A=e.red[0]||e.red[1]?` · удаления ${e.red.join(":")}`:"";return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"}),t("span.badge",{text:`${e.score.join(":")} · ${w}${A}`})),S.map((P,L)=>{let G=e.probs[L],Z=e.book?e.book[L]:null,X=e.compare&&Number.isFinite(Z)?(G-Z)*100:0;return t("div.prob",{},t("span.name",{text:P,title:P}),t("span.odd",{text:H(1/G),title:"Честный кэф по счёту"}),t("span.track",{},t("i",{style:`width:${Math.round(G*100)}%`}),Number.isFinite(Z)?t("u",{style:`left:${Math.round(Z*100)}%`,title:"Шанс по цене этой конторы"}):null),t("span.pct",{},K(G),Math.abs(X)>=3?t(`small${X>0?".pos":".neg"}`,{text:`${ft(X)} п.п. к цене`}):null))}),t("div.legend",{},t("span",{text:"шанс по счёту (основное время)"}),e.book?t("span.model",{text:"шанс по цене этой конторы"}):null),t("ul.facts",{style:"margin-top:8px"},t("li",{},t("span",{text:`Следующий гол: ${r} ${K(e.nextGoal[0])} · не будет ${K(e.nextGoal[1])} · ${l} ${K(e.nextGoal[2])}. Ожидаемый итоговый тотал ≈${e.expTotal}.`})),e.bookLines?.total?t("li",{},t("span",{text:`Тотал ${e.bookLines.total.line}: Fonbet ${e.bookLines.total.odds.map(H).join(" / ")}, честно ${e.bookLines.total.fair.map(g).join(" / ")}`}),Math.abs(e.bookLines.total.gap)>=5?t(`small${e.bookLines.total.gap>0?".pos":".neg"}`,{text:` ${ft(e.bookLines.total.gap)} п.п. к «больше»`}):null):null),_("Тотал — честные кэфы",e.total,"over","under",P=>`больше ${P.line}`,P=>`меньше ${P.line}`),_("Фора — честные кэфы",e.handicap,"home","away",P=>`${r} ${M(P.line)}`,P=>`${l} ${M(-P.line)}`),t("div.hint",{style:"margin-top:8px",text:`Счёт, время${e.sport==="football"?" и удаления":""} — лайв Fonbet${e.clock==="timer"?"":" (время приблизительное)"}. Довоенная сила: ${e.prior.note}.${e.compare?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на ${e.sport==="hockey"?"1 407 играх НХЛ":"1 837 матчах 5 топ-лиг (11 тыс. точек)"}: при оценке 80–85% сбылось 82,5%. Это расчёт, а не обещание.`}))}function St(e,r,l,g){let x=e.bookLines;if(!x)return null;let w=M=>M>0?`+${M}`:`${M}`,S=(M,_,A,P)=>t("li",{},t("span",{text:`${M}: Fonbet ${_.map(H).join(" / ")}, честно ${A.map(L=>L?H(L):"—").join(" / ")}`}),g&&Math.abs(P)>=5?t(`small${P>0?".pos":".neg"}`,{text:` ${ft(P)} п.п. к первой стороне`}):null);return t("ul.facts",{style:"margin-top:8px"},x.handicap?S(`Фора ${r} ${w(x.handicap.line)} / ${l} ${w(-x.handicap.line)}`,x.handicap.odds,x.handicap.fair,x.handicap.gap):null,x.total?S(`Тотал ${x.total.line} больше / меньше`,x.total.odds,x.total.fair,x.total.gap):null)}function bt(e){let r=e.live;if(!r)return null;if(r.kind==="goals")return ht(r);if(r.kind==="tennis")return st(r);if(r.error)return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"})),t("div.hint",{text:r.error}));let[l,g]=r.names,x=L=>L?H(L):"—",w=r.book&&(r.prior.source==="line"||r.prior.source==="model"),S=r.left>0?`${r.period>r.format.periods?"ОТ":`${r.period}-я четв.`} · осталось ≈${Math.max(1,Math.round(r.left))} мин`:"конец игры",M=(L,G,Z,X,at,rt)=>G.length?t("details",{"data-key":`live-${L}`,open:E.get(`live-${L}`)||!1},t("summary",{text:L}),t("ul.facts",{},G.map(q=>t("li",{},t("span",{text:`${at(q)} — ${x(q[Z])} · ${rt(q)} — ${x(q[X])}`}))))):null,_=L=>L>0?`+${L}`:`${L}`,A=r.quarter,P=A&&A.left>0?`${A.index}-я четверть (${A.score.join(":")}, осталось ≈${Math.max(1,Math.round(A.left))} мин): ${l} ${x(A.probs[0]?1/A.probs[0]:null)} · ничья ${x(A.draw?1/A.draw:null)} · ${g} ${x(A.probs[1]?1/A.probs[1]:null)}; разница ${A.expMargin>=0?l:g} ${Math.abs(A.expMargin).toFixed(1)}, тотал четверти ≈${A.projTotal}.`:"";return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"}),t("span.badge",{text:`${r.score.join(":")} · ${S}`})),r.names.map((L,G)=>{let Z=r.probs[G],X=r.book?r.book[G]:null,at=w&&Number.isFinite(X)?(Z-X)*100:0;return t("div.prob",{},t("span.name",{text:L,title:L}),t("span.odd",{text:H(1/Z),title:"Честный кэф по счёту"}),t("span.track",{},t("i",{style:`width:${Math.round(Z*100)}%`}),Number.isFinite(X)?t("u",{style:`left:${Math.round(X*100)}%`,title:"Шанс по цене этой конторы"}):null),t("span.pct",{},K(Z),Math.abs(at)>=3?t(`small${at>0?".pos":".neg"}`,{text:`${ft(at)} п.п. к цене`}):null))}),t("div.legend",{},t("span",{text:"шанс по счёту (с ОТ)"}),r.book?t("span.model",{text:"шанс по цене этой конторы"}):null),St(r,l,g,w),t("ul.facts",{style:"margin-top:8px"},t("li",{},t("span",{text:`Ожидаемая итоговая разница: ${r.expMargin>=0?l:g} ${Math.abs(r.expMargin).toFixed(1)} (разброс ±${r.sd}). Тотал ≈${r.projTotal} (±${r.sdTotal}).`})),P?t("li",{},t("span",{text:P})):null),M("Фора — честные кэфы",r.handicap,"home","away",L=>`${l} ${_(L.line)}`,L=>`${g} ${_(-L.line)}`),M("Тотал матча — честные кэфы",r.total,"over","under",L=>`больше ${L.line}`,L=>`меньше ${L.line}`),M("Тотал четверти — честные кэфы",r.quarterTotal,"over","under",L=>`больше ${L.line}`,L=>`меньше ${L.line}`),t("div.hint",{style:"margin-top:8px",text:`Счёт и время — лайв Fonbet${r.clock==="timer"?"":" (время в четверти оценено по очкам — приблизительно)"}. Довоенная сила: ${r.prior.note}.${w?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на 8 923 играх Евролиги, Еврокубка и НБА: в перерыве при оценке 75–80% побеждали в 78% случаев. Это расчёт, а не обещание; задержка табло у конторы бывает до минуты.`}))}function mt(e){let r=e.verdict;return r?.lines?.length?t("div.card",{},t("div.kicker",{},t("span",{text:"Итог"}),t("span.badge",{text:r.best?`перевес ${Math.round(r.best.edge*100)}%`:"без перевеса"})),t("ul.facts",{},r.lines.map(l=>t("li",{},t("span",{text:l})))),r.track?t("div.hint",{style:"margin-top:6px",text:r.track}):null,e.analysis.status!=="done"?t("div.hint",{style:"margin-top:6px",text:"Доводы «за» и главный риск появятся после «Разобрать матч»."}):null):null}function ut(e,r){let l=e.durations;if(e.sport!=="mma"||!l)return null;let g=w=>w?H(w):"—",x=r.map(w=>w.name);return t("div",{style:"margin-top:10px"},t("div.kicker",{},t("span",{text:"Честные кэфы"}),t("span.badge",{text:`${l.rounds} ${l.rounds===5?"раундов":"раунда"}`})),t("ul.facts",{},t("li",{},t("span",{text:`Победа: ${x[0]||"первый"} ${g(e.fair?.p1)} · ${x[1]||"второй"} ${g(e.fair?.p2)}`})),l.lines.map(w=>t("li",{},t("span",{text:`Тотал ${w.line} раунда: больше ${g(w.over)} · меньше ${g(w.under)}`}))),t("li",{},t("span",{text:`Дойдёт до решения: да ${g(l.decision.yes)} · нет ${g(l.decision.no)}`})),t("li",{},t("span",{text:`Конец боя: 1-й раунд ${Math.round(l.r1*100)}%, 2-й ${Math.round(l.r2*100)}%, позже ${Math.round(l.r3*100)}%, решение ${Math.round(l.dec*100)}%`}))),t("div.hint",{text:"Кэф конторы выше честного — ставка в плюс по модели, ниже — в минус. Длительность считается по всем боям бойцов в UFC и их весовой; проверка на 565 боях: точнее, чем средние цифры по весовой."}))}function dt(e){let l=((e.compare?.model||e.analysis?.result?.model||e.model)?.profiles||[]).filter(g=>g?.lines?.length);return l.length?t("div.card",{},t("div.kicker",{},t("span",{text:"Профили"}),t("span.badge",{text:"модель Линзы"})),l.map((g,x)=>t("details",{"data-key":`profile-${x}`,open:E.get(`profile-${x}`)??x===0},t("summary",{text:g.name}),t("ul.facts",{},g.lines.map(w=>t("li",{},t("span",{text:w})))))),t("div.hint",{style:"margin-top:8px",text:"Из рейтингов Линзы по открытым данным (ESPN, архив ATP/WTA, Евролига, bo3.gg). Это описание, а не прогноз."})):null}function Ct(e){let r=e.facts;if(!r?.facts?.length)return null;let l=r.facts.filter(S=>/травм|отсутств|не играет|стенд-ин|замен|дисквалиф/i.test(S.text)),g=r.facts.filter(S=>!l.includes(S)&&/состав|стартов/i.test(S.text)),x=r.facts.filter(S=>!l.includes(S)&&!g.includes(S)),w=(S,M,_)=>M.length?t("details",{"data-key":`facts-${S}`,open:_||E.get(`facts-${S}`)||!1},t("summary",{text:`${S} (${M.length})`}),t("ul.facts",{},M.map(A=>t("li",{},t("span",{text:A.text}))))):null;return t("div.card",{},t("div.kicker",{},t("span",{text:"Составы, травмы, форма"}),t("span.badge",{text:r.source||r.facts[0].source||"источник"})),w("Травмы и отсутствующие",l,!0),w("Составы",g,!0),w("Форма, таблица, очные встречи",x,!l.length&&!g.length),t("div.hint",{style:"margin-top:8px"},"Факты из открытых данных, как есть. ",r.url?t("a",{href:r.url,target:"_blank",rel:"noopener",text:"Источник"}):null))}let xt=e=>`${Math.round(e).toLocaleString("ru-RU")} ₽`,vt=(e,r,l,g)=>{let x=e%100,w=e%10;return x>10&&x<20?g:w===1?r:w>=2&&w<=4?l:g},_t=e=>(e.erid?["Реклама",e.legal,`erid ${e.erid}`].filter(Boolean).join(" · "):["Партнёрская ссылка",e.legal].filter(Boolean).join(" · "))+" · 18+",Et=(e,r)=>t("a.btn.ghost.small",{href:e.go?`${e.go}?s=panel`:e.url,target:"_blank",rel:"noopener sponsored"},it("link",13),r||`Открыть у ${e.name}`),Pt=e=>e.code?t("button.btn.ghost.small",{type:"button","data-act":"copy-code","data-arg":e.code,title:e.bonus||"Скопировать промокод"},`Промокод ${e.code}`):null;function pe(e){let r=(e.partners||[]).filter(l=>l.url||l.code);return r.length?t("div.card.soft",{},t("div.kicker",{},t("span",{text:r.length===1?`Промокод ${r[0].name}`:"Промокоды контор"})),r.map(l=>t("div.partner",{},t("div.partner-text",{},t("b",{text:l.name}),l.bonus?t("span",{text:` — ${l.bonus}`}):null),t("div.partner-links",{},Pt(l),l.url?Et(l):null),t("div.hint",{text:_t(l)})))):null}function me(e,r={}){if(e.status==="idle")return null;if(e.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:"Смотрю открытые линии…"}));let l=e.labels||[];if(!e.rows?.length)return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:e.note||"В открытых линиях этой пары нет."}));let g=l.map((L,G)=>Math.max(...e.rows.map(Z=>Z.odds[G]||0))),x=Object.fromEntries((r.partners||[]).map(L=>[L.id,L])),w=L=>L.book&&L.book!==r.bookId&&!L.sharp&&x[L.book]||null,S=r.stake||1e3,M=e.rows.find(L=>L.here)||e.rows[0],A=l.map((L,G)=>{let Z=M?.odds?.[G],X=e.rows.filter(at=>at!==M&&!at.sharp&&at.odds[G]).sort((at,rt)=>rt.odds[G]-at.odds[G])[0];return!Z||!X||X.odds[G]<=Z?null:{label:L,row:X,odd:X.odds[G],mine:Z,gain:(X.odds[G]-Z)*S}}).filter(Boolean).sort((L,G)=>G.gain-L.gain)[0],P=e.rows.map(w).filter(Boolean);return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"}),t("span.badge",{text:"лучшая цена выделена"})),t("table",{},t("tr",{},t("th",{text:"Контора"}),l.map(L=>t("th",{text:L}))),e.rows.map(L=>{let G=w(L);return t("tr",{},t("td.name",{title:L.sharp?"Цена с мирового рынка, для сравнения":""},L.name,G?t("div.partner-links",{},G.url?Et(G):null,Pt(G)):null),L.odds.map((Z,X)=>t(`td${Z&&Z===g[X]&&e.rows.length>1?".best":""}`,{text:Z?H(Z):"—"})))})),A&&A.gain>=1?t("div.gain",{},`На «${A.label}» у ${A.row.name} кэф ${H(A.odd)} против ${H(A.mine)} здесь: со ставки ${xt(S)} выигрыш больше на `,t("b",{text:xt(A.gain)}),"."):null,P.length?t("div.hint",{style:"margin-top:6px",text:[...new Set(P.map(_t))].join(" ")}):null,e.note?t("div.hint",{style:"margin-top:8px",text:e.note}):null)}function fe(e){let r=[],l=(x,w,S)=>r.push(t("dt",{text:x}),t(`dd${S?"."+S:""}`,{text:w}));Number.isFinite(e.fair)?(l("Шанс по линии без маржи",K(e.fair,1)),l("Кэф без маржи конторы",H(e.fairOdd)),l("Маржа конторы в этом рынке",K(e.margin,1))):l("Заложено в кэфе (с маржой)",K(1/e.odd,1)),Number.isFinite(e.model)&&(l("Оценка модели",K(e.model,1)),l("Ожидание на рубль по модели",`${ft(e.ev*100)}%`,e.ev>.005?"pos":e.ev<-.005?"neg":"")),e.best&&l(`Лучшая цена: ${e.best.name}`,H(e.best.odd),e.best.odd>e.odd?"pos":"");let g=e.best?.partner&&(e.best.partner.url||e.best.partner.code)?e.best.partner:null;return t("div.card.accent",{},t("div.kicker",{},t("span",{text:e.market}),t("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},it("close",13))),t("div.pick-head",{},t("span.big",{text:H(e.odd)}),t("span.what",{text:e.label,title:e.label})),t("dl.kv",{},r),e.note?t("div.hint",{style:"margin-top:8px",text:e.note}):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!e.canAdd,title:e.canAdd?"":"Нужен рынок с полным набором исходов"},it("plus",14),e.inExpress?"Уже в экспрессе":"В расчёт экспресса")),g?t("div.partner",{style:"margin-top:10px"},e.best.gain>=1?t("div.gain",{},`У ${g.name} этот кэф выше: со ставки ${xt(e.stake||1e3)} выигрыш больше на `,t("b",{text:xt(e.best.gain)}),"."):null,t("div.partner-links",{},g.url?Et(g):null,Pt(g)),t("div.hint",{text:_t(g)})):null)}function he(e){let r=(l,g)=>t("div",{style:"min-width:0"},t("b",{text:l,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),g.map(x=>t("div",{style:"display:flex;justify-content:space-between;gap:8px"},t("span",{text:x.nick}),t("span",{style:"color:var(--lz-muted)",text:x.numbers.slice(0,2).join(" / ")}))));return t("div.card",{},t("div.kicker",{},t("span",{text:"Игроки сейчас"}),t("span.badge",{text:"с табло конторы"})),t("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},r(e.homeName,e.home),r(e.awayName,e.away)))}function Vt(e,r){return t("div.card",{},t("div.kicker",{},t("span",{text:"Статистика команд"}),t("span.badge",{text:"со страницы конторы"})),t("table",{},t("tr",{},t("th",{text:"Показатель"}),t("th",{text:r.home}),t("th",{text:r.away})),e.rows.map(l=>t("tr",{},t("td",{text:l.label}),t("td",{text:l.home}),t("td",{text:l.away})))),e.samples?.length===2?t("div.hint",{style:"margin-top:8px",text:`Выборка: ${e.samples[0]} и ${e.samples[1]} карт.`}):null)}function Wt(e){let r=[];if(e.pick&&r.push(fe({...e.pick,stake:e.stake})),!e.match)return r.push(t("div.empty",{},t("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),r;r.push(I(e.match)),e.esports&&r.push(he(e.esports)),e.match.stats?.rows?.length&&r.push(Vt(e.match.stats,e.match)),e.line&&r.push(D(e.line));let l=tt(e);l&&r.push(l);let g=bt(e);g&&r.push(g);let x=J(e);x&&r.push(x);let w=mt(e);w&&r.push(w);let S=dt(e);S&&r.push(S);let M=Ct(e);M&&r.push(M);let _=e.analysis.status==="loading";r.push(t("div.row",{},t("button.btn",{type:"button","data-act":"analyze",disabled:_},it("spark"),_?"Разбираю…":e.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),t("button.btn.ghost",{type:"button","data-act":"compare",disabled:e.compare.status==="loading"},it("scale"),"Сравнить цены"))),e.quota&&r.push(t("div.hint.center-text",{text:e.quota}));let A=pe(e);A&&r.push(A);let P=U(e);P&&r.push(P);let L=me(e.compare,e);return L&&r.push(L),r}function Kt(e){let r=e.margins;if(!r)return null;let l=[t("div",{},`Сегодня вы открыли ${r.n} ${vt(r.n,"матч","матча","матчей")} до начала: в основной исход ${e.bookName||"контора"} закладывает в среднем `,t("b",{text:K(r.here,1)})," маржи.")];return r.best?(l.push(t("div",{style:"margin-top:6px"},`На тех же ${r.best.n} ${vt(r.best.n,"матче","матчах","матчах")} у ${r.best.name} — `,t("b",{text:K(r.best.there,1)}),` против ${K(r.best.here,1)} здесь: с каждой ставки вы отдавали бы конторе меньше примерно на ${((r.best.here-r.best.there)*100).toFixed(1)} п.п.`)),r.partner&&l.push(t("div.partner-links",{style:"margin-top:8px"},r.partner.url?Et(r.partner):null,Pt(r.partner)),t("div.hint",{text:_t(r.partner)}))):l.push(t("div.hint",{style:"margin-top:6px",text:"Нажмите «Сравнить цены» на странице матча — Линза запомнит маржу других контор на тех же матчах и покажет, где отдаёте меньше."})),t("div.card",{},t("div.kicker",{},t("span",{text:"Сколько маржи вы отдаёте"}),t("span.badge",{text:"сегодня"})),...l)}function ge(e){let r=e.scan,l=Kt(e);return r?.rows?.length?[l,t("div.card",{},t("div.kicker",{},t("span",{text:r.title}),t("span.badge",{text:`средняя маржа ${K(r.average,1)}`})),t("table",{},t("tr",{},t("th",{text:r.first}),t("th",{text:"Фаворит"}),t("th",{text:"Маржа"})),r.rows.map(g=>t("tr.click",{"data-act":"scan-go","data-arg":String(g.index),title:"Показать на странице"},t("td.name",{},g.name,g.sub?t("span.sub",{text:g.sub}):null),t("td",{},g.fav,t("span.sub",{text:K(g.favPct)})),t(`td${g.low?".best":""}`,{text:K(g.margin,1)})))),t("div.hint",{style:"margin-top:8px",text:r.note}))]:[l,t("div.empty",{},t("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function be(e){let r=e.express;if(!r.legs.length)return[t("div.empty",{},t("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let l=r.stats;return[t("div.card",{},t("div.kicker",{},t("span",{text:`Экспресс · ${r.legs.length}`}),t("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},it("trash",13),"Очистить")),r.legs.map(g=>t("div.leg",{},t("div.t",{},t("b",{text:g.label,title:g.label}),t("span",{text:g.title,title:g.title})),t("span.o",{text:H(g.odd)}),t("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":g.id,title:"Убрать",style:"width:24px;height:24px"},it("close",13))))),l?t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Итоговый коэффициент"}),t("dd",{text:H(l.odd)}),t("dt",{text:"Шанс, что зайдёт всё (по линии)"}),t("dd",{text:K(l.chance,1)}),t("dt",{text:"Кэф без маржи"}),t("dd",{text:H(l.fairOdd)}),t("dt",{text:"Маржа конторы на всём экспрессе"}),t("dd.neg",{text:K(l.margin,1)})),t("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Исходы одного матча считаются как независимые — на деле они связаны."})):null]}function Zt(e){let r=e.edges||{status:"idle"},l=_=>t("div.kicker",{},t("span",{text:"Цена выше рынка"}),_?t("span.badge",{text:_}):null);if(r.status==="loading"&&!r.data)return[t("div.card",{},l("ищу сигналы"),t("div.hint",{text:"Сверяю открытую линию с консенсусом двадцати контор…"}))];if(r.status==="error"&&!r.data)return[t("div.card",{},l(),t("div.note.warn",{},it("alert"),t("span",{text:r.error})))];let g=r.data;if(!g)return[t("div.empty",{},t("b",{text:"Сигналы ещё не загружены"}),"Откройте вкладку ещё раз или нажмите «Обновить».")];let x=_=>_==null?"—":`${_>=0?"+":"−"}${(Math.abs(_)*100).toFixed(1)}%`,w=_=>new Date(_).toLocaleString("ru-RU",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"}),S=t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Открытых сигналов"}),t("dd",{text:String(g.open)}),t("dt",{text:"Закрыто за неделю"}),t("dd",{text:String(g.closedWeek)}),t("dt",{text:"Средний CLV за неделю"}),t("dd",{text:x(g.clvWeek)}),t("dt",{text:"Сигналов с плюсовым CLV"}),t("dd",{text:g.positiveWeek==null?"—":K(g.positiveWeek)})),t("div.hint",{style:"margin-top:8px",text:"CLV — насколько цена сигнала была выше цены закрытия линии. Плюсовой CLV на дистанции — единственный честный признак того, что сигналы опережают рынок. Это не обещание выигрыша."})),M=(g.signals||[]).map(_=>t("tr",{},t("td.name",{},`${_.home} — ${_.away}`,t("span.sub",{text:`${_.league} · ${w(_.start)}`})),t("td",{},_.label,t("span.sub",{text:_.book})),t("td",{text:H(_.odds)}),t("td",{text:H(1/_.p),title:`Честная цена по ${_.count} конторам`}),t("td.best",{text:`+${(_.edge*100).toFixed(1)}%`})));return[t("div.card",{},l(g.full?"тариф «Макс»":"витрина"),M.length?t("table",{},t("tr",{},t("th",{text:"Матч"}),t("th",{text:"Исход"}),t("th",{text:"Кэф"}),t("th",{text:"Рынок"}),t("th",{text:"Выше на"})),M):t("div.hint",{text:"Сейчас открытых сигналов нет: контора держится в рынке. Сканер проходит линию каждые полчаса."}),g.note?t("div.hint",{style:"margin-top:8px"},g.note," ",a.bot?t("a",{href:a.bot,target:"_blank",rel:"noopener",text:"Получить «Макс»"}):null):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"edges-refresh"},"Обновить"))),S]}function jt(e){let r=e.settings,l=(g,x,w)=>t("div.seg",{},w.map(([S,M])=>t(`button${x===S?".on":""}`,{type:"button","data-act":g,"data-arg":S,text:M})));return[t("div.card",{},t("div.field",{},t("label",{text:"Отметки на странице"}),l("set-overlay",r.overlay,[["picks","Фавориты"],["all","Все шансы"],["off","Выкл"]]),t("div.hint",{text:"Рамка стоит на самом вероятном исходе каждого рынка. Число — шанс по линии без маржи конторы. Это не прогноз."})),t("div.field",{},t("label",{text:"Тема"}),l("set-theme",r.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]])),t("div.field",{},t("label",{for:"lz-stake",text:"Ставка для расчёта выгоды, ₽"}),t("div.row",{},t("input",{type:"number",id:"lz-stake",value:String(r.stake||1e3),min:"10",step:"10",inputmode:"numeric","data-enter":"set-stake",style:"max-width:140px"}),t("button.btn.small",{type:"button","data-act":"set-stake"},"Сохранить")),t("div.hint",{text:"Разницу лучшей цены Линза показывает в рублях от этой суммы. На ставку это не влияет."}))),t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор матчей"}),t(`span.badge${r.ready?".pos":""}`,{text:r.ready?"подключён":"не подключён"})),r.proxy?t("div.field",{},t("label",{text:"Доступ"}),l("set-mode",r.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,r.mode==="license"&&r.proxy?t("div.field",{},t("label",{for:"lz-license",text:"Лицензионный ключ"}),t("input",{type:"text",id:"lz-license",placeholder:r.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),r.licenseMask?t("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),t("div.hint",{},[r.licenseMask?`Ключ ${r.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",r.plan,r.usage].filter(Boolean).join(" "),a.bot&&!r.licenseMask?[" ",t("a",{href:a.bot,target:"_blank",rel:"noopener",text:"Получить ключ «Про»"})]:null)):t("div.field",{},t("label",{for:"lz-key",text:"API-ключ Clodex"}),t("input",{type:"password",id:"lz-key",placeholder:r.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),r.hasKey?t("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),t("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${r.usage}`}))),t("div.card.soft",{},t("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной."))]}function xe(e){j=e;let r=JSON.stringify(e);if(r===B)return;B=r;for(let M of f.querySelectorAll("details[data-key]"))E.set(M.dataset.key,M.open);let l=f.scrollTop;y.textContent=e.bookName?`· ${e.bookName}`:"",d.classList.toggle("off",e.settings.overlay==="off"),b.replaceChildren(it(e.theme==="dark"?"sun":"moon")),v.replaceChildren(it(e.settings.overlay==="off"?"eyeOff":"eye")),v.classList.toggle("on",e.settings.overlay!=="off"),k.classList.toggle("on",e.tab==="settings"),k.dataset.arg=e.tab==="settings"?e.backTab:"settings";let g=[["match","Матч"],["scan","Маржа"],["edges","Выше рынка"],["express","Экспресс"]];c.replaceChildren(...g.map(([M,_])=>t(`button.tab${e.tab===M?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":M},_,M==="express"&&e.express.legs.length?t("span.count",{text:String(e.express.legs.length)}):null)));let x=e.tab==="settings"?jt(e):e.tab==="scan"?ge(e):e.tab==="express"?be(e):e.tab==="edges"?Zt(e):Wt(e),w=e.update?t("div.card.soft.update",{},t("b",{text:`Вышла Линза ${e.update.version}`})," — ",e.update.url?t("a",{href:e.update.url,target:"_blank",rel:"noopener",text:"скачать архив на сайте"}):"архив на сайте Линзы"," и заменить папку расширения."):null,S=e.whatsnew?.changes?.length&&e.tab!=="settings"?t("div.card.soft.update",{},t("b",{text:`Линза обновилась до ${e.whatsnew.version}`}),t("ul.facts",{style:"margin-top:6px"},e.whatsnew.changes.flatMap(M=>M.items).slice(0,6).map(M=>t("li",{},t("span",{text:M})))),t("div.row",{style:"margin-top:8px"},t("button.btn.ghost.small",{type:"button","data-act":"whatsnew-ok"},"Понятно"))):null;f.replaceChildren(...[w,S,...x].filter(Boolean)),f.scrollTop=l,h.replaceChildren(t("span",{text:"18+ · Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function ve(e){n.setAttribute("data-theme",e)}function Dt(){$.hidden=!1,s.opened?.()}function Nt(){$.hidden=!0}function Ft(){$.hidden?Dt():Nt()}function Ht(e){e?.fab&&N(u,e.fab.left,e.fab.top),e?.panel&&N($,e.panel.left,e.panel.top)}let i=0;function m(e){p.querySelector(".toast")?.remove();let r=t("div.toast",{text:e,role:"status"});p.appendChild(r),clearTimeout(i),i=setTimeout(()=>r.remove(),2600)}return{render:xe,setTheme:ve,open:Dt,close:Nt,toggle:Ft,restore:Ht,toast:m,shadow:p,rect:()=>$.hidden?null:$.getBoundingClientRect(),get isOpen(){return!$.hidden},get view(){return j}}}var bn="Расширение обновилось. Обновите эту вкладку (F5).";function $o(o){return/signal timed out|timeout|timed out/i.test(o)?"Сервер долго не отвечает — нажмите ещё раз.":/failed to fetch|networkerror|load failed|network request failed/i.test(o)?"Нет связи с сервером Линзы — проверьте интернет.":o}function $t(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function nt(o,s={}){if(!$t())return{ok:!1,error:bn,code:"reload"};try{return await chrome.runtime.sendMessage({type:o,...s})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(a){let n=String(a?.message||a);return/context invalidated/i.test(n)||!$t()?{ok:!1,error:bn,code:"reload"}:/message port closed|receiving end does not exist/i.test(n)?{ok:!1,error:"Связь с расширением прервалась — нажмите ещё раз.",code:"retry"}:{ok:!1,error:$o(n)}}}function xn(o){if($t())try{chrome.runtime.onMessage.addListener(s=>{o(s)})}catch{}}async function Ne(o){if(!$t())return{};try{return await chrome.storage.local.get(o)}catch{return{}}}function Mt(o){if($t())try{chrome.storage.local.set(o)}catch{}}var vn=(o=Date.now())=>new Date(o).toISOString().slice(0,10);function le(o,s=Date.now()){return o&&o.day===vn(s)&&o.items&&typeof o.items=="object"?o:{day:vn(s),items:{}}}function yn(o,{key:s,book:a,margin:n}){if(!s||!Number.isFinite(n)||n<=0||n>.5)return!1;let p=Math.round(n*1e4)/1e4,d=o.items[s];return d&&d.here===p&&d.book===a?!1:(o.items[s]={book:a,here:p,others:d?.others||{}},!0)}function kn(o,s,a){let n=o.items[s];if(!n)return!1;let p=!1;for(let d of a||[]){if(d.here||d.sharp||!d.odds?.length||d.odds.some(f=>!(f>1)))continue;let u=kt(d.odds);if(u.kind!=="full"||!(u.margin>0))continue;let c=Math.round(u.margin*1e4)/1e4;n.others[d.name]!==c&&(n.others[d.name]=c,p=!0)}return p}function wn(o,s){let a=Object.values(o?.items||{}).filter(u=>u.book===s);if(!a.length)return null;let n=u=>u.reduce((c,f)=>c+f,0)/u.length,d=[...new Set(a.flatMap(u=>Object.keys(u.others||{})))].map(u=>{let c=a.filter(f=>Number.isFinite(f.others?.[u]));return c.length>=2?{name:u,n:c.length,there:n(c.map(f=>f.others[u])),here:n(c.map(f=>f.here))}:null}).filter(Boolean).sort((u,c)=>u.there-c.there);return{n:a.length,here:n(a.map(u=>u.here)),best:d[0]||null,others:d}}var Mo=[{version:"1.0.14",items:["«Лучшая цена» — только если цена выше честной на 3–12%. Больше 12% — строка «Проверьте данные»: чаще это ошибка в данных, чем подарок конторы.","Модель Линзы пока справочно: «по модели интересная цена от…». Перевес считается по ценам рынка, пока модель не докажет, что она точнее.","Карты в CS и Dota временно убраны из итога: вернём после проверки на честных ценах."]},{version:"1.0.13",items:["Под разбором — «Показать полностью»: итог по всем рынкам, доводы, как может пойти игра, профили и факты.","Итог по рынкам этой страницы: в теннисе — тотал и фора геймов, в CS и Dota — карты, по цене самой конторы на победу."]},{version:"1.0.12",items:["Под разбором — «Сообщить об ошибке»: что сломалось, уходит разработчику без личных данных.","Итог не строится по модели, которой нельзя верить как цене: если она сильно расходится с рынком или у неё мало матчей в архиве."]},{version:"1.0.11",items:["Разобрать матч: разбор идёт на сервере — видно, что происходит (цены, новости, модель), и он не обрывается на «Обновите вкладку».","Разбор работает на всех конторах: если матча нет в линии Fonbet, Линза разбирает по ценам страницы и свежим новостям.","Новости, травмы и составы из прессы — в разборе для всех тарифов; у «Макс» и VIP поиск подробнее.","Бесплатные 3 разбора в день считаются для вашего браузера, а не для всех с одного адреса; истёкший ключ не отключает бесплатные разборы.","Исправлено: счётчик «Разборов сегодня» больше не пропадает, ошибки связи — понятными словами."]},{version:"1.0.10",items:["Исправлено: в доводах моделей имена команд и игроков — как на странице конторы."]},{version:"1.0.9",items:["Лайв тенниса по счёту: шанс матча, текущего сета и гейма от очков и подачи.","Прогноз модели для КХЛ: атака и оборона команд, исход основного времени и победитель с ОТ; на проверке при уверенности от 65% сбылось 70%.","Итог: форы футбола и хоккея против честной цены по Fonbet."]},{version:"1.0.8",items:["Лайв по счёту для футбола и хоккея: шанс исхода основного времени, следующий гол, тоталы и форы по счёту, времени и удалениям; точное игровое время.","Итог для футбола и хоккея: тоталы этой конторы против честной цены по Fonbet без маржи на любой линии.","Журнал итогов: точность прошлых итогов — в карточке и в приложении."]},{version:"1.0.7",items:["ММА (UFC): прогноз модели по бойцам — возраст, размах рук, форма, простой; как скорее всего закончится бой и честные кэфы на тоталы раундов и решение судей; прогноз рынка 5+ контор.","Итог: в конце карточек — лучшая цена против честной, перевес и размер суммы, доводы и главный риск из разбора; каждый итог записывается и потом сверяется с результатом — точность видна в приложении.","Баскетбол: фора и тотал по модели — ожидаемая разница очков и тотал с разбросом, честные кэфы основных линий конторы в «Итоге».","Теннис: подача и приём в модели — шанс матча по доле выигранных очков на своей подаче и на приёме соперника.","Исправлено: бойцы и теннисисты в формате «Фамилия И.» находятся, если полное имя из трёх слов.","Одна палитра у панели, попапа, мини-приложения и сайта; в тёмной теме приложения — светлый акцент."]},{version:"1.0.6",items:["Лайв по счёту: в баскетболе — честный шанс, фора и тотал против цены конторы; в CS и Dota — шанс серии по счёту карт и раундов текущей карты.","Профили участников: теннисисты (покрытия, подача и приём, нагрузка, последние матчи), команды баскетбола и киберспорта (динамика рейтинга, форма, состав с рейтингом каждого игрока).","Баскетбол: Еврокубок, АСВ, Серия А, Адриатическая лига, Единая лига ВТБ и Лига чемпионов FIBA — в модели и в фактах.","Футбол: ход матча и судьи (УЕФА) в карточке «Составы, травмы, форма».","Киберспорт: у подписи уверенности — как часто такие прогнозы сбывались на проверке; модель Dota точнее.","Вкладка «Маржа»: сколько маржи вы отдаёте этой конторе по открытым сегодня матчам и сколько отдавали бы у других контор.","Новая версия подхватывается сама, когда вы заменили файлы в папке расширения."]},{version:"1.0.5",items:["Карточка «Составы, травмы, форма» на странице матча: травмы по именам, составы, форма и очные встречи (ESPN, bo3.gg) — без разбора и без лимита.","Подсказка в панели, когда на сайте вышла новая версия.","Dota 2: точнее вероятность победы в серии до двух побед."]}];function $n(o,s){let a=String(o||"").split(".").map(Number),n=String(s||"").split(".").map(Number);for(let p=0;p<Math.max(a.length,n.length);p++){let d=(a[p]||0)-(n[p]||0);if(d)return d>0}return!1}function Mn(o,s){return Mo.filter(a=>$n(a.version,o)&&!$n(a.version,s))}var zt=o=>Number.isFinite(o)?(Math.round(o*100)/100).toFixed(2):"—",ce=o=>`${Math.round(o*100)}%`,zo=(o,s)=>o*s-1;function So(o){return o<.03?null:o<.06?"небольшая — примерно половина обычной":o<.12?"обычная":"перевес слишком большой — сначала проверьте травмы, замены и что это тот же матч"}function zn(o,{source:s="",reasons:a=[],risk:n=""}={}){let p=(o||[]).filter($=>Number($.odd)>1&&$.p>.01&&$.p<.99).map($=>({...$,fairOdd:1/$.p,edge:zo($.p,Number($.odd))}));if(!p.length)return null;let d=[...p].sort(($,O)=>O.edge-$.edge),u=d.find($=>$.edge>=.03&&$.edge<=.12)||null,c=u?{...u,size:So(u.edge)}:null,f=d.find($=>$.edge>.12)||null,h=f?{...f}:null,y=p.filter($=>$!==u&&$!==f).map($=>({...$,note:$.edge>.12?`перевес ${ce($.edge)} — слишком большой, проверьте данные`:$.edge>=.03?`перевес ${ce($.edge)} к честной цене ${zt($.fairOdd)}`:$.edge>-.02?`честная цена (${zt($.fairOdd)}), перевеса нет`:`цена ниже честной (${zt($.fairOdd)})`})),b=[],v=$=>$.source||s;if(c){let $=v(c);b.push(`Лучшая цена: ${c.label} по ${zt(c.odd)} — перевес около ${ce(c.edge)} к честной цене ${zt(c.fairOdd)}${$?` (${$})`:""}. Сумма: ${c.size}.`),a.length&&b.push(`За: ${a.join(" ")}`),n&&b.push(`Главный риск: ${n}`)}else b.push(`${h?"Надёжного перевеса нет":"Перевеса нет"}: ${h?"остальные":"все"} цены близки к честным или ниже${s?` (${s})`:""} — разумнее пропустить.`);if(h){let $=v(h);b.push(`Проверьте данные: ${h.label} по ${zt(h.odd)} — перевес ${ce(h.edge)} к честной цене ${zt(h.fairOdd)}${$?` (${$})`:""} слишком большой. Чаще это ошибка данных или модели (травма, состав, чужой матч), а не подарок конторы — лучшей ценой не считаем.`)}let k=[...y].sort(($,O)=>O.edge-$.edge).slice(0,6),T=y.length-k.length;return y.length&&b.push(`${c?"Остальное":"По рынкам"}: ${k.map($=>`${$.label} по ${zt($.odd)} — ${$.note}`).join("; ")}${T>0?`; ещё ${T} — с меньшим перевесом или без него`:""}.`),b.push("Это расчёт, а не обещание: проиграть можно и при перевесе в цене. 18+"),{best:c,suspect:h,others:y,lines:b}}function Ut(o){let s=n=>/^(б|больше|бол|over|o\b|тб)/i.test(String(n||"").trim()),a=n=>/^(м|меньше|мен|under|u\b|тм)/i.test(String(n||"").trim());return s(o[0])&&a(o[1])?0:a(o[0])&&s(o[1])?1:-1}var _o=o=>{let s=o<0?-1:1,a=Math.abs(o),n=1/(1+.3275911*a);return s*(1-((((1.061405429*n-1.453152027)*n+1.421413741)*n-.284496736)*n+.254829592)*n*Math.exp(-a*a))},Fe=o=>.5*(1+_o(o/Math.SQRT2));function Sn(o,s,a){if(!(Math.abs(a-Math.round(a))<1e-9)){let u=1-Fe((a-o)/s);return{win:u,push:0,lose:1-u}}let p=1-Fe((a+.5-o)/s),d=Fe((a-.5-o)/s);return{win:p,push:Math.max(0,1-p-d),lose:d}}function No(o,s,a){let n=Sn(o,s,-a);return{home:n.win,away:n.lose,push:n.push}}function Fo(o,s,a){let n=Sn(o,s,a);return{over:n.win,under:n.lose,push:n.push}}function _n(o,{handicap:s=null,total:a=null}={},n=["Хозяева","Гости"]){let p=o?.lines;if(!p||!Number.isFinite(p.margin)||!(p.sigma>0))return[];let d=[],u=h=>h>0?`+${h}`:`${h}`,c=(h,y)=>h/(1-y||1),f=(h,y)=>1/h/(1/h+1/y);if(s&&Number.isFinite(s.line)&&Math.abs(s.line)<60&&s.home>1&&s.away>1){let h=No(p.margin,p.sigma,s.line);Math.abs(c(h.home,h.push)-f(s.home,s.away))<=.3&&d.push({label:`Фора ${n[0]} ${u(s.line)}`,odd:s.home,p:c(h.home,h.push),kind:"handicap",side:"home",source:"модель Линзы"}),d.length&&d.push({label:`Фора ${n[1]} ${u(-s.line)}`,odd:s.away,p:c(h.away,h.push),kind:"handicap",side:"away",source:"модель Линзы"})}if(a&&Number.isFinite(p.total)&&p.sigmaT>0&&Number.isFinite(a.line)&&a.line>50&&a.over>1&&a.under>1){let h=Fo(p.total,p.sigmaT,a.line);Math.abs(c(h.over,h.push)-f(a.over,a.under))<=.3&&(d.push({label:`Тотал больше ${a.line}`,odd:a.over,p:c(h.over,h.push),kind:"total",source:"модель Линзы"}),d.push({label:`Тотал меньше ${a.line}`,odd:a.under,p:c(h.under,h.push),kind:"total",source:"модель Линзы"}))}return d}var Bt={football:{periods:2,minutes:90,stoppage:[2,5],late:1,weights:[.12,.142,.184,.149,.167,.237],trail:.3,lead:.05,redOwn:-.4,redOpp:.45,total:2.7,homeShare:.555,maxGoals:12},hockey:{periods:3,minutes:60,weights:[.297,.344,.359],trail:0,lead:-.1,redOwn:0,redOpp:0,total:6,homeShare:.52,maxGoals:16}},Te=[1];for(let o=1;o<=40;o+=1)Te[o]=Te[o-1]*o;var Nn=(o,s)=>s<=0?o===0?1:0:Math.exp(-s)*s**o/Te[o];function To(o,s){let a=s.weights.length,n=s.minutes/a,p=Math.max(0,Math.min(s.minutes,o)),d=0;for(let c=0;c<a;c+=1){let f=c*n,h=f+n,y=a/(s.periods||1),b=(c+1)%y===0&&s.stoppage?.[Math.floor(c/y)]||0;p<=f?d+=s.weights[c]:p<h&&(d+=s.weights[c]*((h-p+b)/(n+b)))}let u=s.weights.reduce((c,f)=>c+f,0);return d/u}function Fn(o,s,a){let n=[];for(let p=0;p<=a;p+=1){n[p]=[];for(let d=0;d<=a;d+=1)n[p][d]=Nn(p,o)*Nn(d,s)}return n}function Oo(o,s,a,n=null){let p=Fn(o,s,a),d=0,u=0,c=0,f=0;for(let h=0;h<=a;h+=1)for(let y=0;y<=a;y+=1){let b=p[h][y];h>y?d+=b:h===y?u+=b:c+=b,n!=null&&h+y>n&&(f+=b)}return{p1:d,px:u,p2:c,over:f}}function Tn({p1:o,px:s,p2:a,line:n=null,pOver:p=null},d=Bt.football){let u=d.total,c=(h,y)=>{let b=Oo(h,y,d.maxGoals,n!=null&&p!=null?n:null),v=(b.p1-o)**2+(b.p2-a)**2+(s!=null?(b.px-s)**2:0);return n!=null&&p!=null?v+=(b.over-p)**2:v+=.02*((h+y-u)/u)**2,v},f={lh:u*d.homeShare,la:u*(1-d.homeShare),e:1/0};for(let h=.4;h>=.01;h/=2){let y=f;for(let b=-4;b<=4;b+=1)for(let v=-4;v<=4;v+=1){let k=Math.max(.03,y.lh+b*h),T=Math.max(.03,y.la+v*h),$=c(k,T);$<f.e&&(f={lh:k,la:T,e:$})}}return{lh:f.lh,la:f.la}}function Oe(o,s,a=Bt.football){let[n,p]=o.score.map(Number),d=To(Number(o.minute)||0,a),u=n-p,c=Math.sign(u),f=1+(a.late||0)*((Number(o.minute)||0)/a.minutes-.5),h=(Math.abs(u)>=2?.6:1)*Math.max(0,f),y=c<0?a.trail*h:c>0?a.lead*h:0,b=c>0?a.trail*h:c<0?a.lead*h:0,[v,k]=(o.red||[0,0]).map(U=>Math.min(2,Number(U)||0)),T=(U,V)=>(1+a.redOwn)**U*(1+a.redOpp)**V,$=Math.max(0,s.lh*d*(1+y)*T(v,k)),O=Math.max(0,s.la*d*(1+b)*T(k,v)),B=a.maxGoals,j=Fn($,O,B),E=0,W=0,F=0;for(let U=0;U<=B;U+=1)for(let V=0;V<=B;V+=1){let tt=n+U,Q=p+V;tt>Q?E+=j[U][V]:tt===Q?W+=j[U][V]:F+=j[U][V]}let z=E+W+F||1,N=U=>{let V=0,tt=0;for(let Q=0;Q<=B;Q+=1)for(let ot=0;ot<=B;ot+=1){let J=n+p+Q+ot;J>U?V+=j[Q][ot]:J===U&&(tt+=j[Q][ot])}return{over:V,push:tt,under:Math.max(0,1-V-tt)}},C=U=>{let V=0,tt=0;for(let Q=0;Q<=B;Q+=1)for(let ot=0;ot<=B;ot+=1){let J=n+Q-(p+ot)+U;J>0?V+=j[Q][ot]:J===0&&(tt+=j[Q][ot])}return{home:V,push:tt,away:Math.max(0,1-V-tt)}},I=$+O,D=Math.exp(-I);return{p1:E/z,px:W/z,p2:F/z,lh:$,la:O,share:d,expTotal:n+p+I,nextGoal:{home:I>0?(1-D)*($/I):0,away:I>0?(1-D)*(O/I):0,none:D},total:N,handicap:C}}var Ae=(o,s)=>1/o/(1/o+1/s);function Ao(o,s){let a=Bt[s];if(!a||!o?.odds||o.odds.length!==3)return null;let n=kt(o.odds).fair;if(!n)return null;let p=o.total,d=p&&p.over>1&&p.under>1?Ae(p.over,p.under):null;return d==null?null:Tn({p1:n[0],px:n[1],p2:n[2],line:p.line,pOver:d},a)}function On(o,s,a,n=["Хозяева","Гости"]){let p=Ao(o,a);if(!p)return[];let d=Bt[a],u=Oe({score:[0,0],minute:0},p,d),c=[],f=new Set,h=b=>b>0?`+${b}`:`${b}`,y=b=>{let v=String(b??"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?\d+(?:\.\d+)?/g);return v?Number(v[v.length-1]):NaN};for(let b of s||[]){if(b.kind!=="total"&&b.kind!=="handicap"||b.outcomes?.length!==2)continue;let v=`${b.title||""} ${b.period||""}`;if(/тайм|период|четверт|half|period|инд|команд|угл|карт|corner|card|овертайм|буллит|с уч[её]том|(^|[^а-яё])от([^а-яё]|$)/i.test(v.replace(/осн\.?\s*время/i,"")))continue;if(b.kind==="handicap"){let F=y(b.outcomes[0].label);if(Number.isFinite(F)||(F=y(b.line)),!Number.isFinite(F)||Math.abs(F)>4||f.has(`h${F}`))continue;let z=Number(b.outcomes[0].odd),N=Number(b.outcomes[1].odd);if(!(z>1&&N>1))continue;let C=u.handicap(F),I=1-C.push||1;if(Math.abs(C.home/I-Ae(z,N))>.15)continue;f.add(`h${F}`),c.push({label:`Фора ${n[0]} ${h(F)}`,odd:z,p:C.home/I,kind:"handicap",side:"home",line:F,source:"Fonbet без маржи"},{label:`Фора ${n[1]} ${h(-F)}`,odd:N,p:C.away/I,kind:"handicap",side:"away",line:-F,source:"Fonbet без маржи"});continue}let k=Number(String(b.line||"").replace(",","."));if(!Number.isFinite(k)||k<=0||k>(a==="hockey"?12:9)||f.has(k))continue;let T=Ut(b.outcomes.map(F=>F.label));if(T<0)continue;let $=u.total(k),O=1-$.push||1,B=$.over/O,j=$.under/O,E=Number(b.outcomes[T].odd),W=Number(b.outcomes[1-T].odd);!(E>1&&W>1)||Math.abs(B-Ae(E,W))>.2||(f.add(k),c.push({label:`Тотал больше ${k}`,odd:E,p:B,kind:"total",line:k,source:"Fonbet без маржи"},{label:`Тотал меньше ${k}`,odd:W,p:j,kind:"total",line:k,source:"Fonbet без маржи"}))}return c}function Lo(o){let s=(o||[]).map(Number);if(!s.length||!s.every(d=>d>1))return null;let a=s.map(d=>1/d),n=a.reduce((d,u)=>d+u,0),p=a.map(d=>d/n);return p.length===3?p[0]+p[1]/2:p[0]}function An(o,s){if(!o?.p1)return{ok:!1,reason:"нет прогноза"};if(o.confidence==="очень низкая")return{ok:!1,reason:"мало матчей в архиве — модель почти ничего не знает об участниках"};let a=Lo(s);return a!=null&&Math.abs(o.p1-a)>.2?{ok:!1,reason:`модель расходится с ценой конторы на ${Math.round(Math.abs(o.p1-a)*100)} п.п. — скорее всего, она чего-то не знает (квалификация, травма, состав)`}:{ok:!0,reason:""}}var Co={cs:!1,dota:!1,tennis:!1,basketball:!1,mma:!1,hockey:!1},Ln=o=>Co[o]===!0;function Le(o,s){if(!o?.p1||!(o.p2>0))return"";let a=n=>n>.01&&n<.99?(1/n*1.03).toFixed(2):"—";return`По модели Линзы интересная цена от: ${s[0]} — ${a(o.p1)}, ${s[s.length-1]} — ${a(o.p2)} (справочно: модель пока не точнее цены конторы).`}var Ee={atp:{hard:.645,clay:.625,grass:.67},wta:{hard:.565,clay:.55,grass:.585}};function At(o,s=0,a=0){let n=1-o,p=o*o/(o*o+n*n),d=new Map,u=(c,f)=>{if(c>=4&&c-f>=2)return 1;if(f>=4&&f-c>=2)return 0;if(c>=3&&f>=3)return c===f?p:c>f?o+n*p:o*p;let h=c*16+f;return d.has(h)||d.set(h,o*u(c+1,f)+n*u(c,f+1)),d.get(h)};return u(s,a)}function ue(o,s,a=0,n=0,p=!0,d=7){let u=k=>k?o:1-s,c=o*(1-s)/(o*(1-s)+(1-o)*s),f=k=>k===0?0:Math.floor((k+1)/2),h=f(a+n)%2===0?p:!p,y=k=>f(k)%2===0?h:!h,b=new Map,v=(k,T)=>{if(k>=d&&k-T>=2)return 1;if(T>=d&&T-k>=2)return 0;if(k>=d-1&&T>=d-1&&k===T)return c;let $=k*64+T;if(!b.has($)){let O=u(y(k+T));b.set($,O*v(k+1,T)+(1-O)*v(k,T+1))}return b.get($)};return v(a,n)}function Ce(o,s,a=0,n=0,p=!0,d=7){let u=At(o),c=1-At(s),f=new Map,h=(y,b,v)=>{if(y>=6&&y-b>=2||y===7)return 1;if(b>=6&&b-y>=2||b===7)return 0;if(y===6&&b===6)return ue(o,s,0,0,v,d);let k=y*32+b*2+(v?1:0);if(!f.has(k)){let T=v?u:c;f.set(k,T*h(y+1,b,!v)+(1-T)*h(y,b+1,!v))}return f.get(k)};return h(a,n,p)}function Cn(o,s,a,n=3,{finalTb:p=7}={}){let d=n>=5?3:2,u=(o.sets||[]).filter(([F,z])=>F>z).length,c=(o.sets||[]).length-u,[f,h]=o.games||[0,0],[y,b]=o.points||[0,0],v=o.aServes!==!1,T=u===d-1&&c===d-1?p:7,$=new Map,O=(F,z)=>{if(F>=d)return 1;if(z>=d)return 0;let N=F*8+z;if(!$.has(N)){let C=F===d-1&&z===d-1?p:7,I=(Ce(s,a,0,0,!0,C)+Ce(s,a,0,0,!1,C))/2;$.set(N,I*O(F+1,z)+(1-I)*O(F,z+1))}return $.get(N)},B=f===6&&h===6,j,E;if(B)j=ue(s,a,y,b,v,T),E=j;else{E=v?At(s,y,b):1-At(a,b,y);let F=(z,N)=>z>=6&&z-N>=2||z===7?1:N>=6&&N-z>=2||N===7?0:Ce(s,a,z,N,!v,T);j=E*F(f+1,h)+(1-E)*F(f,h+1)}return{match:j*O(u+1,c)+(1-j)*O(u,c+1),set:j,game:E,hold:v?E:1-E}}function En(o,s,a=3){return(Cn({sets:[],games:[0,0],points:[0,0],aServes:!0},o,s,a).match+Cn({sets:[],games:[0,0],points:[0,0],aServes:!1},o,s,a).match)/2}var Eo=.03,Lt=(o,s,a)=>o.set(s,(o.get(s)||0)+a);function Po(o,s,a=!0){let n=At(o),p=At(s),d=new Map,u=new Map([[`0,0,${a?1:0}`,1]]);for(;u.size;){let c=new Map;for(let[f,h]of u){let[y,b,v]=f.split(",").map(Number),k=v===1;if(y===6&&b===6){let $=ue(o,s,0,0,k);Lt(d,`7,6,${k?0:1}`,h*$),Lt(d,`6,7,${k?0:1}`,h*(1-$));continue}let T=k?n:1-p;for(let[$,O,B]of[[y+1,b,T],[y,b+1,1-T]]){let j=($>=6||O>=6)&&Math.abs($-O)>=2||$===7||O===7,E=`${$},${O},${k?0:1}`;Lt(j?d:c,E,h*B)}}u=c}return[...d].map(([c,f])=>{let[h,y,b]=c.split(",").map(Number);return{ga:h,gb:y,nextA:b===1,p:f}})}function Pn(o,s,a=3){let n=a===5?3:2,p=new Map,d=b=>{let v=b?1:0;return p.has(v)||p.set(v,Po(o,s,b)),p.get(v)},u=new Map,c=new Map,f=new Map,h=[{sa:0,sb:0,a:!0,t:0,d:0,p:.5},{sa:0,sb:0,a:!1,t:0,d:0,p:.5}];for(;h.length;){let b=new Map;for(let v of h)for(let k of d(v.a)){let T=v.sa+(k.ga>k.gb?1:0),$=v.sb+(k.gb>k.ga?1:0),O=v.t+k.ga+k.gb,B=v.d+k.ga-k.gb,j=v.p*k.p;if(T===n||$===n){Lt(u,`${T}:${$}`,j),Lt(c,O,j),Lt(f,B,j);continue}let E=`${T},${$},${k.nextA?1:0},${O},${B}`,W=b.get(E);W?W.p+=j:b.set(E,{sa:T,sb:$,a:k.nextA,t:O,d:B,p:j})}h=[...b.values()]}let y=(b,v)=>[...b].reduce((k,[T,$])=>k+(v(Number(T))?$:0),0);return{sets:Object.fromEntries(u),win:[...u].reduce((b,[v,k])=>b+(Number(v.split(":")[0])===n?k:0),0),total:c,diff:f,over:b=>({over:y(c,v=>v>b),push:y(c,v=>v===b)}),handicap:b=>({home:y(f,v=>v+b>0),push:y(f,v=>v+b===0)})}}var jo=0,Io=.04,Bo=[[-2.0201828705,.0199532421],[-.9585724646,.3936193232],[0,.9453087205],[.9585724646,.3936193232],[2.0201828705,.0199532421]].map(([o,s])=>[o*Math.SQRT2,s/Math.sqrt(Math.PI)]);function Do(o,{tour:s="atp",surface:a="hard",bestOf:n=3,serveShift:p=jo,daySd:d=Io}={}){let u=((Ee[s]||Ee.atp)[a]||.63)+p,c=F=>Math.max(-.3,Math.min(.3,F)),f=d>0?Bo:[[0,1]],h=F=>f.reduce((z,[N,C])=>z+C*En(u+c(F+N*d),u-c(F+N*d),n),0),y=-.3,b=.3,v=Math.min(.995,Math.max(.005,o));for(let F=0;F<30;F+=1){let z=(y+b)/2;h(z)<v?y=z:b=z}let k=(y+b)/2;if(f.length===1)return Pn(u+k,u-k,n);let T=f.map(([F,z])=>[z,Pn(u+c(k+F*d),u-c(k+F*d),n)]),$=F=>{let z=new Map;for(let[N,C]of T)for(let[I,D]of F(C))z.set(I,(z.get(I)||0)+N*D);return z},O=$(F=>Object.entries(F.sets)),B=$(F=>F.total),j=$(F=>F.diff),E=(F,z)=>[...F].reduce((N,[C,I])=>N+(z(Number(C))?I:0),0),W=n===5?3:2;return{sets:Object.fromEntries(O),win:[...O].reduce((F,[z,N])=>F+(Number(z.split(":")[0])===W?N:0),0),total:B,diff:j,over:F=>({over:E(B,z=>z>F),push:E(B,z=>z===F)}),handicap:F=>({home:E(j,z=>z+F>0),push:E(j,z=>z+F===0)})}}var qo={cs:0,dota:0};function Ro(o,{pick:s=0}={}){let a=c=>Math.min(.999,Math.max(.001,c)),n=c=>{let f=a(c+s),h=a(c-s),y=a(c),b=f*h,v=(1-f)*(1-h),k=f*(1-h)+(1-f)*h;return{q:c,s20:b,s02:v,s21:k*y,s12:k*(1-y)}},p=0,d=1;for(let c=0;c<50;c+=1){let f=(p+d)/2,h=n(f);h.s20+h.s21<o?p=f:d=f}let u=n((p+d)/2);return{q:u.q,sets:{"2:0":u.s20,"2:1":u.s21,"1:2":u.s12,"0:2":u.s02},over25:u.s21+u.s12,homeMinus15:u.s20,awayMinus15:u.s02}}var Go={tennis:!0,cs:!1,dota:!1};function Uo(o=""){let s=String(o),a=/wta|жен|women/i.test(s)?"wta":"atp",n=/грунт|clay/i.test(s)?"clay":/трав|grass/i.test(s)?"grass":"hard",p=/australian open|roland garros|ролан|уимблдон|wimbledon|us open|открытый чемпионат (австралии|сша)/i.test(s);return{tour:a,surface:n,bestOf:p&&a==="atp"?5:3}}function Pe({sport:o,model:s=null,p:a=null,source:n="модель Линзы",markets:p,names:d=["Хозяева","Гости"],league:u=""}){let c=a??s?.p1;if(!Go[o]||!(c>0&&c<1))return[];let f=o==="tennis",h=f?Do(c,Uo(u)):Ro(c,{pick:qo[o]||0}),y=j=>{let E=String(j??"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?\d+(?:\.\d+)?/g);return E?Number(E[E.length-1]):NaN},b=(j,E)=>1/j/(1/j+1/E),v=(j,E)=>E>0?j/(1-E):j,k=f?"гейма":"карты",T=j=>String(j||"").toLowerCase().replace(/ё/g,"е"),$=d.flatMap(j=>T(j).split(/[^a-zа-я0-9-]+/)).filter(j=>j.length>=4),O=[],B=new Set;for(let j of p||[]){if(j.scope==="list"||j.main===!1||j.kind!=="total"&&j.kind!=="handicap"||j.outcomes?.length!==2||!j.outcomes.every(z=>z.odd>1))continue;let E=`${j.title||""} ${j.period||""}`;if(/сет|set|тай-?брейк|tie|инд|игрок|player|раунд|round|килл|kill|чет|нечет/i.test(E)||$.some(z=>T(E).includes(z))||!f&&/гейм|game/i.test(E))continue;let[W,F]=j.outcomes;if(j.kind==="total"){let z=Number.isFinite(y(j.line))?y(j.line):y(W.label);if(!Number.isFinite(z)||B.has(`t${z}`)||(f?z<12||z>60:z!==2.5))continue;let N=!/меньш|under/i.test(W.label),C,I=0;if(f){let tt=h.over(z);C=tt.over,I=tt.push}else if(z===2.5)C=h.over25;else continue;let D=N?W:F,U=N?F:W,V=v(C,I);if(Math.abs(V-b(D.odd,U.odd))>.2)continue;B.add(`t${z}`),O.push({label:`Тотал ${f?"геймов":"карт"} больше ${z}`,odd:D.odd,p:V,kind:"total",line:z,source:n}),O.push({label:`Тотал ${f?"геймов":"карт"} меньше ${z}`,odd:U.odd,p:1-V,kind:"total",line:z,source:n})}else{let z=Number.isFinite(y(W.label))?y(W.label):y(j.line);if(!Number.isFinite(z)||B.has(`h${z}`)||(f?Math.abs(z)>15:Math.abs(z)!==1.5))continue;let N,C=0;if(f){let U=h.handicap(z);N=U.home,C=U.push}else if(z===-1.5)N=h.homeMinus15;else if(z===1.5)N=1-h.awayMinus15;else continue;let I=v(N,C);if(Math.abs(I-b(W.odd,F.odd))>.2)continue;B.add(`h${z}`);let D=U=>U>0?`+${U}`:`${U}`;O.push({label:`Фора ${d[0]} ${D(z)} ${k}`,odd:W.odd,p:I,kind:"handicap",side:"home",line:z,source:n}),O.push({label:`Фора ${d[1]} ${D(-z)} ${k}`,odd:F.odd,p:1-I,kind:"handicap",side:"away",line:-z,source:n})}}return O}function jn({sport:o,model:s,markets:a,names:n,league:p=""}){let d=Pe({sport:o,model:s,markets:a,names:n,league:p}).filter(c=>c.p>=.15&&c.p<=.85),u=new Map;for(let c of d){let f=`${c.kind}|${Math.abs(c.line)}`;(!u.has(f)||c.p*c.odd>u.get(f).p*u.get(f).odd)&&u.set(f,c)}return[...u.values()].sort((c,f)=>Math.abs(c.p-.5)-Math.abs(f.p-.5)).map(c=>({label:c.label,from:Math.round(1/c.p*(1+Eo)*100)/100,odd:c.odd}))}var de=globalThis.__lzBus,je=de&&window.top===window?on(location.hostname):null;je&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,Ko(je.adapter,je.book));async function Ko(o,s){let a=await Ne(["lz.settings","lz.positions","lz.express","lz.margins","lz.whatsnew"]),n={settings:{...ke,...a["lz.settings"]||{}},positions:(a["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:Zo(a["lz.express"]),margins:le(a["lz.margins"]),whatsnew:a["lz.whatsnew"]||null,analysis:new Map,compare:new Map,consensus:new Map,model:new Map,facts:new Map,fonbetRef:new Map,live:new Map,edges:{status:"idle",data:null,error:"",at:0},partners:{data:{},at:0},status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},p=new WeakMap,d=new WeakMap,u=ln(),c=gn({bus:de,brand:Jt,actions:be()});c.restore(n.positions);function f(i){let m=i.outcomes.map(l=>l.odd).join("/"),e=p.get(i);if(e?.sig===m)return e.set;let r=kt(i.outcomes.map(l=>l.odd));return p.set(i,{sig:m,set:r}),r}function h(){return n.match?n.analysis.get(n.match.key):null}function y(i){let m=h()?.result;if(!m?.model||i.scope==="list"||!n.match||!Object.values(m.shift||{}).some(x=>Math.abs(x)>=.5))return null;let{home:e,draw:r,away:l}=m.model,g=i.outcomes.length;if(i.kind==="1x2"&&i.main&&g===3)return[e,r,l];if(i.kind==="12"&&i.main&&g===2&&r<.005)return[e,l];if(i.kind==="dc"&&i.main&&g===3)return[e+r,e+l,r+l];if(/^победит\s*\(осн\.?\s*время\)$/i.test(i.title)&&g===2){let x=i.period===n.match.home?e:i.period===n.match.away?l:null;if(x!=null)return[x,1-x]}return null}function b(){let i=n.markets.filter(m=>m.scope!=="list"&&m.main&&(m.kind==="1x2"||m.kind==="12"));return i.find(m=>m.scope==="top")||i[0]||null}function v(i,m){let e=i.outcomes[m].label;return i.scope==="list"?!i.event||!i.main?e:i.kind==="1x2"?[i.event.home,"Ничья",i.event.away][m]||e:i.kind==="12"&&[i.event.home,i.event.away][m]||e:n.match?i.kind==="1x2"?[n.match.home,"Ничья",n.match.away][m]||e:i.kind==="12"&&[n.match.home,n.match.away][m]||e:e}function k(){let i=n.settings.overlay,m=[];for(let r of n.markets){if(r.outcomes.forEach((_,A)=>d.set(_.el,{market:r,index:A})),i==="off")continue;let l=f(r);if(l.kind==="partial")continue;let g=y(r),x=g||l.fair,w=0;for(let _=1;_<l.fair.length;_+=1)l.fair[_]>l.fair[w]&&(w=_);let S="accent";if(g){let _=0;for(let A=1;A<g.length;A+=1)g[A]-l.fair[A]>g[_]-l.fair[_]&&(_=A);g[_]-l.fair[_]>=.015&&(w=_,S="pos")}let M=r.scope!=="list"||r.main&&(r.kind==="1x2"||r.kind==="12");r.outcomes.forEach((_,A)=>{let P=A===w&&M;!P&&i!=="all"||m.push({el:_.el,frame:P,chip:wt(x[A]),tone:P?S:"quiet"})})}let e=T();if(e){let r=m.find(l=>l.el===e.item.el);r?r.selected=!0:m.push({el:e.item.el,frame:!1,selected:!0,chip:null})}u.set(m)}function T(){if(!n.selected)return null;let i=n.markets.find(e=>e.id===n.selected.id),m=i?.outcomes[n.selected.index];return m?.el?.isConnected?{market:i,item:m,index:n.selected.index}:null}function $(){if(n.settings.theme!=="auto")return n.settings.theme;for(let i of[document.body,document.documentElement]){let e=(i?getComputedStyle(i).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!e||e[4]==="0")continue;return(.2126*e[1]+.7152*e[2]+.0722*e[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}let O=0;function B(){clearTimeout(O),O=setTimeout(()=>Mt({"lz.margins":n.margins}),1500)}function j(){if(n.pageType!=="match"||!n.match||n.match.live)return;n.margins=le(n.margins);let i=D();i&&yn(n.margins,{key:n.match.key,book:s.id,margin:i.margin})&&B()}function E(){location.href!==n.url&&(n.url=location.href,n.selected=null,u.hideTip());let i="other",m=[],e=null;try{i=o.pageType(document,location),m=o.collect(document,location),e=o.readMatch(document,location)}catch(l){console.error("[Линза] страница не прочитана",l)}i!==n.pageType&&(n.pageType=i,n.tab!=="settings"&&n.tab!=="express"&&(n.tab=i==="match"?"match":"scan")),n.markets=m,n.match=e,j();let r=$();r!==n.theme&&(n.theme=r),u.setTheme(n.theme),c.setTheme(n.theme),k(),xt(),z(),c.isOpen&&(vt(),Vt(),Kt(),_t(),c.render(J()))}let W=new Set,F=null;function z(){if(o.observeTargets)for(let i of o.observeTargets(document))W.has(i)||(W.add(i),F=F||new MutationObserver(I),F.observe(i,{childList:!0,subtree:!0,characterData:!0}))}let N=0,C=0;function I(){let i=Date.now();C||(C=i),clearTimeout(N);let m=i-C>900?0:220;N=setTimeout(()=>{C=0,!document.hidden&&E()},m)}function D(){let i=b();if(!i)return null;let m=f(i);if(m.kind!=="full")return null;let e=y(i);return{title:"Что заложено в цене",margin:m.margin,rows:i.outcomes.map((r,l)=>({name:v(i,l),odd:r.odd,fair:m.fair[l],model:e?e[l]:null})),overtime:U()}}function U(){if(!["hockey","basketball"].includes(n.match?.sport))return null;let i=n.markets.find(e=>e.scope!=="list"&&e.outcomes.length===2&&/овертайм|булл|(^|[^а-яё])от([^а-яё]|$)|\bot\b/i.test(`${e.title} ${e.period}`)&&!/тотал|фора|будет|перв|втор|трет|период|тайм/i.test(`${e.title} ${e.period}`));if(!i)return null;let m=f(i);return m.kind!=="full"?null:{title:[i.title,i.period].filter(Boolean).join(" · "),rows:i.outcomes.map((e,r)=>({name:v(i,r)||[n.match.home,n.match.away][r],odd:e.odd,fair:m.fair[r]}))}}function V(){let i=T();if(!i)return null;let{market:m,item:e,index:r}=i,l=f(m),g=y(m),x=l.fair?l.fair[r]:null,w=m.event?`${m.event.home} — ${m.event.away}`:n.match?`${n.match.home} — ${n.match.away}`:"",S=n.match?n.compare.get(n.match.key):null,M=null;if(S?.rows?.length&&m.main&&(m.kind==="1x2"||m.kind==="12")&&m.scope!=="list")for(let A of S.rows){let P=A.odds[r];P&&(!M||P>M.odd)&&(M={name:A.name,odd:P,book:A.book||""})}M&&(M.partner=M.book&&M.book!==s.id&&n.partners.data?.[M.book]||null,M.gain=Math.round((M.odd-e.odd)*(n.settings.stake||1e3)));let _=`${m.id}#${r}`;return{market:[m.title,m.period,m.line].filter(Boolean).join(" · "),label:[v(m,r),w].filter(Boolean).join(" · "),odd:e.odd,fair:x,margin:l.margin,fairOdd:x?1/x:null,model:g?g[r]:null,ev:g?Ue(g[r],e.odd):null,best:M,canAdd:Number.isFinite(x)&&!n.express.some(A=>A.id===_),inExpress:n.express.some(A=>A.id===_),note:l.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":g?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function tt(){let i=wn(le(n.margins),s.id);if(!i)return null;let m=i.best&&i.best.there<i.best.here?i.best:null,e=m&&bt().find(r=>r.name===m.name&&(r.url||r.code))||null;return{...i,best:m,partner:e}}function Q(){let i=[];if(n.pageType==="match"?n.markets.forEach((l,g)=>{if(l.scope==="list")return;let x=f(l);if(x.kind!=="full")return;let w=0;for(let S=1;S<x.fair.length;S+=1)x.fair[S]>x.fair[w]&&(w=S);i.push({index:g,name:l.title,sub:[l.period,l.line].filter(Boolean).join(" · "),margin:x.margin,fav:l.outcomes[w].label,favPct:x.fair[w]})}):n.markets.forEach((l,g)=>{if(!l.event||!l.main||l.kind!=="1x2"&&l.kind!=="12")return;let x=f(l);if(x.kind!=="full")return;let w=0;for(let M=1;M<x.fair.length;M+=1)x.fair[M]>x.fair[w]&&(w=M);let S=l.kind==="1x2"?[l.event.home,"Ничья",l.event.away][w]:[l.event.home,l.event.away][w];i.push({index:g,name:`${l.event.home} — ${l.event.away}`,sub:l.event.league||l.event.time,margin:x.margin,fav:S,favPct:x.fair[w]})}),!i.length)return null;let m=new Set;for(let l=i.length-1;l>=0;l-=1){let g=`${i[l].name}|${i[l].sub}`;m.has(g)?i.splice(l,1):m.add(g)}let e=i.reduce((l,g)=>l+g.margin,0)/i.length;i.sort((l,g)=>l.margin-g.margin);let r=i.slice(0,16);return r.forEach(l=>{l.low=l.margin<=e*.8}),{title:n.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:n.pageType==="match"?"Рынок":"Матч",average:e,rows:r,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${r.length} из ${i.length}, сначала самые дешёвые.`}}function ot(){let i=n.status;return i.ready?i.limit?`Разборов сегодня: ${i.used} из ${i.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function J(){let i=n.match?.key,m=i&&n.analysis.get(i)||{status:"idle",steps:[]},e=i&&n.compare.get(i)||{status:"idle"},r=n.match?.live&&o.readEsportsWidget?o.readEsportsWidget(document):null,l=n.status;return{tab:n.tab,backTab:n.backTab,theme:n.theme,bookName:s.name,pageType:n.pageType,match:n.match?{...n.match,sportName:Be[n.match.sport]||""}:null,esports:r?{...r,homeName:n.match.home,awayName:n.match.away}:null,line:D(),analysis:{status:m.status,steps:m.steps||[],result:m.result||null,error:m.error||"",needKey:!!m.needKey},compare:e,consensus:i&&n.consensus.get(i)||null,model:i&&n.model.get(i)||null,live:he(i),verdict:pe(i),facts:i&&n.facts.get(i)||null,pick:V(),scan:n.tab==="scan"?Q():null,margins:n.tab==="scan"?tt():null,edges:n.edges,bookId:s.id,partners:bt(),stake:Number(n.settings.stake)||1e3,express:{legs:n.express,stats:Ge(n.express)},quota:ot(),update:n.status.update?{version:n.status.update,url:Jt.site?`${Jt.site}#install`:""}:null,whatsnew:n.whatsnew?{version:n.whatsnew.to,changes:Mn(n.whatsnew.from,n.whatsnew.to)}:null,settings:{overlay:n.settings.overlay,theme:n.settings.theme,stake:Number(n.settings.stake)||1e3,mode:l.mode,proxy:l.proxy,ready:l.ready,hasKey:l.hasKey,keyMask:l.keyMask,licenseMask:l.licenseMask,plan:l.plan==="free"||!l.plan?"":`Тариф «${{max:"Макс",vip:"VIP",api:"API"}[l.plan]||"Про"}»${l.until?` до ${l.until.split("-").reverse().join(".")}`:""}.`,usage:l.limit?`Сегодня разборов: ${l.used} из ${l.limit}.`:""}}}let st=()=>{c.isOpen&&c.render(J())};function ht(i){Object.assign(n.settings,i),Mt({"lz.settings":n.settings}),E(),c.render(J())}async function St(i=!1){if(!i&&Date.now()-n.partners.at<3600*1e3)return;n.partners.at=Date.now();let m=await nt("lz:partners",{force:i});m.ok&&m.data&&typeof m.data=="object"&&(n.partners.data=m.data,c.isOpen&&c.render(J()),mt())}let bt=()=>Object.values(n.partners.data||{}).filter(i=>i&&i.id!==s.id);function mt(){if(!c.isOpen||n.tab!=="match"||!n.match)return;let i=bt().filter(m=>m.url||m.code).map(m=>m.id);i.length&&nt("lz:partner-seen",{ids:i,s:"panel"})}async function ut(){n.edges={...n.edges,status:"loading",error:""};let i=await nt("lz:edges",{sport:n.match?.sport||""});n.edges=i.ok?{status:"done",data:i.data,error:"",at:Date.now()}:{status:"error",data:n.edges.data,error:i.error,at:Date.now()},st()}async function dt(){let i=await nt("lz:status");i.ok&&(n.status=i.data),st()}function Ct(){let i=b(),m=i?f(i):null;return{book:s.name,match:n.match,market:i&&m?.kind==="full"?{kind:i.kind,labels:i.outcomes.map((e,r)=>v(i,r)),odds:i.outcomes.map(e=>e.odd)}:null}}function xt(){if(!n.match||!$t())return;let i=Ct();if(!i.market)return;let m=`${n.match.key}|${i.market.odds.join("/")}`;m!==xt.last&&(xt.last=m,nt("lz:quote",i))}async function vt(){let i=n.match;if(!i||i.live||n.consensus.has(i.key))return;let m=Ct();if(!m.market?.odds?.length)return;n.consensus.set(i.key,null);let e=await nt("lz:consensus",{match:i,size:m.market.odds.length});n.consensus.set(i.key,e.ok&&e.data?.consensus?e.data:null),n.match?.key===i.key&&c.isOpen&&c.render(J())}async function _t(){let i=n.match;if(!i?.live||!["basketball","football","hockey","tennis"].includes(i.sport))return;let m=n.live.get(i.key);if(m&&(m.pending||Date.now()-m.at<3e4))return;n.live.set(i.key,{...m||{},pending:!0});let e=await nt("lz:live",{match:i});n.live.set(i.key,{at:Date.now(),data:e.ok&&e.data&&!e.data.error?e.data:null,error:e.ok?e.data?.error||"":e.error||""}),n.match?.key===i.key&&c.isOpen&&c.render(J())}function Et(i,m){n.fonbetRef.set(i,null),nt("lz:fonbet-ref",{match:m}).then(e=>{n.fonbetRef.set(i,e.ok&&e.data?.odds?e.data:null),e.ok&&e.data?.odds&&n.match?.key===i&&c.isOpen&&c.render(J())}).catch(()=>{})}function Pt(i,m,e){let r=n.match,l=`${i}|${[m.best,m.suspect,...m.others].filter(Boolean).map(x=>`${x.label}:${x.odd}`).join(",")}`;if(n.verdictSent===l)return;n.verdictSent=l;let g=[m.best,m.suspect,...m.others].filter(Boolean).map(x=>({label:x.label,odd:x.odd,p:x.p,kind:x.kind||"win",side:x.side||"",line:x.line??null,source:x.source||e,unit:x.unit||""}));nt("lz:verdict",{payload:{sport:r.sport,league:r.league||"",home:r.home,away:r.away,book:s.name,source:e,best:m.best?.label||"",options:g}}).then(x=>{x?.ok&&x.data?.track&&x.data.track!==n.verdictTrack&&(n.verdictTrack=x.data.track,c.isOpen&&c.render(J()))}).catch(()=>{})}function pe(i){let m=n.match,e=i&&D();if(!m||!e||m.live)return null;let r=n.consensus.get(i),l=e.rows,g=n.model.get(i),x=g&&An(g,l.map(q=>q.odd)).ok?g:null,w=x&&Ln(m.sport)?x:null,S=n.analysis.get(i)?.result,M=[m.home,m.away],_=[],A="";if(r?.consensus?.length===l.length)l.forEach((q,et)=>_.push({label:q.name,odd:q.odd,p:r.consensus[et],side:l.length===3?["home","draw","away"][et]:["home","away"][et]})),A=`консенсус ${r.count} контор`;else if(!r?.consensus&&w?.sport==="hockey"&&w.regulation&&l.length===3){let q=[w.regulation.p1,w.regulation.px,w.regulation.p2];l.forEach((et,ct)=>_.push({label:et.name,odd:et.odd,p:q[ct],side:["home","draw","away"][ct]})),A="модель Линзы"}else{let q=l.length===2?l:m.sport==="mma"&&l.length===3?[l[0],l[2]]:e.overtime?.rows||null,et=r?.consensus?.length===2?r.consensus:w?.p1?[w.p1,w.p2]:null;q&&et&&(q.forEach((ct,lt)=>_.push({label:M[lt],odd:ct.odd,p:et[lt],side:["home","away"][lt]})),A=r?.consensus?.length===2?`консенсус ${r.count} контор`:"модель Линзы")}let P=w?.sport==="mma"?w.durations:null;if(P)for(let q of n.markets){if(q.scope==="list"||q.kind!=="total"||q.outcomes.length!==2)continue;let et=String(q.line||"").replace(",","."),ct=et==="1.5"?P.r1+P.r2/2:et==="2.5"&&P.rounds===3?P.r1+P.r2+P.r3/2:null,lt=Ut(q.outcomes.map(gt=>gt.label));ct==null||lt<0||_.some(gt=>gt.kind==="total"&&gt.line===et)||(_.push({label:`Больше ${et} раунда`,odd:q.outcomes[lt].odd,p:1-ct,kind:"total",line:et}),_.push({label:`Меньше ${et} раунда`,odd:q.outcomes[1-lt].odd,p:ct,kind:"total",line:et}))}if(w?.sport==="basketball"&&w.lines){let q=qt=>{let pt=String(qt||"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?[0-9]+(?:[.][0-9]+)?/);return pt?Number(pt[0]):NaN},et=qt=>n.markets.filter(pt=>pt.scope!=="list"&&pt.main&&pt.kind===qt&&pt.outcomes.length===2&&pt.outcomes.every(Yt=>Yt.odd>1)).sort((pt,Yt)=>Math.abs(pt.outcomes[0].odd-pt.outcomes[1].odd)-Math.abs(Yt.outcomes[0].odd-Yt.outcomes[1].odd))[0]||null,ct=et("handicap"),lt=et("total"),gt=ct?q(ct.outcomes[0].label):NaN;ct&&!Number.isFinite(gt)&&(gt=q(ct.line));let Xt=lt?q(lt.line):NaN;lt&&!Number.isFinite(Xt)&&(Xt=q(lt.outcomes[0].label));let ye=lt?Ut(lt.outcomes.map(qt=>qt.label)):-1;_.push(..._n(w,{handicap:ct&&Number.isFinite(gt)?{line:gt,home:ct.outcomes[0].odd,away:ct.outcomes[1].odd}:null,total:lt&&ye>=0&&Number.isFinite(Xt)?{line:Xt,over:lt.outcomes[ye].odd,under:lt.outcomes[1-ye].odd}:null},M))}let L=n.markets.filter(q=>q.scope!=="list"),G=l.length===2?kt(l.map(q=>q.odd)):null;G?.fair&&["tennis","cs","dota"].includes(m.sport)&&_.push(...Pe({sport:m.sport,p:G.fair[0],source:"цена конторы на победу",markets:L,names:M,league:m.league||""}));let Z=x?.p1&&["tennis","cs","dota"].includes(m.sport)?jn({sport:m.sport,model:x,markets:L,names:M,league:m.league||""}):[];if((m.sport==="football"||m.sport==="hockey")&&s.id!=="fonbet"){let q=n.fonbetRef.get(i);q===void 0?Et(i,m):q&&_.push(...On(q,n.markets.filter(et=>et.scope!=="list"),m.sport,M))}if(!_.length)return x?.p1?{best:null,suspect:null,others:[],lines:[Le(x,M),"Это расчёт, а не обещание: проиграть можно и при перевесе в цене. 18+"],track:n.verdictTrack||""}:null;let X=[..._].filter(q=>q.p*q.odd-1>=.03&&q.p*q.odd-1<=.12).sort((q,et)=>et.p*et.odd-q.p*q.odd)[0]?.side,at=(S?.factors||[]).filter(q=>X&&q.side===X).slice(0,2).map(q=>q.text),rt=zn(_,{source:A,reasons:at,risk:S?.risks?.[0]||""});return rt&&x?.p1&&!w&&rt.lines.splice(rt.lines.length-1,0,Le(x,M)),rt&&Z.length&&rt.lines.splice(rt.lines.length-1,0,`По модели Линзы интересная цена от: ${Z.slice(0,6).map(q=>`${q.label} — ${q.from.toFixed(2)}${q.odd>=q.from?" ✓ здесь выше":""}`).join(" · ")}.`),rt&&Pt(i,rt,A),rt&&{...rt,track:n.verdictTrack||""}}function me(i,m,e){let r=(w,S)=>m?[S,w]:[w,S],g=D()?.rows||[],x=g.length===2&&g.every(w=>Number.isFinite(w.fair))?g.map(w=>w.fair):null;return{kind:"tennis",names:[n.match.home,n.match.away],score:r(i.score[0],i.score[1]),sets:i.sets.map(([w,S])=>r(w,S)),games:r(i.games[0],i.games[1]),points:r(i.points[0],i.points[1]),tiebreak:i.tiebreak,serving:i.aServes==null?null:i.aServes!==m?0:1,bestOf:i.bestOf,prior:i.prior,serve:r(i.serve.a,i.serve.b),probs:r(i.p1,i.p2),set:r(i.set.p1,1-i.set.p1),game:r(i.game.p1,1-i.game.p1),book:x,compare:i.prior.source==="line"||i.prior.source==="model",at:e}}function fe(i,m,e){let r=(S,M)=>m?[M,S]:[S,M],l=S=>m?[S[2],S[1],S[0]]:S,x=D()?.rows||[],w=x.length===3&&x.every(S=>Number.isFinite(S.fair))?x.map(S=>S.fair):null;return{kind:"goals",sport:i.sport,names:[n.match.home,n.match.away],score:r(i.score[0],i.score[1]),red:r(i.red[0],i.red[1]),minute:i.minute,period:i.period,periods:i.periods,clock:i.clock,prior:i.prior,probs:l([i.p1,i.px,i.p2]),book:w,compare:i.prior.source==="line",expTotal:i.expTotal,nextGoal:l([i.nextGoal.home,i.nextGoal.none,i.nextGoal.away]),total:i.tables.total,handicap:i.tables.handicap.map(S=>m?{line:-S.line,home:S.away,away:S.home}:S).sort((S,M)=>S.line-M.line),bookLines:i.bookLines,at:e}}function he(i){let m=i&&n.live.get(i);if(!m?.data)return m?.error?{error:m.error}:null;let e=m.data,r=!!e.flipped;if(e.kind==="goals")return fe(e,r,m.at);if(e.kind==="tennis")return me(e,r,m.at);let l=(M,_)=>r?[_,M]:[M,_],g=D(),x=g?.overtime?.rows||g?.rows||[],w=x.length===2?x.map(M=>M.fair):x.length===3&&x.every(M=>Number.isFinite(M.fair))?[x[0].fair+x[1].fair/2,x[2].fair+x[1].fair/2]:null,S=e.tables||{};return{names:[n.match.home,n.match.away],score:l(e.score[0],e.score[1]),periods:(e.periods||[]).map(([M,_])=>l(M,_)),period:e.period,elapsed:e.elapsed,left:e.left,clock:e.clock,format:e.format,probs:l(e.p1,e.p2),book:w,prior:e.prior,expMargin:r?-e.expMargin:e.expMargin,sd:e.sd,projTotal:e.projTotal,sdTotal:e.sdTotal,handicap:(S.handicap||[]).map(M=>r?{line:-M.line,home:M.away,away:M.home}:M).sort((M,_)=>M.line-_.line),total:S.total||[],quarterTotal:S.quarterTotal||[],bookLines:e.bookLines?{handicap:e.bookLines.handicap?r?{...e.bookLines.handicap,line:-e.bookLines.handicap.line,odds:[...e.bookLines.handicap.odds].reverse(),fair:[...e.bookLines.handicap.fair].reverse(),p:1-e.bookLines.handicap.p,book:1-e.bookLines.handicap.book,gap:-e.bookLines.handicap.gap}:e.bookLines.handicap:null,total:e.bookLines.total||null}:null,quarter:e.quarter?{...e.quarter,score:l(e.quarter.score[0],e.quarter.score[1]),expMargin:r?-e.quarter.expMargin:e.quarter.expMargin,probs:l(e.quarter.p1,e.quarter.p2)}:null,at:m.at}}async function Vt(){let i=n.match;if(!i||!["cs","dota","tennis","basketball","mma","hockey"].includes(i.sport)||n.model.has(i.key)||i.live&&(i.sport==="tennis"||i.sport==="basketball"||i.sport==="mma"||i.sport==="hockey"))return;n.model.set(i.key,null);let m=await nt("lz:model",{match:i});n.model.set(i.key,m.ok&&m.data?.p1?m.data:null),n.match?.key===i.key&&c.isOpen&&c.render(J())}let Wt=new Map;async function Kt(){let i=n.match;if(!i||!["football","hockey","basketball","cs","dota"].includes(i.sport))return;let m=i.live&&Date.now()-(Wt.get(i.key)||0)>60*1e3;if(n.facts.has(i.key)&&!m)return;let e=n.facts.get(i.key)||null;Wt.set(i.key,Date.now()),n.facts.set(i.key,e);let r=await nt("lz:facts",{match:i});n.facts.set(i.key,r.ok&&r.data?.facts?.length?r.data:e),n.match?.key===i.key&&c.isOpen&&c.render(J())}async function ge(){let i=n.match;if(!i||n.analysis.has(i.key))return;let m=await nt("lz:cached",{match:i});!m.ok||!m.data||n.analysis.has(i.key)||(n.analysis.set(i.key,{status:"done",steps:[],result:m.data}),E(),st())}function be(){return{opened(){dt(),E(),ge(),vt(),Vt(),Kt(),_t(),St(),c.render(J()),mt()},tab(i){i==="settings"&&(n.backTab=n.tab==="settings"?n.backTab:n.tab),n.tab=i||"match",i==="edges"&&n.edges.status!=="loading"&&Date.now()-n.edges.at>300*1e3&&ut(),c.render(J())},"edges-refresh"(){ut(),c.render(J())},theme(){ht({theme:n.theme==="dark"?"light":"dark"})},"overlay-toggle"(){ht({overlay:n.settings.overlay==="off"?"picks":"off"})},"set-overlay"(i){ht({overlay:i})},"set-theme"(i){ht({theme:i})},async"set-mode"(i){await nt("lz:settings",{mode:i}),dt()},"copy-code"(i){if(!i)return;let m=()=>c.toast("Промокод скопирован");navigator.clipboard?.writeText?navigator.clipboard.writeText(i).then(m,()=>c.toast(`Промокод: ${i}`)):c.toast(`Промокод: ${i}`)},"set-stake"(i,m,e){let r=Math.round(Number(e.getElementById("lz-stake")?.value));if(!Number.isFinite(r)||r<10||r>1e7)return c.toast("Введите сумму от 10 ₽");ht({stake:r}),c.toast("Сумма сохранена")},async"save-key"(i,m,e){let r=e.getElementById("lz-key"),l=(r?.value||"").trim();if(l.length<8)return c.toast("Вставьте ключ целиком");let g=await nt("lz:settings",{apiKey:l});c.toast(g.ok?"Ключ сохранён":g.error),r&&(r.value=""),dt()},async"clear-key"(){await nt("lz:settings",{apiKey:""}),c.toast("Ключ удалён"),dt()},async"save-license"(i,m,e){let r=e.getElementById("lz-license"),l=(r?.value||"").trim();if(l.length<6)return c.toast("Вставьте ключ целиком");let g=await nt("lz:settings",{licenseKey:l});c.toast(g.ok?"Ключ принят":g.error),r&&(r.value=""),dt()},async"clear-license"(){await nt("lz:settings",{licenseKey:""}),c.toast("Ключ удалён"),dt()},savePosition(i,m){n.positions[i]=m,Ne(["lz.positions"]).then(e=>{let r=e["lz.positions"]||{};r[location.hostname]=n.positions,Mt({"lz.positions":r})})},async analyze(){if(!n.match)return;let i=n.match.key,m={status:"loading",steps:[`${n.match.home} — ${n.match.away}`]};n.analysis.set(i,m),st();let e=await nt("lz:analyze",{...Ct(),force:!0}),r=e.ok?e.data?.job:"",l=Date.now();for(;r&&e.ok&&e.data?.status==="running"&&Date.now()-l<420*1e3;){if(m.steps=[m.steps[0],...(e.data.steps||[]).map(g=>g.text)].slice(-8),st(),await new Promise(g=>setTimeout(g,2e3)),n.analysis.get(i)!==m)return;e=await nt("lz:job",{job:r}),!e.ok&&e.code==="retry"&&(e=await nt("lz:job",{job:r}))}if(e.ok&&r){let g=e.data?.steps?.length?[m.steps[0],...e.data.steps.map(x=>x.text)].slice(-8):m.steps;e.data.status==="done"?n.analysis.set(i,{status:"done",steps:g,result:{...e.data.result,full:e.data.full||null}}):e.data.status==="error"?n.analysis.set(i,{status:"error",steps:g,error:e.data.error}):n.analysis.set(i,{status:"error",steps:g,error:"Разбор идёт дольше 7 минут. Нажмите ещё раз — собранное уже на сервере, второй раз будет быстрее."})}else e.ok?n.analysis.set(i,{status:"done",steps:m.steps,result:e.data}):n.analysis.set(i,{status:"error",steps:m.steps,error:e.error,needKey:e.code==="no-access"});dt(),E(),c.render(J())},async report(){let i=n.match?n.analysis.get(n.match.key):null,m="";try{m=chrome.runtime.getManifest().version}catch{}let e=await nt("lz:report",{where:"panel",url:location.href,book:s.name,version:m,match:n.match?`${n.match.home} — ${n.match.away}`:"",step:i?.steps?.slice(-1)[0]||"",error:i?.error||(i?.status==="done"?"разбор выглядит неправильно":"страница матча не узнана")});c.toast(e.ok?"Спасибо! Сообщение ушло разработчику.":e.error)},async compare(){if(!n.match)return;let i=n.match.key;n.compare.set(i,{status:"loading"}),st();let m=await nt("lz:compare",Ct());n.compare.set(i,m.ok?{status:"done",...m.data}:{status:"done",rows:[],labels:[],note:m.error}),m.ok&&kn(n.margins,i,m.data.rows)&&B(),st()},"whatsnew-ok"(){n.whatsnew=null,Mt({"lz.whatsnew":null}),st()},"pick-clear"(){n.selected=null,k(),st()},"leg-add"(){let i=V(),m=T();!i?.canAdd||!m||(n.express.push({id:`${m.market.id}#${m.index}`,title:i.market,label:i.label,odd:i.odd,fair:i.fair,at:Date.now()}),Mt({"lz.express":n.express}),c.toast("Добавлено в расчёт экспресса"),st())},"leg-remove"(i){n.express=n.express.filter(m=>m.id!==i),Mt({"lz.express":n.express}),st()},"leg-clear"(){n.express=[],Mt({"lz.express":n.express}),st()},"scan-go"(i){let m=n.markets[Number(i)],e=m?.outcomes[0]?.el;e?.isConnected&&(e.scrollIntoView({behavior:"smooth",block:"center"}),n.selected={id:m.id,index:0},setTimeout(k,400))}}}function Zt(i){let m=i.composedPath();for(let e=0;e<Math.min(m.length,6);e+=1){let r=m[e]instanceof Element?d.get(m[e]):null;if(r&&r.market.outcomes[r.index]?.el===m[e])return r}return null}let jt=new Map;function xe(i){if(!i.event||!i.main||!["1x2","12"].includes(i.kind)||i.scope!=="list"||i.event.live)return console.debug("[lz] рынок для списка не запрашивается:",JSON.stringify({event:!!i.event,main:i.main,kind:i.kind,scope:i.scope,live:i.event?.live})),null;let m=i.event.key;if(jt.has(m))return jt.get(m);let e={home:i.event.home,away:i.event.away,sport:ve(i),league:i.event.league||""},r=nt("lz:consensus",{match:e,size:i.outcomes.length}).then(l=>((!l.ok||!l.data?.consensus)&&console.debug("[lz] рынок для списка:",l.error||l.data?.error||"нет данных"),l.ok&&l.data?.consensus?l.data:null)).catch(l=>(console.debug("[lz] рынок для списка:",String(l?.message||l)),null));return jt.set(m,r),r.then(l=>jt.set(m,l)),r}let ve=i=>i.event?.sport||n.match?.sport||It(location.pathname,document.title,i.event?.league);function Dt({market:i,index:m},e=null){let r=f(i),l=y(i),g=i.event?`${i.event.home} — ${i.event.away}`:"",x=i.outcomes.map((M,_)=>{let A=r.fair?r.fair[_]:1/M.odd;return t(`div.tip-row${_===m?".hot":""}`,{},t("span",{text:v(i,_)}),t("span.odd",{text:H(M.odd)}),t("span.pct",{text:wt(A,A<.1?1:0)}),t("span.tip-bar",{},t("i",{style:`width:${Math.round(A*100)}%`})))}),w=r.kind==="partial"?t("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):t("div.tip-foot",{},"Маржа конторы ",t("b",{text:wt(r.margin,1)}),l?t("span",{}," · модель: ",t("b",{text:wt(l[m],1)})):null),S=null;if(e?.consensus){let M=e.consensus.length===i.outcomes.length,_=!M&&e.consensus.length===2&&i.outcomes.length===3;if(M||_){let A=M?e.consensus[m]:null,P=A?i.outcomes[m].odd*A-1:0;S=t("div.tip-foot",{},`Рынок, ${e.count} контор${_?", с овертаймом":""}: `,t("b",{text:e.consensus.map(L=>wt(L,0)).join(" / ")}),P>.005?t("span.pos",{text:` · кэф выше рынка на ${(P*100).toFixed(1)}%`}):null)}}else e===void 0&&(S=t("div.tip-foot",{text:"Рынок: сверяю…"}));return t("div",{},t("div.tip-title",{text:[i.title,i.period,i.line].filter(Boolean).join(" · ")}),g?t("div.tip-sub",{text:g}):t("div.tip-sub",{text:"Шанс по линии без маржи"}),x.slice(0,8),w,S)}let Nt=0,Ft=null;de.on("page:pointerover",i=>{if(n.settings.overlay==="off")return;let m=Zt(i),e=m?m.market.outcomes[m.index].el:null;if(e!==Ft){if(Ft=e,clearTimeout(Nt),!m)return u.hideTip();Nt=setTimeout(()=>{if(Ft!==e||!e.isConnected)return;u.setAvoid(c.rect());let r=xe(m.market);u.showTip(e,Dt(m,r instanceof Promise?void 0:r)),r instanceof Promise&&r.then(l=>{Ft===e&&e.isConnected&&u.showTip(e,Dt(m,l))})},280)}}),de.on("page:click",i=>{let m=Zt(i);m&&(n.selected={id:m.market.id,index:m.index},n.tab==="scan"&&(n.tab="match"),k(),st())}),xn(i=>{if(i.type!=="lz:progress")return;let m=n.analysis.get(i.key);!m||m.status!=="loading"||(m.steps=[...m.steps,i.text].slice(-7),st())});let Ht=()=>{E(),new MutationObserver(I).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||E()}),setInterval(()=>{!document.hidden&&location.href!==n.url&&E()},600),setInterval(()=>{!document.hidden&&c.isOpen&&I()},4e3),$t()&&chrome.storage.onChanged.addListener(i=>{i["lz.settings"]&&(n.settings={...ke,...i["lz.settings"].newValue||{}},E())}),dt()};document.body?Ht():document.addEventListener("DOMContentLoaded",Ht,{once:!0}),document.documentElement.setAttribute("data-lz",s.id),globalThis.__lz={state:n,view:J,refresh:E,overlay:u,panel:c}}function Zo(o){let s=Date.now()-432e5;return(Array.isArray(o)?o:[]).filter(a=>a&&a.at>s&&a.odd>1)}})();
