(()=>{var Gt=s=>typeof s=="string"?s:"",ee={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:Gt("https://linzabet.ru/"),telegram:Gt("https://t.me/linza_odds"),bot:Gt("https://t.me/linza_keys_bot?start=ext")},cs=Gt("https://linzabet.ru"),us=Gt("https://185-72-145-3.sslip.io"),Kn={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var Zn=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function Ge(s){let r=String(s||"").toLowerCase();return Zn.find(a=>a.hosts.some(n=>r===n||r.endsWith(`.${n}`)))||null}var ze={overlay:"picks",theme:"auto",mode:"own",model:Kn.model,stake:1e3},Ue={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",mma:"ММА",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function yt(s){let r=String(s??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(r))return null;let a=parseFloat(r.replace(",","."));return a>=1.001&&a<=1e3?a:null}var Ve=s=>s.reduce((r,a)=>r+1/a,0);function vt(s){let r=(s||[]).filter(n=>Number.isFinite(n)&&n>1);if(r.length<2||r.length!==(s||[]).length)return{kind:"partial",margin:null,fair:null};let a=Ve(r);if(a>=.985&&a<=1.3)return{kind:"full",margin:a-1,fair:r.map(n=>1/n/a)};if(r.length===3&&a>=1.97&&a<=2.4){let n=a/2;return{kind:"double",margin:n-1,fair:r.map(m=>Math.min(.995,1/m/n))}}return{kind:"partial",margin:null,fair:null}}function We(s){let r=(s||[]).map(h=>h||[]).filter(h=>h.length),a=r.flat().filter(Boolean);if(a.length<2)return{sets:[],rest:a};let n=h=>h.length>=2&&h.every(Boolean)&&vt(h.map(f=>f.odd)).kind!=="partial",m=h=>{let f=h.filter(y=>y.some(Boolean));if(!f.length)return null;let x=f.filter(n);if(x.length/f.length<.6)return null;let g=new Set(x.flat());return{sets:x,rest:a.filter(y=>!g.has(y))}},d=h=>{let f=[];for(let x=0;x<r.length;x+=h)f.push(r.slice(x,x+h).flat());return f},u=()=>{let h=[];for(let f=0;f+1<r.length;f+=2){let x=Math.max(r[f].length,r[f+1].length);for(let g=0;g<x;g+=1)h.push([r[f][g]??null,r[f+1][g]??null])}return h},c=[()=>d(1)];r.length>=2&&r.length%2===0&&c.push(u,()=>d(2)),r.length>=3&&r.length%3===0&&c.push(()=>d(3)),r.length>1&&c.push(()=>[r.flat()]);for(let h of c){let f=m(h());if(f)return f}return{sets:[],rest:a}}function Ke(s,r=1.13){let a=c=>{let h=Ve(c.map(f=>f.odd));return h>=.995&&h<=r?!0:c.length===3&&h>=1.99&&h<=r*2},n=c=>Math.abs(c*4-Math.round(c*4))<1e-9,m=[],d=[],u=0;for(;u<s.length;){let c=s.slice(u,u+3),h=s.slice(u,u+2);c.length===3&&a(c)?(m.push(c),u+=3):h.length===2&&a(h)?(m.push(h),u+=2):s[u+2]&&n(s[u+1].odd)&&a([s[u],s[u+2]])?(m.push([s[u],s[u+2]]),d.push(s[u+1]),u+=3):(d.push(s[u]),u+=1)}return{sets:m,rest:d}}function Ze(s){let r=(s||[]).filter(m=>m&&m.odd>1&&m.fair>0&&m.fair<1);if(!r.length)return null;let a=r.reduce((m,d)=>m*d.odd,1),n=r.reduce((m,d)=>m*d.fair,1);return{legs:r.length,odd:a,chance:n,fairOdd:1/n,margin:1-a*n}}function He(s,r){return s*r-1}function Z(s){return Number.isFinite(s)?s>=100?s.toFixed(0):s>=10?s.toFixed(1):s.toFixed(2):"—"}function kt(s,r=0){if(!Number.isFinite(s))return"—";let a=s*100;return a>0&&a<1&&r===0?"<1%":`${a.toFixed(r)}%`}function Se(s){return String(s??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zа-я0-9]/g,"")}var Hn=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function Xe(s){return String(s??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[\u0300-\u036f]/g,"").split(/[^a-zа-я0-9]+/).filter(r=>r.length>=2&&!Hn.has(r))}function Ut(s,r){let a=Se(s),n=Se(r);if(a.length<2||n.length<2)return 0;if(a===n)return 1;let m=a.length<=n.length?a:n,d=m===a?n:a;if(m.length>=4&&d.includes(m))return .85;let u=Xe(s),c=Xe(r),h=x=>String(x??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[̀-ͯ]/g,"").match(/^\s*([a-zа-я-]{3,})\s+([a-zа-я])\.?\s*$/);for(let[x,g]of[[s,c],[r,u]]){let y=h(x);if(y&&g.length>=2&&g.includes(y[1])&&g.some(v=>v!==y[1]&&v[0]===y[2]))return .8}if(u.length&&c.length){let g=u.filter(y=>c.some(v=>v===y||y.length>=5&&v.startsWith(y.slice(0,5)))).length/Math.max(u.length,c.length);if(g>=.5)return .6+.3*g}let f=0;for(;f<a.length&&f<n.length&&a[f]===n[f];)f+=1;return f>=5?Math.min(.8,.45+f*.04):0}function Xn(s){let r=String(s??"").toLowerCase(),a=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(r)&&a.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(r)&&a.push("women"),/\(рез|\(р\)|резерв|reserve/.test(r)&&a.push("reserve"),/люб/.test(r)&&a.push("amateur"),/кибер|esport|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(r)&&a.push("cyber"),a.join("+")}function At(s,r){let a=d=>{let u=Se(d),c=Xn(d);return u.length<2?"":c?`${u}~${c}`:u},n=a(s),m=a(r);return!n||!m?"":[n,m].sort().join("|")}var R=s=>(s?.textContent||"").replace(/[ \s]+/g," ").trim(),_e=s=>s.offsetParent===null&&s.tagName!=="BODY";function Yn(s){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(s||"").trim())}function Jn(s){let r=String(s||"").match(/(\d+)\s*[-‑–]?\s*(?:го|й|м|ой|ий|я|ая|ья|ый)?\s+(период|тайм|сет|четверт|половин|карт|гейм|иннинг)/i);return r?r[0]:""}function Vt(s,r){let a=String(s||"").toLowerCase();return/двойной шанс/.test(a)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(a)?"other":/фор[аы]|гандикап/.test(a)?"handicap":/тотал/.test(a)?"total":/обе забьют/.test(a)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(a)?r===3?"1x2":r===2?"12":"other":"other"}var Qn=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/(^|[^а-яёa-z])(мма|mma|ufc|юфс)([^а-яёa-z]|$)|смешанн|единоборств|mixed martial|бои без правил/i,"mma"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function It(...s){let r=s.filter(Boolean).join(" ");for(let[a,n]of Qn)if(a.test(r))return n;return""}function Ne(s){if(!s)return null;let r=yt(R(s));if(r)return r;let a=R(s).split(" ");return yt(a[a.length-1])}var to=0;function Ft({scope:s,title:r,period:a="",line:n="",kind:m,outcomes:d,event:u=null,anchor:c=null,eventKey:h=""}){let f=d.length;return{id:`${s}|${h}|${r}|${a}|${n}|${d.map(x=>x.label).join("/")}`,serial:to+=1,scope:s,title:r,period:a,line:n,kind:m||Vt(r,f),main:Yn(a)&&!Jn(r),outcomes:d,event:u,anchor:c||d[0]?.el||null}}var X=(s,r)=>[...s.querySelectorAll(r)];function en(s){return(String(s||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function Ae(s){return s.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":s.querySelector(".card")?"list":"other"}var Ye={win:"В",loose:"П",lose:"П",draw:"Н"};function Je(s){return X(s,".competitor-form__value").map(r=>Ye[[...r.classList].find(a=>Ye[a])]||R(r).slice(0,1)).filter(Boolean).join("")}function eo(s){let r=s.querySelector(".marketbook-header--live");if(r){let n=X(r,".game-scoring__item").map(u=>R(u)),m=X(r,".game-periods .period").map(u=>{let c=X(u,"span");return{label:R(u.querySelector("i")),home:R(c[0]),away:R(c[1])}}).filter(u=>u.home!==""&&u.away!==""),d=X(r,".game-specials > div").map(u=>{let c=X(u,"span"),h=u.querySelector("i"),f=h?.classList.contains("yellow-card")?"жёлтые":h?.classList.contains("red-card")?"красные":h?.classList.contains("penalty-card")?"угловые":"";return f?{kind:f,home:R(c[0]),away:R(c[1])}:null}).filter(Boolean);return{state:R(r.querySelector(".game-timing-state")),score:n.length===2?n:[],periods:m,extras:d}}let a=s.querySelector(".match-card");if(a&&!a.querySelector(".match-card__timer--prematch")){let n=R(a.querySelector(".match-card__main-score")).replace(/\s/g,""),m=X(a,".match-card__score").map(u=>R(u)).filter(u=>/^\d{1,2}$/.test(u)),d=X(s,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(u=>R(u)).filter(u=>/\d\s*:\s*\d/.test(u)).slice(0,5);return{state:R(a.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(n)?n.split(":"):[],rounds:m.length>=2?m.slice(0,2):[],periods:d.map((u,c)=>({label:`${c+1} карта`,raw:u})),extras:[]}}return null}function Qe(s,r){if(Ae(s)!=="match")return null;let a=X(s,".breadcrumbs .breadcrumbs__item").map(f=>R(f)).filter(Boolean),n=R(s.querySelector(".event-breadcrumbs")),m=X(s,".marketbook-header--prematch .competitor-name").map(f=>R(f));if(m.length<2&&(m=X(s,".marketbook-header--live .competitors-desc__name").map(f=>R(f))),m.length<2&&(m=X(s,".match-card .match-card__team-name").map(f=>R(f))),m.length<2||!m[0]||!m[1])return null;let d=It(a[1]&&/киберспорт/i.test(a[0])?a[1]:"",a[0],n),u=/киберспорт/i.test(a[0]||"")?a.slice(2).join(", ")||n.split(",").slice(1).join(",").trim():a.slice(1).join(", "),c=[R(s.querySelector(".prematch-date")),R(s.querySelector(".prematch-time"))].filter(Boolean).join(" ")||R(s.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),h=eo(s);return{book:"Winline",id:en(r?.pathname),key:At(m[0],m[1]),home:m[0],away:m[1],sport:d,league:u,start:h?"":c,live:h,form:{home:Je(s.querySelector(".competitor-form--left")||s.createElement("div")),away:Je(s.querySelector(".competitor-form--right")||s.createElement("div"))},stats:io(lo(s),m[0],m[1]),url:r?.href||""}}function no(s,r){let a=[];for(let n of X(s,".bet-line")){if(_e(n))continue;let m=R(n.querySelector(".bet-line__market-name")),d=R(n.querySelector(".bet-line__period")),u=X(n,".odd-btn"),c=u.map((f,x)=>{let g=R(f.querySelector(".odd-btn__label")),y=X(f,"span").map(v=>yt(R(v))).find(Boolean)||null;return y?{el:f,odd:y,label:g||Fe(u.length,x,m),locked:!1}:null});if(c.length<2||c.some(f=>!f))continue;let h=R(n.querySelector(".coef-btn")).replace(/\s+/g," ");a.push(Ft({scope:"top",title:m,period:d,line:h,outcomes:c,anchor:n,eventKey:r}))}return a}function Fe(s,r,a){return/тотал/i.test(a)?["Меньше","Больше"][r]||"":s===3?["П1","Х","П2"][r]:s===2?["1","2"][r]:String(r+1)}function oo(s,r){let a=[];for(let n of X(s,".market")){let m=X(n,".market__row");if(!m.length)continue;let d=R(n.querySelector(".market-title")),u=m.map(h=>{let f=R(h.querySelector(".market__row-text"));return X(h,".market-row-btn").map(x=>{let g=yt(R(x.querySelector(".market-row-btn__coef")));if(!g||x.hasAttribute("disabled"))return null;let y=x.getAttribute("title")||R(x.querySelector(".market-row-btn__text"));return{el:x,odd:g,label:y.replace(/\s+/g," ").trim(),rowLabel:f,locked:!1}})}),{sets:c}=We(u);for(let h of c){let f=[...new Set(h.map(v=>v.rowLabel).filter(Boolean))],x=f.length<=1,g=x?"":(h[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],y=h.map(v=>({el:v.el,odd:v.odd,label:x?v.label:v.rowLabel||v.label,locked:!1}));a.push(Ft({scope:"board",title:d,period:x&&f[0]||"",line:g,kind:Vt(d,y.length),outcomes:y,anchor:n,eventKey:r}))}}return a}var so=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function ro(s){let r=X(s,".card__competitors .name .name, .half__names .name").map(n=>R(n));if(r.length<2)return null;let a=s.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:en(a),key:At(r[0],r[1]),home:r[0],away:r[1],href:a,live:/card--live/.test(s.className)||!!s.querySelector(".card__body-live"),time:R(s.querySelector(".header-left__time, .footer__time")),league:R(s.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:s}}function tn(s){let r=[];for(let a of X(s,".card")){if(_e(a))continue;let n=ro(a);if(n){for(let m of X(a,".card__body")){let d=R(m.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(m.className)?"отрезок":"");for(let u of X(m,".card__market")){let c=X(u,".coefficient-button");if(c.length<2)continue;let h=(so.find(([x])=>x.test(c[0].className))||[])[1]||"other",f=c.map((x,g)=>{let y=/--is-blank/.test(x.className)?null:Ne(x);return y?{el:x,odd:y,label:h==="total"?["Меньше","Больше"][g]:Fe(c.length,g,""),locked:/coefficient-button_locked/.test(x.className)}:null});f.some(x=>!x)||r.push(Ft({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[h]||"Рынок",period:/^матч$/i.test(d)?"":d,line:R(u.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:h,outcomes:f,event:n,anchor:a,eventKey:n.key}))}}for(let m of X(a,".half__coef-buttons")){let d=X(m,".coef-buttons__button"),u=d.map((c,h)=>{let f=Ne(c.querySelector(".button__coef-title")||c);return f?{el:c,odd:f,label:Fe(d.length,h,""),locked:!1}:null});u.length<2||u.some(c=>!c)||r.push(Ft({scope:"list",title:u.length===3?"Исход":"Победитель",kind:u.length===3?"1x2":"12",outcomes:u,event:n,anchor:a,eventKey:n.key}))}}}return r}function ao(s){if(!s?.body)return null;let r=h=>/^\d{1,3}\s?%$/.test(h),a=X(s,"h4").map(h=>{let f=[...h.nextElementSibling?.children||[]],x=R(f[0]),g=R(f[f.length-1]);return r(x)&&r(g)?{label:R(h),home:x.replace(/\s/g,""),away:g.replace(/\s/g,"")}:null}).filter(Boolean);if(!a.length)return null;let n=(s.body.innerText||s.body.textContent||"").replace(/\s+/g," "),m=[...n.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(h=>Number(h[1])),u=[...(n.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(h=>h[1].replace(/\s/g,""));return{names:R(s.querySelector("h3")).split(/\s+vs\s+/i).map(h=>h.trim()).filter(Boolean),rows:a,samples:m.slice(0,2),form:u.length>=2?{home:u[0],away:u[1]}:null}}function io(s,r,a){if(!s||s.names.length<2)return s;let n=Ut(s.names[0],r)+Ut(s.names[1],a);return Ut(s.names[0],a)+Ut(s.names[1],r)<=n?s:{names:[s.names[1],s.names[0]],rows:s.rows.map(d=>({label:d.label,home:d.away,away:d.home})),samples:s.samples.slice().reverse(),form:s.form?{home:s.form.away,away:s.form.home}:null}}function lo(s){let r=s.querySelector("iframe.stats__iframe");if(!r)return null;try{return ao(r.contentDocument)}catch{return null}}function co(s){let r=["one","two"].map(d=>s.querySelector(`.event-live-center__team-widget--${d}`));if(!r[0]||!r[1])return null;let a=d=>{let u=d;try{u=d.querySelector("iframe")?.contentDocument?.body||d}catch{u=d}let c=X(u,'[class*="player"]').filter(f=>!X(f,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(f.className)),h=[];for(let f of c){let x=R(f).split(" ").filter(Boolean),g=x.find(v=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test(v)&&/[A-Za-z]/.test(v));if(!g||h.some(v=>v.nick===g))continue;let y=x.filter(v=>/^\d{1,3}$/.test(v)).map(Number);h.push({nick:g,numbers:y.slice(0,4)})}return h.slice(0,5)},n=a(r[0]),m=a(r[1]);return n.length<3||m.length<3?null:{home:n,away:m}}var nn={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:Ae,readMatch:Qe,readEsportsWidget:co,observeTargets(s){try{let r=s.querySelector("iframe.stats__iframe")?.contentDocument?.body;return r?[r]:[]}catch{return[]}},collect(s,r){if(Ae(s)==="match"){let m=Qe(s,r)?.key||"";return[...no(s,m),...oo(s,m),...tn(s)]}return tn(s)}};var oe=(s,r)=>{try{return[...s.querySelectorAll(r)]}catch{return[]}};function on(s,r){let a=[s];if(r.shadow)for(let n of oe(s,r.shadow))n.shadowRoot&&a.push(n.shadowRoot);return a}var ne=s=>(s.defaultView?.innerWidth||0)>0,uo='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function po(s){let r=[],a=s.ownerDocument.createTreeWalker(s,4);for(;a.nextNode();){let n=a.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(n&&r.push(...n.split(" ")),r.length>5)return null}return r}function mo(s,r){if(r.label){let a=s.querySelector(r.label),n=a?a.textContent.replace(/[ \s]+/g," ").trim():"";if(n&&!/^\d{1,3}[.,]\d{1,3}$/.test(n))return n}if(r.cell&&r.headerRow){let a=s.closest(r.cell),n=a?.parentElement,m=n?.parentElement?.querySelector(r.headerRow);if(m&&m!==n){let d=[...n.children].indexOf(a),u=m.children[d]?.textContent.replace(/[ \s]+/g," ").trim()||"";if(u)return u.charAt(0).toUpperCase()+u.slice(1).toLowerCase()}}return""}function fo(s,r){if(!r.cell||!r.lineCell)return"";let a=s.closest(r.cell);for(;a&&(a=a.previousElementSibling);){if(!a.matches?.(r.lineCell))continue;let n=a.textContent.replace(/[ \s]+/g," ").trim().match(/([+\-−–]?\d+(?:[.,]\d+)?)\s*\)?\s*$/);return n?n[1].replace(",",".").replace(/[−–]/,"-"):""}return""}function ho(s,r){if(s.disabled||s.hasAttribute?.("disabled"))return null;let a=r.value&&s.querySelector(r.value)||s,n=po(a);if(!n||!n.length||n.join(" ").length>28)return null;let m=n[n.length-1];if(!(r.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(m))return null;let d=yt(m);if(!d||d>500||n.slice(0,-1).some(c=>/^\d{1,3}[.,]\d{1,3}$/.test(c)))return null;let u=n.slice(0,-1).join(" ");return!r.outcome&&/[+−]|^-/.test(u)?null:{odd:d,label:u}}function go(s,r){let a=[],n=new Set,m=on(s,r).flatMap(d=>oe(d,r.outcome||uo));for(let d of m){if(n.has(d)||r.skip&&d.closest(r.skip)||d.closest("#lz-root, #lz-marks"))continue;let u=ho(d,r);if(u){if(!r.outcome&&ne(s)){let c=d.getBoundingClientRect();if(c.width<26||c.width>320||c.height<16||c.height>90)continue}n.add(d),a.push({el:d,odd:u.odd,label:u.label||mo(d,r),line:fo(d,r),locked:!1})}}return r.outcome?a:a.filter(d=>!a.some(u=>u.el!==d.el&&u.el.contains(d.el)))}function bo(s,r,a){if(r.row)return s.closest(r.row);let n=s.parentElement;for(let m=0;m<6&&n&&n!==n.ownerDocument.body;m+=1){let d=a(n);if(d>=2&&d<=16){if(!ne(n.ownerDocument))return n;let u=n.getBoundingClientRect();if(u.height<=130&&u.width>=120)return n}if(d>16)break;n=n.parentElement}return null}var sn=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось|окко|okko|матч тв|match tv|кинопоиск|трансляция|видео|статистика|stats)$/i;function xo(s,r){let a=r.length,n=s;for(let x=0;x<7;x+=1){let g=n.parentElement;if(!g||r.some(_=>!g.contains(_.el))||g.querySelectorAll("*").length>400||[...g.querySelectorAll('button, a, td, [role="button"]')].filter(_=>!r.some($=>$.el===_||$.el.contains(_)||_.contains($.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(R(_))).length>a)break;n=g}let m=r[0].el,d=[],u=n.ownerDocument.createTreeWalker(n,4);for(;u.nextNode();){let x=u.currentNode;if(m.contains(x))break;let g=x.textContent.replace(/[ \s]+/g," ").trim();g.length<2||g.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(g)||/\d{1,2}:\d{2}|^\d|['′]$/.test(g)||sn.test(g)||d.push(g)}let c=d.slice(-2),h=d.map(x=>x.split(/\s+[—–-]\s+/)).filter(x=>x.length===2).pop();if(h&&(c=h),c.length<2||c[0]===c[1])return null;let f=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:At(c[0],c[1]),home:c[0],away:c[1],href:f,live:!1,time:"",league:"",card:n}}function yo(s,r,a){if(!r.names)return xo(s,a);let n=r.event&&s.closest(r.event)||s,m=[...new Set(oe(n,r.names).map(c=>R(c)).filter(Boolean))],d=m;if(m.length===1&&(d=m[0].split(/\s+[—–-]\s+/)),d.length<2||!d[0]||!d[1])return null;let u=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:At(d[0],d[1]),home:d[0],away:d[1],href:u,live:!1,time:"",league:"",card:n}}function vo(s){let a=String(s.title||"").replace(/^\s*(ставки на (матч|игру|бой)|матч)\s+/i,"").match(/^(.{2,40}?)\s+(?:[—–-]|x|vs|против)\s+(.{2,40}?)(?=\s*[:,|.(📅]|\s+[—–-]\s|\s+ставк|\s+прогноз|\s+коэффиц|\s+live\b|\s+лайв\b|\s+\d{1,2}(?:[./]\d|\s+[а-я]{3,})|$)/i);if(!a)return null;let n=[a[1].trim(),a[2].trim()];return n.some(m=>/ставк|контор|онлайн|букмекер|прогноз|коэффиц|!$/i.test(m))?null:n}function rn(s,r={}){function a(y,v){return r.matchUrl&&r.matchUrl.test(v?.pathname||"")||r.matchPage&&y.querySelector(r.matchPage)?"match":"list"}function n(y){let v=y.defaultView;if(!v||!ne(y))return[];let _=[];for(let $ of y.querySelectorAll("h1, h2, h3, div, span, p, a")){if($.children.length)continue;let C=R($);if(C.length<3||C.length>40||!/[A-Za-zА-Яа-яЁё]{3}/.test(C)||/\d{1,2}[:.]\d{2}/.test(C)||sn.test(C))continue;let I=$.getBoundingClientRect();if(!(I.top<60||I.top>450||I.width<30||parseFloat(v.getComputedStyle($).fontSize)<15)&&(_.includes(C)||_.push(C),_.length===2))break}return _}function m(y,v){if(a(y,v)!=="match")return null;let _=r.matchNames?oe(y,r.matchNames).map(C=>R(C)).filter(Boolean):[];if(_.length===1&&(_=_[0].split(/\s+[—–-]\s+/)),_.length<2&&(_=vo(y)||[]),_.length<2&&(_=n(y)),_.length<2)return null;let $=r.matchLeague?R(y.querySelector(r.matchLeague)):"";return{book:s.name,id:(String(v?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:At(_[0],_[1]),home:_[0],away:_[1],sport:It(v?.pathname,$,y.title,R(y.querySelector('[class*="breadcrumb" i], nav[aria-label*="крошк" i]'))),league:$,start:"",live:/(^|\/)live(\/|$)/i.test(v?.pathname||"")?!0:null,form:{home:"",away:""},url:v?.href||""}}function d(y,v){return!y||!v?"":v.startsWith("attr:")?String(y.getAttribute(v.slice(5))||"").trim():R(y.querySelector(v))}function u(y,v){if(!ne(v))return[y];let _=y.map(C=>{let I=C.el.getBoundingClientRect();return{cell:C,top:I.top,left:I.left}}).sort((C,I)=>Math.abs(C.top-I.top)>8?C.top-I.top:C.left-I.left),$=[];for(let C of _){let I=$[$.length-1];I&&Math.abs(I.top-C.top)<=8?I.cells.push(C.cell):$.push({top:C.top,cells:[C.cell]})}return $.map(C=>C.cells)}let c=[[/^(п1|1)\/(х|x|ничья)\/(п2|2)$/i,"1x2"],[/^(п1|1)\/(п2|2)$/i,"12"],[/^(1х|1x)\/12\/(х2|x2)$/i,"dc"]],h=y=>(c.find(([v])=>v.test(y.join("/").toLowerCase()))||[])[1]||"other";function f(y,v){let _=a(y,v),$=_==="match"&&r.match?{...r,...r.match}:r;return x(y,v,_,$)}function x(y,v,_,$){let C=go(y,$);if(C.length<2)return[];let I=new Set(C.map(M=>M.el)),P=M=>{let N=0;for(let O of I)M.contains(O)&&(N+=1);return N},E=new Map;for(let M of C){let N=bo(M.el,$,P);N&&(E.has(N)||E.set(N,[]),E.get(N).push(M))}let W=_==="match"?m(y,v):null,F=[];for(let[M,N]of E){let O=_==="match"?null:yo(M,$,N),j=$.group?M.closest($.group):null,D=d(j,$.groupTitle),G=d(j,$.groupPeriod),U=$.visualRows?u(N,y):[N],Q=0;for(let Y of U)for(let nt of Ke(Y).sets){let J=Q===0,ot=nt.length,ht=ot===3?["П1","Х","П2"]:["1","2"],zt=nt.map((ct,ut)=>({...ct,label:ct.label||ht[ut]||String(ut+1)})),xt=J&&ot===3?"Исход":J?"Победитель":`Рынок ${Q+1}`,pt=J?ot===3?"1x2":"12":"other";D&&(xt=D,pt=Vt(D,ot),pt==="other"&&(pt=h(zt.map(ct=>ct.label)))),ot===3&&zt.every(ct=>/\sили\s/i.test(ct.label))&&(pt="dc"),F.push(Ft({scope:_==="match"?"board":"list",title:xt,period:G,line:nt[0].line&&nt.every(ct=>ct.line===nt[0].line)?nt[0].line:"",kind:pt,outcomes:zt,event:O,anchor:M,eventKey:O?.key||W?.key||`row${F.length}`})),Q+=1}}return F}let g=y=>on(y,r).slice(1);return{id:s.id,name:s.name,hosts:s.hosts,generic:!0,pageType:a,readMatch:m,collect:f,observeTargets:g,readEsportsWidget:()=>null}}var an={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]',match:{group:'[class*="market-group-box--"]',groupTitle:'[class*="header--"] [class*="text--"]',label:'[class*="text--"]',cell:'[class*="cell--"]',headerRow:'[class*="header-row--"]',lineCell:'[class*="_align-left--"]'}},ln={fonbet:an,pari:an,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd, .dg_euv_stake",value:".dg_euv_stake_factor_new",row:".euv_event_home, .dg_euv_stake_grid",names:".euv_event_name_team",integers:!0,matchUrl:/\/sport\/event-details\//,matchNames:"h1"},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name",matchUrl:/\/su\/betting\/.*vs.*\d{5,}/i},leon:{matchUrl:/\/bets\/.+\/\d{10,}-/},olimp:{matchUrl:/\/line\/[^/]+\/[^/]+-\d{4,}\/[^/]+/,match:{outcome:'[data-testid^="bet-button"]',row:'[data-testid="accordion-content"]',group:'[data-testid="accordion"]',groupTitle:'[class*="title--"]',visualRows:!0}},betcity:{matchUrl:/\/ru\/(live|line)\/[^/]+\/\d+\/\d+/},betboom:{matchUrl:/\/sport\/(?:live\/)?[^/]+\/\d+\/\d+\/\d+/},liga:{matchUrl:/\/sports\/[^/]+\/.+-id-\d+/,match:{outcome:"button[outcomeid]",row:"[data-t-market]",group:"[data-t-market]",groupTitle:"attr:data-t-market",groupPeriod:'[class*="header__description"]',visualRows:!0}}};function cn(s){let r=Ge(s);return r?r.id==="winline"?{adapter:nn,book:r}:{adapter:rn(r,ln[r.id]||{}),book:r}:null}var se=`/* Цвета, шрифт и радиусы панели — из design/tokens.json (node tools/tokens.mjs). Блоки между метками руками не править. */
:host {
  /* tokens:light */
  --lz-accent: #5b4be6;
  --lz-accent-strong: #4a3bd1;
  --lz-accent-soft: rgba(91, 75, 230, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0b8a4d;
  --lz-pos-soft: rgba(11, 138, 77, 0.14);
  --lz-neg: #c93636;
  --lz-neg-soft: rgba(201, 54, 54, 0.12);
  --lz-warn: #b45309;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6fa;
  --lz-surface-2: #eef0f5;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #555c6b;
  --lz-faint: #666b7f;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  /* /tokens */
  color-scheme: light;
}

:host([data-theme="dark"]) {
  /* tokens:dark */
  --lz-accent: #8f82ff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(143, 130, 255, 0.18);
  --lz-accent-ink: #0f1017;
  --lz-pos: #45d08f;
  --lz-pos-soft: rgba(69, 208, 143, 0.16);
  --lz-neg: #ff7676;
  --lz-neg-soft: rgba(255, 118, 118, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #171a23;
  --lz-surface: #1f2330;
  --lz-surface-2: #272b34;
  --lz-border: #2c3040;
  --lz-text: #eef0f6;
  --lz-muted: #a4a8bb;
  --lz-faint: #8e92a8;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  /* /tokens */
  color-scheme: dark;
}
`;var un=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}

.tip-foot .pos {
  color: var(--lz-pos);
  font-weight: 600;
}
`;function e(s,r,...a){let[n,...m]=s.split("."),d=document.createElement(n||"div");m.length&&(d.className=m.join(" "));for(let[u,c]of Object.entries(r||{}))if(!(c==null||c===!1))if(u==="class")d.className=[d.className,c].filter(Boolean).join(" ");else if(u==="style")d.style.cssText=c;else if(u==="text")d.textContent=c;else{if(u==="html")throw new Error("html запрещён");u.startsWith("data-")||u.startsWith("aria-")||u==="role"||u==="title"||u==="type"||u==="href"||u==="target"||u==="rel"||u==="placeholder"||u==="value"||u==="for"||u==="name"||u==="maxlength"||u==="autocomplete"||u==="spellcheck"||u==="tabindex"?d.setAttribute(u,c===!0?"":String(c)):u==="disabled"||u==="hidden"||u==="checked"||u==="selected"?d[u]=!!c:d[u]=c}return pn(d,a),d}function pn(s,r){for(let a of r)a==null||a===!1||(Array.isArray(a)?pn(s,a):s.appendChild(a instanceof Node?a:document.createTextNode(String(a))))}var dn="http://www.w3.org/2000/svg";function rt(s,r=16){let a=document.createElementNS(dn,"svg");a.setAttribute("viewBox","0 0 20 20"),a.setAttribute("width",r),a.setAttribute("height",r),a.setAttribute("fill","none"),a.setAttribute("stroke","currentColor"),a.setAttribute("stroke-width","1.7"),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),a.setAttribute("aria-hidden","true");for(let n of $o[s]||[]){let m=document.createElementNS(dn,"path");m.setAttribute("d",n),a.appendChild(m)}return a}var $o={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"]};function mn(){let s=document.createElement("div");s.id="lz-marks",s.style.cssText="position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;overflow:hidden!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let r=s.attachShadow({mode:"open"});r.appendChild(e("style",{text:se+un}));let a=e("div.layer"),n=e("div.tip");r.append(a,n);let m=new Map,d=new Set,u=0,c=null,h=null,f=new IntersectionObserver(M=>{for(let N of M)N.isIntersecting?d.add(N.target):(d.delete(N.target),m.get(N.target)?.node.classList.remove("on"));g()},{rootMargin:"120px"});function x(){s.isConnected||document.documentElement.appendChild(s)}function g(){u||(u=requestAnimationFrame(()=>{u=0,_()}))}let y=(M,N)=>{for(let O=N;O;O=O.parentNode||O.host)if(O===M)return!0;return!1};function v(M,N){let O=N.left+N.width/2,j=N.top+N.height/2;if(O<0||j<0||O>window.innerWidth||j>window.innerHeight)return!1;let D=document.elementFromPoint(O,j);for(;D?.shadowRoot?.elementFromPoint;){let G=D.shadowRoot.elementFromPoint(O,j);if(!G||G===D)break;D=G}return!!D&&D!==M&&!y(M,D)&&!y(D,M)}function _(){for(let M of d){let N=m.get(M);if(!N)continue;if(!M.isConnected){$(M);continue}let O=M.getBoundingClientRect();if(O.width<6||O.height<6||v(M,O)){N.node.classList.remove("on");continue}let j=Math.round(O.left),D=Math.round(O.top),G=Math.round(O.width),U=Math.round(O.height);(N.x!==j||N.y!==D)&&(N.node.style.transform=`translate3d(${j}px, ${D}px, 0)`,N.x=j,N.y=D),(N.w!==G||N.h!==U)&&(N.node.style.width=`${G}px`,N.node.style.height=`${U}px`,N.w=G,N.h=U,N.node.classList.toggle("small",U<26)),N.node.classList.add("on")}c&&I()}function $(M){let N=m.get(M);N&&(f.unobserve(M),d.delete(M),N.node.remove(),m.delete(M))}function C(M){x();let N=new Map;for(let O of M)O.el?.isConnected&&N.set(O.el,O);for(let O of[...m.keys()])N.has(O)||$(O);for(let[O,j]of N){let D=m.get(O);if(!D){let U=e("div.mark"),Q=parseFloat(getComputedStyle(O).borderTopLeftRadius);U.style.borderRadius=`${Number.isFinite(Q)&&Q>0?Math.min(Q,16):6}px`;let Y=e("span.chip");U.appendChild(Y),a.appendChild(U),D={node:U,chip:Y,sig:""},m.set(O,D),f.observe(O)}let G=`${j.frame?1:0}|${j.selected?1:0}|${j.tone||""}|${j.chip||""}`;G!==D.sig&&(D.sig=G,D.node.classList.toggle("frame",!!j.frame),D.node.classList.toggle("selected",!!j.selected),D.node.classList.toggle("pos",j.tone==="pos"&&!!j.frame),D.chip.hidden=!j.chip,D.chip.textContent=j.chip||"",D.chip.className=`chip${j.tone&&j.tone!=="accent"?" "+j.tone:""}`)}g()}function I(){if(!c?.isConnected)return E();let M=c.getBoundingClientRect(),N=264,O=n.offsetHeight||140,j=M.left+M.width/2-N/2;j=Math.max(8,Math.min(j,window.innerWidth-N-8)),h&&j+N>h.left-8&&j<h.right&&(j=Math.max(8,h.left-N-10));let D=M.bottom+10;D+O>window.innerHeight-8&&(D=M.top-O-10),D<8&&(D=8),n.style.transform=`translate3d(${Math.round(j)}px, ${Math.round(D)}px, 0)`}function P(M,N){x(),c=M,n.replaceChildren(N),I(),n.classList.add("on")}function E(){c=null,n.classList.remove("on")}function W(M){h=M}function F(M){s.setAttribute("data-theme",M)}return window.addEventListener("scroll",g,{capture:!0,passive:!0}),window.addEventListener("resize",g,{passive:!0}),setInterval(()=>{m.size&&!document.hidden&&g()},700),{set:C,schedule:g,showTip:P,hideTip:E,setTheme:F,setAvoid:W,get tipTarget(){return c},count:()=>m.size}}var fn=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 72px minmax(60px, max-content);
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  white-space: nowrap;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.partner { margin-top: 8px; }
.partner-text { font-size: 12px; margin-bottom: 4px; }
.partner-links { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
.partner-links a.btn { text-decoration: none; }
.gain { margin-top: 8px; font-size: 12px; color: var(--lz-text); }
.gain b { color: var(--lz-pos); }
td.name .partner-links { margin-top: 3px; }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.card.update { font-size: 12.5px; }
.card.update b { color: var(--lz-accent); }
/* Строка без номера (факторы модели, факты о составах) занимает обе колонки, иначе текст ломается по словам в узкой. */
.facts li > span:only-child { grid-column: 1 / -1; }
.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  /* 18+ и предупреждение о зависимости должны читаться: не бледный, а обычный второстепенный цвет. */
  color: var(--lz-muted);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;var ie=s=>Math.min(.999,Math.max(.001,s));function Le(s,r,a=0,n=0){let m=Math.ceil(r/2),d=new Map,u=(c,h)=>{if(c>=m)return 1;if(h>=m)return 0;let f=c*16+h;return d.has(f)||d.set(f,s*u(c+1,h)+(1-s)*u(c,h+1)),d.get(f)};return u(a,n)}function le(s,r){let a=.001,n=.999;for(let m=0;m<50;m++){let d=(a+n)/2;s(d)<r?a=d:n=d}return(a+n)/2}function zo(s,r){let a=ie(s);return Math.ceil(r/2)<=1?a:le(n=>Le(n,r),a)}function ae(s,r,a,n=new Map){if(r>=4)return[1,0];if(a>=4)return[0,0];if(r===3&&a===3)return[0,1];let m=r*8+a;if(!n.has(m)){let[d,u]=ae(s,r+1,a,n),[c,h]=ae(s,r,a+1,n);n.set(m,[s*d+(1-s)*c,s*u+(1-s)*h])}return n.get(m)}function hn(s){let[r,a]=ae(s,0,0);return r/(1-a)}function re(s,r,a){if(r=Math.max(0,Math.floor(r)),a=Math.max(0,Math.floor(a)),Math.min(r,a)>=12){let d=Math.floor((Math.min(r,a)-12)/3),u=r-12-3*d,c=a-12-3*d,[h,f]=ae(s,u,c);return h+f*hn(s)}let n=new Map,m=(d,u)=>{if(d>=13)return 1;if(u>=13)return 0;if(d===12&&u===12)return hn(s);let c=d*32+u;return n.has(c)||n.set(c,s*m(d+1,u)+(1-s)*m(d,u+1)),n.get(c)};return m(r,a)}function So(s){return le(r=>re(r,0,0),ie(s))}var _o=24,Wt=Array.from({length:101},(s,r)=>(r+.5)/101),gn=null;function ce(s,r){let a=Wt.map(u=>(s-1)*Math.log(u)+(r-1)*Math.log(1-u)),n=Math.max(...a),m=a.map(u=>Math.exp(u-n)),d=m.reduce((u,c)=>u+c,0);return m.map(u=>u/d)}var bn=()=>Wt;function xn(s,r,a=0,n=0){if(!Number.isFinite(r))return re(s,a,n);let m=ce(s*r+a,(1-s)*r+n);return!a&&!n?(gn||=Wt.map(d=>re(d,0,0)),m.reduce((d,u,c)=>d+u*gn[c],0)):m.reduce((d,u,c)=>d+u*re(Wt[c],a,n),0)}function No(s,r){return Number.isFinite(r)?le(a=>xn(a,r),ie(s)):So(s)}var Ao={cs:8,dota:1/0};function yn(s,r,a,n=0,m=0){return Number.isFinite(r)?ce(s*r+n,(1-s)*r+m).reduce((u,c,h)=>u+c*Le(Wt[h],a,n,m),0):Le(s,a,n,m)}function Te(s,r,a){return Number.isFinite(a)?le(n=>yn(n,a,r),ie(s)):zo(s,r)}function Fo(s,r){let a=Math.max(s,r),n=Math.min(s,r);return n<12?a>=13:a-12-3*Math.floor((n-12)/3)>=4}function vn({pre:s,bo:r=3,maps:a=[0,0],rounds:n=null,game:m="cs",kappa:d=_o,kappaMap:u=Ao[m]??1/0}){let c=Math.ceil(r/2),[h,f]=(a||[0,0]).map(C=>Math.max(0,Number(C)||0));if(h>=c)return{p:1,map:null};if(f>=c)return{p:0,map:null};let x=Te(s,r,u),g=(C,I)=>yn(x,u,r,C,I),[y,v]=Array.isArray(n)&&n.length===2?n.map(Number):[NaN,NaN];if(!Number.isFinite(y)||!Number.isFinite(v)||y===0&&v===0||Fo(y,v))return{p:g(h,f),map:null};let _=Number.isFinite(u)?(x*u+h)/(u+h+f):x,$=xn(No(_,d),d,y,v);return{p:$*g(h+1,f)+(1-$)*g(h,f+1),map:$}}var Lo={mirage:"Mirage",inferno:"Inferno",nuke:"Nuke",ancient:"Ancient",anubis:"Anubis",dust2:"Dust2",vertigo:"Vertigo",train:"Train",overpass:"Overpass",cache:"Cache",cobblestone:"Cobblestone",tuscan:"Tuscan"};var kn=s=>{let r=String(s||"").replace(/^de_/,"").toLowerCase();return Lo[r]||(r?r[0].toUpperCase()+r.slice(1):"")};var To=s=>(s||[]).filter(r=>r.type==="pick"||r.type==="decider").map((r,a)=>({n:a+1,map:r.map,pick:r.type==="decider"?"":r.team}));function wn(s,r=null){let a=f=>String(f||"").replace(/^de_/,"").toLowerCase(),n=new Map((r?.perMap||[]).map(f=>[a(f.name),f])),m=f=>new Set(((r?.profiles||[])[f]?.bestMaps||[]).map(x=>a(x.map))),d={home:m(0),away:m(1)},u=(f,x)=>({map:f,title:kn(f),p:n.get(f)?.p??null,strong:["home","away"].filter(g=>d[g].has(f)),...x}),c=To(s?.veto);if(c.length)return{known:!0,rows:c.map(f=>u(f.map,{n:f.n,pick:f.pick})),bans:(s.veto||[]).filter(f=>f.type==="ban").map(f=>({map:f.map,title:kn(f.map),team:f.team}))};let h=[...n.values()].filter(f=>f.w>0).sort((f,x)=>x.w-f.w).slice(0,3).map((f,x)=>u(a(f.name),{n:x+1,pick:"",w:f.w}));return h.length?{known:!1,rows:h,bans:[]}:null}var $n="Как Линза зарабатывает",Co="Платные тарифы: больше разборов матчей в день.",Oo=["Партнёрские ссылки контор: если вы откроете контору по ссылке из Линзы и зарегистрируетесь, контора заплатит Линзе. Вам это ничего не стоит.","На сравнение ссылки не влияют: лучшая цена выбирается только по коэффициентам и показывается, даже если у этой конторы нет нашей ссылки. На сайте самой конторы ссылок нет."],Mn=s=>[Co,...s?Oo:[]];var V=(s,r=0)=>kt(s,r),ft=s=>`${s>0?"+":s<0?"−":""}${Math.abs(s).toFixed(1)}`;function zn({bus:s,actions:r,brand:a}){let n=document.createElement("div");n.id=s.rootId,n.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let m=n.attachShadow({mode:"open"});m.appendChild(e("style",{text:se+fn}));let d=e("span.dot"),u=e("button.fab",{type:"button","data-act":"toggle",title:`${a.name}: открыть панель`,"aria-label":`${a.name}: открыть панель`},rt("lens",18),e("span",{text:a.name}),d),c=e("div.tabs",{role:"tablist"}),h=e("div.body"),f=e("div.foot"),x=e("small"),g=e("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),y=e("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),v=e("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},rt("gear")),_=e("div.head",{},e("div.brand",{},e("span.logo",{},rt("lens",15)),e("span",{text:a.name}),x),e("span.grow"),y,g,v,e("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},rt("close"))),$=e("section.panel",{hidden:!0,role:"dialog","aria-label":a.name},_,c,h,f);m.append(u,$);let C=()=>{n.isConnected||document.documentElement.appendChild(n)};C(),new MutationObserver(C).observe(document.documentElement,{childList:!0});let I="",P=null,E=new Map,W=t=>{for(let o of t.composedPath()){if(o===n)break;if(o?.dataset?.act)return o}return null},F=null;s.on("ui:pointerdown",t=>{if(t.button!==0)return;let o=t.composedPath(),l=o.includes(u),p=o.includes(_)&&!o.some(w=>w?.dataset?.act);if(!l&&!p)return;let k=l?u:$,b=k.getBoundingClientRect();F={target:k,key:l?"fab":"panel",sx:t.clientX,sy:t.clientY,ox:b.left,oy:b.top,moved:!1},s.setDragging(!0)}),s.on("drag:move",t=>{if(!F)return;let o=t.clientX-F.sx,l=t.clientY-F.sy;!F.moved&&Math.hypot(o,l)<5||(F.moved=!0,F.target.classList.add("dragging"),N(F.target,F.ox+o,F.oy+l))}),s.on("drag:end",()=>{if(F){if(s.setDragging(!1),F.target.classList.remove("dragging"),F.moved){let t=F.target.getBoundingClientRect();r.savePosition(F.key,{left:t.left,top:t.top}),M=!0,setTimeout(()=>{M=!1},60)}F=null}});let M=!1;function N(t,o,l){let p=t.offsetWidth||120,k=t.offsetHeight||40,b=Math.max(6,Math.min(o,window.innerWidth-p-6)),w=Math.max(6,Math.min(l,window.innerHeight-Math.min(k,60)-6));t.style.left=`${Math.round(b)}px`,t.style.top=`${Math.round(w)}px`,t.style.right="auto"}s.on("ui:click",t=>{if(M)return;let o=W(t);if(!o||o.disabled)return;t.preventDefault();let l=o.dataset.act;if(l==="toggle")return Bt();if(l==="close")return Nt();let p=r[l];p&&p(o.dataset.arg,o,m)}),s.on("ui:keydown",t=>{if(t.key==="Escape"&&Nt(),t.key==="Enter"){let o=t.composedPath()[0];o?.dataset?.enter&&r[o.dataset.enter]?.(o.value,o,m)}});let O=(t,o)=>e("span.form",{},[...String(t||"")].slice(0,5).map(l=>e(`i${l==="В"?".w":l==="П"?".l":""}`,{text:l,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[l]||""})),o);function j(t,o=null){let l=t.live,p=l?e("div.center",{},l.score?.length===2?e("span.score",{text:`${l.score[0]} : ${l.score[1]}`}):null,e("span.badge.live",{text:l.state||"Лайв"})):e("div.center",{},e("span",{text:t.start||"до матча"})),k=l?.periods?.length?e("div.periods",{text:l.periods.map(w=>w.raw?`${w.label} ${w.raw}`:`${/^\d+$/.test(w.label)?`${w.label}-й отрезок`:w.label} ${w.home}:${w.away}`).join(" · ")}):null,b=l?.extras?.length?e("div.periods",{text:l.extras.map(w=>`${w.kind} ${w.home}:${w.away}`).join(" · ")}):null;return e("div.card",{},e("div.league",{text:t.league||t.sportName||"",title:t.league||""}),o?.stage?.title?e("div.periods",{text:`${o.stage.title}${o.stage.playoff?" · плей-офф":""}${o.lan===!0?" · LAN":o.lan===!1?" · онлайн":""}`}):null,e("div.teams",{},e("div.team",{},e("b",{text:t.home,title:t.home}),t.form?.home?O(t.form.home):null),p,e("div.team.away",{},e("b",{text:t.away,title:t.away}),t.form?.away?O(t.form.away):null)),k,b)}function D(t){let o=t.rows.some(l=>Number.isFinite(l.model));return e("div.card",{},e("div.kicker",{},e("span",{text:t.title}),Number.isFinite(t.margin)?e("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${V(t.margin,1)}`}):null),t.rows.map(l=>{let p=o&&Number.isFinite(l.model)?(l.model-l.fair)*100:null;return e("div.prob",{},e("span.name",{text:l.name,title:l.name}),e("span.odd",{text:Z(l.odd)}),e("span.track",{},e("i",{style:`width:${Math.round((l.fair||0)*100)}%`}),Number.isFinite(l.model)?e("u",{style:`left:${Math.round(l.model*100)}%`}):null),e("span.pct",{},V(o&&Number.isFinite(l.model)?l.model:l.fair),p!=null&&Math.abs(p)>=.05?e(`small${p>0?".pos":".neg"}`,{text:`${ft(p)} п.п.`}):null))}),e("div.legend",{},e("span",{text:"шанс по линии без маржи"}),o?e("span.model",{text:"оценка модели"}):null))}function G(t){let o=t.analysis;if(o.status==="loading")return e("div.card",{},e("div.kicker",{},e("span",{text:"Разбор"}),e("span.badge.accent",{text:"собираю данные"})),e("div.steps",{},o.steps.map((w,z)=>e(`div.step${z===o.steps.length-1?".now":".done"}`,{},e("span.mark"),e("span",{text:w})))));if(o.status==="error")return e("div.card",{},e("div.note.warn",{},rt("alert"),e("span",{text:o.error})),e("div.row",{style:"margin-top:10px"},o.needKey?e("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},rt("gear"),"Открыть настройки"):null,e("button.btn.ghost",{type:"button","data-act":"report"},"Сообщить об ошибке")));if(o.status!=="done"||!o.result)return null;let l=o.result,p={home:t.match?.home,away:t.match?.away,draw:"ничья"}[l.lean],k=l.proposed?.lean&&l.proposed.lean!=="none"&&l.lean==="none"?{name:{home:t.match?.home,away:t.match?.away,draw:"ничью"}[l.proposed.lean],by:Math.abs(l.proposed.shift[l.proposed.lean]||0)}:null,b=new Map((l.facts||[]).map(w=>[w.id,w]));return e("div.card",{},e("div.kicker",{},e("span",{text:"Разбор"}),e("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${l.confidence||"низкая"}`})),e("div.verdict",{text:p?`Данные сдвигают оценку в сторону: ${p}`:k?`Данные слегка склоняют в сторону: ${k.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),k?e("div.note",{style:"margin-bottom:10px"},rt("info"),e("span",{text:`Модель предложила сдвиг на ${k.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,l.summary?e("p.summary",{text:l.summary}):null,l.factors?.length?e("ul.factors",{},l.factors.map(w=>e(`li.factor${w.side==="home"?".home":w.side==="away"?".away":""}`,{},e("div",{},e("p",{text:w.text}),e("div.src",{},(w.facts||[]).map(z=>b.get(z)).filter(Boolean).map(z=>e("span.tag",{text:`${z.id} · ${z.source}`,title:z.text}))))))):null,l.scenarios?.length?e("div",{style:"margin-top:10px"},e("div.kicker",{},e("span",{text:"Как может пойти игра"})),e("ul.facts",{},l.scenarios.map(w=>e("li",{},e("span",{text:w.text})," ",e("em",{text:`— ${w.facts.join(", ")}`}))))):null,l.risks?.length?e("div.note",{style:"margin-top:10px"},rt("info"),e("span",{text:`Что может сломать вывод: ${l.risks.join(" ")}`})):null,(l.full?.sections||[]).some(w=>w?.lines?.length)?e("details",{"data-key":"full",open:E.get("full")||!1,style:"margin-top:8px"},e("summary",{text:"Показать полностью: итог по всем рынкам, профили, факты"}),(l.full.sections||[]).filter(w=>w?.title&&w.lines?.length).map(w=>e("div",{style:"margin-top:6px"},e("div.kicker",{},e("span",{text:w.title})),e("ul.facts",{},w.lines.map(z=>e("li",{text:z})))))):null,e("div.row",{style:"margin-top:8px"},e("button.btn.ghost.small",{type:"button","data-act":"report",title:"Разбор выглядит неправильно — сообщить разработчику"},"Сообщить об ошибке")),e("details",{"data-key":"facts",open:E.get("facts")||!1},e("summary",{text:`Данные, на которых стоит разбор (${l.facts?.length||0})`}),e("ul.facts",{},(l.facts||[]).map(w=>e("li",{},e("b",{text:w.id}),e("span",{},w.text," ",e("em",{text:`— ${w.source}`})))))),U(l.research),e("div.hint",{style:"margin-top:8px",text:l.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function U(t){return t?t.skipped==="plan"?e("div.hint",{style:"margin-top:8px",text:"Поиск превью, травм и судей в прессе — в тарифах «Макс» и VIP."}):t.sources?.length?e("div.hint",{style:"margin-top:8px"},`${t.note} Прочитано: `,t.sources.map((o,l)=>[l?", ":"",e("a",{href:o.url,target:"_blank",rel:"noopener",text:o.domain})])):t.note?e("div.hint",{style:"margin-top:8px",text:t.note}):null:null}function Q(t){let o=t.compare?.consensus||t.analysis?.result?.consensus||t.consensus;if(!o?.consensus||!t.line?.rows?.length)return null;let l=o.consensus.length===2&&t.line.rows.length===3;if(!l&&t.line.rows.length!==o.consensus.length)return null;let p=l?t.line.overtime:null,k=p?p.rows:l?[t.line.rows[0],t.line.rows[2]].map(z=>({...z,odd:null,fair:null})):t.line.rows,b=t.match?.sport==="mma",w=o.updated?new Date(o.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"";return e("div.card",{},e("div.kicker",{},e("span",{text:l?b?"Прогноз рынка · без ничьей":"Прогноз рынка · с овертаймом":"Прогноз рынка"}),e("span.badge",{text:`${o.count} контор`})),k.map((z,S)=>{let A=o.consensus[S],T=z.odd?z.odd*A-1:0,L=Number.isFinite(z.fair)?(z.fair-A)*100:0;return e("div.prob",{},e("span.name",{text:z.name,title:z.name}),e("span.odd",{text:Z(1/A),title:"Кэф без маржи по консенсусу"}),e("span.track",{},e("i",{style:`width:${Math.round(A*100)}%`}),e("u",{style:`left:${Math.round((z.fair||0)*100)}%`,title:"Шанс по линии этой конторы"})),e("span.pct",{},V(A),T>.005?e("small.pos",{text:`кэф выше рынка ${ft(T*100)}%`}):Math.abs(L)>=2?e(`small${L>0?".neg":""}`,{text:`${ft(L)} п.п. к рынку`,title:L>0?"Контора оценивает этот исход выше рынка — кэф ниже":"Контора оценивает этот исход ниже рынка"}):null))}),e("div.legend",{},e("span",{text:"шанс по консенсусу"}),l&&!p?null:e("span.model",{text:p?`шанс по рынку «${p.title}» этой конторы`:"шанс по линии этой конторы"})),e("div.hint",{style:"margin-top:8px",text:`${l&&b?"Ничьи в ММА — доли процента, поэтому рынок двухисходный; ничья этой конторы не сравнивается. ":l?p?"Победитель с учётом овертайма и буллитов: сравнивается с одноимённым рынком этой конторы, а не с трёхисходным. ":"Победитель с учётом овертайма и буллитов; ничья в основное время сюда не входит, поэтому с трёхисходным рынком конторы напрямую не сравнивается. ":""}${o.pinnacle?`Pinnacle ${o.pinnacle.map(Z).join(" / ")}. `:""}${o.betfair?`Betfair ${o.betfair.map(Z).join(" / ")}. `:""}Цены ${o.count} контор без маржи${w?`, обновлено в ${w}`:""}${o.stale?" (данные старше шести часов)":""}. На проверке 1915 матчей фаворит по консенсусу выиграл 54% — точнее этого прогноза у нас нет.`}))}let Y=new Map;function nt(t,o){let l=t.match?.live;if(!l||!["cs","dota"].includes(o.game)||l.score?.length!==2)return null;let p=l.score.map(Number),k=Number(o.bo)||3;if(p.some(z=>!Number.isFinite(z)||z<0)||Math.max(...p)>=Math.ceil(k/2))return null;let b=o.game==="cs"&&l.rounds?.length===2&&l.rounds.every(z=>/^[0-9]{1,2}$/.test(String(z)))?l.rounds.map(Number):null,w=`${o.p1}|${k}|${p}|${b}`;return Y.has(w)||(Y.size>50&&Y.clear(),Y.set(w,{...vn({pre:o.p1,bo:k,maps:p,rounds:b,game:o.game}),bo:k,maps:p,rounds:b})),Y.get(w)}function J(t){let o=t.compare?.model||t.analysis?.result?.model||t.model;if(!o?.p1||!t.line?.rows?.length)return null;let l=t.line.rows.length===3&&(o.overtime||o.drawless);if(!l&&t.line.rows.length!==2)return null;let p=l?t.line.overtime:null,k=p?p.rows:l?[t.line.rows[0],t.line.rows[2]].map(B=>({...B,fair:null})):t.line.rows,b=nt(t,o),w=b?[b.p,1-b.p]:[o.p1,o.p2],z=o.sport==="tennis"?`Рейтинги Линзы по покрытиям, форме, нагрузке и очным встречам (архив ATP/WTA, ${o.samples} матчей у менее опытного игрока)`:o.sport==="hockey"?`Рейтинги Линзы по матчам КХЛ: атака и оборона команд, дом, усталость (приложение КХЛ, 2023–2026; ${o.samples} игр у менее опытной команды)${o.regulation?`. Основное время: ${Math.round(o.regulation.p1*100)}% / ничья ${Math.round(o.regulation.px*100)}% / ${Math.round(o.regulation.p2*100)}%`:""}`:o.sport==="mma"?`Рейтинги Линзы по боям UFC: Elo с весом досрочных побед, форма, возраст, размах рук, простой (ESPN; ${o.samples} боёв в UFC у менее опытного бойца)`:o.sport==="basketball"?`Рейтинги Линзы по разнице очков, дому и усталости (НБА, Евролига, Еврокубок, АСВ, Серия А, Адриатическая лига, ВТБ, Лига чемпионов FIBA; ${o.samples} игр у менее опытной команды)`:o.game==="dota"?`Рейтинги Линзы по матчам, форме и очным встречам (bo3.gg, ${o.samples} ${gt(o.samples,"матч","матча","матчей")} у менее опытной команды)`:`Рейтинги Линзы по картам, форме и очным встречам (bo3.gg, ${o.samples} ${gt(o.samples,"карта","карты","карт")} у менее опытной команды)`,S=o.backtest,A=(S?.calibration||[]).filter(B=>[60,70,80].includes(B.threshold)),T=S?.labels?.[o.confidence],L=(T?`С подписью «${o.confidence}» на проверке сбывалось ${V(T.hit/100,1)} (${T.n} ${gt(T.n,"матч","матча","матчей")}). `:"")+(A.length?`На проверке ${S.test} сыгранных матчей: ${A.map(B=>`при уверенности ≥${B.threshold}% сбывалось ${B.hit}%`).join(", ")}`:S?`На проверке ${S.test} матчей угадано ${Math.round(S.acc*100)}%`:"Точность ещё измеряется");return e("div.card",{},e("div.kicker",{},e("span",{text:b?`Модель по счёту · bo${b.bo}`:l?o.drawless?"Прогноз модели · без ничьей":"Прогноз модели · с овертаймом":"Прогноз модели"}),e("span.badge",{text:b?`до матча: ${o.confidence}`:`уверенность: ${o.confidence}`})),k.map((B,K)=>{let H=w[K],st=Number.isFinite(B.fair)?(H-B.fair)*100:0;return e("div.prob",{},e("span.name",{text:B.name,title:B.name}),e("span.odd",{text:Z(1/H),title:"Кэф без маржи по модели"}),e("span.track",{},e("i",{style:`width:${Math.round(H*100)}%`}),e("u",{style:`left:${Math.round((B.fair||0)*100)}%`,title:"Шанс по линии конторы"})),e("span.pct",{},V(H),Math.abs(st)>=3?e(`small${st>0?".pos":".neg"}`,{text:`${ft(st)} п.п. к линии`}):null))}),e("div.legend",{},e("span",{text:b?"шанс серии по счёту":"оценка модели"}),e("span.model",{text:"шанс по линии конторы"})),b?e("div.hint",{style:"margin-top:6px",text:`Счёт по картам ${b.maps.join(":")}${b.rounds?`, на карте ${b.rounds.join(":")} — шанс текущей карты ${V(b.map??.5)}`:""}. До матча модель давала ${V(o.p1)} / ${V(o.p2)}.`}):null,ct(o,k),o.factors?.length?e("ul.facts",{style:"margin-top:8px"},o.factors.slice(0,o.sport==="mma"?12:4).map(B=>e("li",{},e("span",{text:B})))):null,e("div.hint",{style:"margin-top:8px",text:b?`Шанс по ходу матча пересчитывается из прогноза до матча и счёта: выигранные карты${o.game==="cs"?" и раунды":""} уточняют силу команд. ${o.game==="cs"?"Проверка на сыгранных сериях CS: при 1:0 в bo3 модель давала в среднем 82%, сбылось 83% (2 905 серий)":"Проверка на сыгранных сериях Dota: при 1:1 модель давала в среднем 53%, сбылось 55% (516 серий)"}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`:`${z}. ${L}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`}))}function ot(t){let[o,l]=t.names,p=["0","15","30","40","Б"],k=t.tiebreak?t.points.join(":"):t.points.map(z=>p[Math.min(4,z)]||z).join(":"),b=t.sets.map(([z,S])=>`${z}:${S}`).concat(`${t.games[0]}:${t.games[1]}`).join(" "),w=t.serving==null?"":` · подаёт ${t.names[t.serving]}`;return e("div.card",{},e("div.kicker",{},e("span",{text:"Лайв по счёту"}),e("span.badge",{text:`${t.score.join(":")} по сетам · ${b} · ${k}${t.tiebreak?" (тай-брейк)":""}`})),t.names.map((z,S)=>{let A=t.probs[S],T=t.book?t.book[S]:null,L=t.compare&&Number.isFinite(T)?(A-T)*100:0;return e("div.prob",{},e("span.name",{text:z,title:z}),e("span.odd",{text:Z(1/A),title:"Честный кэф на матч по счёту"}),e("span.track",{},e("i",{style:`width:${Math.round(A*100)}%`}),Number.isFinite(T)?e("u",{style:`left:${Math.round(T*100)}%`,title:"Шанс по цене этой конторы"}):null),e("span.pct",{},V(A),Math.abs(L)>=3?e(`small${L>0?".pos":".neg"}`,{text:`${ft(L)} п.п. к цене`}):null))}),e("div.legend",{},e("span",{text:"шанс матча по счёту"}),t.book?e("span.model",{text:"шанс по цене этой конторы"}):null),e("ul.facts",{style:"margin-top:8px"},e("li",{},e("span",{text:`Текущий сет: ${o} ${V(t.set[0])} (кэф ${Z(1/t.set[0])}) · ${l} ${V(t.set[1])} (${Z(1/t.set[1])})`})),e("li",{},e("span",{text:`Текущий ${t.tiebreak?"тай-брейк":"гейм"}${w}: ${o} ${V(t.game[0])} · ${l} ${V(t.game[1])}`})),e("li",{},e("span",{text:`Очко на своей подаче (под довоенную силу): ${o} ${t.serve[0]}%, ${l} ${t.serve[1]}%; матч до ${t.bestOf===5?"трёх":"двух"} выигранных сетов.`}))),e("div.hint",{style:"margin-top:8px",text:`Счёт, очки и подача — лайв Fonbet. Довоенная сила: ${t.prior.note}.${t.compare?"":" Без довоенной цены оценка подстроена под текущую цену Fonbet — как сигнал против конторы её не используйте."} Проверено на 10 064 моментах матчей ATP/WTA 2025–2026 (после каждого сета): при оценке 80–85% сбылось 82,9%, 85–90% — 87,8%. Это расчёт, а не обещание.`}))}function ht(t){let[o,l]=t.names,p=T=>T?Z(T):"—",k=t.sport==="hockey"?"период":"тайм",b=`${t.minute}' · ${Math.min(t.period,t.periods)}-й ${k}`,w=[o,"Ничья",l],z=T=>T>0?`+${T}`:`${T}`,S=(T,L,B,K,H,st)=>L?.length?e("details",{"data-key":`live-${T}`,open:E.get(`live-${T}`)||!1},e("summary",{text:T}),e("ul.facts",{},L.map(mt=>e("li",{},e("span",{text:`${H(mt)} — ${p(mt[B])} · ${st(mt)} — ${p(mt[K])}`}))))):null,A=t.red[0]||t.red[1]?` · удаления ${t.red.join(":")}`:"";return e("div.card",{},e("div.kicker",{},e("span",{text:"Лайв по счёту"}),e("span.badge",{text:`${t.score.join(":")} · ${b}${A}`})),w.map((T,L)=>{let B=t.probs[L],K=t.book?t.book[L]:null,H=t.compare&&Number.isFinite(K)?(B-K)*100:0;return e("div.prob",{},e("span.name",{text:T,title:T}),e("span.odd",{text:Z(1/B),title:"Честный кэф по счёту"}),e("span.track",{},e("i",{style:`width:${Math.round(B*100)}%`}),Number.isFinite(K)?e("u",{style:`left:${Math.round(K*100)}%`,title:"Шанс по цене этой конторы"}):null),e("span.pct",{},V(B),Math.abs(H)>=3?e(`small${H>0?".pos":".neg"}`,{text:`${ft(H)} п.п. к цене`}):null))}),e("div.legend",{},e("span",{text:"шанс по счёту (основное время)"}),t.book?e("span.model",{text:"шанс по цене этой конторы"}):null),e("ul.facts",{style:"margin-top:8px"},e("li",{},e("span",{text:`Следующий гол: ${o} ${V(t.nextGoal[0])} · не будет ${V(t.nextGoal[1])} · ${l} ${V(t.nextGoal[2])}. Ожидаемый итоговый тотал ≈${t.expTotal}.`})),t.bookLines?.total?e("li",{},e("span",{text:`Тотал ${t.bookLines.total.line}: Fonbet ${t.bookLines.total.odds.map(Z).join(" / ")}, честно ${t.bookLines.total.fair.map(p).join(" / ")}`}),Math.abs(t.bookLines.total.gap)>=5?e(`small${t.bookLines.total.gap>0?".pos":".neg"}`,{text:` ${ft(t.bookLines.total.gap)} п.п. к «больше»`}):null):null),S("Тотал — честные кэфы",t.total,"over","under",T=>`больше ${T.line}`,T=>`меньше ${T.line}`),S("Фора — честные кэфы",t.handicap,"home","away",T=>`${o} ${z(T.line)}`,T=>`${l} ${z(-T.line)}`),e("div.hint",{style:"margin-top:8px",text:`Счёт, время${t.sport==="football"?" и удаления":""} — лайв Fonbet${t.clock==="timer"?"":" (время приблизительное)"}. Довоенная сила: ${t.prior.note}.${t.compare?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на ${t.sport==="hockey"?"1 407 играх НХЛ":"1 837 матчах 5 топ-лиг (11 тыс. точек)"}: при оценке 80–85% сбылось 82,5%. Это расчёт, а не обещание.`}))}function zt(t,o,l,p){let k=t.bookLines;if(!k)return null;let b=z=>z>0?`+${z}`:`${z}`,w=(z,S,A,T)=>e("li",{},e("span",{text:`${z}: Fonbet ${S.map(Z).join(" / ")}, честно ${A.map(L=>L?Z(L):"—").join(" / ")}`}),p&&Math.abs(T)>=5?e(`small${T>0?".pos":".neg"}`,{text:` ${ft(T)} п.п. к первой стороне`}):null);return e("ul.facts",{style:"margin-top:8px"},k.handicap?w(`Фора ${o} ${b(k.handicap.line)} / ${l} ${b(-k.handicap.line)}`,k.handicap.odds,k.handicap.fair,k.handicap.gap):null,k.total?w(`Тотал ${k.total.line} больше / меньше`,k.total.odds,k.total.fair,k.total.gap):null)}function xt(t){let o=t.live;if(!o)return null;if(o.kind==="goals")return ht(o);if(o.kind==="tennis")return ot(o);if(o.error)return e("div.card",{},e("div.kicker",{},e("span",{text:"Лайв по счёту"})),e("div.hint",{text:o.error}));let[l,p]=o.names,k=L=>L?Z(L):"—",b=o.book&&(o.prior.source==="line"||o.prior.source==="model"),w=o.left>0?`${o.period>o.format.periods?"ОТ":`${o.period}-я четв.`} · осталось ≈${Math.max(1,Math.round(o.left))} мин`:"конец игры",z=(L,B,K,H,st,mt)=>B.length?e("details",{"data-key":`live-${L}`,open:E.get(`live-${L}`)||!1},e("summary",{text:L}),e("ul.facts",{},B.map(it=>e("li",{},e("span",{text:`${st(it)} — ${k(it[K])} · ${mt(it)} — ${k(it[H])}`}))))):null,S=L=>L>0?`+${L}`:`${L}`,A=o.quarter,T=A&&A.left>0?`${A.index}-я четверть (${A.score.join(":")}, осталось ≈${Math.max(1,Math.round(A.left))} мин): ${l} ${k(A.probs[0]?1/A.probs[0]:null)} · ничья ${k(A.draw?1/A.draw:null)} · ${p} ${k(A.probs[1]?1/A.probs[1]:null)}; разница ${A.expMargin>=0?l:p} ${Math.abs(A.expMargin).toFixed(1)}, тотал четверти ≈${A.projTotal}.`:"";return e("div.card",{},e("div.kicker",{},e("span",{text:"Лайв по счёту"}),e("span.badge",{text:`${o.score.join(":")} · ${w}`})),o.names.map((L,B)=>{let K=o.probs[B],H=o.book?o.book[B]:null,st=b&&Number.isFinite(H)?(K-H)*100:0;return e("div.prob",{},e("span.name",{text:L,title:L}),e("span.odd",{text:Z(1/K),title:"Честный кэф по счёту"}),e("span.track",{},e("i",{style:`width:${Math.round(K*100)}%`}),Number.isFinite(H)?e("u",{style:`left:${Math.round(H*100)}%`,title:"Шанс по цене этой конторы"}):null),e("span.pct",{},V(K),Math.abs(st)>=3?e(`small${st>0?".pos":".neg"}`,{text:`${ft(st)} п.п. к цене`}):null))}),e("div.legend",{},e("span",{text:"шанс по счёту (с ОТ)"}),o.book?e("span.model",{text:"шанс по цене этой конторы"}):null),zt(o,l,p,b),e("ul.facts",{style:"margin-top:8px"},e("li",{},e("span",{text:`Ожидаемая итоговая разница: ${o.expMargin>=0?l:p} ${Math.abs(o.expMargin).toFixed(1)} (разброс ±${o.sd}). Тотал ≈${o.projTotal} (±${o.sdTotal}).`})),T?e("li",{},e("span",{text:T})):null),z("Фора — честные кэфы",o.handicap,"home","away",L=>`${l} ${S(L.line)}`,L=>`${p} ${S(-L.line)}`),z("Тотал матча — честные кэфы",o.total,"over","under",L=>`больше ${L.line}`,L=>`меньше ${L.line}`),z("Тотал четверти — честные кэфы",o.quarterTotal,"over","under",L=>`больше ${L.line}`,L=>`меньше ${L.line}`),e("div.hint",{style:"margin-top:8px",text:`Счёт и время — лайв Fonbet${o.clock==="timer"?"":" (время в четверти оценено по очкам — приблизительно)"}. Довоенная сила: ${o.prior.note}.${b?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на 8 923 играх Евролиги, Еврокубка и НБА: в перерыве при оценке 75–80% побеждали в 78% случаев. Это расчёт, а не обещание; задержка табло у конторы бывает до минуты.`}))}function pt(t){let o=t.verdict;return o?.lines?.length?e("div.card",{},e("div.kicker",{},e("span",{text:"Итог"}),e("span.badge",{text:o.best?`перевес ${Math.round(o.best.edge*100)}%`:"без перевеса"})),e("ul.facts",{},o.lines.map(l=>e("li",{},e("span",{text:l})))),o.track?e("div.hint",{style:"margin-top:6px",text:o.track}):null,t.analysis.status!=="done"?e("div.hint",{style:"margin-top:6px",text:"Доводы «за» и главный риск появятся после «Разобрать матч»."}):null):null}function ct(t,o){let l=t.durations;if(t.sport!=="mma"||!l)return null;let p=b=>b?Z(b):"—",k=o.map(b=>b.name);return e("div",{style:"margin-top:10px"},e("div.kicker",{},e("span",{text:"Честные кэфы"}),e("span.badge",{text:`${l.rounds} ${l.rounds===5?"раундов":"раунда"}`})),e("ul.facts",{},e("li",{},e("span",{text:`Победа: ${k[0]||"первый"} ${p(t.fair?.p1)} · ${k[1]||"второй"} ${p(t.fair?.p2)}`})),l.lines.map(b=>e("li",{},e("span",{text:`Тотал ${b.line} раунда: больше ${p(b.over)} · меньше ${p(b.under)}`}))),e("li",{},e("span",{text:`Дойдёт до решения: да ${p(l.decision.yes)} · нет ${p(l.decision.no)}`})),e("li",{},e("span",{text:`Конец боя: 1-й раунд ${Math.round(l.r1*100)}%, 2-й ${Math.round(l.r2*100)}%, позже ${Math.round(l.r3*100)}%, решение ${Math.round(l.dec*100)}%`}))),e("div.hint",{text:"Кэф конторы выше честного — ставка в плюс по модели, ниже — в минус. Длительность считается по всем боям бойцов в UFC и их весовой; проверка на 565 боях: точнее, чем средние цифры по весовой."}))}function ut(t){let o=t.facts?.cs||t.analysis?.result?.cs||null,l=t.compare?.model||t.analysis?.result?.model||t.model;if(!o&&(t.match?.sport||l?.game)!=="cs")return null;let p=wn(o,l?.untrusted?null:l);if(!p)return null;let k=b=>b==="home"?t.match.home:t.match.away;return e("div.card",{},e("div.kicker",{},e("span",{text:"Карты серии"}),e("span.badge",{text:p.known?"вето bo3.gg":"до вето: вероятные карты"})),e("ul.facts",{},p.rows.map(b=>e("li",{},e("span",{text:`${b.n}. ${b.title}${p.known?` — ${b.pick?`пик ${k(b.pick)}`:"решающая"}`:""}${b.p!=null?` · ${t.match.home} ${V(b.p)}`:""}${b.strong.length?` · сильная у ${b.strong.map(k).join(" и ")}`:""}`})))),p.bans.length?e("div.hint",{style:"margin-top:6px",text:`Убраны: ${p.bans.map(b=>`${b.title}${b.team?` (${k(b.team)})`:""}`).join(", ")}.`}):null,e("div.hint",{style:"margin-top:6px",text:`${p.known?"":"Пики и баны появятся перед матчем. "}Шанс на карте — по рейтингам карт модели Линзы, справочно; в «Итог» карты не идут.`}))}function Ct(t){let l=((t.compare?.model||t.analysis?.result?.model||t.model)?.profiles||[]).filter(p=>p?.lines?.length);return l.length?e("div.card",{},e("div.kicker",{},e("span",{text:"Профили"}),e("span.badge",{text:"модель Линзы"})),l.map((p,k)=>e("details",{"data-key":`profile-${k}`,open:E.get(`profile-${k}`)??k===0},e("summary",{text:p.name}),e("ul.facts",{},p.lines.map(b=>e("li",{},e("span",{text:b})))))),e("div.hint",{style:"margin-top:8px",text:"Из рейтингов Линзы по открытым данным (ESPN, архив ATP/WTA, Евролига, bo3.gg). Это описание, а не прогноз."})):null}function he(t){let o=t.facts;if(!o?.facts?.length)return null;let l=o.facts.filter(w=>/травм|отсутств|не играет|стенд-ин|замен|дисквалиф/i.test(w.text)),p=o.facts.filter(w=>!l.includes(w)&&/состав|стартов/i.test(w.text)),k=o.facts.filter(w=>!l.includes(w)&&!p.includes(w)),b=(w,z,S)=>z.length?e("details",{"data-key":`facts-${w}`,open:S||E.get(`facts-${w}`)||!1},e("summary",{text:`${w} (${z.length})`}),e("ul.facts",{},z.map(A=>e("li",{},e("span",{text:A.text}))))):null;return e("div.card",{},e("div.kicker",{},e("span",{text:"Составы, травмы, форма"}),e("span.badge",{text:o.source||o.facts[0].source||"источник"})),b("Травмы и отсутствующие",l,!0),b("Составы",p,!0),b("Форма, таблица, очные встречи",k,!l.length&&!p.length),e("div.hint",{style:"margin-top:8px"},"Факты из открытых данных, как есть. ",o.url?e("a",{href:o.url,target:"_blank",rel:"noopener",text:"Источник"}):null))}let Ot=t=>`${Math.round(t).toLocaleString("ru-RU")} ₽`,gt=(t,o,l,p)=>{let k=t%100,b=t%10;return k>10&&k<20?p:b===1?o:b>=2&&b<=4?l:p},St=t=>(t.erid?["Реклама",t.legal,`erid ${t.erid}`].filter(Boolean).join(" · "):["Партнёрская ссылка",t.legal].filter(Boolean).join(" · "))+" · 18+",_t=(t,o)=>e("a.btn.ghost.small",{href:t.go?`${t.go}?s=panel`:t.url,target:"_blank",rel:"noopener sponsored"},rt("link",13),o||`Открыть у ${t.name}`),Et=t=>t.code?e("button.btn.ghost.small",{type:"button","data-act":"copy-code","data-arg":t.code,title:t.bonus||"Скопировать промокод"},`Промокод ${t.code}`):null;function ge(t){let o=(t.partners||[]).filter(l=>l.url||l.code);return o.length?e("div.card.soft",{},e("div.kicker",{},e("span",{text:o.length===1?`Промокод ${o[0].name}`:"Промокоды контор"})),o.map(l=>e("div.partner",{},e("div.partner-text",{},e("b",{text:l.name}),l.bonus?e("span",{text:` — ${l.bonus}`}):null),e("div.partner-links",{},Et(l),l.url?_t(l):null),e("div.hint",{text:St(l)})))):null}function be(t,o={}){if(t.status==="idle")return null;if(t.status==="loading")return e("div.card",{},e("div.kicker",{},e("span",{text:"Цены других контор"})),e("div.hint",{text:"Смотрю открытые линии…"}));let l=t.labels||[];if(!t.rows?.length)return e("div.card",{},e("div.kicker",{},e("span",{text:"Цены других контор"})),e("div.hint",{text:t.note||"В открытых линиях этой пары нет."}));let p=l.map((L,B)=>Math.max(...t.rows.map(K=>K.odds[B]||0))),k=Object.fromEntries((o.partners||[]).map(L=>[L.id,L])),b=L=>L.book&&L.book!==o.bookId&&!L.sharp&&k[L.book]||null,w=o.stake||1e3,z=t.rows.find(L=>L.here)||t.rows[0],A=l.map((L,B)=>{let K=z?.odds?.[B],H=t.rows.filter(st=>st!==z&&!st.sharp&&st.odds[B]).sort((st,mt)=>mt.odds[B]-st.odds[B])[0];return!K||!H||H.odds[B]<=K?null:{label:L,row:H,odd:H.odds[B],mine:K,gain:(H.odds[B]-K)*w}}).filter(Boolean).sort((L,B)=>B.gain-L.gain)[0],T=t.rows.map(b).filter(Boolean);return e("div.card",{},e("div.kicker",{},e("span",{text:"Цены других контор"}),e("span.badge",{text:"лучшая цена выделена"})),e("table",{},e("tr",{},e("th",{text:"Контора"}),l.map(L=>e("th",{text:L}))),t.rows.map(L=>{let B=b(L);return e("tr",{},e("td.name",{title:L.sharp?"Цена с мирового рынка, для сравнения":""},L.name,B?e("div.partner-links",{},B.url?_t(B):null,Et(B)):null),L.odds.map((K,H)=>e(`td${K&&K===p[H]&&t.rows.length>1?".best":""}`,{text:K?Z(K):"—"})))})),A&&A.gain>=1?e("div.gain",{},`На «${A.label}» у ${A.row.name} кэф ${Z(A.odd)} против ${Z(A.mine)} здесь: со ставки ${Ot(w)} выигрыш больше на `,e("b",{text:Ot(A.gain)}),"."):null,T.length?e("div.hint",{style:"margin-top:6px",text:[...new Set(T.map(St))].join(" ")}):null,t.note?e("div.hint",{style:"margin-top:8px",text:t.note}):null)}function xe(t){let o=[],l=(k,b,w)=>o.push(e("dt",{text:k}),e(`dd${w?"."+w:""}`,{text:b}));Number.isFinite(t.fair)?(l("Шанс по линии без маржи",V(t.fair,1)),l("Кэф без маржи конторы",Z(t.fairOdd)),l("Маржа конторы в этом рынке",V(t.margin,1))):l("Заложено в кэфе (с маржой)",V(1/t.odd,1)),Number.isFinite(t.model)&&(l("Оценка модели",V(t.model,1)),l("Ожидание на рубль по модели",`${ft(t.ev*100)}%`,t.ev>.005?"pos":t.ev<-.005?"neg":"")),t.best&&l(`Лучшая цена: ${t.best.name}`,Z(t.best.odd),t.best.odd>t.odd?"pos":"");let p=t.best?.partner&&(t.best.partner.url||t.best.partner.code)?t.best.partner:null;return e("div.card.accent",{},e("div.kicker",{},e("span",{text:t.market}),e("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},rt("close",13))),e("div.pick-head",{},e("span.big",{text:Z(t.odd)}),e("span.what",{text:t.label,title:t.label})),e("dl.kv",{},o),t.note?e("div.hint",{style:"margin-top:8px",text:t.note}):null,e("div.row",{style:"margin-top:10px"},e("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!t.canAdd,title:t.canAdd?"":"Нужен рынок с полным набором исходов"},rt("plus",14),t.inExpress?"Уже в экспрессе":"В расчёт экспресса")),p?e("div.partner",{style:"margin-top:10px"},t.best.gain>=1?e("div.gain",{},`У ${p.name} этот кэф выше: со ставки ${Ot(t.stake||1e3)} выигрыш больше на `,e("b",{text:Ot(t.best.gain)}),"."):null,e("div.partner-links",{},p.url?_t(p):null,Et(p)),e("div.hint",{text:St(p)})):null)}function ye(t){let o=(l,p)=>e("div",{style:"min-width:0"},e("b",{text:l,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),p.map(k=>e("div",{style:"display:flex;justify-content:space-between;gap:8px"},e("span",{text:k.nick}),e("span",{style:"color:var(--lz-muted)",text:k.numbers.slice(0,2).join(" / ")}))));return e("div.card",{},e("div.kicker",{},e("span",{text:"Игроки сейчас"}),e("span.badge",{text:"с табло конторы"})),e("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},o(t.homeName,t.home),o(t.awayName,t.away)))}function ve(t,o){return e("div.card",{},e("div.kicker",{},e("span",{text:"Статистика команд"}),e("span.badge",{text:"со страницы конторы"})),e("table",{},e("tr",{},e("th",{text:"Показатель"}),e("th",{text:o.home}),e("th",{text:o.away})),t.rows.map(l=>e("tr",{},e("td",{text:l.label}),e("td",{text:l.home}),e("td",{text:l.away})))),t.samples?.length===2?e("div.hint",{style:"margin-top:8px",text:`Выборка: ${t.samples[0]} и ${t.samples[1]} карт.`}):null)}function Zt(t){let o=[];if(t.pick&&o.push(xe({...t.pick,stake:t.stake})),!t.match)return o.push(e("div.empty",{},e("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),o;o.push(j(t.match,t.facts?.cs)),t.esports&&o.push(ye(t.esports)),t.match.stats?.rows?.length&&o.push(ve(t.match.stats,t.match)),t.line&&o.push(D(t.line));let l=Q(t);l&&o.push(l);let p=xt(t);p&&o.push(p);let k=J(t);k&&o.push(k);let b=ut(t);b&&o.push(b);let w=pt(t);w&&o.push(w);let z=Ct(t);z&&o.push(z);let S=he(t);S&&o.push(S);let A=t.analysis.status==="loading";o.push(e("div.row",{},e("button.btn",{type:"button","data-act":"analyze",disabled:A},rt("spark"),A?"Разбираю…":t.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),e("button.btn.ghost",{type:"button","data-act":"compare",disabled:t.compare.status==="loading"},rt("scale"),"Сравнить цены"))),t.quota&&o.push(e("div.hint.center-text",{text:t.quota}));let T=ge(t);T&&o.push(T);let L=G(t);L&&o.push(L);let B=be(t.compare,t);return B&&o.push(B),o}function Ht(t){let o=t.margins;if(!o)return null;let l=[e("div",{},`Сегодня вы открыли ${o.n} ${gt(o.n,"матч","матча","матчей")} до начала: в основной исход ${t.bookName||"контора"} закладывает в среднем `,e("b",{text:V(o.here,1)})," маржи.")];return o.best?(l.push(e("div",{style:"margin-top:6px"},`На тех же ${o.best.n} ${gt(o.best.n,"матче","матчах","матчах")} у ${o.best.name} — `,e("b",{text:V(o.best.there,1)}),` против ${V(o.best.here,1)} здесь: с каждой ставки вы отдавали бы конторе меньше примерно на ${((o.best.here-o.best.there)*100).toFixed(1)} п.п.`)),o.partner&&l.push(e("div.partner-links",{style:"margin-top:8px"},o.partner.url?_t(o.partner):null,Et(o.partner)),e("div.hint",{text:St(o.partner)}))):l.push(e("div.hint",{style:"margin-top:6px",text:"Нажмите «Сравнить цены» на странице матча — Линза запомнит маржу других контор на тех же матчах и покажет, где отдаёте меньше."})),e("div.card",{},e("div.kicker",{},e("span",{text:"Сколько маржи вы отдаёте"}),e("span.badge",{text:"сегодня"})),...l)}function Xt(t){let o=t.scan,l=Ht(t);return o?.rows?.length?[l,e("div.card",{},e("div.kicker",{},e("span",{text:o.title}),e("span.badge",{text:`средняя маржа ${V(o.average,1)}`})),e("table",{},e("tr",{},e("th",{text:o.first}),e("th",{text:"Фаворит"}),e("th",{text:"Маржа"})),o.rows.map(p=>e("tr.click",{"data-act":"scan-go","data-arg":String(p.index),title:"Показать на странице"},e("td.name",{},p.name,p.sub?e("span.sub",{text:p.sub}):null),e("td",{},p.fav,e("span.sub",{text:V(p.favPct)})),e(`td${p.low?".best":""}`,{text:V(p.margin,1)})))),e("div.hint",{style:"margin-top:8px",text:o.note}))]:[l,e("div.empty",{},e("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function ke(t){let o=t.express;if(!o.legs.length)return[e("div.empty",{},e("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let l=o.stats;return[e("div.card",{},e("div.kicker",{},e("span",{text:`Экспресс · ${o.legs.length}`}),e("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},rt("trash",13),"Очистить")),o.legs.map(p=>e("div.leg",{},e("div.t",{},e("b",{text:p.label,title:p.label}),e("span",{text:p.title,title:p.title})),e("span.o",{text:Z(p.odd)}),e("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":p.id,title:"Убрать",style:"width:24px;height:24px"},rt("close",13))))),l?e("div.card.soft",{},e("dl.kv",{},e("dt",{text:"Итоговый коэффициент"}),e("dd",{text:Z(l.odd)}),e("dt",{text:"Шанс, что зайдёт всё (по линии)"}),e("dd",{text:V(l.chance,1)}),e("dt",{text:"Кэф без маржи"}),e("dd",{text:Z(l.fairOdd)}),e("dt",{text:"Маржа конторы на всём экспрессе"}),e("dd.neg",{text:V(l.margin,1)})),e("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Исходы одного матча считаются как независимые — на деле они связаны."})):null]}function we(t){let o=t.edges||{status:"idle"},l=S=>e("div.kicker",{},e("span",{text:"Цена выше рынка"}),S?e("span.badge",{text:S}):null);if(o.status==="loading"&&!o.data)return[e("div.card",{},l("ищу сигналы"),e("div.hint",{text:"Сверяю открытую линию с консенсусом двадцати контор…"}))];if(o.status==="error"&&!o.data)return[e("div.card",{},l(),e("div.note.warn",{},rt("alert"),e("span",{text:o.error})))];let p=o.data;if(!p)return[e("div.empty",{},e("b",{text:"Сигналы ещё не загружены"}),"Откройте вкладку ещё раз или нажмите «Обновить».")];let k=S=>S==null?"—":`${S>=0?"+":"−"}${(Math.abs(S)*100).toFixed(1)}%`,b=S=>new Date(S).toLocaleString("ru-RU",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"}),w=e("div.card.soft",{},e("dl.kv",{},e("dt",{text:"Открытых сигналов"}),e("dd",{text:String(p.open)}),e("dt",{text:"Закрыто за неделю"}),e("dd",{text:String(p.closedWeek)}),e("dt",{text:"Средний CLV за неделю"}),e("dd",{text:k(p.clvWeek)}),e("dt",{text:"Сигналов с плюсовым CLV"}),e("dd",{text:p.positiveWeek==null?"—":V(p.positiveWeek)})),e("div.hint",{style:"margin-top:8px",text:"CLV — насколько цена сигнала была выше цены закрытия линии. Плюсовой CLV на дистанции — единственный честный признак того, что сигналы опережают рынок. Это не обещание выигрыша."})),z=(p.signals||[]).map(S=>e("tr",{},e("td.name",{},`${S.home} — ${S.away}`,e("span.sub",{text:`${S.league} · ${b(S.start)}`})),e("td",{},S.label,e("span.sub",{text:S.book})),e("td",{text:Z(S.odds)}),e("td",{text:Z(1/S.p),title:`Честная цена по ${S.count} конторам`}),e("td.best",{text:`+${(S.edge*100).toFixed(1)}%`})));return[e("div.card",{},l(p.full?"тариф «Макс»":"витрина"),z.length?e("table",{},e("tr",{},e("th",{text:"Матч"}),e("th",{text:"Исход"}),e("th",{text:"Кэф"}),e("th",{text:"Рынок"}),e("th",{text:"Выше на"})),z):e("div.hint",{text:"Сейчас открытых сигналов нет: контора держится в рынке. Сканер проходит линию каждые полчаса."}),p.note?e("div.hint",{style:"margin-top:8px"},p.note," ",a.bot?e("a",{href:a.bot,target:"_blank",rel:"noopener",text:"Получить «Макс»"}):null):null,e("div.row",{style:"margin-top:10px"},e("button.btn.ghost.small",{type:"button","data-act":"edges-refresh"},"Обновить"))),w]}function Yt(t){let o=t.settings,l=(p,k,b)=>e("div.seg",{},b.map(([w,z])=>e(`button${k===w?".on":""}`,{type:"button","data-act":p,"data-arg":w,text:z})));return[e("div.card",{},e("div.field",{},e("label",{text:"Отметки на странице"}),l("set-overlay",o.overlay,[["picks","Фавориты"],["all","Все шансы"],["off","Выкл"]]),e("div.hint",{text:"Рамка стоит на самом вероятном исходе каждого рынка. Число — шанс по линии без маржи конторы. Это не прогноз."})),e("div.field",{},e("label",{text:"Тема"}),l("set-theme",o.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]])),e("div.field",{},e("label",{for:"lz-stake",text:"Ставка для расчёта выгоды, ₽"}),e("div.row",{},e("input",{type:"number",id:"lz-stake",value:String(o.stake||1e3),min:"10",step:"10",inputmode:"numeric","data-enter":"set-stake",style:"max-width:140px"}),e("button.btn.small",{type:"button","data-act":"set-stake"},"Сохранить")),e("div.hint",{text:"Разницу лучшей цены Линза показывает в рублях от этой суммы. На ставку это не влияет."}))),e("div.card",{},e("div.kicker",{},e("span",{text:"Разбор матчей"}),e(`span.badge${o.ready?".pos":""}`,{text:o.ready?"подключён":"не подключён"})),o.proxy?e("div.field",{},e("label",{text:"Доступ"}),l("set-mode",o.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,o.mode==="license"&&o.proxy?e("div.field",{},e("label",{for:"lz-license",text:"Лицензионный ключ"}),e("input",{type:"text",id:"lz-license",placeholder:o.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),e("div.row",{},e("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),o.licenseMask?e("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),e("div.hint",{},[o.licenseMask?`Ключ ${o.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",o.plan,o.usage].filter(Boolean).join(" "),a.bot&&!o.licenseMask?[" ",e("a",{href:a.bot,target:"_blank",rel:"noopener",text:"Получить ключ «Про»"})]:null)):e("div.field",{},e("label",{for:"lz-key",text:"API-ключ Clodex"}),e("input",{type:"password",id:"lz-key",placeholder:o.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),e("div.row",{},e("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),o.hasKey?e("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),e("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${o.usage}`}))),e("div.card.soft",{},e("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной.")),e("div.card.soft",{},e("div.kicker",{},e("span",{text:$n})),Mn(t.earnLinks).map(p=>e("div.hint",{text:p})))]}function Pt(t){P=t;let o=JSON.stringify(t);if(o===I)return;I=o;for(let z of h.querySelectorAll("details[data-key]"))E.set(z.dataset.key,z.open);let l=h.scrollTop;x.textContent=t.bookName?`· ${t.bookName}`:"",d.classList.toggle("off",t.settings.overlay==="off"),g.replaceChildren(rt(t.theme==="dark"?"sun":"moon")),y.replaceChildren(rt(t.settings.overlay==="off"?"eyeOff":"eye")),y.classList.toggle("on",t.settings.overlay!=="off"),v.classList.toggle("on",t.tab==="settings"),v.dataset.arg=t.tab==="settings"?t.backTab:"settings";let p=[["match","Матч"],["scan","Маржа"],["edges","Выше рынка"],["express","Экспресс"]];c.replaceChildren(...p.map(([z,S])=>e(`button.tab${t.tab===z?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":z},S,z==="express"&&t.express.legs.length?e("span.count",{text:String(t.express.legs.length)}):null)));let k=t.tab==="settings"?Yt(t):t.tab==="scan"?Xt(t):t.tab==="express"?ke(t):t.tab==="edges"?we(t):Zt(t),b=t.update?e("div.card.soft.update",{},e("b",{text:`Вышла Линза ${t.update.version}`})," — ",t.update.url?e("a",{href:t.update.url,target:"_blank",rel:"noopener",text:"скачать архив на сайте"}):"архив на сайте Линзы"," и заменить папку расширения."):null,w=t.whatsnew?.changes?.length&&t.tab!=="settings"?e("div.card.soft.update",{},e("b",{text:`Линза обновилась до ${t.whatsnew.version}`}),e("ul.facts",{style:"margin-top:6px"},t.whatsnew.changes.flatMap(z=>z.items).slice(0,6).map(z=>e("li",{},e("span",{text:z})))),e("div.row",{style:"margin-top:8px"},e("button.btn.ghost.small",{type:"button","data-act":"whatsnew-ok"},"Понятно"))):null;h.replaceChildren(...[b,w,...k].filter(Boolean)),h.scrollTop=l,f.replaceChildren(e("span",{text:"18+ · Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function $e(t){n.setAttribute("data-theme",t)}function Jt(){$.hidden=!1,r.opened?.()}function Nt(){$.hidden=!0}function Bt(){$.hidden?Jt():Nt()}function jt(t){t?.fab&&N(u,t.fab.left,t.fab.top),t?.panel&&N($,t.panel.left,t.panel.top)}let Rt=0;function i(t){m.querySelector(".toast")?.remove();let o=e("div.toast",{text:t,role:"status"});m.appendChild(o),clearTimeout(Rt),Rt=setTimeout(()=>o.remove(),2600)}return{render:Pt,setTheme:$e,open:Jt,close:Nt,toggle:Bt,restore:jt,toast:i,shadow:m,rect:()=>$.hidden?null:$.getBoundingClientRect(),get isOpen(){return!$.hidden},get view(){return P}}}var Sn="Расширение обновилось. Обновите эту вкладку (F5).";function Eo(s){return/signal timed out|timeout|timed out/i.test(s)?"Сервер долго не отвечает — нажмите ещё раз.":/failed to fetch|networkerror|load failed|network request failed/i.test(s)?"Нет связи с сервером Линзы — проверьте интернет.":s}function wt(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function et(s,r={}){if(!wt())return{ok:!1,error:Sn,code:"reload"};try{return await chrome.runtime.sendMessage({type:s,...r})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(a){let n=String(a?.message||a);return/context invalidated/i.test(n)||!wt()?{ok:!1,error:Sn,code:"reload"}:/message port closed|receiving end does not exist/i.test(n)?{ok:!1,error:"Связь с расширением прервалась — нажмите ещё раз.",code:"retry"}:{ok:!1,error:Eo(n)}}}function _n(s){if(wt())try{chrome.runtime.onMessage.addListener(r=>{s(r)})}catch{}}async function Ce(s){if(!wt())return{};try{return await chrome.storage.local.get(s)}catch{return{}}}function $t(s){if(wt())try{chrome.storage.local.set(s)}catch{}}var Nn=(s=Date.now())=>new Date(s).toISOString().slice(0,10);function ue(s,r=Date.now()){return s&&s.day===Nn(r)&&s.items&&typeof s.items=="object"?s:{day:Nn(r),items:{}}}function An(s,{key:r,book:a,margin:n}){if(!r||!Number.isFinite(n)||n<=0||n>.5)return!1;let m=Math.round(n*1e4)/1e4,d=s.items[r];return d&&d.here===m&&d.book===a?!1:(s.items[r]={book:a,here:m,others:d?.others||{}},!0)}function Fn(s,r,a){let n=s.items[r];if(!n)return!1;let m=!1;for(let d of a||[]){if(d.here||d.sharp||!d.odds?.length||d.odds.some(h=>!(h>1)))continue;let u=vt(d.odds);if(u.kind!=="full"||!(u.margin>0))continue;let c=Math.round(u.margin*1e4)/1e4;n.others[d.name]!==c&&(n.others[d.name]=c,m=!0)}return m}function Ln(s,r){let a=Object.values(s?.items||{}).filter(u=>u.book===r);if(!a.length)return null;let n=u=>u.reduce((c,h)=>c+h,0)/u.length,d=[...new Set(a.flatMap(u=>Object.keys(u.others||{})))].map(u=>{let c=a.filter(h=>Number.isFinite(h.others?.[u]));return c.length>=2?{name:u,n:c.length,there:n(c.map(h=>h.others[u])),here:n(c.map(h=>h.here))}:null}).filter(Boolean).sort((u,c)=>u.there-c.there);return{n:a.length,here:n(a.map(u=>u.here)),best:d[0]||null,others:d}}var Po=[{version:"1.0.17",items:["В настройках панели и в окне расширения — «Как Линза зарабатывает»: платные тарифы и партнёрские ссылки контор. На сравнение цен ссылки не влияют."]},{version:"1.0.16",items:["Новый адрес Линзы — linzabet.ru: сайт, мини-приложение и сервер разборов. Если он вдруг недоступен, расширение само переходит на запасной.","В разборе — «Прогноз Линзы»: кто, как и почему, до матча и в лайве.","Лайв CS и Dota: счёт карт и раундов с панели уходит в разбор, сервер учитывает, кто забирает текущую карту."]},{version:"1.0.15",items:["Разбор на сервере видит тоталы и форы этой страницы: в теннисе «Показать полностью» — итог и по геймам, по цене самой конторы."]},{version:"1.0.14",items:["«Лучшая цена» — только если цена выше честной на 3–12%. Больше 12% — строка «Проверьте данные»: чаще это ошибка в данных, чем подарок конторы.","Модель Линзы пока справочно: «по модели интересная цена от…». Перевес считается по ценам рынка, пока модель не докажет, что она точнее.","Карты в CS и Dota временно убраны из итога: вернём после проверки на честных ценах."]},{version:"1.0.13",items:["Под разбором — «Показать полностью»: итог по всем рынкам, доводы, как может пойти игра, профили и факты.","Итог по рынкам этой страницы: в теннисе — тотал и фора геймов, в CS и Dota — карты, по цене самой конторы на победу."]},{version:"1.0.12",items:["Под разбором — «Сообщить об ошибке»: что сломалось, уходит разработчику без личных данных.","Итог не строится по модели, которой нельзя верить как цене: если она сильно расходится с рынком или у неё мало матчей в архиве."]},{version:"1.0.11",items:["Разобрать матч: разбор идёт на сервере — видно, что происходит (цены, новости, модель), и он не обрывается на «Обновите вкладку».","Разбор работает на всех конторах: если матча нет в линии Fonbet, Линза разбирает по ценам страницы и свежим новостям.","Новости, травмы и составы из прессы — в разборе для всех тарифов; у «Макс» и VIP поиск подробнее.","Бесплатные 3 разбора в день считаются для вашего браузера, а не для всех с одного адреса; истёкший ключ не отключает бесплатные разборы.","Исправлено: счётчик «Разборов сегодня» больше не пропадает, ошибки связи — понятными словами."]},{version:"1.0.10",items:["Исправлено: в доводах моделей имена команд и игроков — как на странице конторы."]},{version:"1.0.9",items:["Лайв тенниса по счёту: шанс матча, текущего сета и гейма от очков и подачи.","Прогноз модели для КХЛ: атака и оборона команд, исход основного времени и победитель с ОТ; на проверке при уверенности от 65% сбылось 70%.","Итог: форы футбола и хоккея против честной цены по Fonbet."]},{version:"1.0.8",items:["Лайв по счёту для футбола и хоккея: шанс исхода основного времени, следующий гол, тоталы и форы по счёту, времени и удалениям; точное игровое время.","Итог для футбола и хоккея: тоталы этой конторы против честной цены по Fonbet без маржи на любой линии.","Журнал итогов: точность прошлых итогов — в карточке и в приложении."]},{version:"1.0.7",items:["ММА (UFC): прогноз модели по бойцам — возраст, размах рук, форма, простой; как скорее всего закончится бой и честные кэфы на тоталы раундов и решение судей; прогноз рынка 5+ контор.","Итог: в конце карточек — лучшая цена против честной, перевес и размер суммы, доводы и главный риск из разбора; каждый итог записывается и потом сверяется с результатом — точность видна в приложении.","Баскетбол: фора и тотал по модели — ожидаемая разница очков и тотал с разбросом, честные кэфы основных линий конторы в «Итоге».","Теннис: подача и приём в модели — шанс матча по доле выигранных очков на своей подаче и на приёме соперника.","Исправлено: бойцы и теннисисты в формате «Фамилия И.» находятся, если полное имя из трёх слов.","Одна палитра у панели, попапа, мини-приложения и сайта; в тёмной теме приложения — светлый акцент."]},{version:"1.0.6",items:["Лайв по счёту: в баскетболе — честный шанс, фора и тотал против цены конторы; в CS и Dota — шанс серии по счёту карт и раундов текущей карты.","Профили участников: теннисисты (покрытия, подача и приём, нагрузка, последние матчи), команды баскетбола и киберспорта (динамика рейтинга, форма, состав с рейтингом каждого игрока).","Баскетбол: Еврокубок, АСВ, Серия А, Адриатическая лига, Единая лига ВТБ и Лига чемпионов FIBA — в модели и в фактах.","Футбол: ход матча и судьи (УЕФА) в карточке «Составы, травмы, форма».","Киберспорт: у подписи уверенности — как часто такие прогнозы сбывались на проверке; модель Dota точнее.","Вкладка «Маржа»: сколько маржи вы отдаёте этой конторе по открытым сегодня матчам и сколько отдавали бы у других контор.","Новая версия подхватывается сама, когда вы заменили файлы в папке расширения."]},{version:"1.0.5",items:["Карточка «Составы, травмы, форма» на странице матча: травмы по именам, составы, форма и очные встречи (ESPN, bo3.gg) — без разбора и без лимита.","Подсказка в панели, когда на сайте вышла новая версия.","Dota 2: точнее вероятность победы в серии до двух побед."]}];function Tn(s,r){let a=String(s||"").split(".").map(Number),n=String(r||"").split(".").map(Number);for(let m=0;m<Math.max(a.length,n.length);m++){let d=(a[m]||0)-(n[m]||0);if(d)return d>0}return!1}function Cn(s,r){return Po.filter(a=>Tn(a.version,s)&&!Tn(a.version,r))}var Mt=s=>Number.isFinite(s)?(Math.round(s*100)/100).toFixed(2):"—",de=s=>`${Math.round(s*100)}%`,jo=(s,r)=>s*r-1;function Io(s){return s<.03?null:s<.06?"небольшая — примерно половина обычной":s<.12?"обычная":"перевес слишком большой — сначала проверьте травмы, замены и что это тот же матч"}function On(s,{source:r="",reasons:a=[],risk:n=""}={}){let m=(s||[]).filter($=>Number($.odd)>1&&$.p>.01&&$.p<.99).map($=>({...$,fairOdd:1/$.p,edge:jo($.p,Number($.odd))}));if(!m.length)return null;let d=[...m].sort(($,C)=>C.edge-$.edge),u=d.find($=>$.edge>=.03&&$.edge<=.12)||null,c=u?{...u,size:Io(u.edge)}:null,h=d.find($=>$.edge>.12)||null,f=h?{...h}:null,x=m.filter($=>$!==u&&$!==h).map($=>({...$,note:$.edge>.12?`перевес ${de($.edge)} — слишком большой, проверьте данные`:$.edge>=.03?`перевес ${de($.edge)} к честной цене ${Mt($.fairOdd)}`:$.edge>-.02?`честная цена (${Mt($.fairOdd)}), перевеса нет`:`цена ниже честной (${Mt($.fairOdd)})`})),g=[],y=$=>$.source||r;if(c){let $=y(c);g.push(`Лучшая цена: ${c.label} по ${Mt(c.odd)} — перевес около ${de(c.edge)} к честной цене ${Mt(c.fairOdd)}${$?` (${$})`:""}. Сумма: ${c.size}.`),a.length&&g.push(`За: ${a.join(" ")}`),n&&g.push(`Главный риск: ${n}`)}else g.push(`${f?"Надёжного перевеса нет":"Перевеса нет"}: ${f?"остальные":"все"} цены близки к честным или ниже${r?` (${r})`:""} — разумнее пропустить.`);if(f){let $=y(f);g.push(`Проверьте данные: ${f.label} по ${Mt(f.odd)} — перевес ${de(f.edge)} к честной цене ${Mt(f.fairOdd)}${$?` (${$})`:""} слишком большой. Чаще это ошибка данных или модели (травма, состав, чужой матч), а не подарок конторы — лучшей ценой не считаем.`)}let v=[...x].sort(($,C)=>C.edge-$.edge).slice(0,6),_=x.length-v.length;return x.length&&g.push(`${c?"Остальное":"По рынкам"}: ${v.map($=>`${$.label} по ${Mt($.odd)} — ${$.note}`).join("; ")}${_>0?`; ещё ${_} — с меньшим перевесом или без него`:""}.`),g.push("Это расчёт, а не обещание: проиграть можно и при перевесе в цене. 18+"),{best:c,suspect:f,others:x,lines:g}}function Kt(s){let r=n=>/^(б|больше|бол|over|o\b|тб)/i.test(String(n||"").trim()),a=n=>/^(м|меньше|мен|under|u\b|тм)/i.test(String(n||"").trim());return r(s[0])&&a(s[1])?0:a(s[0])&&r(s[1])?1:-1}var Do=s=>{let r=s<0?-1:1,a=Math.abs(s),n=1/(1+.3275911*a);return r*(1-((((1.061405429*n-1.453152027)*n+1.421413741)*n-.284496736)*n+.254829592)*n*Math.exp(-a*a))},Oe=s=>.5*(1+Do(s/Math.SQRT2));function En(s,r,a){if(!(Math.abs(a-Math.round(a))<1e-9)){let u=1-Oe((a-s)/r);return{win:u,push:0,lose:1-u}}let m=1-Oe((a+.5-s)/r),d=Oe((a-.5-s)/r);return{win:m,push:Math.max(0,1-m-d),lose:d}}function Bo(s,r,a){let n=En(s,r,-a);return{home:n.win,away:n.lose,push:n.push}}function Ro(s,r,a){let n=En(s,r,a);return{over:n.win,under:n.lose,push:n.push}}function Pn(s,{handicap:r=null,total:a=null}={},n=["Хозяева","Гости"]){let m=s?.lines;if(!m||!Number.isFinite(m.margin)||!(m.sigma>0))return[];let d=[],u=f=>f>0?`+${f}`:`${f}`,c=(f,x)=>f/(1-x||1),h=(f,x)=>1/f/(1/f+1/x);if(r&&Number.isFinite(r.line)&&Math.abs(r.line)<60&&r.home>1&&r.away>1){let f=Bo(m.margin,m.sigma,r.line);Math.abs(c(f.home,f.push)-h(r.home,r.away))<=.3&&d.push({label:`Фора ${n[0]} ${u(r.line)}`,odd:r.home,p:c(f.home,f.push),kind:"handicap",side:"home",source:"модель Линзы"}),d.length&&d.push({label:`Фора ${n[1]} ${u(-r.line)}`,odd:r.away,p:c(f.away,f.push),kind:"handicap",side:"away",source:"модель Линзы"})}if(a&&Number.isFinite(m.total)&&m.sigmaT>0&&Number.isFinite(a.line)&&a.line>50&&a.over>1&&a.under>1){let f=Ro(m.total,m.sigmaT,a.line);Math.abs(c(f.over,f.push)-h(a.over,a.under))<=.3&&(d.push({label:`Тотал больше ${a.line}`,odd:a.over,p:c(f.over,f.push),kind:"total",source:"модель Линзы"}),d.push({label:`Тотал меньше ${a.line}`,odd:a.under,p:c(f.under,f.push),kind:"total",source:"модель Линзы"}))}return d}var Dt={football:{periods:2,minutes:90,stoppage:[2,5],late:1,weights:[.12,.142,.184,.149,.167,.237],trail:.3,lead:.05,redOwn:-.4,redOpp:.45,total:2.7,homeShare:.555,maxGoals:12},hockey:{periods:3,minutes:60,weights:[.297,.344,.359],trail:0,lead:-.1,redOwn:0,redOpp:0,total:6,homeShare:.52,maxGoals:16}},Ee=[1];for(let s=1;s<=40;s+=1)Ee[s]=Ee[s-1]*s;var jn=(s,r)=>r<=0?s===0?1:0:Math.exp(-r)*r**s/Ee[s];function qo(s,r){let a=r.weights.length,n=r.minutes/a,m=Math.max(0,Math.min(r.minutes,s)),d=0;for(let c=0;c<a;c+=1){let h=c*n,f=h+n,x=a/(r.periods||1),g=(c+1)%x===0&&r.stoppage?.[Math.floor(c/x)]||0;m<=h?d+=r.weights[c]:m<f&&(d+=r.weights[c]*((f-m+g)/(n+g)))}let u=r.weights.reduce((c,h)=>c+h,0);return d/u}function In(s,r,a){let n=[];for(let m=0;m<=a;m+=1){n[m]=[];for(let d=0;d<=a;d+=1)n[m][d]=jn(m,s)*jn(d,r)}return n}function Go(s,r,a,n=null){let m=In(s,r,a),d=0,u=0,c=0,h=0;for(let f=0;f<=a;f+=1)for(let x=0;x<=a;x+=1){let g=m[f][x];f>x?d+=g:f===x?u+=g:c+=g,n!=null&&f+x>n&&(h+=g)}return{p1:d,px:u,p2:c,over:h}}function Dn({p1:s,px:r,p2:a,line:n=null,pOver:m=null},d=Dt.football){let u=d.total,c=(f,x)=>{let g=Go(f,x,d.maxGoals,n!=null&&m!=null?n:null),y=(g.p1-s)**2+(g.p2-a)**2+(r!=null?(g.px-r)**2:0);return n!=null&&m!=null?y+=(g.over-m)**2:y+=.02*((f+x-u)/u)**2,y},h={lh:u*d.homeShare,la:u*(1-d.homeShare),e:1/0};for(let f=.4;f>=.01;f/=2){let x=h;for(let g=-4;g<=4;g+=1)for(let y=-4;y<=4;y+=1){let v=Math.max(.03,x.lh+g*f),_=Math.max(.03,x.la+y*f),$=c(v,_);$<h.e&&(h={lh:v,la:_,e:$})}}return{lh:h.lh,la:h.la}}function Pe(s,r,a=Dt.football){let[n,m]=s.score.map(Number),d=qo(Number(s.minute)||0,a),u=n-m,c=Math.sign(u),h=1+(a.late||0)*((Number(s.minute)||0)/a.minutes-.5),f=(Math.abs(u)>=2?.6:1)*Math.max(0,h),x=c<0?a.trail*f:c>0?a.lead*f:0,g=c>0?a.trail*f:c<0?a.lead*f:0,[y,v]=(s.red||[0,0]).map(G=>Math.min(2,Number(G)||0)),_=(G,U)=>(1+a.redOwn)**G*(1+a.redOpp)**U,$=Math.max(0,r.lh*d*(1+x)*_(y,v)),C=Math.max(0,r.la*d*(1+g)*_(v,y)),I=a.maxGoals,P=In($,C,I),E=0,W=0,F=0;for(let G=0;G<=I;G+=1)for(let U=0;U<=I;U+=1){let Q=n+G,Y=m+U;Q>Y?E+=P[G][U]:Q===Y?W+=P[G][U]:F+=P[G][U]}let M=E+W+F||1,N=G=>{let U=0,Q=0;for(let Y=0;Y<=I;Y+=1)for(let nt=0;nt<=I;nt+=1){let J=n+m+Y+nt;J>G?U+=P[Y][nt]:J===G&&(Q+=P[Y][nt])}return{over:U,push:Q,under:Math.max(0,1-U-Q)}},O=G=>{let U=0,Q=0;for(let Y=0;Y<=I;Y+=1)for(let nt=0;nt<=I;nt+=1){let J=n+Y-(m+nt)+G;J>0?U+=P[Y][nt]:J===0&&(Q+=P[Y][nt])}return{home:U,push:Q,away:Math.max(0,1-U-Q)}},j=$+C,D=Math.exp(-j);return{p1:E/M,px:W/M,p2:F/M,lh:$,la:C,share:d,expTotal:n+m+j,nextGoal:{home:j>0?(1-D)*($/j):0,away:j>0?(1-D)*(C/j):0,none:D},total:N,handicap:O}}var je=(s,r)=>1/s/(1/s+1/r);function Uo(s,r){let a=Dt[r];if(!a||!s?.odds||s.odds.length!==3)return null;let n=vt(s.odds).fair;if(!n)return null;let m=s.total,d=m&&m.over>1&&m.under>1?je(m.over,m.under):null;return d==null?null:Dn({p1:n[0],px:n[1],p2:n[2],line:m.line,pOver:d},a)}function Bn(s,r,a,n=["Хозяева","Гости"]){let m=Uo(s,a);if(!m)return[];let d=Dt[a],u=Pe({score:[0,0],minute:0},m,d),c=[],h=new Set,f=g=>g>0?`+${g}`:`${g}`,x=g=>{let y=String(g??"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?\d+(?:\.\d+)?/g);return y?Number(y[y.length-1]):NaN};for(let g of r||[]){if(g.kind!=="total"&&g.kind!=="handicap"||g.outcomes?.length!==2)continue;let y=`${g.title||""} ${g.period||""}`;if(/тайм|период|четверт|half|period|инд|команд|угл|карт|corner|card|овертайм|буллит|с уч[её]том|(^|[^а-яё])от([^а-яё]|$)/i.test(y.replace(/осн\.?\s*время/i,"")))continue;if(g.kind==="handicap"){let F=x(g.outcomes[0].label);if(Number.isFinite(F)||(F=x(g.line)),!Number.isFinite(F)||Math.abs(F)>4||h.has(`h${F}`))continue;let M=Number(g.outcomes[0].odd),N=Number(g.outcomes[1].odd);if(!(M>1&&N>1))continue;let O=u.handicap(F),j=1-O.push||1;if(Math.abs(O.home/j-je(M,N))>.15)continue;h.add(`h${F}`),c.push({label:`Фора ${n[0]} ${f(F)}`,odd:M,p:O.home/j,kind:"handicap",side:"home",line:F,source:"Fonbet без маржи"},{label:`Фора ${n[1]} ${f(-F)}`,odd:N,p:O.away/j,kind:"handicap",side:"away",line:-F,source:"Fonbet без маржи"});continue}let v=Number(String(g.line||"").replace(",","."));if(!Number.isFinite(v)||v<=0||v>(a==="hockey"?12:9)||h.has(v))continue;let _=Kt(g.outcomes.map(F=>F.label));if(_<0)continue;let $=u.total(v),C=1-$.push||1,I=$.over/C,P=$.under/C,E=Number(g.outcomes[_].odd),W=Number(g.outcomes[1-_].odd);!(E>1&&W>1)||Math.abs(I-je(E,W))>.2||(h.add(v),c.push({label:`Тотал больше ${v}`,odd:E,p:I,kind:"total",line:v,source:"Fonbet без маржи"},{label:`Тотал меньше ${v}`,odd:W,p:P,kind:"total",line:v,source:"Fonbet без маржи"}))}return c}function Vo(s){let r=(s||[]).map(Number);if(!r.length||!r.every(d=>d>1))return null;let a=r.map(d=>1/d),n=a.reduce((d,u)=>d+u,0),m=a.map(d=>d/n);return m.length===3?m[0]+m[1]/2:m[0]}function Rn(s,r){if(!s?.p1)return{ok:!1,reason:"нет прогноза"};if(s.confidence==="очень низкая")return{ok:!1,reason:"мало матчей в архиве — модель почти ничего не знает об участниках"};let a=Vo(r);return a!=null&&Math.abs(s.p1-a)>.2?{ok:!1,reason:`модель расходится с ценой конторы на ${Math.round(Math.abs(s.p1-a)*100)} п.п. — скорее всего, она чего-то не знает (квалификация, травма, состав)`}:{ok:!0,reason:""}}var Wo={cs:!1,dota:!1,tennis:!1,basketball:!1,mma:!1,hockey:!1},qn=s=>Wo[s]===!0;function Ie(s,r){if(!s?.p1||!(s.p2>0))return"";let a=n=>n>.01&&n<.99?(1/n*1.03).toFixed(2):"—";return`По модели Линзы интересная цена от: ${r[0]} — ${a(s.p1)}, ${r[r.length-1]} — ${a(s.p2)} (справочно: модель пока не точнее цены конторы).`}var Be={atp:{hard:.645,clay:.625,grass:.67},wta:{hard:.565,clay:.55,grass:.585}};function Lt(s,r=0,a=0){let n=1-s,m=s*s/(s*s+n*n),d=new Map,u=(c,h)=>{if(c>=4&&c-h>=2)return 1;if(h>=4&&h-c>=2)return 0;if(c>=3&&h>=3)return c===h?m:c>h?s+n*m:s*m;let f=c*16+h;return d.has(f)||d.set(f,s*u(c+1,h)+n*u(c,h+1)),d.get(f)};return u(r,a)}function pe(s,r,a=0,n=0,m=!0,d=7){let u=v=>v?s:1-r,c=s*(1-r)/(s*(1-r)+(1-s)*r),h=v=>v===0?0:Math.floor((v+1)/2),f=h(a+n)%2===0?m:!m,x=v=>h(v)%2===0?f:!f,g=new Map,y=(v,_)=>{if(v>=d&&v-_>=2)return 1;if(_>=d&&_-v>=2)return 0;if(v>=d-1&&_>=d-1&&v===_)return c;let $=v*64+_;if(!g.has($)){let C=u(x(v+_));g.set($,C*y(v+1,_)+(1-C)*y(v,_+1))}return g.get($)};return y(a,n)}function De(s,r,a=0,n=0,m=!0,d=7){let u=Lt(s),c=1-Lt(r),h=new Map,f=(x,g,y)=>{if(x>=6&&x-g>=2||x===7)return 1;if(g>=6&&g-x>=2||g===7)return 0;if(x===6&&g===6)return pe(s,r,0,0,y,d);let v=x*32+g*2+(y?1:0);if(!h.has(v)){let _=y?u:c;h.set(v,_*f(x+1,g,!y)+(1-_)*f(x,g+1,!y))}return h.get(v)};return f(a,n,m)}function Gn(s,r,a,n=3,{finalTb:m=7}={}){let d=n>=5?3:2,u=(s.sets||[]).filter(([F,M])=>F>M).length,c=(s.sets||[]).length-u,[h,f]=s.games||[0,0],[x,g]=s.points||[0,0],y=s.aServes!==!1,_=u===d-1&&c===d-1?m:7,$=new Map,C=(F,M)=>{if(F>=d)return 1;if(M>=d)return 0;let N=F*8+M;if(!$.has(N)){let O=F===d-1&&M===d-1?m:7,j=(De(r,a,0,0,!0,O)+De(r,a,0,0,!1,O))/2;$.set(N,j*C(F+1,M)+(1-j)*C(F,M+1))}return $.get(N)},I=h===6&&f===6,P,E;if(I)P=pe(r,a,x,g,y,_),E=P;else{E=y?Lt(r,x,g):1-Lt(a,g,x);let F=(M,N)=>M>=6&&M-N>=2||M===7?1:N>=6&&N-M>=2||N===7?0:De(r,a,M,N,!y,_);P=E*F(h+1,f)+(1-E)*F(h,f+1)}return{match:P*C(u+1,c)+(1-P)*C(u,c+1),set:P,game:E,hold:y?E:1-E}}function Un(s,r,a=3){return(Gn({sets:[],games:[0,0],points:[0,0],aServes:!0},s,r,a).match+Gn({sets:[],games:[0,0],points:[0,0],aServes:!1},s,r,a).match)/2}var Ko=.03,Tt=(s,r,a)=>s.set(r,(s.get(r)||0)+a);function Zo(s,r,a=!0){let n=Lt(s),m=Lt(r),d=new Map,u=new Map([[`0,0,${a?1:0}`,1]]);for(;u.size;){let c=new Map;for(let[h,f]of u){let[x,g,y]=h.split(",").map(Number),v=y===1;if(x===6&&g===6){let $=pe(s,r,0,0,v);Tt(d,`7,6,${v?0:1}`,f*$),Tt(d,`6,7,${v?0:1}`,f*(1-$));continue}let _=v?n:1-m;for(let[$,C,I]of[[x+1,g,_],[x,g+1,1-_]]){let P=($>=6||C>=6)&&Math.abs($-C)>=2||$===7||C===7,E=`${$},${C},${v?0:1}`;Tt(P?d:c,E,f*I)}}u=c}return[...d].map(([c,h])=>{let[f,x,g]=c.split(",").map(Number);return{ga:f,gb:x,nextA:g===1,p:h}})}function Vn(s,r,a=3){let n=a===5?3:2,m=new Map,d=g=>{let y=g?1:0;return m.has(y)||m.set(y,Zo(s,r,g)),m.get(y)},u=new Map,c=new Map,h=new Map,f=[{sa:0,sb:0,a:!0,t:0,d:0,p:.5},{sa:0,sb:0,a:!1,t:0,d:0,p:.5}];for(;f.length;){let g=new Map;for(let y of f)for(let v of d(y.a)){let _=y.sa+(v.ga>v.gb?1:0),$=y.sb+(v.gb>v.ga?1:0),C=y.t+v.ga+v.gb,I=y.d+v.ga-v.gb,P=y.p*v.p;if(_===n||$===n){Tt(u,`${_}:${$}`,P),Tt(c,C,P),Tt(h,I,P);continue}let E=`${_},${$},${v.nextA?1:0},${C},${I}`,W=g.get(E);W?W.p+=P:g.set(E,{sa:_,sb:$,a:v.nextA,t:C,d:I,p:P})}f=[...g.values()]}let x=(g,y)=>[...g].reduce((v,[_,$])=>v+(y(Number(_))?$:0),0);return{sets:Object.fromEntries(u),win:[...u].reduce((g,[y,v])=>g+(Number(y.split(":")[0])===n?v:0),0),total:c,diff:h,over:g=>({over:x(c,y=>y>g),push:x(c,y=>y===g)}),handicap:g=>({home:x(h,y=>y+g>0),push:x(h,y=>y+g===0)})}}var Ho=0,Xo=.04,Yo=[[-2.0201828705,.0199532421],[-.9585724646,.3936193232],[0,.9453087205],[.9585724646,.3936193232],[2.0201828705,.0199532421]].map(([s,r])=>[s*Math.SQRT2,r/Math.sqrt(Math.PI)]);function Jo(s,{tour:r="atp",surface:a="hard",bestOf:n=3,serveShift:m=Ho,daySd:d=Xo}={}){let u=((Be[r]||Be.atp)[a]||.63)+m,c=F=>Math.max(-.3,Math.min(.3,F)),h=d>0?Yo:[[0,1]],f=F=>h.reduce((M,[N,O])=>M+O*Un(u+c(F+N*d),u-c(F+N*d),n),0),x=-.3,g=.3,y=Math.min(.995,Math.max(.005,s));for(let F=0;F<30;F+=1){let M=(x+g)/2;f(M)<y?x=M:g=M}let v=(x+g)/2;if(h.length===1)return Vn(u+v,u-v,n);let _=h.map(([F,M])=>[M,Vn(u+c(v+F*d),u-c(v+F*d),n)]),$=F=>{let M=new Map;for(let[N,O]of _)for(let[j,D]of F(O))M.set(j,(M.get(j)||0)+N*D);return M},C=$(F=>Object.entries(F.sets)),I=$(F=>F.total),P=$(F=>F.diff),E=(F,M)=>[...F].reduce((N,[O,j])=>N+(M(Number(O))?j:0),0),W=n===5?3:2;return{sets:Object.fromEntries(C),win:[...C].reduce((F,[M,N])=>F+(Number(M.split(":")[0])===W?N:0),0),total:I,diff:P,over:F=>({over:E(I,M=>M>F),push:E(I,M=>M===F)}),handicap:F=>({home:E(P,M=>M+F>0),push:E(P,M=>M+F===0)})}}var Qo={cs:0,dota:0},ts={cs:8,dota:12},me=new Map;function es(s,r){let a=`${r}|${Math.round(Math.min(.999,Math.max(.001,s))*1e3)}`,n=me.get(a);if(n)return n;let m=Te(s,3,r),d=ce(m*r,(1-m)*r),u=bn(),c=0,h=0,f=0,x=0;for(let y=0;y<u.length;y+=1){let v=u[y],_=2*v*(1-v);c+=d[y]*v*v,h+=d[y]*(1-v)*(1-v),f+=d[y]*_*v,x+=d[y]*_*(1-v)}let g={q:m,sets:{"2:0":c,"2:1":f,"1:2":x,"0:2":h},over25:f+x,homeMinus15:c,awayMinus15:h};return me.size>5e3&&me.clear(),me.set(a,g),g}function ns(s,{pick:r=0,kappaMap:a=1/0}={}){if(Number.isFinite(a)&&!r)return es(s,a);let n=h=>Math.min(.999,Math.max(.001,h)),m=h=>{let f=n(h+r),x=n(h-r),g=n(h),y=f*x,v=(1-f)*(1-x),_=f*(1-x)+(1-f)*x;return{q:h,s20:y,s02:v,s21:_*g,s12:_*(1-g)}},d=0,u=1;for(let h=0;h<50;h+=1){let f=(d+u)/2,x=m(f);x.s20+x.s21<s?d=f:u=f}let c=m((d+u)/2);return{q:c.q,sets:{"2:0":c.s20,"2:1":c.s21,"1:2":c.s12,"0:2":c.s02},over25:c.s21+c.s12,homeMinus15:c.s20,awayMinus15:c.s02}}var os={tennis:!0,cs:!1,dota:!1};function ss(s=""){let r=String(s),a=/wta|жен|women/i.test(r)?"wta":"atp",n=/грунт|clay/i.test(r)?"clay":/трав|grass/i.test(r)?"grass":"hard",m=/australian open|roland garros|ролан|уимблдон|wimbledon|us open|открытый чемпионат (австралии|сша)/i.test(r);return{tour:a,surface:n,bestOf:m&&a==="atp"?5:3}}function Re({sport:s,model:r=null,p:a=null,source:n="модель Линзы",markets:m,names:d=["Хозяева","Гости"],league:u=""}){let c=a??r?.p1;if(!os[s]||!(c>0&&c<1))return[];let h=s==="tennis",f=h?Jo(c,ss(u)):ns(c,{pick:Qo[s]||0,kappaMap:ts[s]??1/0}),x=P=>{let E=String(P??"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?\d+(?:\.\d+)?/g);return E?Number(E[E.length-1]):NaN},g=(P,E)=>1/P/(1/P+1/E),y=(P,E)=>E>0?P/(1-E):P,v=h?"гейма":"карты",_=P=>String(P||"").toLowerCase().replace(/ё/g,"е"),$=d.flatMap(P=>_(P).split(/[^a-zа-я0-9-]+/)).filter(P=>P.length>=4),C=[],I=new Set;for(let P of m||[]){if(P.scope==="list"||P.main===!1||P.kind!=="total"&&P.kind!=="handicap"||P.outcomes?.length!==2||!P.outcomes.every(M=>M.odd>1))continue;let E=`${P.title||""} ${P.period||""}`;if(/сет|set|тай-?брейк|tie|инд|игрок|player|раунд|round|килл|kill|чет|нечет/i.test(E)||$.some(M=>_(E).includes(M))||!h&&/гейм|game/i.test(E))continue;let[W,F]=P.outcomes;if(P.kind==="total"){let M=Number.isFinite(x(P.line))?x(P.line):x(W.label);if(!Number.isFinite(M)||I.has(`t${M}`)||(h?M<12||M>60:M!==2.5))continue;let N=!/меньш|under/i.test(W.label),O,j=0;if(h){let Q=f.over(M);O=Q.over,j=Q.push}else if(M===2.5)O=f.over25;else continue;let D=N?W:F,G=N?F:W,U=y(O,j);if(Math.abs(U-g(D.odd,G.odd))>.2)continue;I.add(`t${M}`),C.push({label:`Тотал ${h?"геймов":"карт"} больше ${M}`,odd:D.odd,p:U,kind:"total",line:M,source:n}),C.push({label:`Тотал ${h?"геймов":"карт"} меньше ${M}`,odd:G.odd,p:1-U,kind:"total",line:M,source:n})}else{let M=Number.isFinite(x(W.label))?x(W.label):x(P.line);if(!Number.isFinite(M)||I.has(`h${M}`)||(h?Math.abs(M)>15:Math.abs(M)!==1.5))continue;let N,O=0;if(h){let G=f.handicap(M);N=G.home,O=G.push}else if(M===-1.5)N=f.homeMinus15;else if(M===1.5)N=1-f.awayMinus15;else continue;let j=y(N,O);if(Math.abs(j-g(W.odd,F.odd))>.2)continue;I.add(`h${M}`);let D=G=>G>0?`+${G}`:`${G}`;C.push({label:`Фора ${d[0]} ${D(M)} ${v}`,odd:W.odd,p:j,kind:"handicap",side:"home",line:M,source:n}),C.push({label:`Фора ${d[1]} ${D(-M)} ${v}`,odd:F.odd,p:1-j,kind:"handicap",side:"away",line:-M,source:n})}}return C}function Wn({sport:s,model:r,markets:a,names:n,league:m=""}){let d=Re({sport:s,model:r,markets:a,names:n,league:m}).filter(c=>c.p>=.15&&c.p<=.85),u=new Map;for(let c of d){let h=`${c.kind}|${Math.abs(c.line)}`;(!u.has(h)||c.p*c.odd>u.get(h).p*u.get(h).odd)&&u.set(h,c)}return[...u.values()].sort((c,h)=>Math.abs(c.p-.5)-Math.abs(h.p-.5)).map(c=>({label:c.label,from:Math.round(1/c.p*(1+Ko)*100)/100,odd:c.odd}))}var fe=globalThis.__lzBus,qe=fe&&window.top===window?cn(location.hostname):null;qe&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,is(qe.adapter,qe.book));async function is(s,r){let a=await Ce(["lz.settings","lz.positions","lz.express","lz.margins","lz.whatsnew"]),n={settings:{...ze,...a["lz.settings"]||{}},positions:(a["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:ls(a["lz.express"]),margins:ue(a["lz.margins"]),whatsnew:a["lz.whatsnew"]||null,analysis:new Map,compare:new Map,consensus:new Map,model:new Map,facts:new Map,fonbetRef:new Map,live:new Map,edges:{status:"idle",data:null,error:"",at:0},partners:{data:{},at:0},status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},m=new WeakMap,d=new WeakMap,u=mn(),c=zn({bus:fe,brand:ee,actions:we()});c.restore(n.positions);function h(i){let t=i.outcomes.map(p=>p.odd).join("/"),o=m.get(i);if(o?.sig===t)return o.set;let l=vt(i.outcomes.map(p=>p.odd));return m.set(i,{sig:t,set:l}),l}function f(){return n.match?n.analysis.get(n.match.key):null}function x(i){let t=f()?.result;if(!t?.model||i.scope==="list"||!n.match||!Object.values(t.shift||{}).some(b=>Math.abs(b)>=.5))return null;let{home:o,draw:l,away:p}=t.model,k=i.outcomes.length;if(i.kind==="1x2"&&i.main&&k===3)return[o,l,p];if(i.kind==="12"&&i.main&&k===2&&l<.005)return[o,p];if(i.kind==="dc"&&i.main&&k===3)return[o+l,o+p,l+p];if(/^победит\s*\(осн\.?\s*время\)$/i.test(i.title)&&k===2){let b=i.period===n.match.home?o:i.period===n.match.away?p:null;if(b!=null)return[b,1-b]}return null}function g(){let i=n.markets.filter(t=>t.scope!=="list"&&t.main&&(t.kind==="1x2"||t.kind==="12"));return i.find(t=>t.scope==="top")||i[0]||null}function y(i,t){let o=i.outcomes[t].label;return i.scope==="list"?!i.event||!i.main?o:i.kind==="1x2"?[i.event.home,"Ничья",i.event.away][t]||o:i.kind==="12"&&[i.event.home,i.event.away][t]||o:n.match?i.kind==="1x2"?[n.match.home,"Ничья",n.match.away][t]||o:i.kind==="12"&&[n.match.home,n.match.away][t]||o:o}function v(){let i=n.settings.overlay,t=[];for(let l of n.markets){if(l.outcomes.forEach((A,T)=>d.set(A.el,{market:l,index:T})),i==="off")continue;let p=h(l);if(p.kind==="partial")continue;let k=x(l),b=k||p.fair,w=0;for(let A=1;A<p.fair.length;A+=1)p.fair[A]>p.fair[w]&&(w=A);let z="accent";if(k){let A=0;for(let T=1;T<k.length;T+=1)k[T]-p.fair[T]>k[A]-p.fair[A]&&(A=T);k[A]-p.fair[A]>=.015&&(w=A,z="pos")}let S=l.scope!=="list"||l.main&&(l.kind==="1x2"||l.kind==="12");l.outcomes.forEach((A,T)=>{let L=T===w&&S;!L&&i!=="all"||t.push({el:A.el,frame:L,chip:kt(b[T]),tone:L?z:"quiet"})})}let o=_();if(o){let l=t.find(p=>p.el===o.item.el);l?l.selected=!0:t.push({el:o.item.el,frame:!1,selected:!0,chip:null})}u.set(t)}function _(){if(!n.selected)return null;let i=n.markets.find(o=>o.id===n.selected.id),t=i?.outcomes[n.selected.index];return t?.el?.isConnected?{market:i,item:t,index:n.selected.index}:null}function $(){if(n.settings.theme!=="auto")return n.settings.theme;for(let i of[document.body,document.documentElement]){let o=(i?getComputedStyle(i).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!o||o[4]==="0")continue;return(.2126*o[1]+.7152*o[2]+.0722*o[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}let C=0;function I(){clearTimeout(C),C=setTimeout(()=>$t({"lz.margins":n.margins}),1500)}function P(){if(n.pageType!=="match"||!n.match||n.match.live)return;n.margins=ue(n.margins);let i=D();i&&An(n.margins,{key:n.match.key,book:r.id,margin:i.margin})&&I()}function E(){location.href!==n.url&&(n.url=location.href,n.selected=null,u.hideTip());let i="other",t=[],o=null;try{i=s.pageType(document,location),t=s.collect(document,location),o=s.readMatch(document,location)}catch(p){console.error("[Линза] страница не прочитана",p)}i!==n.pageType&&(n.pageType=i,n.tab!=="settings"&&n.tab!=="express"&&(n.tab=i==="match"?"match":"scan")),n.markets=t,n.match=o,P();let l=$();l!==n.theme&&(n.theme=l),u.setTheme(n.theme),c.setTheme(n.theme),v(),gt(),M(),c.isOpen&&(St(),Zt(),Xt(),_t(),c.render(J()))}let W=new Set,F=null;function M(){if(s.observeTargets)for(let i of s.observeTargets(document))W.has(i)||(W.add(i),F=F||new MutationObserver(j),F.observe(i,{childList:!0,subtree:!0,characterData:!0}))}let N=0,O=0;function j(){let i=Date.now();O||(O=i),clearTimeout(N);let t=i-O>900?0:220;N=setTimeout(()=>{O=0,!document.hidden&&E()},t)}function D(){let i=g();if(!i)return null;let t=h(i);if(t.kind!=="full")return null;let o=x(i);return{title:"Что заложено в цене",margin:t.margin,rows:i.outcomes.map((l,p)=>({name:y(i,p),odd:l.odd,fair:t.fair[p],model:o?o[p]:null})),overtime:G()}}function G(){if(!["hockey","basketball"].includes(n.match?.sport))return null;let i=n.markets.find(o=>o.scope!=="list"&&o.outcomes.length===2&&/овертайм|булл|(^|[^а-яё])от([^а-яё]|$)|\bot\b/i.test(`${o.title} ${o.period}`)&&!/тотал|фора|будет|перв|втор|трет|период|тайм/i.test(`${o.title} ${o.period}`));if(!i)return null;let t=h(i);return t.kind!=="full"?null:{title:[i.title,i.period].filter(Boolean).join(" · "),rows:i.outcomes.map((o,l)=>({name:y(i,l)||[n.match.home,n.match.away][l],odd:o.odd,fair:t.fair[l]}))}}function U(){let i=_();if(!i)return null;let{market:t,item:o,index:l}=i,p=h(t),k=x(t),b=p.fair?p.fair[l]:null,w=t.event?`${t.event.home} — ${t.event.away}`:n.match?`${n.match.home} — ${n.match.away}`:"",z=n.match?n.compare.get(n.match.key):null,S=null;if(z?.rows?.length&&t.main&&(t.kind==="1x2"||t.kind==="12")&&t.scope!=="list")for(let T of z.rows){let L=T.odds[l];L&&(!S||L>S.odd)&&(S={name:T.name,odd:L,book:T.book||""})}S&&(S.partner=S.book&&S.book!==r.id&&n.partners.data?.[S.book]||null,S.gain=Math.round((S.odd-o.odd)*(n.settings.stake||1e3)));let A=`${t.id}#${l}`;return{market:[t.title,t.period,t.line].filter(Boolean).join(" · "),label:[y(t,l),w].filter(Boolean).join(" · "),odd:o.odd,fair:b,margin:p.margin,fairOdd:b?1/b:null,model:k?k[l]:null,ev:k?He(k[l],o.odd):null,best:S,canAdd:Number.isFinite(b)&&!n.express.some(T=>T.id===A),inExpress:n.express.some(T=>T.id===A),note:p.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":k?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function Q(){let i=Ln(ue(n.margins),r.id);if(!i)return null;let t=i.best&&i.best.there<i.best.here?i.best:null,o=t&&xt().find(l=>l.name===t.name&&(l.url||l.code))||null;return{...i,best:t,partner:o}}function Y(){let i=[];if(n.pageType==="match"?n.markets.forEach((p,k)=>{if(p.scope==="list")return;let b=h(p);if(b.kind!=="full")return;let w=0;for(let z=1;z<b.fair.length;z+=1)b.fair[z]>b.fair[w]&&(w=z);i.push({index:k,name:p.title,sub:[p.period,p.line].filter(Boolean).join(" · "),margin:b.margin,fav:p.outcomes[w].label,favPct:b.fair[w]})}):n.markets.forEach((p,k)=>{if(!p.event||!p.main||p.kind!=="1x2"&&p.kind!=="12")return;let b=h(p);if(b.kind!=="full")return;let w=0;for(let S=1;S<b.fair.length;S+=1)b.fair[S]>b.fair[w]&&(w=S);let z=p.kind==="1x2"?[p.event.home,"Ничья",p.event.away][w]:[p.event.home,p.event.away][w];i.push({index:k,name:`${p.event.home} — ${p.event.away}`,sub:p.event.league||p.event.time,margin:b.margin,fav:z,favPct:b.fair[w]})}),!i.length)return null;let t=new Set;for(let p=i.length-1;p>=0;p-=1){let k=`${i[p].name}|${i[p].sub}`;t.has(k)?i.splice(p,1):t.add(k)}let o=i.reduce((p,k)=>p+k.margin,0)/i.length;i.sort((p,k)=>p.margin-k.margin);let l=i.slice(0,16);return l.forEach(p=>{p.low=p.margin<=o*.8}),{title:n.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:n.pageType==="match"?"Рынок":"Матч",average:o,rows:l,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${l.length} из ${i.length}, сначала самые дешёвые.`}}function nt(){let i=n.status;return i.ready?i.limit?`Разборов сегодня: ${i.used} из ${i.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function J(){let i=n.match?.key,t=i&&n.analysis.get(i)||{status:"idle",steps:[]},o=i&&n.compare.get(i)||{status:"idle"},l=n.match?.live&&s.readEsportsWidget?s.readEsportsWidget(document):null,p=n.status;return{tab:n.tab,backTab:n.backTab,theme:n.theme,bookName:r.name,pageType:n.pageType,match:n.match?{...n.match,sportName:Ue[n.match.sport]||""}:null,esports:l?{...l,homeName:n.match.home,awayName:n.match.away}:null,line:D(),analysis:{status:t.status,steps:t.steps||[],result:t.result||null,error:t.error||"",needKey:!!t.needKey},compare:o,consensus:i&&n.consensus.get(i)||null,model:i&&n.model.get(i)||null,live:ve(i),verdict:be(i),facts:i&&n.facts.get(i)||null,pick:U(),scan:n.tab==="scan"?Y():null,margins:n.tab==="scan"?Q():null,edges:n.edges,bookId:r.id,partners:xt(),earnLinks:Object.values(n.partners.data||{}).some(k=>k&&(k.url||k.code)),stake:Number(n.settings.stake)||1e3,express:{legs:n.express,stats:Ze(n.express)},quota:nt(),update:n.status.update?{version:n.status.update,url:ee.site?`${ee.site}#install`:""}:null,whatsnew:n.whatsnew?{version:n.whatsnew.to,changes:Cn(n.whatsnew.from,n.whatsnew.to)}:null,settings:{overlay:n.settings.overlay,theme:n.settings.theme,stake:Number(n.settings.stake)||1e3,mode:p.mode,proxy:p.proxy,ready:p.ready,hasKey:p.hasKey,keyMask:p.keyMask,licenseMask:p.licenseMask,plan:p.plan==="free"||!p.plan?"":`Тариф «${{max:"Макс",vip:"VIP",api:"API"}[p.plan]||"Про"}»${p.until?` до ${p.until.split("-").reverse().join(".")}`:""}.`,usage:p.limit?`Сегодня разборов: ${p.used} из ${p.limit}.`:""}}}let ot=()=>{c.isOpen&&c.render(J())};function ht(i){Object.assign(n.settings,i),$t({"lz.settings":n.settings}),E(),c.render(J())}async function zt(i=!1){if(!i&&Date.now()-n.partners.at<3600*1e3)return;n.partners.at=Date.now();let t=await et("lz:partners",{force:i});t.ok&&t.data&&typeof t.data=="object"&&(n.partners.data=t.data,c.isOpen&&c.render(J()),pt())}let xt=()=>Object.values(n.partners.data||{}).filter(i=>i&&i.id!==r.id);function pt(){if(!c.isOpen||n.tab!=="match"||!n.match)return;let i=xt().filter(t=>t.url||t.code).map(t=>t.id);i.length&&et("lz:partner-seen",{ids:i,s:"panel"})}async function ct(){n.edges={...n.edges,status:"loading",error:""};let i=await et("lz:edges",{sport:n.match?.sport||""});n.edges=i.ok?{status:"done",data:i.data,error:"",at:Date.now()}:{status:"error",data:n.edges.data,error:i.error,at:Date.now()},ot()}async function ut(){let i=await et("lz:status");i.ok&&(n.status=i.data),ot()}function Ct(){let i=g(),t=i?h(i):null;return{book:r.name,match:n.match,market:i&&t?.kind==="full"?{kind:i.kind,labels:i.outcomes.map((o,l)=>y(i,l)),odds:i.outcomes.map(o=>o.odd)}:null}}function he(){return n.markets.filter(i=>i.scope!=="list"&&i.main!==!1&&(i.kind==="total"||i.kind==="handicap")&&i.outcomes?.length===2).slice(0,40).map(i=>({kind:i.kind,title:i.title||"",period:i.period||"",line:i.line??"",outcomes:i.outcomes.map(t=>({label:t.label||"",odd:Number(t.odd)}))}))}function Ot(){let i=n.match?.live&&s.readEsportsWidget?s.readEsportsWidget(document):null;return i?{home:i.home.map(t=>t.nick),away:i.away.map(t=>t.nick)}:null}function gt(){if(!n.match||!wt())return;let i=Ct();if(!i.market)return;let t=`${n.match.key}|${i.market.odds.join("/")}`;t!==gt.last&&(gt.last=t,et("lz:quote",i))}async function St(){let i=n.match;if(!i||i.live||n.consensus.has(i.key))return;let t=Ct();if(!t.market?.odds?.length)return;n.consensus.set(i.key,null);let o=await et("lz:consensus",{match:i,size:t.market.odds.length});n.consensus.set(i.key,o.ok&&o.data?.consensus?o.data:null),n.match?.key===i.key&&c.isOpen&&c.render(J())}async function _t(){let i=n.match;if(!i?.live||!["basketball","football","hockey","tennis"].includes(i.sport))return;let t=n.live.get(i.key);if(t&&(t.pending||Date.now()-t.at<3e4))return;n.live.set(i.key,{...t||{},pending:!0});let o=await et("lz:live",{match:i});n.live.set(i.key,{at:Date.now(),data:o.ok&&o.data&&!o.data.error?o.data:null,error:o.ok?o.data?.error||"":o.error||""}),n.match?.key===i.key&&c.isOpen&&c.render(J())}function Et(i,t){n.fonbetRef.set(i,null),et("lz:fonbet-ref",{match:t}).then(o=>{n.fonbetRef.set(i,o.ok&&o.data?.odds?o.data:null),o.ok&&o.data?.odds&&n.match?.key===i&&c.isOpen&&c.render(J())}).catch(()=>{})}function ge(i,t,o){let l=n.match,p=`${i}|${[t.best,t.suspect,...t.others].filter(Boolean).map(b=>`${b.label}:${b.odd}`).join(",")}`;if(n.verdictSent===p)return;n.verdictSent=p;let k=[t.best,t.suspect,...t.others].filter(Boolean).map(b=>({label:b.label,odd:b.odd,p:b.p,kind:b.kind||"win",side:b.side||"",line:b.line??null,source:b.source||o,unit:b.unit||""}));et("lz:verdict",{payload:{sport:l.sport,league:l.league||"",home:l.home,away:l.away,book:r.name,source:o,best:t.best?.label||"",options:k}}).then(b=>{b?.ok&&b.data?.track&&b.data.track!==n.verdictTrack&&(n.verdictTrack=b.data.track,c.isOpen&&c.render(J()))}).catch(()=>{})}function be(i){let t=n.match,o=i&&D();if(!t||!o||t.live)return null;let l=n.consensus.get(i),p=o.rows,k=n.model.get(i),b=k&&Rn(k,p.map(q=>q.odd)).ok?k:null,w=b&&qn(t.sport)?b:null,z=n.analysis.get(i)?.result,S=[t.home,t.away],A=[],T="";if(l?.consensus?.length===p.length)p.forEach((q,tt)=>A.push({label:q.name,odd:q.odd,p:l.consensus[tt],side:p.length===3?["home","draw","away"][tt]:["home","away"][tt]})),T=`консенсус ${l.count} контор`;else if(!l?.consensus&&w?.sport==="hockey"&&w.regulation&&p.length===3){let q=[w.regulation.p1,w.regulation.px,w.regulation.p2];p.forEach((tt,lt)=>A.push({label:tt.name,odd:tt.odd,p:q[lt],side:["home","draw","away"][lt]})),T="модель Линзы"}else{let q=p.length===2?p:t.sport==="mma"&&p.length===3?[p[0],p[2]]:o.overtime?.rows||null,tt=l?.consensus?.length===2?l.consensus:w?.p1?[w.p1,w.p2]:null;q&&tt&&(q.forEach((lt,at)=>A.push({label:S[at],odd:lt.odd,p:tt[at],side:["home","away"][at]})),T=l?.consensus?.length===2?`консенсус ${l.count} контор`:"модель Линзы")}let L=w?.sport==="mma"?w.durations:null;if(L)for(let q of n.markets){if(q.scope==="list"||q.kind!=="total"||q.outcomes.length!==2)continue;let tt=String(q.line||"").replace(",","."),lt=tt==="1.5"?L.r1+L.r2/2:tt==="2.5"&&L.rounds===3?L.r1+L.r2+L.r3/2:null,at=Kt(q.outcomes.map(bt=>bt.label));lt==null||at<0||A.some(bt=>bt.kind==="total"&&bt.line===tt)||(A.push({label:`Больше ${tt} раунда`,odd:q.outcomes[at].odd,p:1-lt,kind:"total",line:tt}),A.push({label:`Меньше ${tt} раунда`,odd:q.outcomes[1-at].odd,p:lt,kind:"total",line:tt}))}if(w?.sport==="basketball"&&w.lines){let q=qt=>{let dt=String(qt||"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?[0-9]+(?:[.][0-9]+)?/);return dt?Number(dt[0]):NaN},tt=qt=>n.markets.filter(dt=>dt.scope!=="list"&&dt.main&&dt.kind===qt&&dt.outcomes.length===2&&dt.outcomes.every(te=>te.odd>1)).sort((dt,te)=>Math.abs(dt.outcomes[0].odd-dt.outcomes[1].odd)-Math.abs(te.outcomes[0].odd-te.outcomes[1].odd))[0]||null,lt=tt("handicap"),at=tt("total"),bt=lt?q(lt.outcomes[0].label):NaN;lt&&!Number.isFinite(bt)&&(bt=q(lt.line));let Qt=at?q(at.line):NaN;at&&!Number.isFinite(Qt)&&(Qt=q(at.outcomes[0].label));let Me=at?Kt(at.outcomes.map(qt=>qt.label)):-1;A.push(...Pn(w,{handicap:lt&&Number.isFinite(bt)?{line:bt,home:lt.outcomes[0].odd,away:lt.outcomes[1].odd}:null,total:at&&Me>=0&&Number.isFinite(Qt)?{line:Qt,over:at.outcomes[Me].odd,under:at.outcomes[1-Me].odd}:null},S))}let B=n.markets.filter(q=>q.scope!=="list"),K=p.length===2?vt(p.map(q=>q.odd)):null;K?.fair&&["tennis","cs","dota"].includes(t.sport)&&A.push(...Re({sport:t.sport,p:K.fair[0],source:"цена конторы на победу",markets:B,names:S,league:t.league||""}));let H=b?.p1&&["tennis","cs","dota"].includes(t.sport)?Wn({sport:t.sport,model:b,markets:B,names:S,league:t.league||""}):[];if((t.sport==="football"||t.sport==="hockey")&&r.id!=="fonbet"){let q=n.fonbetRef.get(i);q===void 0?Et(i,t):q&&A.push(...Bn(q,n.markets.filter(tt=>tt.scope!=="list"),t.sport,S))}if(!A.length)return b?.p1?{best:null,suspect:null,others:[],lines:[Ie(b,S),"Это расчёт, а не обещание: проиграть можно и при перевесе в цене. 18+"],track:n.verdictTrack||""}:null;let st=[...A].filter(q=>q.p*q.odd-1>=.03&&q.p*q.odd-1<=.12).sort((q,tt)=>tt.p*tt.odd-q.p*q.odd)[0]?.side,mt=(z?.factors||[]).filter(q=>st&&q.side===st).slice(0,2).map(q=>q.text),it=On(A,{source:T,reasons:mt,risk:z?.risks?.[0]||""});return it&&b?.p1&&!w&&it.lines.splice(it.lines.length-1,0,Ie(b,S)),it&&H.length&&it.lines.splice(it.lines.length-1,0,`По модели Линзы интересная цена от: ${H.slice(0,6).map(q=>`${q.label} — ${q.from.toFixed(2)}${q.odd>=q.from?" ✓ здесь выше":""}`).join(" · ")}.`),it&&ge(i,it,T),it&&{...it,track:n.verdictTrack||""}}function xe(i,t,o){let l=(w,z)=>t?[z,w]:[w,z],k=D()?.rows||[],b=k.length===2&&k.every(w=>Number.isFinite(w.fair))?k.map(w=>w.fair):null;return{kind:"tennis",names:[n.match.home,n.match.away],score:l(i.score[0],i.score[1]),sets:i.sets.map(([w,z])=>l(w,z)),games:l(i.games[0],i.games[1]),points:l(i.points[0],i.points[1]),tiebreak:i.tiebreak,serving:i.aServes==null?null:i.aServes!==t?0:1,bestOf:i.bestOf,prior:i.prior,serve:l(i.serve.a,i.serve.b),probs:l(i.p1,i.p2),set:l(i.set.p1,1-i.set.p1),game:l(i.game.p1,1-i.game.p1),book:b,compare:i.prior.source==="line"||i.prior.source==="model",at:o}}function ye(i,t,o){let l=(z,S)=>t?[S,z]:[z,S],p=z=>t?[z[2],z[1],z[0]]:z,b=D()?.rows||[],w=b.length===3&&b.every(z=>Number.isFinite(z.fair))?b.map(z=>z.fair):null;return{kind:"goals",sport:i.sport,names:[n.match.home,n.match.away],score:l(i.score[0],i.score[1]),red:l(i.red[0],i.red[1]),minute:i.minute,period:i.period,periods:i.periods,clock:i.clock,prior:i.prior,probs:p([i.p1,i.px,i.p2]),book:w,compare:i.prior.source==="line",expTotal:i.expTotal,nextGoal:p([i.nextGoal.home,i.nextGoal.none,i.nextGoal.away]),total:i.tables.total,handicap:i.tables.handicap.map(z=>t?{line:-z.line,home:z.away,away:z.home}:z).sort((z,S)=>z.line-S.line),bookLines:i.bookLines,at:o}}function ve(i){let t=i&&n.live.get(i);if(!t?.data)return t?.error?{error:t.error}:null;let o=t.data,l=!!o.flipped;if(o.kind==="goals")return ye(o,l,t.at);if(o.kind==="tennis")return xe(o,l,t.at);let p=(S,A)=>l?[A,S]:[S,A],k=D(),b=k?.overtime?.rows||k?.rows||[],w=b.length===2?b.map(S=>S.fair):b.length===3&&b.every(S=>Number.isFinite(S.fair))?[b[0].fair+b[1].fair/2,b[2].fair+b[1].fair/2]:null,z=o.tables||{};return{names:[n.match.home,n.match.away],score:p(o.score[0],o.score[1]),periods:(o.periods||[]).map(([S,A])=>p(S,A)),period:o.period,elapsed:o.elapsed,left:o.left,clock:o.clock,format:o.format,probs:p(o.p1,o.p2),book:w,prior:o.prior,expMargin:l?-o.expMargin:o.expMargin,sd:o.sd,projTotal:o.projTotal,sdTotal:o.sdTotal,handicap:(z.handicap||[]).map(S=>l?{line:-S.line,home:S.away,away:S.home}:S).sort((S,A)=>S.line-A.line),total:z.total||[],quarterTotal:z.quarterTotal||[],bookLines:o.bookLines?{handicap:o.bookLines.handicap?l?{...o.bookLines.handicap,line:-o.bookLines.handicap.line,odds:[...o.bookLines.handicap.odds].reverse(),fair:[...o.bookLines.handicap.fair].reverse(),p:1-o.bookLines.handicap.p,book:1-o.bookLines.handicap.book,gap:-o.bookLines.handicap.gap}:o.bookLines.handicap:null,total:o.bookLines.total||null}:null,quarter:o.quarter?{...o.quarter,score:p(o.quarter.score[0],o.quarter.score[1]),expMargin:l?-o.quarter.expMargin:o.quarter.expMargin,probs:p(o.quarter.p1,o.quarter.p2)}:null,at:t.at}}async function Zt(){let i=n.match;if(!i||!["cs","dota","tennis","basketball","mma","hockey"].includes(i.sport)||n.model.has(i.key)||i.live&&(i.sport==="tennis"||i.sport==="basketball"||i.sport==="mma"||i.sport==="hockey"))return;n.model.set(i.key,null);let t=await et("lz:model",{match:i});n.model.set(i.key,t.ok&&t.data?.p1?t.data:null),n.match?.key===i.key&&c.isOpen&&c.render(J())}let Ht=new Map;async function Xt(){let i=n.match;if(!i||!["football","hockey","basketball","cs","dota"].includes(i.sport))return;let t=i.live&&Date.now()-(Ht.get(i.key)||0)>60*1e3;if(n.facts.has(i.key)&&!t)return;let o=n.facts.get(i.key)||null;Ht.set(i.key,Date.now()),n.facts.set(i.key,o);let l=await et("lz:facts",{match:i});n.facts.set(i.key,l.ok&&l.data?.facts?.length?l.data:o),n.match?.key===i.key&&c.isOpen&&c.render(J())}async function ke(){let i=n.match;if(!i||n.analysis.has(i.key))return;let t=await et("lz:cached",{match:i});!t.ok||!t.data||n.analysis.has(i.key)||(n.analysis.set(i.key,{status:"done",steps:[],result:t.data}),E(),ot())}function we(){return{opened(){ut(),E(),ke(),St(),Zt(),Xt(),_t(),zt(),c.render(J()),pt()},tab(i){i==="settings"&&(n.backTab=n.tab==="settings"?n.backTab:n.tab),n.tab=i||"match",i==="edges"&&n.edges.status!=="loading"&&Date.now()-n.edges.at>300*1e3&&ct(),c.render(J())},"edges-refresh"(){ct(),c.render(J())},theme(){ht({theme:n.theme==="dark"?"light":"dark"})},"overlay-toggle"(){ht({overlay:n.settings.overlay==="off"?"picks":"off"})},"set-overlay"(i){ht({overlay:i})},"set-theme"(i){ht({theme:i})},async"set-mode"(i){await et("lz:settings",{mode:i}),ut()},"copy-code"(i){if(!i)return;let t=()=>c.toast("Промокод скопирован");navigator.clipboard?.writeText?navigator.clipboard.writeText(i).then(t,()=>c.toast(`Промокод: ${i}`)):c.toast(`Промокод: ${i}`)},"set-stake"(i,t,o){let l=Math.round(Number(o.getElementById("lz-stake")?.value));if(!Number.isFinite(l)||l<10||l>1e7)return c.toast("Введите сумму от 10 ₽");ht({stake:l}),c.toast("Сумма сохранена")},async"save-key"(i,t,o){let l=o.getElementById("lz-key"),p=(l?.value||"").trim();if(p.length<8)return c.toast("Вставьте ключ целиком");let k=await et("lz:settings",{apiKey:p});c.toast(k.ok?"Ключ сохранён":k.error),l&&(l.value=""),ut()},async"clear-key"(){await et("lz:settings",{apiKey:""}),c.toast("Ключ удалён"),ut()},async"save-license"(i,t,o){let l=o.getElementById("lz-license"),p=(l?.value||"").trim();if(p.length<6)return c.toast("Вставьте ключ целиком");let k=await et("lz:settings",{licenseKey:p});c.toast(k.ok?"Ключ принят":k.error),l&&(l.value=""),ut()},async"clear-license"(){await et("lz:settings",{licenseKey:""}),c.toast("Ключ удалён"),ut()},savePosition(i,t){n.positions[i]=t,Ce(["lz.positions"]).then(o=>{let l=o["lz.positions"]||{};l[location.hostname]=n.positions,$t({"lz.positions":l})})},async analyze(){if(!n.match)return;let i=n.match.key,t={status:"loading",steps:[`${n.match.home} — ${n.match.away}`]};n.analysis.set(i,t),ot();let o=await et("lz:analyze",{...Ct(),markets:he(),players:Ot(),force:!0}),l=o.ok?o.data?.job:"",p=Date.now();for(;l&&o.ok&&o.data?.status==="running"&&Date.now()-p<420*1e3;){if(t.steps=[t.steps[0],...(o.data.steps||[]).map(k=>k.text)].slice(-8),ot(),await new Promise(k=>setTimeout(k,2e3)),n.analysis.get(i)!==t)return;o=await et("lz:job",{job:l}),!o.ok&&o.code==="retry"&&(o=await et("lz:job",{job:l}))}if(o.ok&&l){let k=o.data?.steps?.length?[t.steps[0],...o.data.steps.map(b=>b.text)].slice(-8):t.steps;o.data.status==="done"?n.analysis.set(i,{status:"done",steps:k,result:{...o.data.result,full:o.data.full||null}}):o.data.status==="error"?n.analysis.set(i,{status:"error",steps:k,error:o.data.error}):n.analysis.set(i,{status:"error",steps:k,error:"Разбор идёт дольше 7 минут. Нажмите ещё раз — собранное уже на сервере, второй раз будет быстрее."})}else o.ok?n.analysis.set(i,{status:"done",steps:t.steps,result:o.data}):n.analysis.set(i,{status:"error",steps:t.steps,error:o.error,needKey:o.code==="no-access"});ut(),E(),c.render(J())},async report(){let i=n.match?n.analysis.get(n.match.key):null,t="";try{t=chrome.runtime.getManifest().version}catch{}let o=await et("lz:report",{where:"panel",url:location.href,book:r.name,version:t,match:n.match?`${n.match.home} — ${n.match.away}`:"",step:i?.steps?.slice(-1)[0]||"",error:i?.error||(i?.status==="done"?"разбор выглядит неправильно":"страница матча не узнана")});c.toast(o.ok?"Спасибо! Сообщение ушло разработчику.":o.error)},async compare(){if(!n.match)return;let i=n.match.key;n.compare.set(i,{status:"loading"}),ot();let t=await et("lz:compare",Ct());n.compare.set(i,t.ok?{status:"done",...t.data}:{status:"done",rows:[],labels:[],note:t.error}),t.ok&&Fn(n.margins,i,t.data.rows)&&I(),ot()},"whatsnew-ok"(){n.whatsnew=null,$t({"lz.whatsnew":null}),ot()},"pick-clear"(){n.selected=null,v(),ot()},"leg-add"(){let i=U(),t=_();!i?.canAdd||!t||(n.express.push({id:`${t.market.id}#${t.index}`,title:i.market,label:i.label,odd:i.odd,fair:i.fair,at:Date.now()}),$t({"lz.express":n.express}),c.toast("Добавлено в расчёт экспресса"),ot())},"leg-remove"(i){n.express=n.express.filter(t=>t.id!==i),$t({"lz.express":n.express}),ot()},"leg-clear"(){n.express=[],$t({"lz.express":n.express}),ot()},"scan-go"(i){let t=n.markets[Number(i)],o=t?.outcomes[0]?.el;o?.isConnected&&(o.scrollIntoView({behavior:"smooth",block:"center"}),n.selected={id:t.id,index:0},setTimeout(v,400))}}}function Yt(i){let t=i.composedPath();for(let o=0;o<Math.min(t.length,6);o+=1){let l=t[o]instanceof Element?d.get(t[o]):null;if(l&&l.market.outcomes[l.index]?.el===t[o])return l}return null}let Pt=new Map;function $e(i){if(!i.event||!i.main||!["1x2","12"].includes(i.kind)||i.scope!=="list"||i.event.live)return console.debug("[lz] рынок для списка не запрашивается:",JSON.stringify({event:!!i.event,main:i.main,kind:i.kind,scope:i.scope,live:i.event?.live})),null;let t=i.event.key;if(Pt.has(t))return Pt.get(t);let o={home:i.event.home,away:i.event.away,sport:Jt(i),league:i.event.league||""},l=et("lz:consensus",{match:o,size:i.outcomes.length}).then(p=>((!p.ok||!p.data?.consensus)&&console.debug("[lz] рынок для списка:",p.error||p.data?.error||"нет данных"),p.ok&&p.data?.consensus?p.data:null)).catch(p=>(console.debug("[lz] рынок для списка:",String(p?.message||p)),null));return Pt.set(t,l),l.then(p=>Pt.set(t,p)),l}let Jt=i=>i.event?.sport||n.match?.sport||It(location.pathname,document.title,i.event?.league);function Nt({market:i,index:t},o=null){let l=h(i),p=x(i),k=i.event?`${i.event.home} — ${i.event.away}`:"",b=i.outcomes.map((S,A)=>{let T=l.fair?l.fair[A]:1/S.odd;return e(`div.tip-row${A===t?".hot":""}`,{},e("span",{text:y(i,A)}),e("span.odd",{text:Z(S.odd)}),e("span.pct",{text:kt(T,T<.1?1:0)}),e("span.tip-bar",{},e("i",{style:`width:${Math.round(T*100)}%`})))}),w=l.kind==="partial"?e("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):e("div.tip-foot",{},"Маржа конторы ",e("b",{text:kt(l.margin,1)}),p?e("span",{}," · модель: ",e("b",{text:kt(p[t],1)})):null),z=null;if(o?.consensus){let S=o.consensus.length===i.outcomes.length,A=!S&&o.consensus.length===2&&i.outcomes.length===3;if(S||A){let T=S?o.consensus[t]:null,L=T?i.outcomes[t].odd*T-1:0;z=e("div.tip-foot",{},`Рынок, ${o.count} контор${A?", с овертаймом":""}: `,e("b",{text:o.consensus.map(B=>kt(B,0)).join(" / ")}),L>.005?e("span.pos",{text:` · кэф выше рынка на ${(L*100).toFixed(1)}%`}):null)}}else o===void 0&&(z=e("div.tip-foot",{text:"Рынок: сверяю…"}));return e("div",{},e("div.tip-title",{text:[i.title,i.period,i.line].filter(Boolean).join(" · ")}),k?e("div.tip-sub",{text:k}):e("div.tip-sub",{text:"Шанс по линии без маржи"}),b.slice(0,8),w,z)}let Bt=0,jt=null;fe.on("page:pointerover",i=>{if(n.settings.overlay==="off")return;let t=Yt(i),o=t?t.market.outcomes[t.index].el:null;if(o!==jt){if(jt=o,clearTimeout(Bt),!t)return u.hideTip();Bt=setTimeout(()=>{if(jt!==o||!o.isConnected)return;u.setAvoid(c.rect());let l=$e(t.market);u.showTip(o,Nt(t,l instanceof Promise?void 0:l)),l instanceof Promise&&l.then(p=>{jt===o&&o.isConnected&&u.showTip(o,Nt(t,p))})},280)}}),fe.on("page:click",i=>{let t=Yt(i);t&&(n.selected={id:t.market.id,index:t.index},n.tab==="scan"&&(n.tab="match"),v(),ot())}),_n(i=>{if(i.type!=="lz:progress")return;let t=n.analysis.get(i.key);!t||t.status!=="loading"||(t.steps=[...t.steps,i.text].slice(-7),ot())});let Rt=()=>{E(),new MutationObserver(j).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||E()}),setInterval(()=>{!document.hidden&&location.href!==n.url&&E()},600),setInterval(()=>{!document.hidden&&c.isOpen&&j()},4e3),wt()&&chrome.storage.onChanged.addListener(i=>{i["lz.settings"]&&(n.settings={...ze,...i["lz.settings"].newValue||{}},E())}),ut()};document.body?Rt():document.addEventListener("DOMContentLoaded",Rt,{once:!0}),document.documentElement.setAttribute("data-lz",r.id),globalThis.__lz={state:n,view:J,refresh:E,overlay:u,panel:c}}function ls(s){let r=Date.now()-432e5;return(Array.isArray(s)?s:[]).filter(a=>a&&a.at>r&&a.odd>1)}})();
