(()=>{var Qt=s=>typeof s=="string"?s:"",te={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:Qt("https://efremen512218-lang.github.io/linza/"),telegram:Qt("https://t.me/linza_odds"),bot:Qt("https://t.me/linza_keys_bot?start=ext")},Xo=Qt("https://185-72-145-3.sslip.io"),Bn={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var Dn=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function Be(s){let r=String(s||"").toLowerCase();return Dn.find(a=>a.hosts.some(n=>r===n||r.endsWith(`.${n}`)))||null}var we={overlay:"picks",theme:"auto",mode:"own",model:Bn.model,stake:1e3},De={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",mma:"ММА",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function vt(s){let r=String(s??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(r))return null;let a=parseFloat(r.replace(",","."));return a>=1.001&&a<=1e3?a:null}var qe=s=>s.reduce((r,a)=>r+1/a,0);function yt(s){let r=(s||[]).filter(n=>Number.isFinite(n)&&n>1);if(r.length<2||r.length!==(s||[]).length)return{kind:"partial",margin:null,fair:null};let a=qe(r);if(a>=.985&&a<=1.3)return{kind:"full",margin:a-1,fair:r.map(n=>1/n/a)};if(r.length===3&&a>=1.97&&a<=2.4){let n=a/2;return{kind:"double",margin:n-1,fair:r.map(m=>Math.min(.995,1/m/n))}}return{kind:"partial",margin:null,fair:null}}function Re(s){let r=(s||[]).map(f=>f||[]).filter(f=>f.length),a=r.flat().filter(Boolean);if(a.length<2)return{sets:[],rest:a};let n=f=>f.length>=2&&f.every(Boolean)&&yt(f.map(h=>h.odd)).kind!=="partial",m=f=>{let h=f.filter(x=>x.some(Boolean));if(!h.length)return null;let v=h.filter(n);if(v.length/h.length<.6)return null;let g=new Set(v.flat());return{sets:v,rest:a.filter(x=>!g.has(x))}},d=f=>{let h=[];for(let v=0;v<r.length;v+=f)h.push(r.slice(v,v+f).flat());return h},u=()=>{let f=[];for(let h=0;h+1<r.length;h+=2){let v=Math.max(r[h].length,r[h+1].length);for(let g=0;g<v;g+=1)f.push([r[h][g]??null,r[h+1][g]??null])}return f},c=[()=>d(1)];r.length>=2&&r.length%2===0&&c.push(u,()=>d(2)),r.length>=3&&r.length%3===0&&c.push(()=>d(3)),r.length>1&&c.push(()=>[r.flat()]);for(let f of c){let h=m(f());if(h)return h}return{sets:[],rest:a}}function Ge(s,r=1.13){let a=c=>{let f=qe(c.map(h=>h.odd));return f>=.995&&f<=r?!0:c.length===3&&f>=1.99&&f<=r*2},n=c=>Math.abs(c*4-Math.round(c*4))<1e-9,m=[],d=[],u=0;for(;u<s.length;){let c=s.slice(u,u+3),f=s.slice(u,u+2);c.length===3&&a(c)?(m.push(c),u+=3):f.length===2&&a(f)?(m.push(f),u+=2):s[u+2]&&n(s[u+1].odd)&&a([s[u],s[u+2]])?(m.push([s[u],s[u+2]]),d.push(s[u+1]),u+=3):(d.push(s[u]),u+=1)}return{sets:m,rest:d}}function Ue(s){let r=(s||[]).filter(m=>m&&m.odd>1&&m.fair>0&&m.fair<1);if(!r.length)return null;let a=r.reduce((m,d)=>m*d.odd,1),n=r.reduce((m,d)=>m*d.fair,1);return{legs:r.length,odd:a,chance:n,fairOdd:1/n,margin:1-a*n}}function Ve(s,r){return s*r-1}function Z(s){return Number.isFinite(s)?s>=100?s.toFixed(0):s>=10?s.toFixed(1):s.toFixed(2):"—"}function kt(s,r=0){if(!Number.isFinite(s))return"—";let a=s*100;return a>0&&a<1&&r===0?"<1%":`${a.toFixed(r)}%`}function $e(s){return String(s??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zа-я0-9]/g,"")}var qn=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function We(s){return String(s??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[\u0300-\u036f]/g,"").split(/[^a-zа-я0-9]+/).filter(r=>r.length>=2&&!qn.has(r))}function Gt(s,r){let a=$e(s),n=$e(r);if(a.length<2||n.length<2)return 0;if(a===n)return 1;let m=a.length<=n.length?a:n,d=m===a?n:a;if(m.length>=4&&d.includes(m))return .85;let u=We(s),c=We(r),f=v=>String(v??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[̀-ͯ]/g,"").match(/^\s*([a-zа-я-]{3,})\s+([a-zа-я])\.?\s*$/);for(let[v,g]of[[s,c],[r,u]]){let x=f(v);if(x&&g.length>=2&&g.includes(x[1])&&g.some(y=>y!==x[1]&&y[0]===x[2]))return .8}if(u.length&&c.length){let g=u.filter(x=>c.some(y=>y===x||x.length>=5&&y.startsWith(x.slice(0,5)))).length/Math.max(u.length,c.length);if(g>=.5)return .6+.3*g}let h=0;for(;h<a.length&&h<n.length&&a[h]===n[h];)h+=1;return h>=5?Math.min(.8,.45+h*.04):0}function Rn(s){let r=String(s??"").toLowerCase(),a=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(r)&&a.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(r)&&a.push("women"),/\(рез|\(р\)|резерв|reserve/.test(r)&&a.push("reserve"),/люб/.test(r)&&a.push("amateur"),/кибер|esport|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(r)&&a.push("cyber"),a.join("+")}function Ft(s,r){let a=d=>{let u=$e(d),c=Rn(d);return u.length<2?"":c?`${u}~${c}`:u},n=a(s),m=a(r);return!n||!m?"":[n,m].sort().join("|")}var D=s=>(s?.textContent||"").replace(/[ \s]+/g," ").trim(),Me=s=>s.offsetParent===null&&s.tagName!=="BODY";function Gn(s){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(s||"").trim())}function Un(s){let r=String(s||"").match(/(\d+)\s*[-‑–]?\s*(?:го|й|м|ой|ий|я|ая|ья|ый)?\s+(период|тайм|сет|четверт|половин|карт|гейм|иннинг)/i);return r?r[0]:""}function Ut(s,r){let a=String(s||"").toLowerCase();return/двойной шанс/.test(a)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(a)?"other":/фор[аы]|гандикап/.test(a)?"handicap":/тотал/.test(a)?"total":/обе забьют/.test(a)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(a)?r===3?"1x2":r===2?"12":"other":"other"}var Vn=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/(^|[^а-яёa-z])(мма|mma|ufc|юфс)([^а-яёa-z]|$)|смешанн|единоборств|mixed martial|бои без правил/i,"mma"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function It(...s){let r=s.filter(Boolean).join(" ");for(let[a,n]of Vn)if(a.test(r))return n;return""}function ze(s){if(!s)return null;let r=vt(D(s));if(r)return r;let a=D(s).split(" ");return vt(a[a.length-1])}var Wn=0;function Tt({scope:s,title:r,period:a="",line:n="",kind:m,outcomes:d,event:u=null,anchor:c=null,eventKey:f=""}){let h=d.length;return{id:`${s}|${f}|${r}|${a}|${n}|${d.map(v=>v.label).join("/")}`,serial:Wn+=1,scope:s,title:r,period:a,line:n,kind:m||Ut(r,h),main:Gn(a)&&!Un(r),outcomes:d,event:u,anchor:c||d[0]?.el||null}}var X=(s,r)=>[...s.querySelectorAll(r)];function Ye(s){return(String(s||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function Se(s){return s.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":s.querySelector(".card")?"list":"other"}var Ke={win:"В",loose:"П",lose:"П",draw:"Н"};function Ze(s){return X(s,".competitor-form__value").map(r=>Ke[[...r.classList].find(a=>Ke[a])]||D(r).slice(0,1)).filter(Boolean).join("")}function Kn(s){let r=s.querySelector(".marketbook-header--live");if(r){let n=X(r,".game-scoring__item").map(u=>D(u)),m=X(r,".game-periods .period").map(u=>{let c=X(u,"span");return{label:D(u.querySelector("i")),home:D(c[0]),away:D(c[1])}}).filter(u=>u.home!==""&&u.away!==""),d=X(r,".game-specials > div").map(u=>{let c=X(u,"span"),f=u.querySelector("i"),h=f?.classList.contains("yellow-card")?"жёлтые":f?.classList.contains("red-card")?"красные":f?.classList.contains("penalty-card")?"угловые":"";return h?{kind:h,home:D(c[0]),away:D(c[1])}:null}).filter(Boolean);return{state:D(r.querySelector(".game-timing-state")),score:n.length===2?n:[],periods:m,extras:d}}let a=s.querySelector(".match-card");if(a&&!a.querySelector(".match-card__timer--prematch")){let n=D(a.querySelector(".match-card__main-score")).replace(/\s/g,""),m=X(a,".match-card__score").map(u=>D(u)).filter(u=>/^\d{1,2}$/.test(u)),d=X(s,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(u=>D(u)).filter(u=>/\d\s*:\s*\d/.test(u)).slice(0,5);return{state:D(a.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(n)?n.split(":"):[],rounds:m.length>=2?m.slice(0,2):[],periods:d.map((u,c)=>({label:`${c+1} карта`,raw:u})),extras:[]}}return null}function He(s,r){if(Se(s)!=="match")return null;let a=X(s,".breadcrumbs .breadcrumbs__item").map(h=>D(h)).filter(Boolean),n=D(s.querySelector(".event-breadcrumbs")),m=X(s,".marketbook-header--prematch .competitor-name").map(h=>D(h));if(m.length<2&&(m=X(s,".marketbook-header--live .competitors-desc__name").map(h=>D(h))),m.length<2&&(m=X(s,".match-card .match-card__team-name").map(h=>D(h))),m.length<2||!m[0]||!m[1])return null;let d=It(a[1]&&/киберспорт/i.test(a[0])?a[1]:"",a[0],n),u=/киберспорт/i.test(a[0]||"")?a.slice(2).join(", ")||n.split(",").slice(1).join(",").trim():a.slice(1).join(", "),c=[D(s.querySelector(".prematch-date")),D(s.querySelector(".prematch-time"))].filter(Boolean).join(" ")||D(s.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),f=Kn(s);return{book:"Winline",id:Ye(r?.pathname),key:Ft(m[0],m[1]),home:m[0],away:m[1],sport:d,league:u,start:f?"":c,live:f,form:{home:Ze(s.querySelector(".competitor-form--left")||s.createElement("div")),away:Ze(s.querySelector(".competitor-form--right")||s.createElement("div"))},stats:Qn(to(s),m[0],m[1]),url:r?.href||""}}function Zn(s,r){let a=[];for(let n of X(s,".bet-line")){if(Me(n))continue;let m=D(n.querySelector(".bet-line__market-name")),d=D(n.querySelector(".bet-line__period")),u=X(n,".odd-btn"),c=u.map((h,v)=>{let g=D(h.querySelector(".odd-btn__label")),x=X(h,"span").map(y=>vt(D(y))).find(Boolean)||null;return x?{el:h,odd:x,label:g||_e(u.length,v,m),locked:!1}:null});if(c.length<2||c.some(h=>!h))continue;let f=D(n.querySelector(".coef-btn")).replace(/\s+/g," ");a.push(Tt({scope:"top",title:m,period:d,line:f,outcomes:c,anchor:n,eventKey:r}))}return a}function _e(s,r,a){return/тотал/i.test(a)?["Меньше","Больше"][r]||"":s===3?["П1","Х","П2"][r]:s===2?["1","2"][r]:String(r+1)}function Hn(s,r){let a=[];for(let n of X(s,".market")){let m=X(n,".market__row");if(!m.length)continue;let d=D(n.querySelector(".market-title")),u=m.map(f=>{let h=D(f.querySelector(".market__row-text"));return X(f,".market-row-btn").map(v=>{let g=vt(D(v.querySelector(".market-row-btn__coef")));if(!g||v.hasAttribute("disabled"))return null;let x=v.getAttribute("title")||D(v.querySelector(".market-row-btn__text"));return{el:v,odd:g,label:x.replace(/\s+/g," ").trim(),rowLabel:h,locked:!1}})}),{sets:c}=Re(u);for(let f of c){let h=[...new Set(f.map(y=>y.rowLabel).filter(Boolean))],v=h.length<=1,g=v?"":(f[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],x=f.map(y=>({el:y.el,odd:y.odd,label:v?y.label:y.rowLabel||y.label,locked:!1}));a.push(Tt({scope:"board",title:d,period:v&&h[0]||"",line:g,kind:Ut(d,x.length),outcomes:x,anchor:n,eventKey:r}))}}return a}var Xn=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function Yn(s){let r=X(s,".card__competitors .name .name, .half__names .name").map(n=>D(n));if(r.length<2)return null;let a=s.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:Ye(a),key:Ft(r[0],r[1]),home:r[0],away:r[1],href:a,live:/card--live/.test(s.className)||!!s.querySelector(".card__body-live"),time:D(s.querySelector(".header-left__time, .footer__time")),league:D(s.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:s}}function Xe(s){let r=[];for(let a of X(s,".card")){if(Me(a))continue;let n=Yn(a);if(n){for(let m of X(a,".card__body")){let d=D(m.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(m.className)?"отрезок":"");for(let u of X(m,".card__market")){let c=X(u,".coefficient-button");if(c.length<2)continue;let f=(Xn.find(([v])=>v.test(c[0].className))||[])[1]||"other",h=c.map((v,g)=>{let x=/--is-blank/.test(v.className)?null:ze(v);return x?{el:v,odd:x,label:f==="total"?["Меньше","Больше"][g]:_e(c.length,g,""),locked:/coefficient-button_locked/.test(v.className)}:null});h.some(v=>!v)||r.push(Tt({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[f]||"Рынок",period:/^матч$/i.test(d)?"":d,line:D(u.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:f,outcomes:h,event:n,anchor:a,eventKey:n.key}))}}for(let m of X(a,".half__coef-buttons")){let d=X(m,".coef-buttons__button"),u=d.map((c,f)=>{let h=ze(c.querySelector(".button__coef-title")||c);return h?{el:c,odd:h,label:_e(d.length,f,""),locked:!1}:null});u.length<2||u.some(c=>!c)||r.push(Tt({scope:"list",title:u.length===3?"Исход":"Победитель",kind:u.length===3?"1x2":"12",outcomes:u,event:n,anchor:a,eventKey:n.key}))}}}return r}function Jn(s){if(!s?.body)return null;let r=f=>/^\d{1,3}\s?%$/.test(f),a=X(s,"h4").map(f=>{let h=[...f.nextElementSibling?.children||[]],v=D(h[0]),g=D(h[h.length-1]);return r(v)&&r(g)?{label:D(f),home:v.replace(/\s/g,""),away:g.replace(/\s/g,"")}:null}).filter(Boolean);if(!a.length)return null;let n=(s.body.innerText||s.body.textContent||"").replace(/\s+/g," "),m=[...n.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(f=>Number(f[1])),u=[...(n.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(f=>f[1].replace(/\s/g,""));return{names:D(s.querySelector("h3")).split(/\s+vs\s+/i).map(f=>f.trim()).filter(Boolean),rows:a,samples:m.slice(0,2),form:u.length>=2?{home:u[0],away:u[1]}:null}}function Qn(s,r,a){if(!s||s.names.length<2)return s;let n=Gt(s.names[0],r)+Gt(s.names[1],a);return Gt(s.names[0],a)+Gt(s.names[1],r)<=n?s:{names:[s.names[1],s.names[0]],rows:s.rows.map(d=>({label:d.label,home:d.away,away:d.home})),samples:s.samples.slice().reverse(),form:s.form?{home:s.form.away,away:s.form.home}:null}}function to(s){let r=s.querySelector("iframe.stats__iframe");if(!r)return null;try{return Jn(r.contentDocument)}catch{return null}}function eo(s){let r=["one","two"].map(d=>s.querySelector(`.event-live-center__team-widget--${d}`));if(!r[0]||!r[1])return null;let a=d=>{let u=d;try{u=d.querySelector("iframe")?.contentDocument?.body||d}catch{u=d}let c=X(u,'[class*="player"]').filter(h=>!X(h,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(h.className)),f=[];for(let h of c){let v=D(h).split(" ").filter(Boolean),g=v.find(y=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test(y)&&/[A-Za-z]/.test(y));if(!g||f.some(y=>y.nick===g))continue;let x=v.filter(y=>/^\d{1,3}$/.test(y)).map(Number);f.push({nick:g,numbers:x.slice(0,4)})}return f.slice(0,5)},n=a(r[0]),m=a(r[1]);return n.length<3||m.length<3?null:{home:n,away:m}}var Je={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:Se,readMatch:He,readEsportsWidget:eo,observeTargets(s){try{let r=s.querySelector("iframe.stats__iframe")?.contentDocument?.body;return r?[r]:[]}catch{return[]}},collect(s,r){if(Se(s)==="match"){let m=He(s,r)?.key||"";return[...Zn(s,m),...Hn(s,m),...Xe(s)]}return Xe(s)}};var ne=(s,r)=>{try{return[...s.querySelectorAll(r)]}catch{return[]}};function Qe(s,r){let a=[s];if(r.shadow)for(let n of ne(s,r.shadow))n.shadowRoot&&a.push(n.shadowRoot);return a}var ee=s=>(s.defaultView?.innerWidth||0)>0,no='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function oo(s){let r=[],a=s.ownerDocument.createTreeWalker(s,4);for(;a.nextNode();){let n=a.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(n&&r.push(...n.split(" ")),r.length>5)return null}return r}function so(s,r){if(r.label){let a=s.querySelector(r.label),n=a?a.textContent.replace(/[ \s]+/g," ").trim():"";if(n&&!/^\d{1,3}[.,]\d{1,3}$/.test(n))return n}if(r.cell&&r.headerRow){let a=s.closest(r.cell),n=a?.parentElement,m=n?.parentElement?.querySelector(r.headerRow);if(m&&m!==n){let d=[...n.children].indexOf(a),u=m.children[d]?.textContent.replace(/[ \s]+/g," ").trim()||"";if(u)return u.charAt(0).toUpperCase()+u.slice(1).toLowerCase()}}return""}function ro(s,r){if(!r.cell||!r.lineCell)return"";let a=s.closest(r.cell);for(;a&&(a=a.previousElementSibling);){if(!a.matches?.(r.lineCell))continue;let n=a.textContent.replace(/[ \s]+/g," ").trim().match(/([+\-−–]?\d+(?:[.,]\d+)?)\s*\)?\s*$/);return n?n[1].replace(",",".").replace(/[−–]/,"-"):""}return""}function ao(s,r){if(s.disabled||s.hasAttribute?.("disabled"))return null;let a=r.value&&s.querySelector(r.value)||s,n=oo(a);if(!n||!n.length||n.join(" ").length>28)return null;let m=n[n.length-1];if(!(r.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(m))return null;let d=vt(m);if(!d||d>500||n.slice(0,-1).some(c=>/^\d{1,3}[.,]\d{1,3}$/.test(c)))return null;let u=n.slice(0,-1).join(" ");return!r.outcome&&/[+−]|^-/.test(u)?null:{odd:d,label:u}}function io(s,r){let a=[],n=new Set,m=Qe(s,r).flatMap(d=>ne(d,r.outcome||no));for(let d of m){if(n.has(d)||r.skip&&d.closest(r.skip)||d.closest("#lz-root, #lz-marks"))continue;let u=ao(d,r);if(u){if(!r.outcome&&ee(s)){let c=d.getBoundingClientRect();if(c.width<26||c.width>320||c.height<16||c.height>90)continue}n.add(d),a.push({el:d,odd:u.odd,label:u.label||so(d,r),line:ro(d,r),locked:!1})}}return r.outcome?a:a.filter(d=>!a.some(u=>u.el!==d.el&&u.el.contains(d.el)))}function lo(s,r,a){if(r.row)return s.closest(r.row);let n=s.parentElement;for(let m=0;m<6&&n&&n!==n.ownerDocument.body;m+=1){let d=a(n);if(d>=2&&d<=16){if(!ee(n.ownerDocument))return n;let u=n.getBoundingClientRect();if(u.height<=130&&u.width>=120)return n}if(d>16)break;n=n.parentElement}return null}var tn=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось|окко|okko|матч тв|match tv|кинопоиск|трансляция|видео|статистика|stats)$/i;function co(s,r){let a=r.length,n=s;for(let v=0;v<7;v+=1){let g=n.parentElement;if(!g||r.some(O=>!g.contains(O.el))||g.querySelectorAll("*").length>400||[...g.querySelectorAll('button, a, td, [role="button"]')].filter(O=>!r.some(w=>w.el===O||w.el.contains(O)||O.contains(w.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(D(O))).length>a)break;n=g}let m=r[0].el,d=[],u=n.ownerDocument.createTreeWalker(n,4);for(;u.nextNode();){let v=u.currentNode;if(m.contains(v))break;let g=v.textContent.replace(/[ \s]+/g," ").trim();g.length<2||g.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(g)||/\d{1,2}:\d{2}|^\d|['′]$/.test(g)||tn.test(g)||d.push(g)}let c=d.slice(-2),f=d.map(v=>v.split(/\s+[—–-]\s+/)).filter(v=>v.length===2).pop();if(f&&(c=f),c.length<2||c[0]===c[1])return null;let h=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:Ft(c[0],c[1]),home:c[0],away:c[1],href:h,live:!1,time:"",league:"",card:n}}function uo(s,r,a){if(!r.names)return co(s,a);let n=r.event&&s.closest(r.event)||s,m=[...new Set(ne(n,r.names).map(c=>D(c)).filter(Boolean))],d=m;if(m.length===1&&(d=m[0].split(/\s+[—–-]\s+/)),d.length<2||!d[0]||!d[1])return null;let u=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:Ft(d[0],d[1]),home:d[0],away:d[1],href:u,live:!1,time:"",league:"",card:n}}function po(s){let a=String(s.title||"").replace(/^\s*(ставки на (матч|игру|бой)|матч)\s+/i,"").match(/^(.{2,40}?)\s+(?:[—–-]|x|vs|против)\s+(.{2,40}?)(?=\s*[:,|.(📅]|\s+[—–-]\s|\s+ставк|\s+прогноз|\s+коэффиц|\s+live\b|\s+лайв\b|\s+\d{1,2}(?:[./]\d|\s+[а-я]{3,})|$)/i);if(!a)return null;let n=[a[1].trim(),a[2].trim()];return n.some(m=>/ставк|контор|онлайн|букмекер|прогноз|коэффиц|!$/i.test(m))?null:n}function en(s,r={}){function a(x,y){return r.matchUrl&&r.matchUrl.test(y?.pathname||"")||r.matchPage&&x.querySelector(r.matchPage)?"match":"list"}function n(x){let y=x.defaultView;if(!y||!ee(x))return[];let O=[];for(let w of x.querySelectorAll("h1, h2, h3, div, span, p, a")){if(w.children.length)continue;let L=D(w);if(L.length<3||L.length>40||!/[A-Za-zА-Яа-яЁё]{3}/.test(L)||/\d{1,2}[:.]\d{2}/.test(L)||tn.test(L))continue;let I=w.getBoundingClientRect();if(!(I.top<60||I.top>450||I.width<30||parseFloat(y.getComputedStyle(w).fontSize)<15)&&(O.includes(L)||O.push(L),O.length===2))break}return O}function m(x,y){if(a(x,y)!=="match")return null;let O=r.matchNames?ne(x,r.matchNames).map(L=>D(L)).filter(Boolean):[];if(O.length===1&&(O=O[0].split(/\s+[—–-]\s+/)),O.length<2&&(O=po(x)||[]),O.length<2&&(O=n(x)),O.length<2)return null;let w=r.matchLeague?D(x.querySelector(r.matchLeague)):"";return{book:s.name,id:(String(y?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:Ft(O[0],O[1]),home:O[0],away:O[1],sport:It(y?.pathname,w,x.title,D(x.querySelector('[class*="breadcrumb" i], nav[aria-label*="крошк" i]'))),league:w,start:"",live:/(^|\/)live(\/|$)/i.test(y?.pathname||"")?!0:null,form:{home:"",away:""},url:y?.href||""}}function d(x,y){return!x||!y?"":y.startsWith("attr:")?String(x.getAttribute(y.slice(5))||"").trim():D(x.querySelector(y))}function u(x,y){if(!ee(y))return[x];let O=x.map(L=>{let I=L.el.getBoundingClientRect();return{cell:L,top:I.top,left:I.left}}).sort((L,I)=>Math.abs(L.top-I.top)>8?L.top-I.top:L.left-I.left),w=[];for(let L of O){let I=w[w.length-1];I&&Math.abs(I.top-L.top)<=8?I.cells.push(L.cell):w.push({top:L.top,cells:[L.cell]})}return w.map(L=>L.cells)}let c=[[/^(п1|1)\/(х|x|ничья)\/(п2|2)$/i,"1x2"],[/^(п1|1)\/(п2|2)$/i,"12"],[/^(1х|1x)\/12\/(х2|x2)$/i,"dc"]],f=x=>(c.find(([y])=>y.test(x.join("/").toLowerCase()))||[])[1]||"other";function h(x,y){let O=a(x,y),w=O==="match"&&r.match?{...r,...r.match}:r;return v(x,y,O,w)}function v(x,y,O,w){let L=io(x,w);if(L.length<2)return[];let I=new Set(L.map($=>$.el)),P=$=>{let _=0;for(let C of I)$.contains(C)&&(_+=1);return _},E=new Map;for(let $ of L){let _=lo($.el,w,P);_&&(E.has(_)||E.set(_,[]),E.get(_).push($))}let V=O==="match"?m(x,y):null,F=[];for(let[$,_]of E){let C=O==="match"?null:uo($,w,_),j=w.group?$.closest(w.group):null,B=d(j,w.groupTitle),G=d(j,w.groupPeriod),U=w.visualRows?u(_,x):[_],Q=0;for(let Y of U)for(let nt of Ge(Y).sets){let J=Q===0,ot=nt.length,ht=ot===3?["П1","Х","П2"]:["1","2"],zt=nt.map((ct,ut)=>({...ct,label:ct.label||ht[ut]||String(ut+1)})),xt=J&&ot===3?"Исход":J?"Победитель":`Рынок ${Q+1}`,pt=J?ot===3?"1x2":"12":"other";B&&(xt=B,pt=Ut(B,ot),pt==="other"&&(pt=f(zt.map(ct=>ct.label)))),ot===3&&zt.every(ct=>/\sили\s/i.test(ct.label))&&(pt="dc"),F.push(Tt({scope:O==="match"?"board":"list",title:xt,period:G,line:nt[0].line&&nt.every(ct=>ct.line===nt[0].line)?nt[0].line:"",kind:pt,outcomes:zt,event:C,anchor:$,eventKey:C?.key||V?.key||`row${F.length}`})),Q+=1}}return F}let g=x=>Qe(x,r).slice(1);return{id:s.id,name:s.name,hosts:s.hosts,generic:!0,pageType:a,readMatch:m,collect:h,observeTargets:g,readEsportsWidget:()=>null}}var nn={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]',match:{group:'[class*="market-group-box--"]',groupTitle:'[class*="header--"] [class*="text--"]',label:'[class*="text--"]',cell:'[class*="cell--"]',headerRow:'[class*="header-row--"]',lineCell:'[class*="_align-left--"]'}},on={fonbet:nn,pari:nn,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd, .dg_euv_stake",value:".dg_euv_stake_factor_new",row:".euv_event_home, .dg_euv_stake_grid",names:".euv_event_name_team",integers:!0,matchUrl:/\/sport\/event-details\//,matchNames:"h1"},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name",matchUrl:/\/su\/betting\/.*vs.*\d{5,}/i},leon:{matchUrl:/\/bets\/.+\/\d{10,}-/},olimp:{matchUrl:/\/line\/[^/]+\/[^/]+-\d{4,}\/[^/]+/,match:{outcome:'[data-testid^="bet-button"]',row:'[data-testid="accordion-content"]',group:'[data-testid="accordion"]',groupTitle:'[class*="title--"]',visualRows:!0}},betcity:{matchUrl:/\/ru\/(live|line)\/[^/]+\/\d+\/\d+/},betboom:{matchUrl:/\/sport\/(?:live\/)?[^/]+\/\d+\/\d+\/\d+/},liga:{matchUrl:/\/sports\/[^/]+\/.+-id-\d+/,match:{outcome:"button[outcomeid]",row:"[data-t-market]",group:"[data-t-market]",groupTitle:"attr:data-t-market",groupPeriod:'[class*="header__description"]',visualRows:!0}}};function sn(s){let r=Be(s);return r?r.id==="winline"?{adapter:Je,book:r}:{adapter:en(r,on[r.id]||{}),book:r}:null}var oe=`/* Цвета, шрифт и радиусы панели — из design/tokens.json (node tools/tokens.mjs). Блоки между метками руками не править. */
:host {
  /* tokens:light */
  --lz-accent: #5b4be6;
  --lz-accent-strong: #4a3bd1;
  --lz-accent-soft: rgba(91, 75, 230, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0b8a4d;
  --lz-pos-soft: rgba(11, 138, 77, 0.14);
  --lz-neg: #c93636;
  --lz-neg-soft: rgba(201, 54, 54, 0.12);
  --lz-warn: #b45309;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6fa;
  --lz-surface-2: #eef0f5;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #555c6b;
  --lz-faint: #666b7f;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  /* /tokens */
  color-scheme: light;
}

:host([data-theme="dark"]) {
  /* tokens:dark */
  --lz-accent: #8f82ff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(143, 130, 255, 0.18);
  --lz-accent-ink: #0f1017;
  --lz-pos: #45d08f;
  --lz-pos-soft: rgba(69, 208, 143, 0.16);
  --lz-neg: #ff7676;
  --lz-neg-soft: rgba(255, 118, 118, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #171a23;
  --lz-surface: #1f2330;
  --lz-surface-2: #272b34;
  --lz-border: #2c3040;
  --lz-text: #eef0f6;
  --lz-muted: #a4a8bb;
  --lz-faint: #8e92a8;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  /* /tokens */
  color-scheme: dark;
}
`;var rn=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}

.tip-foot .pos {
  color: var(--lz-pos);
  font-weight: 600;
}
`;function e(s,r,...a){let[n,...m]=s.split("."),d=document.createElement(n||"div");m.length&&(d.className=m.join(" "));for(let[u,c]of Object.entries(r||{}))if(!(c==null||c===!1))if(u==="class")d.className=[d.className,c].filter(Boolean).join(" ");else if(u==="style")d.style.cssText=c;else if(u==="text")d.textContent=c;else{if(u==="html")throw new Error("html запрещён");u.startsWith("data-")||u.startsWith("aria-")||u==="role"||u==="title"||u==="type"||u==="href"||u==="target"||u==="rel"||u==="placeholder"||u==="value"||u==="for"||u==="name"||u==="maxlength"||u==="autocomplete"||u==="spellcheck"||u==="tabindex"?d.setAttribute(u,c===!0?"":String(c)):u==="disabled"||u==="hidden"||u==="checked"||u==="selected"?d[u]=!!c:d[u]=c}return ln(d,a),d}function ln(s,r){for(let a of r)a==null||a===!1||(Array.isArray(a)?ln(s,a):s.appendChild(a instanceof Node?a:document.createTextNode(String(a))))}var an="http://www.w3.org/2000/svg";function rt(s,r=16){let a=document.createElementNS(an,"svg");a.setAttribute("viewBox","0 0 20 20"),a.setAttribute("width",r),a.setAttribute("height",r),a.setAttribute("fill","none"),a.setAttribute("stroke","currentColor"),a.setAttribute("stroke-width","1.7"),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),a.setAttribute("aria-hidden","true");for(let n of ho[s]||[]){let m=document.createElementNS(an,"path");m.setAttribute("d",n),a.appendChild(m)}return a}var ho={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"]};function cn(){let s=document.createElement("div");s.id="lz-marks",s.style.cssText="position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;overflow:hidden!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let r=s.attachShadow({mode:"open"});r.appendChild(e("style",{text:oe+rn}));let a=e("div.layer"),n=e("div.tip");r.append(a,n);let m=new Map,d=new Set,u=0,c=null,f=null,h=new IntersectionObserver($=>{for(let _ of $)_.isIntersecting?d.add(_.target):(d.delete(_.target),m.get(_.target)?.node.classList.remove("on"));g()},{rootMargin:"120px"});function v(){s.isConnected||document.documentElement.appendChild(s)}function g(){u||(u=requestAnimationFrame(()=>{u=0,O()}))}let x=($,_)=>{for(let C=_;C;C=C.parentNode||C.host)if(C===$)return!0;return!1};function y($,_){let C=_.left+_.width/2,j=_.top+_.height/2;if(C<0||j<0||C>window.innerWidth||j>window.innerHeight)return!1;let B=document.elementFromPoint(C,j);for(;B?.shadowRoot?.elementFromPoint;){let G=B.shadowRoot.elementFromPoint(C,j);if(!G||G===B)break;B=G}return!!B&&B!==$&&!x($,B)&&!x(B,$)}function O(){for(let $ of d){let _=m.get($);if(!_)continue;if(!$.isConnected){w($);continue}let C=$.getBoundingClientRect();if(C.width<6||C.height<6||y($,C)){_.node.classList.remove("on");continue}let j=Math.round(C.left),B=Math.round(C.top),G=Math.round(C.width),U=Math.round(C.height);(_.x!==j||_.y!==B)&&(_.node.style.transform=`translate3d(${j}px, ${B}px, 0)`,_.x=j,_.y=B),(_.w!==G||_.h!==U)&&(_.node.style.width=`${G}px`,_.node.style.height=`${U}px`,_.w=G,_.h=U,_.node.classList.toggle("small",U<26)),_.node.classList.add("on")}c&&I()}function w($){let _=m.get($);_&&(h.unobserve($),d.delete($),_.node.remove(),m.delete($))}function L($){v();let _=new Map;for(let C of $)C.el?.isConnected&&_.set(C.el,C);for(let C of[...m.keys()])_.has(C)||w(C);for(let[C,j]of _){let B=m.get(C);if(!B){let U=e("div.mark"),Q=parseFloat(getComputedStyle(C).borderTopLeftRadius);U.style.borderRadius=`${Number.isFinite(Q)&&Q>0?Math.min(Q,16):6}px`;let Y=e("span.chip");U.appendChild(Y),a.appendChild(U),B={node:U,chip:Y,sig:""},m.set(C,B),h.observe(C)}let G=`${j.frame?1:0}|${j.selected?1:0}|${j.tone||""}|${j.chip||""}`;G!==B.sig&&(B.sig=G,B.node.classList.toggle("frame",!!j.frame),B.node.classList.toggle("selected",!!j.selected),B.node.classList.toggle("pos",j.tone==="pos"&&!!j.frame),B.chip.hidden=!j.chip,B.chip.textContent=j.chip||"",B.chip.className=`chip${j.tone&&j.tone!=="accent"?" "+j.tone:""}`)}g()}function I(){if(!c?.isConnected)return E();let $=c.getBoundingClientRect(),_=264,C=n.offsetHeight||140,j=$.left+$.width/2-_/2;j=Math.max(8,Math.min(j,window.innerWidth-_-8)),f&&j+_>f.left-8&&j<f.right&&(j=Math.max(8,f.left-_-10));let B=$.bottom+10;B+C>window.innerHeight-8&&(B=$.top-C-10),B<8&&(B=8),n.style.transform=`translate3d(${Math.round(j)}px, ${Math.round(B)}px, 0)`}function P($,_){v(),c=$,n.replaceChildren(_),I(),n.classList.add("on")}function E(){c=null,n.classList.remove("on")}function V($){f=$}function F($){s.setAttribute("data-theme",$)}return window.addEventListener("scroll",g,{capture:!0,passive:!0}),window.addEventListener("resize",g,{passive:!0}),setInterval(()=>{m.size&&!document.hidden&&g()},700),{set:L,schedule:g,showTip:P,hideTip:E,setTheme:F,setAvoid:V,get tipTarget(){return c},count:()=>m.size}}var un=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 72px minmax(60px, max-content);
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  white-space: nowrap;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.partner { margin-top: 8px; }
.partner-text { font-size: 12px; margin-bottom: 4px; }
.partner-links { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
.partner-links a.btn { text-decoration: none; }
.gain { margin-top: 8px; font-size: 12px; color: var(--lz-text); }
.gain b { color: var(--lz-pos); }
td.name .partner-links { margin-top: 3px; }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.card.update { font-size: 12.5px; }
.card.update b { color: var(--lz-accent); }
/* Строка без номера (факторы модели, факты о составах) занимает обе колонки, иначе текст ломается по словам в узкой. */
.facts li > span:only-child { grid-column: 1 / -1; }
.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  /* 18+ и предупреждение о зависимости должны читаться: не бледный, а обычный второстепенный цвет. */
  color: var(--lz-muted);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;var ie=s=>Math.min(.999,Math.max(.001,s));function Ne(s,r,a=0,n=0){let m=Math.ceil(r/2),d=new Map,u=(c,f)=>{if(c>=m)return 1;if(f>=m)return 0;let h=c*16+f;return d.has(h)||d.set(h,s*u(c+1,f)+(1-s)*u(c,f+1)),d.get(h)};return u(a,n)}function le(s,r){let a=.001,n=.999;for(let m=0;m<50;m++){let d=(a+n)/2;s(d)<r?a=d:n=d}return(a+n)/2}function bo(s,r){let a=ie(s);return Math.ceil(r/2)<=1?a:le(n=>Ne(n,r),a)}function re(s,r,a,n=new Map){if(r>=4)return[1,0];if(a>=4)return[0,0];if(r===3&&a===3)return[0,1];let m=r*8+a;if(!n.has(m)){let[d,u]=re(s,r+1,a,n),[c,f]=re(s,r,a+1,n);n.set(m,[s*d+(1-s)*c,s*u+(1-s)*f])}return n.get(m)}function dn(s){let[r,a]=re(s,0,0);return r/(1-a)}function se(s,r,a){if(r=Math.max(0,Math.floor(r)),a=Math.max(0,Math.floor(a)),Math.min(r,a)>=12){let d=Math.floor((Math.min(r,a)-12)/3),u=r-12-3*d,c=a-12-3*d,[f,h]=re(s,u,c);return f+h*dn(s)}let n=new Map,m=(d,u)=>{if(d>=13)return 1;if(u>=13)return 0;if(d===12&&u===12)return dn(s);let c=d*32+u;return n.has(c)||n.set(c,s*m(d+1,u)+(1-s)*m(d,u+1)),n.get(c)};return m(r,a)}function xo(s){return le(r=>se(r,0,0),ie(s))}var vo=24,ae=Array.from({length:101},(s,r)=>(r+.5)/101),pn=null;function mn(s,r){let a=ae.map(u=>(s-1)*Math.log(u)+(r-1)*Math.log(1-u)),n=Math.max(...a),m=a.map(u=>Math.exp(u-n)),d=m.reduce((u,c)=>u+c,0);return m.map(u=>u/d)}function fn(s,r,a=0,n=0){if(!Number.isFinite(r))return se(s,a,n);let m=mn(s*r+a,(1-s)*r+n);return!a&&!n?(pn||=ae.map(d=>se(d,0,0)),m.reduce((d,u,c)=>d+u*pn[c],0)):m.reduce((d,u,c)=>d+u*se(ae[c],a,n),0)}function yo(s,r){return Number.isFinite(r)?le(a=>fn(a,r),ie(s)):xo(s)}var ko={cs:8,dota:1/0};function hn(s,r,a,n=0,m=0){return Number.isFinite(r)?mn(s*r+n,(1-s)*r+m).reduce((u,c,f)=>u+c*Ne(ae[f],a,n,m),0):Ne(s,a,n,m)}function wo(s,r,a){return Number.isFinite(a)?le(n=>hn(n,a,r),ie(s)):bo(s,r)}function $o(s,r){let a=Math.max(s,r),n=Math.min(s,r);return n<12?a>=13:a-12-3*Math.floor((n-12)/3)>=4}function gn({pre:s,bo:r=3,maps:a=[0,0],rounds:n=null,game:m="cs",kappa:d=vo,kappaMap:u=ko[m]??1/0}){let c=Math.ceil(r/2),[f,h]=(a||[0,0]).map(L=>Math.max(0,Number(L)||0));if(f>=c)return{p:1,map:null};if(h>=c)return{p:0,map:null};let v=wo(s,r,u),g=(L,I)=>hn(v,u,r,L,I),[x,y]=Array.isArray(n)&&n.length===2?n.map(Number):[NaN,NaN];if(!Number.isFinite(x)||!Number.isFinite(y)||x===0&&y===0||$o(x,y))return{p:g(f,h),map:null};let O=Number.isFinite(u)?(v*u+f)/(u+f+h):v,w=fn(yo(O,d),d,x,y);return{p:w*g(f+1,h)+(1-w)*g(f,h+1),map:w}}var W=(s,r=0)=>kt(s,r),ft=s=>`${s>0?"+":s<0?"−":""}${Math.abs(s).toFixed(1)}`;function bn({bus:s,actions:r,brand:a}){let n=document.createElement("div");n.id=s.rootId,n.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let m=n.attachShadow({mode:"open"});m.appendChild(e("style",{text:oe+un}));let d=e("span.dot"),u=e("button.fab",{type:"button","data-act":"toggle",title:`${a.name}: открыть панель`,"aria-label":`${a.name}: открыть панель`},rt("lens",18),e("span",{text:a.name}),d),c=e("div.tabs",{role:"tablist"}),f=e("div.body"),h=e("div.foot"),v=e("small"),g=e("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),x=e("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),y=e("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},rt("gear")),O=e("div.head",{},e("div.brand",{},e("span.logo",{},rt("lens",15)),e("span",{text:a.name}),v),e("span.grow"),x,g,y,e("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},rt("close"))),w=e("section.panel",{hidden:!0,role:"dialog","aria-label":a.name},O,c,f,h);m.append(u,w);let L=()=>{n.isConnected||document.documentElement.appendChild(n)};L(),new MutationObserver(L).observe(document.documentElement,{childList:!0});let I="",P=null,E=new Map,V=t=>{for(let o of t.composedPath()){if(o===n)break;if(o?.dataset?.act)return o}return null},F=null;s.on("ui:pointerdown",t=>{if(t.button!==0)return;let o=t.composedPath(),l=o.includes(u),p=o.includes(O)&&!o.some(M=>M?.dataset?.act);if(!l&&!p)return;let k=l?u:w,b=k.getBoundingClientRect();F={target:k,key:l?"fab":"panel",sx:t.clientX,sy:t.clientY,ox:b.left,oy:b.top,moved:!1},s.setDragging(!0)}),s.on("drag:move",t=>{if(!F)return;let o=t.clientX-F.sx,l=t.clientY-F.sy;!F.moved&&Math.hypot(o,l)<5||(F.moved=!0,F.target.classList.add("dragging"),_(F.target,F.ox+o,F.oy+l))}),s.on("drag:end",()=>{if(F){if(s.setDragging(!1),F.target.classList.remove("dragging"),F.moved){let t=F.target.getBoundingClientRect();r.savePosition(F.key,{left:t.left,top:t.top}),$=!0,setTimeout(()=>{$=!1},60)}F=null}});let $=!1;function _(t,o,l){let p=t.offsetWidth||120,k=t.offsetHeight||40,b=Math.max(6,Math.min(o,window.innerWidth-p-6)),M=Math.max(6,Math.min(l,window.innerHeight-Math.min(k,60)-6));t.style.left=`${Math.round(b)}px`,t.style.top=`${Math.round(M)}px`,t.style.right="auto"}s.on("ui:click",t=>{if($)return;let o=V(t);if(!o||o.disabled)return;t.preventDefault();let l=o.dataset.act;if(l==="toggle")return Dt();if(l==="close")return Nt();let p=r[l];p&&p(o.dataset.arg,o,m)}),s.on("ui:keydown",t=>{if(t.key==="Escape"&&Nt(),t.key==="Enter"){let o=t.composedPath()[0];o?.dataset?.enter&&r[o.dataset.enter]?.(o.value,o,m)}});let C=(t,o)=>e("span.form",{},[...String(t||"")].slice(0,5).map(l=>e(`i${l==="В"?".w":l==="П"?".l":""}`,{text:l,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[l]||""})),o);function j(t){let o=t.live,l=o?e("div.center",{},o.score?.length===2?e("span.score",{text:`${o.score[0]} : ${o.score[1]}`}):null,e("span.badge.live",{text:o.state||"Лайв"})):e("div.center",{},e("span",{text:t.start||"до матча"})),p=o?.periods?.length?e("div.periods",{text:o.periods.map(b=>b.raw?`${b.label} ${b.raw}`:`${/^\d+$/.test(b.label)?`${b.label}-й отрезок`:b.label} ${b.home}:${b.away}`).join(" · ")}):null,k=o?.extras?.length?e("div.periods",{text:o.extras.map(b=>`${b.kind} ${b.home}:${b.away}`).join(" · ")}):null;return e("div.card",{},e("div.league",{text:t.league||t.sportName||"",title:t.league||""}),e("div.teams",{},e("div.team",{},e("b",{text:t.home,title:t.home}),t.form?.home?C(t.form.home):null),l,e("div.team.away",{},e("b",{text:t.away,title:t.away}),t.form?.away?C(t.form.away):null)),p,k)}function B(t){let o=t.rows.some(l=>Number.isFinite(l.model));return e("div.card",{},e("div.kicker",{},e("span",{text:t.title}),Number.isFinite(t.margin)?e("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${W(t.margin,1)}`}):null),t.rows.map(l=>{let p=o&&Number.isFinite(l.model)?(l.model-l.fair)*100:null;return e("div.prob",{},e("span.name",{text:l.name,title:l.name}),e("span.odd",{text:Z(l.odd)}),e("span.track",{},e("i",{style:`width:${Math.round((l.fair||0)*100)}%`}),Number.isFinite(l.model)?e("u",{style:`left:${Math.round(l.model*100)}%`}):null),e("span.pct",{},W(o&&Number.isFinite(l.model)?l.model:l.fair),p!=null&&Math.abs(p)>=.05?e(`small${p>0?".pos":".neg"}`,{text:`${ft(p)} п.п.`}):null))}),e("div.legend",{},e("span",{text:"шанс по линии без маржи"}),o?e("span.model",{text:"оценка модели"}):null))}function G(t){let o=t.analysis;if(o.status==="loading")return e("div.card",{},e("div.kicker",{},e("span",{text:"Разбор"}),e("span.badge.accent",{text:"собираю данные"})),e("div.steps",{},o.steps.map((M,z)=>e(`div.step${z===o.steps.length-1?".now":".done"}`,{},e("span.mark"),e("span",{text:M})))));if(o.status==="error")return e("div.card",{},e("div.note.warn",{},rt("alert"),e("span",{text:o.error})),e("div.row",{style:"margin-top:10px"},o.needKey?e("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},rt("gear"),"Открыть настройки"):null,e("button.btn.ghost",{type:"button","data-act":"report"},"Сообщить об ошибке")));if(o.status!=="done"||!o.result)return null;let l=o.result,p={home:t.match?.home,away:t.match?.away,draw:"ничья"}[l.lean],k=l.proposed?.lean&&l.proposed.lean!=="none"&&l.lean==="none"?{name:{home:t.match?.home,away:t.match?.away,draw:"ничью"}[l.proposed.lean],by:Math.abs(l.proposed.shift[l.proposed.lean]||0)}:null,b=new Map((l.facts||[]).map(M=>[M.id,M]));return e("div.card",{},e("div.kicker",{},e("span",{text:"Разбор"}),e("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${l.confidence||"низкая"}`})),e("div.verdict",{text:p?`Данные сдвигают оценку в сторону: ${p}`:k?`Данные слегка склоняют в сторону: ${k.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),k?e("div.note",{style:"margin-bottom:10px"},rt("info"),e("span",{text:`Модель предложила сдвиг на ${k.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,l.summary?e("p.summary",{text:l.summary}):null,l.factors?.length?e("ul.factors",{},l.factors.map(M=>e(`li.factor${M.side==="home"?".home":M.side==="away"?".away":""}`,{},e("div",{},e("p",{text:M.text}),e("div.src",{},(M.facts||[]).map(z=>b.get(z)).filter(Boolean).map(z=>e("span.tag",{text:`${z.id} · ${z.source}`,title:z.text}))))))):null,l.scenarios?.length?e("div",{style:"margin-top:10px"},e("div.kicker",{},e("span",{text:"Как может пойти игра"})),e("ul.facts",{},l.scenarios.map(M=>e("li",{},e("span",{text:M.text})," ",e("em",{text:`— ${M.facts.join(", ")}`}))))):null,l.risks?.length?e("div.note",{style:"margin-top:10px"},rt("info"),e("span",{text:`Что может сломать вывод: ${l.risks.join(" ")}`})):null,(l.full?.sections||[]).some(M=>M?.lines?.length)?e("details",{"data-key":"full",open:E.get("full")||!1,style:"margin-top:8px"},e("summary",{text:"Показать полностью: итог по всем рынкам, профили, факты"}),(l.full.sections||[]).filter(M=>M?.title&&M.lines?.length).map(M=>e("div",{style:"margin-top:6px"},e("div.kicker",{},e("span",{text:M.title})),e("ul.facts",{},M.lines.map(z=>e("li",{text:z})))))):null,e("div.row",{style:"margin-top:8px"},e("button.btn.ghost.small",{type:"button","data-act":"report",title:"Разбор выглядит неправильно — сообщить разработчику"},"Сообщить об ошибке")),e("details",{"data-key":"facts",open:E.get("facts")||!1},e("summary",{text:`Данные, на которых стоит разбор (${l.facts?.length||0})`}),e("ul.facts",{},(l.facts||[]).map(M=>e("li",{},e("b",{text:M.id}),e("span",{},M.text," ",e("em",{text:`— ${M.source}`})))))),U(l.research),e("div.hint",{style:"margin-top:8px",text:l.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function U(t){return t?t.skipped==="plan"?e("div.hint",{style:"margin-top:8px",text:"Поиск превью, травм и судей в прессе — в тарифах «Макс» и VIP."}):t.sources?.length?e("div.hint",{style:"margin-top:8px"},`${t.note} Прочитано: `,t.sources.map((o,l)=>[l?", ":"",e("a",{href:o.url,target:"_blank",rel:"noopener",text:o.domain})])):t.note?e("div.hint",{style:"margin-top:8px",text:t.note}):null:null}function Q(t){let o=t.compare?.consensus||t.analysis?.result?.consensus||t.consensus;if(!o?.consensus||!t.line?.rows?.length)return null;let l=o.consensus.length===2&&t.line.rows.length===3;if(!l&&t.line.rows.length!==o.consensus.length)return null;let p=l?t.line.overtime:null,k=p?p.rows:l?[t.line.rows[0],t.line.rows[2]].map(z=>({...z,odd:null,fair:null})):t.line.rows,b=t.match?.sport==="mma",M=o.updated?new Date(o.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"";return e("div.card",{},e("div.kicker",{},e("span",{text:l?b?"Прогноз рынка · без ничьей":"Прогноз рынка · с овертаймом":"Прогноз рынка"}),e("span.badge",{text:`${o.count} контор`})),k.map((z,S)=>{let N=o.consensus[S],A=z.odd?z.odd*N-1:0,T=Number.isFinite(z.fair)?(z.fair-N)*100:0;return e("div.prob",{},e("span.name",{text:z.name,title:z.name}),e("span.odd",{text:Z(1/N),title:"Кэф без маржи по консенсусу"}),e("span.track",{},e("i",{style:`width:${Math.round(N*100)}%`}),e("u",{style:`left:${Math.round((z.fair||0)*100)}%`,title:"Шанс по линии этой конторы"})),e("span.pct",{},W(N),A>.005?e("small.pos",{text:`кэф выше рынка ${ft(A*100)}%`}):Math.abs(T)>=2?e(`small${T>0?".neg":""}`,{text:`${ft(T)} п.п. к рынку`,title:T>0?"Контора оценивает этот исход выше рынка — кэф ниже":"Контора оценивает этот исход ниже рынка"}):null))}),e("div.legend",{},e("span",{text:"шанс по консенсусу"}),l&&!p?null:e("span.model",{text:p?`шанс по рынку «${p.title}» этой конторы`:"шанс по линии этой конторы"})),e("div.hint",{style:"margin-top:8px",text:`${l&&b?"Ничьи в ММА — доли процента, поэтому рынок двухисходный; ничья этой конторы не сравнивается. ":l?p?"Победитель с учётом овертайма и буллитов: сравнивается с одноимённым рынком этой конторы, а не с трёхисходным. ":"Победитель с учётом овертайма и буллитов; ничья в основное время сюда не входит, поэтому с трёхисходным рынком конторы напрямую не сравнивается. ":""}${o.pinnacle?`Pinnacle ${o.pinnacle.map(Z).join(" / ")}. `:""}${o.betfair?`Betfair ${o.betfair.map(Z).join(" / ")}. `:""}Цены ${o.count} контор без маржи${M?`, обновлено в ${M}`:""}${o.stale?" (данные старше шести часов)":""}. На проверке 1915 матчей фаворит по консенсусу выиграл 54% — точнее этого прогноза у нас нет.`}))}let Y=new Map;function nt(t,o){let l=t.match?.live;if(!l||!["cs","dota"].includes(o.game)||l.score?.length!==2)return null;let p=l.score.map(Number),k=Number(o.bo)||3;if(p.some(z=>!Number.isFinite(z)||z<0)||Math.max(...p)>=Math.ceil(k/2))return null;let b=o.game==="cs"&&l.rounds?.length===2&&l.rounds.every(z=>/^[0-9]{1,2}$/.test(String(z)))?l.rounds.map(Number):null,M=`${o.p1}|${k}|${p}|${b}`;return Y.has(M)||(Y.size>50&&Y.clear(),Y.set(M,{...gn({pre:o.p1,bo:k,maps:p,rounds:b,game:o.game}),bo:k,maps:p,rounds:b})),Y.get(M)}function J(t){let o=t.compare?.model||t.analysis?.result?.model||t.model;if(!o?.p1||!t.line?.rows?.length)return null;let l=t.line.rows.length===3&&(o.overtime||o.drawless);if(!l&&t.line.rows.length!==2)return null;let p=l?t.line.overtime:null,k=p?p.rows:l?[t.line.rows[0],t.line.rows[2]].map(q=>({...q,fair:null})):t.line.rows,b=nt(t,o),M=b?[b.p,1-b.p]:[o.p1,o.p2],z=o.sport==="tennis"?`Рейтинги Линзы по покрытиям, форме, нагрузке и очным встречам (архив ATP/WTA, ${o.samples} матчей у менее опытного игрока)`:o.sport==="hockey"?`Рейтинги Линзы по матчам КХЛ: атака и оборона команд, дом, усталость (приложение КХЛ, 2023–2026; ${o.samples} игр у менее опытной команды)${o.regulation?`. Основное время: ${Math.round(o.regulation.p1*100)}% / ничья ${Math.round(o.regulation.px*100)}% / ${Math.round(o.regulation.p2*100)}%`:""}`:o.sport==="mma"?`Рейтинги Линзы по боям UFC: Elo с весом досрочных побед, форма, возраст, размах рук, простой (ESPN; ${o.samples} боёв в UFC у менее опытного бойца)`:o.sport==="basketball"?`Рейтинги Линзы по разнице очков, дому и усталости (НБА, Евролига, Еврокубок, АСВ, Серия А, Адриатическая лига, ВТБ, Лига чемпионов FIBA; ${o.samples} игр у менее опытной команды)`:o.game==="dota"?`Рейтинги Линзы по матчам, форме и очным встречам (bo3.gg, ${o.samples} ${gt(o.samples,"матч","матча","матчей")} у менее опытной команды)`:`Рейтинги Линзы по картам, форме и очным встречам (bo3.gg, ${o.samples} ${gt(o.samples,"карта","карты","карт")} у менее опытной команды)`,S=o.backtest,N=(S?.calibration||[]).filter(q=>[60,70,80].includes(q.threshold)),A=S?.labels?.[o.confidence],T=(A?`С подписью «${o.confidence}» на проверке сбывалось ${W(A.hit/100,1)} (${A.n} ${gt(A.n,"матч","матча","матчей")}). `:"")+(N.length?`На проверке ${S.test} сыгранных матчей: ${N.map(q=>`при уверенности ≥${q.threshold}% сбывалось ${q.hit}%`).join(", ")}`:S?`На проверке ${S.test} матчей угадано ${Math.round(S.acc*100)}%`:"Точность ещё измеряется");return e("div.card",{},e("div.kicker",{},e("span",{text:b?`Модель по счёту · bo${b.bo}`:l?o.drawless?"Прогноз модели · без ничьей":"Прогноз модели · с овертаймом":"Прогноз модели"}),e("span.badge",{text:b?`до матча: ${o.confidence}`:`уверенность: ${o.confidence}`})),k.map((q,K)=>{let H=M[K],st=Number.isFinite(q.fair)?(H-q.fair)*100:0;return e("div.prob",{},e("span.name",{text:q.name,title:q.name}),e("span.odd",{text:Z(1/H),title:"Кэф без маржи по модели"}),e("span.track",{},e("i",{style:`width:${Math.round(H*100)}%`}),e("u",{style:`left:${Math.round((q.fair||0)*100)}%`,title:"Шанс по линии конторы"})),e("span.pct",{},W(H),Math.abs(st)>=3?e(`small${st>0?".pos":".neg"}`,{text:`${ft(st)} п.п. к линии`}):null))}),e("div.legend",{},e("span",{text:b?"шанс серии по счёту":"оценка модели"}),e("span.model",{text:"шанс по линии конторы"})),b?e("div.hint",{style:"margin-top:6px",text:`Счёт по картам ${b.maps.join(":")}${b.rounds?`, на карте ${b.rounds.join(":")} — шанс текущей карты ${W(b.map??.5)}`:""}. До матча модель давала ${W(o.p1)} / ${W(o.p2)}.`}):null,ct(o,k),o.factors?.length?e("ul.facts",{style:"margin-top:8px"},o.factors.slice(0,o.sport==="mma"?12:4).map(q=>e("li",{},e("span",{text:q})))):null,e("div.hint",{style:"margin-top:8px",text:b?`Шанс по ходу матча пересчитывается из прогноза до матча и счёта: выигранные карты${o.game==="cs"?" и раунды":""} уточняют силу команд. ${o.game==="cs"?"Проверка на сыгранных сериях CS: при 1:0 в bo3 модель давала в среднем 82%, сбылось 83% (2 905 серий)":"Проверка на сыгранных сериях Dota: при 1:1 модель давала в среднем 53%, сбылось 55% (516 серий)"}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`:`${z}. ${T}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`}))}function ot(t){let[o,l]=t.names,p=["0","15","30","40","Б"],k=t.tiebreak?t.points.join(":"):t.points.map(z=>p[Math.min(4,z)]||z).join(":"),b=t.sets.map(([z,S])=>`${z}:${S}`).concat(`${t.games[0]}:${t.games[1]}`).join(" "),M=t.serving==null?"":` · подаёт ${t.names[t.serving]}`;return e("div.card",{},e("div.kicker",{},e("span",{text:"Лайв по счёту"}),e("span.badge",{text:`${t.score.join(":")} по сетам · ${b} · ${k}${t.tiebreak?" (тай-брейк)":""}`})),t.names.map((z,S)=>{let N=t.probs[S],A=t.book?t.book[S]:null,T=t.compare&&Number.isFinite(A)?(N-A)*100:0;return e("div.prob",{},e("span.name",{text:z,title:z}),e("span.odd",{text:Z(1/N),title:"Честный кэф на матч по счёту"}),e("span.track",{},e("i",{style:`width:${Math.round(N*100)}%`}),Number.isFinite(A)?e("u",{style:`left:${Math.round(A*100)}%`,title:"Шанс по цене этой конторы"}):null),e("span.pct",{},W(N),Math.abs(T)>=3?e(`small${T>0?".pos":".neg"}`,{text:`${ft(T)} п.п. к цене`}):null))}),e("div.legend",{},e("span",{text:"шанс матча по счёту"}),t.book?e("span.model",{text:"шанс по цене этой конторы"}):null),e("ul.facts",{style:"margin-top:8px"},e("li",{},e("span",{text:`Текущий сет: ${o} ${W(t.set[0])} (кэф ${Z(1/t.set[0])}) · ${l} ${W(t.set[1])} (${Z(1/t.set[1])})`})),e("li",{},e("span",{text:`Текущий ${t.tiebreak?"тай-брейк":"гейм"}${M}: ${o} ${W(t.game[0])} · ${l} ${W(t.game[1])}`})),e("li",{},e("span",{text:`Очко на своей подаче (под довоенную силу): ${o} ${t.serve[0]}%, ${l} ${t.serve[1]}%; матч до ${t.bestOf===5?"трёх":"двух"} выигранных сетов.`}))),e("div.hint",{style:"margin-top:8px",text:`Счёт, очки и подача — лайв Fonbet. Довоенная сила: ${t.prior.note}.${t.compare?"":" Без довоенной цены оценка подстроена под текущую цену Fonbet — как сигнал против конторы её не используйте."} Проверено на 10 064 моментах матчей ATP/WTA 2025–2026 (после каждого сета): при оценке 80–85% сбылось 82,9%, 85–90% — 87,8%. Это расчёт, а не обещание.`}))}function ht(t){let[o,l]=t.names,p=A=>A?Z(A):"—",k=t.sport==="hockey"?"период":"тайм",b=`${t.minute}' · ${Math.min(t.period,t.periods)}-й ${k}`,M=[o,"Ничья",l],z=A=>A>0?`+${A}`:`${A}`,S=(A,T,q,K,H,st)=>T?.length?e("details",{"data-key":`live-${A}`,open:E.get(`live-${A}`)||!1},e("summary",{text:A}),e("ul.facts",{},T.map(mt=>e("li",{},e("span",{text:`${H(mt)} — ${p(mt[q])} · ${st(mt)} — ${p(mt[K])}`}))))):null,N=t.red[0]||t.red[1]?` · удаления ${t.red.join(":")}`:"";return e("div.card",{},e("div.kicker",{},e("span",{text:"Лайв по счёту"}),e("span.badge",{text:`${t.score.join(":")} · ${b}${N}`})),M.map((A,T)=>{let q=t.probs[T],K=t.book?t.book[T]:null,H=t.compare&&Number.isFinite(K)?(q-K)*100:0;return e("div.prob",{},e("span.name",{text:A,title:A}),e("span.odd",{text:Z(1/q),title:"Честный кэф по счёту"}),e("span.track",{},e("i",{style:`width:${Math.round(q*100)}%`}),Number.isFinite(K)?e("u",{style:`left:${Math.round(K*100)}%`,title:"Шанс по цене этой конторы"}):null),e("span.pct",{},W(q),Math.abs(H)>=3?e(`small${H>0?".pos":".neg"}`,{text:`${ft(H)} п.п. к цене`}):null))}),e("div.legend",{},e("span",{text:"шанс по счёту (основное время)"}),t.book?e("span.model",{text:"шанс по цене этой конторы"}):null),e("ul.facts",{style:"margin-top:8px"},e("li",{},e("span",{text:`Следующий гол: ${o} ${W(t.nextGoal[0])} · не будет ${W(t.nextGoal[1])} · ${l} ${W(t.nextGoal[2])}. Ожидаемый итоговый тотал ≈${t.expTotal}.`})),t.bookLines?.total?e("li",{},e("span",{text:`Тотал ${t.bookLines.total.line}: Fonbet ${t.bookLines.total.odds.map(Z).join(" / ")}, честно ${t.bookLines.total.fair.map(p).join(" / ")}`}),Math.abs(t.bookLines.total.gap)>=5?e(`small${t.bookLines.total.gap>0?".pos":".neg"}`,{text:` ${ft(t.bookLines.total.gap)} п.п. к «больше»`}):null):null),S("Тотал — честные кэфы",t.total,"over","under",A=>`больше ${A.line}`,A=>`меньше ${A.line}`),S("Фора — честные кэфы",t.handicap,"home","away",A=>`${o} ${z(A.line)}`,A=>`${l} ${z(-A.line)}`),e("div.hint",{style:"margin-top:8px",text:`Счёт, время${t.sport==="football"?" и удаления":""} — лайв Fonbet${t.clock==="timer"?"":" (время приблизительное)"}. Довоенная сила: ${t.prior.note}.${t.compare?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на ${t.sport==="hockey"?"1 407 играх НХЛ":"1 837 матчах 5 топ-лиг (11 тыс. точек)"}: при оценке 80–85% сбылось 82,5%. Это расчёт, а не обещание.`}))}function zt(t,o,l,p){let k=t.bookLines;if(!k)return null;let b=z=>z>0?`+${z}`:`${z}`,M=(z,S,N,A)=>e("li",{},e("span",{text:`${z}: Fonbet ${S.map(Z).join(" / ")}, честно ${N.map(T=>T?Z(T):"—").join(" / ")}`}),p&&Math.abs(A)>=5?e(`small${A>0?".pos":".neg"}`,{text:` ${ft(A)} п.п. к первой стороне`}):null);return e("ul.facts",{style:"margin-top:8px"},k.handicap?M(`Фора ${o} ${b(k.handicap.line)} / ${l} ${b(-k.handicap.line)}`,k.handicap.odds,k.handicap.fair,k.handicap.gap):null,k.total?M(`Тотал ${k.total.line} больше / меньше`,k.total.odds,k.total.fair,k.total.gap):null)}function xt(t){let o=t.live;if(!o)return null;if(o.kind==="goals")return ht(o);if(o.kind==="tennis")return ot(o);if(o.error)return e("div.card",{},e("div.kicker",{},e("span",{text:"Лайв по счёту"})),e("div.hint",{text:o.error}));let[l,p]=o.names,k=T=>T?Z(T):"—",b=o.book&&(o.prior.source==="line"||o.prior.source==="model"),M=o.left>0?`${o.period>o.format.periods?"ОТ":`${o.period}-я четв.`} · осталось ≈${Math.max(1,Math.round(o.left))} мин`:"конец игры",z=(T,q,K,H,st,mt)=>q.length?e("details",{"data-key":`live-${T}`,open:E.get(`live-${T}`)||!1},e("summary",{text:T}),e("ul.facts",{},q.map(it=>e("li",{},e("span",{text:`${st(it)} — ${k(it[K])} · ${mt(it)} — ${k(it[H])}`}))))):null,S=T=>T>0?`+${T}`:`${T}`,N=o.quarter,A=N&&N.left>0?`${N.index}-я четверть (${N.score.join(":")}, осталось ≈${Math.max(1,Math.round(N.left))} мин): ${l} ${k(N.probs[0]?1/N.probs[0]:null)} · ничья ${k(N.draw?1/N.draw:null)} · ${p} ${k(N.probs[1]?1/N.probs[1]:null)}; разница ${N.expMargin>=0?l:p} ${Math.abs(N.expMargin).toFixed(1)}, тотал четверти ≈${N.projTotal}.`:"";return e("div.card",{},e("div.kicker",{},e("span",{text:"Лайв по счёту"}),e("span.badge",{text:`${o.score.join(":")} · ${M}`})),o.names.map((T,q)=>{let K=o.probs[q],H=o.book?o.book[q]:null,st=b&&Number.isFinite(H)?(K-H)*100:0;return e("div.prob",{},e("span.name",{text:T,title:T}),e("span.odd",{text:Z(1/K),title:"Честный кэф по счёту"}),e("span.track",{},e("i",{style:`width:${Math.round(K*100)}%`}),Number.isFinite(H)?e("u",{style:`left:${Math.round(H*100)}%`,title:"Шанс по цене этой конторы"}):null),e("span.pct",{},W(K),Math.abs(st)>=3?e(`small${st>0?".pos":".neg"}`,{text:`${ft(st)} п.п. к цене`}):null))}),e("div.legend",{},e("span",{text:"шанс по счёту (с ОТ)"}),o.book?e("span.model",{text:"шанс по цене этой конторы"}):null),zt(o,l,p,b),e("ul.facts",{style:"margin-top:8px"},e("li",{},e("span",{text:`Ожидаемая итоговая разница: ${o.expMargin>=0?l:p} ${Math.abs(o.expMargin).toFixed(1)} (разброс ±${o.sd}). Тотал ≈${o.projTotal} (±${o.sdTotal}).`})),A?e("li",{},e("span",{text:A})):null),z("Фора — честные кэфы",o.handicap,"home","away",T=>`${l} ${S(T.line)}`,T=>`${p} ${S(-T.line)}`),z("Тотал матча — честные кэфы",o.total,"over","under",T=>`больше ${T.line}`,T=>`меньше ${T.line}`),z("Тотал четверти — честные кэфы",o.quarterTotal,"over","under",T=>`больше ${T.line}`,T=>`меньше ${T.line}`),e("div.hint",{style:"margin-top:8px",text:`Счёт и время — лайв Fonbet${o.clock==="timer"?"":" (время в четверти оценено по очкам — приблизительно)"}. Довоенная сила: ${o.prior.note}.${b?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на 8 923 играх Евролиги, Еврокубка и НБА: в перерыве при оценке 75–80% побеждали в 78% случаев. Это расчёт, а не обещание; задержка табло у конторы бывает до минуты.`}))}function pt(t){let o=t.verdict;return o?.lines?.length?e("div.card",{},e("div.kicker",{},e("span",{text:"Итог"}),e("span.badge",{text:o.best?`перевес ${Math.round(o.best.edge*100)}%`:"без перевеса"})),e("ul.facts",{},o.lines.map(l=>e("li",{},e("span",{text:l})))),o.track?e("div.hint",{style:"margin-top:6px",text:o.track}):null,t.analysis.status!=="done"?e("div.hint",{style:"margin-top:6px",text:"Доводы «за» и главный риск появятся после «Разобрать матч»."}):null):null}function ct(t,o){let l=t.durations;if(t.sport!=="mma"||!l)return null;let p=b=>b?Z(b):"—",k=o.map(b=>b.name);return e("div",{style:"margin-top:10px"},e("div.kicker",{},e("span",{text:"Честные кэфы"}),e("span.badge",{text:`${l.rounds} ${l.rounds===5?"раундов":"раунда"}`})),e("ul.facts",{},e("li",{},e("span",{text:`Победа: ${k[0]||"первый"} ${p(t.fair?.p1)} · ${k[1]||"второй"} ${p(t.fair?.p2)}`})),l.lines.map(b=>e("li",{},e("span",{text:`Тотал ${b.line} раунда: больше ${p(b.over)} · меньше ${p(b.under)}`}))),e("li",{},e("span",{text:`Дойдёт до решения: да ${p(l.decision.yes)} · нет ${p(l.decision.no)}`})),e("li",{},e("span",{text:`Конец боя: 1-й раунд ${Math.round(l.r1*100)}%, 2-й ${Math.round(l.r2*100)}%, позже ${Math.round(l.r3*100)}%, решение ${Math.round(l.dec*100)}%`}))),e("div.hint",{text:"Кэф конторы выше честного — ставка в плюс по модели, ниже — в минус. Длительность считается по всем боям бойцов в UFC и их весовой; проверка на 565 боях: точнее, чем средние цифры по весовой."}))}function ut(t){let l=((t.compare?.model||t.analysis?.result?.model||t.model)?.profiles||[]).filter(p=>p?.lines?.length);return l.length?e("div.card",{},e("div.kicker",{},e("span",{text:"Профили"}),e("span.badge",{text:"модель Линзы"})),l.map((p,k)=>e("details",{"data-key":`profile-${k}`,open:E.get(`profile-${k}`)??k===0},e("summary",{text:p.name}),e("ul.facts",{},p.lines.map(b=>e("li",{},e("span",{text:b})))))),e("div.hint",{style:"margin-top:8px",text:"Из рейтингов Линзы по открытым данным (ESPN, архив ATP/WTA, Евролига, bo3.gg). Это описание, а не прогноз."})):null}function Lt(t){let o=t.facts;if(!o?.facts?.length)return null;let l=o.facts.filter(M=>/травм|отсутств|не играет|стенд-ин|замен|дисквалиф/i.test(M.text)),p=o.facts.filter(M=>!l.includes(M)&&/состав|стартов/i.test(M.text)),k=o.facts.filter(M=>!l.includes(M)&&!p.includes(M)),b=(M,z,S)=>z.length?e("details",{"data-key":`facts-${M}`,open:S||E.get(`facts-${M}`)||!1},e("summary",{text:`${M} (${z.length})`}),e("ul.facts",{},z.map(N=>e("li",{},e("span",{text:N.text}))))):null;return e("div.card",{},e("div.kicker",{},e("span",{text:"Составы, травмы, форма"}),e("span.badge",{text:o.source||o.facts[0].source||"источник"})),b("Травмы и отсутствующие",l,!0),b("Составы",p,!0),b("Форма, таблица, очные встречи",k,!l.length&&!p.length),e("div.hint",{style:"margin-top:8px"},"Факты из открытых данных, как есть. ",o.url?e("a",{href:o.url,target:"_blank",rel:"noopener",text:"Источник"}):null))}let Ct=t=>`${Math.round(t).toLocaleString("ru-RU")} ₽`,gt=(t,o,l,p)=>{let k=t%100,b=t%10;return k>10&&k<20?p:b===1?o:b>=2&&b<=4?l:p},St=t=>(t.erid?["Реклама",t.legal,`erid ${t.erid}`].filter(Boolean).join(" · "):["Партнёрская ссылка",t.legal].filter(Boolean).join(" · "))+" · 18+",_t=(t,o)=>e("a.btn.ghost.small",{href:t.go?`${t.go}?s=panel`:t.url,target:"_blank",rel:"noopener sponsored"},rt("link",13),o||`Открыть у ${t.name}`),Et=t=>t.code?e("button.btn.ghost.small",{type:"button","data-act":"copy-code","data-arg":t.code,title:t.bonus||"Скопировать промокод"},`Промокод ${t.code}`):null;function me(t){let o=(t.partners||[]).filter(l=>l.url||l.code);return o.length?e("div.card.soft",{},e("div.kicker",{},e("span",{text:o.length===1?`Промокод ${o[0].name}`:"Промокоды контор"})),o.map(l=>e("div.partner",{},e("div.partner-text",{},e("b",{text:l.name}),l.bonus?e("span",{text:` — ${l.bonus}`}):null),e("div.partner-links",{},Et(l),l.url?_t(l):null),e("div.hint",{text:St(l)})))):null}function fe(t,o={}){if(t.status==="idle")return null;if(t.status==="loading")return e("div.card",{},e("div.kicker",{},e("span",{text:"Цены других контор"})),e("div.hint",{text:"Смотрю открытые линии…"}));let l=t.labels||[];if(!t.rows?.length)return e("div.card",{},e("div.kicker",{},e("span",{text:"Цены других контор"})),e("div.hint",{text:t.note||"В открытых линиях этой пары нет."}));let p=l.map((T,q)=>Math.max(...t.rows.map(K=>K.odds[q]||0))),k=Object.fromEntries((o.partners||[]).map(T=>[T.id,T])),b=T=>T.book&&T.book!==o.bookId&&!T.sharp&&k[T.book]||null,M=o.stake||1e3,z=t.rows.find(T=>T.here)||t.rows[0],N=l.map((T,q)=>{let K=z?.odds?.[q],H=t.rows.filter(st=>st!==z&&!st.sharp&&st.odds[q]).sort((st,mt)=>mt.odds[q]-st.odds[q])[0];return!K||!H||H.odds[q]<=K?null:{label:T,row:H,odd:H.odds[q],mine:K,gain:(H.odds[q]-K)*M}}).filter(Boolean).sort((T,q)=>q.gain-T.gain)[0],A=t.rows.map(b).filter(Boolean);return e("div.card",{},e("div.kicker",{},e("span",{text:"Цены других контор"}),e("span.badge",{text:"лучшая цена выделена"})),e("table",{},e("tr",{},e("th",{text:"Контора"}),l.map(T=>e("th",{text:T}))),t.rows.map(T=>{let q=b(T);return e("tr",{},e("td.name",{title:T.sharp?"Цена с мирового рынка, для сравнения":""},T.name,q?e("div.partner-links",{},q.url?_t(q):null,Et(q)):null),T.odds.map((K,H)=>e(`td${K&&K===p[H]&&t.rows.length>1?".best":""}`,{text:K?Z(K):"—"})))})),N&&N.gain>=1?e("div.gain",{},`На «${N.label}» у ${N.row.name} кэф ${Z(N.odd)} против ${Z(N.mine)} здесь: со ставки ${Ct(M)} выигрыш больше на `,e("b",{text:Ct(N.gain)}),"."):null,A.length?e("div.hint",{style:"margin-top:6px",text:[...new Set(A.map(St))].join(" ")}):null,t.note?e("div.hint",{style:"margin-top:8px",text:t.note}):null)}function he(t){let o=[],l=(k,b,M)=>o.push(e("dt",{text:k}),e(`dd${M?"."+M:""}`,{text:b}));Number.isFinite(t.fair)?(l("Шанс по линии без маржи",W(t.fair,1)),l("Кэф без маржи конторы",Z(t.fairOdd)),l("Маржа конторы в этом рынке",W(t.margin,1))):l("Заложено в кэфе (с маржой)",W(1/t.odd,1)),Number.isFinite(t.model)&&(l("Оценка модели",W(t.model,1)),l("Ожидание на рубль по модели",`${ft(t.ev*100)}%`,t.ev>.005?"pos":t.ev<-.005?"neg":"")),t.best&&l(`Лучшая цена: ${t.best.name}`,Z(t.best.odd),t.best.odd>t.odd?"pos":"");let p=t.best?.partner&&(t.best.partner.url||t.best.partner.code)?t.best.partner:null;return e("div.card.accent",{},e("div.kicker",{},e("span",{text:t.market}),e("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},rt("close",13))),e("div.pick-head",{},e("span.big",{text:Z(t.odd)}),e("span.what",{text:t.label,title:t.label})),e("dl.kv",{},o),t.note?e("div.hint",{style:"margin-top:8px",text:t.note}):null,e("div.row",{style:"margin-top:10px"},e("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!t.canAdd,title:t.canAdd?"":"Нужен рынок с полным набором исходов"},rt("plus",14),t.inExpress?"Уже в экспрессе":"В расчёт экспресса")),p?e("div.partner",{style:"margin-top:10px"},t.best.gain>=1?e("div.gain",{},`У ${p.name} этот кэф выше: со ставки ${Ct(t.stake||1e3)} выигрыш больше на `,e("b",{text:Ct(t.best.gain)}),"."):null,e("div.partner-links",{},p.url?_t(p):null,Et(p)),e("div.hint",{text:St(p)})):null)}function ge(t){let o=(l,p)=>e("div",{style:"min-width:0"},e("b",{text:l,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),p.map(k=>e("div",{style:"display:flex;justify-content:space-between;gap:8px"},e("span",{text:k.nick}),e("span",{style:"color:var(--lz-muted)",text:k.numbers.slice(0,2).join(" / ")}))));return e("div.card",{},e("div.kicker",{},e("span",{text:"Игроки сейчас"}),e("span.badge",{text:"с табло конторы"})),e("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},o(t.homeName,t.home),o(t.awayName,t.away)))}function be(t,o){return e("div.card",{},e("div.kicker",{},e("span",{text:"Статистика команд"}),e("span.badge",{text:"со страницы конторы"})),e("table",{},e("tr",{},e("th",{text:"Показатель"}),e("th",{text:o.home}),e("th",{text:o.away})),t.rows.map(l=>e("tr",{},e("td",{text:l.label}),e("td",{text:l.home}),e("td",{text:l.away})))),t.samples?.length===2?e("div.hint",{style:"margin-top:8px",text:`Выборка: ${t.samples[0]} и ${t.samples[1]} карт.`}):null)}function Wt(t){let o=[];if(t.pick&&o.push(he({...t.pick,stake:t.stake})),!t.match)return o.push(e("div.empty",{},e("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),o;o.push(j(t.match)),t.esports&&o.push(ge(t.esports)),t.match.stats?.rows?.length&&o.push(be(t.match.stats,t.match)),t.line&&o.push(B(t.line));let l=Q(t);l&&o.push(l);let p=xt(t);p&&o.push(p);let k=J(t);k&&o.push(k);let b=pt(t);b&&o.push(b);let M=ut(t);M&&o.push(M);let z=Lt(t);z&&o.push(z);let S=t.analysis.status==="loading";o.push(e("div.row",{},e("button.btn",{type:"button","data-act":"analyze",disabled:S},rt("spark"),S?"Разбираю…":t.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),e("button.btn.ghost",{type:"button","data-act":"compare",disabled:t.compare.status==="loading"},rt("scale"),"Сравнить цены"))),t.quota&&o.push(e("div.hint.center-text",{text:t.quota}));let N=me(t);N&&o.push(N);let A=G(t);A&&o.push(A);let T=fe(t.compare,t);return T&&o.push(T),o}function Kt(t){let o=t.margins;if(!o)return null;let l=[e("div",{},`Сегодня вы открыли ${o.n} ${gt(o.n,"матч","матча","матчей")} до начала: в основной исход ${t.bookName||"контора"} закладывает в среднем `,e("b",{text:W(o.here,1)})," маржи.")];return o.best?(l.push(e("div",{style:"margin-top:6px"},`На тех же ${o.best.n} ${gt(o.best.n,"матче","матчах","матчах")} у ${o.best.name} — `,e("b",{text:W(o.best.there,1)}),` против ${W(o.best.here,1)} здесь: с каждой ставки вы отдавали бы конторе меньше примерно на ${((o.best.here-o.best.there)*100).toFixed(1)} п.п.`)),o.partner&&l.push(e("div.partner-links",{style:"margin-top:8px"},o.partner.url?_t(o.partner):null,Et(o.partner)),e("div.hint",{text:St(o.partner)}))):l.push(e("div.hint",{style:"margin-top:6px",text:"Нажмите «Сравнить цены» на странице матча — Линза запомнит маржу других контор на тех же матчах и покажет, где отдаёте меньше."})),e("div.card",{},e("div.kicker",{},e("span",{text:"Сколько маржи вы отдаёте"}),e("span.badge",{text:"сегодня"})),...l)}function Zt(t){let o=t.scan,l=Kt(t);return o?.rows?.length?[l,e("div.card",{},e("div.kicker",{},e("span",{text:o.title}),e("span.badge",{text:`средняя маржа ${W(o.average,1)}`})),e("table",{},e("tr",{},e("th",{text:o.first}),e("th",{text:"Фаворит"}),e("th",{text:"Маржа"})),o.rows.map(p=>e("tr.click",{"data-act":"scan-go","data-arg":String(p.index),title:"Показать на странице"},e("td.name",{},p.name,p.sub?e("span.sub",{text:p.sub}):null),e("td",{},p.fav,e("span.sub",{text:W(p.favPct)})),e(`td${p.low?".best":""}`,{text:W(p.margin,1)})))),e("div.hint",{style:"margin-top:8px",text:o.note}))]:[l,e("div.empty",{},e("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function xe(t){let o=t.express;if(!o.legs.length)return[e("div.empty",{},e("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let l=o.stats;return[e("div.card",{},e("div.kicker",{},e("span",{text:`Экспресс · ${o.legs.length}`}),e("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},rt("trash",13),"Очистить")),o.legs.map(p=>e("div.leg",{},e("div.t",{},e("b",{text:p.label,title:p.label}),e("span",{text:p.title,title:p.title})),e("span.o",{text:Z(p.odd)}),e("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":p.id,title:"Убрать",style:"width:24px;height:24px"},rt("close",13))))),l?e("div.card.soft",{},e("dl.kv",{},e("dt",{text:"Итоговый коэффициент"}),e("dd",{text:Z(l.odd)}),e("dt",{text:"Шанс, что зайдёт всё (по линии)"}),e("dd",{text:W(l.chance,1)}),e("dt",{text:"Кэф без маржи"}),e("dd",{text:Z(l.fairOdd)}),e("dt",{text:"Маржа конторы на всём экспрессе"}),e("dd.neg",{text:W(l.margin,1)})),e("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Исходы одного матча считаются как независимые — на деле они связаны."})):null]}function ve(t){let o=t.edges||{status:"idle"},l=S=>e("div.kicker",{},e("span",{text:"Цена выше рынка"}),S?e("span.badge",{text:S}):null);if(o.status==="loading"&&!o.data)return[e("div.card",{},l("ищу сигналы"),e("div.hint",{text:"Сверяю открытую линию с консенсусом двадцати контор…"}))];if(o.status==="error"&&!o.data)return[e("div.card",{},l(),e("div.note.warn",{},rt("alert"),e("span",{text:o.error})))];let p=o.data;if(!p)return[e("div.empty",{},e("b",{text:"Сигналы ещё не загружены"}),"Откройте вкладку ещё раз или нажмите «Обновить».")];let k=S=>S==null?"—":`${S>=0?"+":"−"}${(Math.abs(S)*100).toFixed(1)}%`,b=S=>new Date(S).toLocaleString("ru-RU",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"}),M=e("div.card.soft",{},e("dl.kv",{},e("dt",{text:"Открытых сигналов"}),e("dd",{text:String(p.open)}),e("dt",{text:"Закрыто за неделю"}),e("dd",{text:String(p.closedWeek)}),e("dt",{text:"Средний CLV за неделю"}),e("dd",{text:k(p.clvWeek)}),e("dt",{text:"Сигналов с плюсовым CLV"}),e("dd",{text:p.positiveWeek==null?"—":W(p.positiveWeek)})),e("div.hint",{style:"margin-top:8px",text:"CLV — насколько цена сигнала была выше цены закрытия линии. Плюсовой CLV на дистанции — единственный честный признак того, что сигналы опережают рынок. Это не обещание выигрыша."})),z=(p.signals||[]).map(S=>e("tr",{},e("td.name",{},`${S.home} — ${S.away}`,e("span.sub",{text:`${S.league} · ${b(S.start)}`})),e("td",{},S.label,e("span.sub",{text:S.book})),e("td",{text:Z(S.odds)}),e("td",{text:Z(1/S.p),title:`Честная цена по ${S.count} конторам`}),e("td.best",{text:`+${(S.edge*100).toFixed(1)}%`})));return[e("div.card",{},l(p.full?"тариф «Макс»":"витрина"),z.length?e("table",{},e("tr",{},e("th",{text:"Матч"}),e("th",{text:"Исход"}),e("th",{text:"Кэф"}),e("th",{text:"Рынок"}),e("th",{text:"Выше на"})),z):e("div.hint",{text:"Сейчас открытых сигналов нет: контора держится в рынке. Сканер проходит линию каждые полчаса."}),p.note?e("div.hint",{style:"margin-top:8px"},p.note," ",a.bot?e("a",{href:a.bot,target:"_blank",rel:"noopener",text:"Получить «Макс»"}):null):null,e("div.row",{style:"margin-top:10px"},e("button.btn.ghost.small",{type:"button","data-act":"edges-refresh"},"Обновить"))),M]}function Ht(t){let o=t.settings,l=(p,k,b)=>e("div.seg",{},b.map(([M,z])=>e(`button${k===M?".on":""}`,{type:"button","data-act":p,"data-arg":M,text:z})));return[e("div.card",{},e("div.field",{},e("label",{text:"Отметки на странице"}),l("set-overlay",o.overlay,[["picks","Фавориты"],["all","Все шансы"],["off","Выкл"]]),e("div.hint",{text:"Рамка стоит на самом вероятном исходе каждого рынка. Число — шанс по линии без маржи конторы. Это не прогноз."})),e("div.field",{},e("label",{text:"Тема"}),l("set-theme",o.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]])),e("div.field",{},e("label",{for:"lz-stake",text:"Ставка для расчёта выгоды, ₽"}),e("div.row",{},e("input",{type:"number",id:"lz-stake",value:String(o.stake||1e3),min:"10",step:"10",inputmode:"numeric","data-enter":"set-stake",style:"max-width:140px"}),e("button.btn.small",{type:"button","data-act":"set-stake"},"Сохранить")),e("div.hint",{text:"Разницу лучшей цены Линза показывает в рублях от этой суммы. На ставку это не влияет."}))),e("div.card",{},e("div.kicker",{},e("span",{text:"Разбор матчей"}),e(`span.badge${o.ready?".pos":""}`,{text:o.ready?"подключён":"не подключён"})),o.proxy?e("div.field",{},e("label",{text:"Доступ"}),l("set-mode",o.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,o.mode==="license"&&o.proxy?e("div.field",{},e("label",{for:"lz-license",text:"Лицензионный ключ"}),e("input",{type:"text",id:"lz-license",placeholder:o.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),e("div.row",{},e("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),o.licenseMask?e("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),e("div.hint",{},[o.licenseMask?`Ключ ${o.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",o.plan,o.usage].filter(Boolean).join(" "),a.bot&&!o.licenseMask?[" ",e("a",{href:a.bot,target:"_blank",rel:"noopener",text:"Получить ключ «Про»"})]:null)):e("div.field",{},e("label",{for:"lz-key",text:"API-ключ Clodex"}),e("input",{type:"password",id:"lz-key",placeholder:o.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),e("div.row",{},e("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),o.hasKey?e("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),e("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${o.usage}`}))),e("div.card.soft",{},e("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной."))]}function Pt(t){P=t;let o=JSON.stringify(t);if(o===I)return;I=o;for(let z of f.querySelectorAll("details[data-key]"))E.set(z.dataset.key,z.open);let l=f.scrollTop;v.textContent=t.bookName?`· ${t.bookName}`:"",d.classList.toggle("off",t.settings.overlay==="off"),g.replaceChildren(rt(t.theme==="dark"?"sun":"moon")),x.replaceChildren(rt(t.settings.overlay==="off"?"eyeOff":"eye")),x.classList.toggle("on",t.settings.overlay!=="off"),y.classList.toggle("on",t.tab==="settings"),y.dataset.arg=t.tab==="settings"?t.backTab:"settings";let p=[["match","Матч"],["scan","Маржа"],["edges","Выше рынка"],["express","Экспресс"]];c.replaceChildren(...p.map(([z,S])=>e(`button.tab${t.tab===z?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":z},S,z==="express"&&t.express.legs.length?e("span.count",{text:String(t.express.legs.length)}):null)));let k=t.tab==="settings"?Ht(t):t.tab==="scan"?Zt(t):t.tab==="express"?xe(t):t.tab==="edges"?ve(t):Wt(t),b=t.update?e("div.card.soft.update",{},e("b",{text:`Вышла Линза ${t.update.version}`})," — ",t.update.url?e("a",{href:t.update.url,target:"_blank",rel:"noopener",text:"скачать архив на сайте"}):"архив на сайте Линзы"," и заменить папку расширения."):null,M=t.whatsnew?.changes?.length&&t.tab!=="settings"?e("div.card.soft.update",{},e("b",{text:`Линза обновилась до ${t.whatsnew.version}`}),e("ul.facts",{style:"margin-top:6px"},t.whatsnew.changes.flatMap(z=>z.items).slice(0,6).map(z=>e("li",{},e("span",{text:z})))),e("div.row",{style:"margin-top:8px"},e("button.btn.ghost.small",{type:"button","data-act":"whatsnew-ok"},"Понятно"))):null;f.replaceChildren(...[b,M,...k].filter(Boolean)),f.scrollTop=l,h.replaceChildren(e("span",{text:"18+ · Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function ye(t){n.setAttribute("data-theme",t)}function Xt(){w.hidden=!1,r.opened?.()}function Nt(){w.hidden=!0}function Dt(){w.hidden?Xt():Nt()}function jt(t){t?.fab&&_(u,t.fab.left,t.fab.top),t?.panel&&_(w,t.panel.left,t.panel.top)}let qt=0;function i(t){m.querySelector(".toast")?.remove();let o=e("div.toast",{text:t,role:"status"});m.appendChild(o),clearTimeout(qt),qt=setTimeout(()=>o.remove(),2600)}return{render:Pt,setTheme:ye,open:Xt,close:Nt,toggle:Dt,restore:jt,toast:i,shadow:m,rect:()=>w.hidden?null:w.getBoundingClientRect(),get isOpen(){return!w.hidden},get view(){return P}}}var xn="Расширение обновилось. Обновите эту вкладку (F5).";function Mo(s){return/signal timed out|timeout|timed out/i.test(s)?"Сервер долго не отвечает — нажмите ещё раз.":/failed to fetch|networkerror|load failed|network request failed/i.test(s)?"Нет связи с сервером Линзы — проверьте интернет.":s}function wt(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function et(s,r={}){if(!wt())return{ok:!1,error:xn,code:"reload"};try{return await chrome.runtime.sendMessage({type:s,...r})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(a){let n=String(a?.message||a);return/context invalidated/i.test(n)||!wt()?{ok:!1,error:xn,code:"reload"}:/message port closed|receiving end does not exist/i.test(n)?{ok:!1,error:"Связь с расширением прервалась — нажмите ещё раз.",code:"retry"}:{ok:!1,error:Mo(n)}}}function vn(s){if(wt())try{chrome.runtime.onMessage.addListener(r=>{s(r)})}catch{}}async function Fe(s){if(!wt())return{};try{return await chrome.storage.local.get(s)}catch{return{}}}function $t(s){if(wt())try{chrome.storage.local.set(s)}catch{}}var yn=(s=Date.now())=>new Date(s).toISOString().slice(0,10);function ce(s,r=Date.now()){return s&&s.day===yn(r)&&s.items&&typeof s.items=="object"?s:{day:yn(r),items:{}}}function kn(s,{key:r,book:a,margin:n}){if(!r||!Number.isFinite(n)||n<=0||n>.5)return!1;let m=Math.round(n*1e4)/1e4,d=s.items[r];return d&&d.here===m&&d.book===a?!1:(s.items[r]={book:a,here:m,others:d?.others||{}},!0)}function wn(s,r,a){let n=s.items[r];if(!n)return!1;let m=!1;for(let d of a||[]){if(d.here||d.sharp||!d.odds?.length||d.odds.some(f=>!(f>1)))continue;let u=yt(d.odds);if(u.kind!=="full"||!(u.margin>0))continue;let c=Math.round(u.margin*1e4)/1e4;n.others[d.name]!==c&&(n.others[d.name]=c,m=!0)}return m}function $n(s,r){let a=Object.values(s?.items||{}).filter(u=>u.book===r);if(!a.length)return null;let n=u=>u.reduce((c,f)=>c+f,0)/u.length,d=[...new Set(a.flatMap(u=>Object.keys(u.others||{})))].map(u=>{let c=a.filter(f=>Number.isFinite(f.others?.[u]));return c.length>=2?{name:u,n:c.length,there:n(c.map(f=>f.others[u])),here:n(c.map(f=>f.here))}:null}).filter(Boolean).sort((u,c)=>u.there-c.there);return{n:a.length,here:n(a.map(u=>u.here)),best:d[0]||null,others:d}}var zo=[{version:"1.0.15",items:["Разбор на сервере видит тоталы и форы этой страницы: в теннисе «Показать полностью» — итог и по геймам, по цене самой конторы."]},{version:"1.0.14",items:["«Лучшая цена» — только если цена выше честной на 3–12%. Больше 12% — строка «Проверьте данные»: чаще это ошибка в данных, чем подарок конторы.","Модель Линзы пока справочно: «по модели интересная цена от…». Перевес считается по ценам рынка, пока модель не докажет, что она точнее.","Карты в CS и Dota временно убраны из итога: вернём после проверки на честных ценах."]},{version:"1.0.13",items:["Под разбором — «Показать полностью»: итог по всем рынкам, доводы, как может пойти игра, профили и факты.","Итог по рынкам этой страницы: в теннисе — тотал и фора геймов, в CS и Dota — карты, по цене самой конторы на победу."]},{version:"1.0.12",items:["Под разбором — «Сообщить об ошибке»: что сломалось, уходит разработчику без личных данных.","Итог не строится по модели, которой нельзя верить как цене: если она сильно расходится с рынком или у неё мало матчей в архиве."]},{version:"1.0.11",items:["Разобрать матч: разбор идёт на сервере — видно, что происходит (цены, новости, модель), и он не обрывается на «Обновите вкладку».","Разбор работает на всех конторах: если матча нет в линии Fonbet, Линза разбирает по ценам страницы и свежим новостям.","Новости, травмы и составы из прессы — в разборе для всех тарифов; у «Макс» и VIP поиск подробнее.","Бесплатные 3 разбора в день считаются для вашего браузера, а не для всех с одного адреса; истёкший ключ не отключает бесплатные разборы.","Исправлено: счётчик «Разборов сегодня» больше не пропадает, ошибки связи — понятными словами."]},{version:"1.0.10",items:["Исправлено: в доводах моделей имена команд и игроков — как на странице конторы."]},{version:"1.0.9",items:["Лайв тенниса по счёту: шанс матча, текущего сета и гейма от очков и подачи.","Прогноз модели для КХЛ: атака и оборона команд, исход основного времени и победитель с ОТ; на проверке при уверенности от 65% сбылось 70%.","Итог: форы футбола и хоккея против честной цены по Fonbet."]},{version:"1.0.8",items:["Лайв по счёту для футбола и хоккея: шанс исхода основного времени, следующий гол, тоталы и форы по счёту, времени и удалениям; точное игровое время.","Итог для футбола и хоккея: тоталы этой конторы против честной цены по Fonbet без маржи на любой линии.","Журнал итогов: точность прошлых итогов — в карточке и в приложении."]},{version:"1.0.7",items:["ММА (UFC): прогноз модели по бойцам — возраст, размах рук, форма, простой; как скорее всего закончится бой и честные кэфы на тоталы раундов и решение судей; прогноз рынка 5+ контор.","Итог: в конце карточек — лучшая цена против честной, перевес и размер суммы, доводы и главный риск из разбора; каждый итог записывается и потом сверяется с результатом — точность видна в приложении.","Баскетбол: фора и тотал по модели — ожидаемая разница очков и тотал с разбросом, честные кэфы основных линий конторы в «Итоге».","Теннис: подача и приём в модели — шанс матча по доле выигранных очков на своей подаче и на приёме соперника.","Исправлено: бойцы и теннисисты в формате «Фамилия И.» находятся, если полное имя из трёх слов.","Одна палитра у панели, попапа, мини-приложения и сайта; в тёмной теме приложения — светлый акцент."]},{version:"1.0.6",items:["Лайв по счёту: в баскетболе — честный шанс, фора и тотал против цены конторы; в CS и Dota — шанс серии по счёту карт и раундов текущей карты.","Профили участников: теннисисты (покрытия, подача и приём, нагрузка, последние матчи), команды баскетбола и киберспорта (динамика рейтинга, форма, состав с рейтингом каждого игрока).","Баскетбол: Еврокубок, АСВ, Серия А, Адриатическая лига, Единая лига ВТБ и Лига чемпионов FIBA — в модели и в фактах.","Футбол: ход матча и судьи (УЕФА) в карточке «Составы, травмы, форма».","Киберспорт: у подписи уверенности — как часто такие прогнозы сбывались на проверке; модель Dota точнее.","Вкладка «Маржа»: сколько маржи вы отдаёте этой конторе по открытым сегодня матчам и сколько отдавали бы у других контор.","Новая версия подхватывается сама, когда вы заменили файлы в папке расширения."]},{version:"1.0.5",items:["Карточка «Составы, травмы, форма» на странице матча: травмы по именам, составы, форма и очные встречи (ESPN, bo3.gg) — без разбора и без лимита.","Подсказка в панели, когда на сайте вышла новая версия.","Dota 2: точнее вероятность победы в серии до двух побед."]}];function Mn(s,r){let a=String(s||"").split(".").map(Number),n=String(r||"").split(".").map(Number);for(let m=0;m<Math.max(a.length,n.length);m++){let d=(a[m]||0)-(n[m]||0);if(d)return d>0}return!1}function zn(s,r){return zo.filter(a=>Mn(a.version,s)&&!Mn(a.version,r))}var Mt=s=>Number.isFinite(s)?(Math.round(s*100)/100).toFixed(2):"—",ue=s=>`${Math.round(s*100)}%`,So=(s,r)=>s*r-1;function _o(s){return s<.03?null:s<.06?"небольшая — примерно половина обычной":s<.12?"обычная":"перевес слишком большой — сначала проверьте травмы, замены и что это тот же матч"}function Sn(s,{source:r="",reasons:a=[],risk:n=""}={}){let m=(s||[]).filter(w=>Number(w.odd)>1&&w.p>.01&&w.p<.99).map(w=>({...w,fairOdd:1/w.p,edge:So(w.p,Number(w.odd))}));if(!m.length)return null;let d=[...m].sort((w,L)=>L.edge-w.edge),u=d.find(w=>w.edge>=.03&&w.edge<=.12)||null,c=u?{...u,size:_o(u.edge)}:null,f=d.find(w=>w.edge>.12)||null,h=f?{...f}:null,v=m.filter(w=>w!==u&&w!==f).map(w=>({...w,note:w.edge>.12?`перевес ${ue(w.edge)} — слишком большой, проверьте данные`:w.edge>=.03?`перевес ${ue(w.edge)} к честной цене ${Mt(w.fairOdd)}`:w.edge>-.02?`честная цена (${Mt(w.fairOdd)}), перевеса нет`:`цена ниже честной (${Mt(w.fairOdd)})`})),g=[],x=w=>w.source||r;if(c){let w=x(c);g.push(`Лучшая цена: ${c.label} по ${Mt(c.odd)} — перевес около ${ue(c.edge)} к честной цене ${Mt(c.fairOdd)}${w?` (${w})`:""}. Сумма: ${c.size}.`),a.length&&g.push(`За: ${a.join(" ")}`),n&&g.push(`Главный риск: ${n}`)}else g.push(`${h?"Надёжного перевеса нет":"Перевеса нет"}: ${h?"остальные":"все"} цены близки к честным или ниже${r?` (${r})`:""} — разумнее пропустить.`);if(h){let w=x(h);g.push(`Проверьте данные: ${h.label} по ${Mt(h.odd)} — перевес ${ue(h.edge)} к честной цене ${Mt(h.fairOdd)}${w?` (${w})`:""} слишком большой. Чаще это ошибка данных или модели (травма, состав, чужой матч), а не подарок конторы — лучшей ценой не считаем.`)}let y=[...v].sort((w,L)=>L.edge-w.edge).slice(0,6),O=v.length-y.length;return v.length&&g.push(`${c?"Остальное":"По рынкам"}: ${y.map(w=>`${w.label} по ${Mt(w.odd)} — ${w.note}`).join("; ")}${O>0?`; ещё ${O} — с меньшим перевесом или без него`:""}.`),g.push("Это расчёт, а не обещание: проиграть можно и при перевесе в цене. 18+"),{best:c,suspect:h,others:v,lines:g}}function Vt(s){let r=n=>/^(б|больше|бол|over|o\b|тб)/i.test(String(n||"").trim()),a=n=>/^(м|меньше|мен|under|u\b|тм)/i.test(String(n||"").trim());return r(s[0])&&a(s[1])?0:a(s[0])&&r(s[1])?1:-1}var No=s=>{let r=s<0?-1:1,a=Math.abs(s),n=1/(1+.3275911*a);return r*(1-((((1.061405429*n-1.453152027)*n+1.421413741)*n-.284496736)*n+.254829592)*n*Math.exp(-a*a))},Te=s=>.5*(1+No(s/Math.SQRT2));function _n(s,r,a){if(!(Math.abs(a-Math.round(a))<1e-9)){let u=1-Te((a-s)/r);return{win:u,push:0,lose:1-u}}let m=1-Te((a+.5-s)/r),d=Te((a-.5-s)/r);return{win:m,push:Math.max(0,1-m-d),lose:d}}function Fo(s,r,a){let n=_n(s,r,-a);return{home:n.win,away:n.lose,push:n.push}}function To(s,r,a){let n=_n(s,r,a);return{over:n.win,under:n.lose,push:n.push}}function Nn(s,{handicap:r=null,total:a=null}={},n=["Хозяева","Гости"]){let m=s?.lines;if(!m||!Number.isFinite(m.margin)||!(m.sigma>0))return[];let d=[],u=h=>h>0?`+${h}`:`${h}`,c=(h,v)=>h/(1-v||1),f=(h,v)=>1/h/(1/h+1/v);if(r&&Number.isFinite(r.line)&&Math.abs(r.line)<60&&r.home>1&&r.away>1){let h=Fo(m.margin,m.sigma,r.line);Math.abs(c(h.home,h.push)-f(r.home,r.away))<=.3&&d.push({label:`Фора ${n[0]} ${u(r.line)}`,odd:r.home,p:c(h.home,h.push),kind:"handicap",side:"home",source:"модель Линзы"}),d.length&&d.push({label:`Фора ${n[1]} ${u(-r.line)}`,odd:r.away,p:c(h.away,h.push),kind:"handicap",side:"away",source:"модель Линзы"})}if(a&&Number.isFinite(m.total)&&m.sigmaT>0&&Number.isFinite(a.line)&&a.line>50&&a.over>1&&a.under>1){let h=To(m.total,m.sigmaT,a.line);Math.abs(c(h.over,h.push)-f(a.over,a.under))<=.3&&(d.push({label:`Тотал больше ${a.line}`,odd:a.over,p:c(h.over,h.push),kind:"total",source:"модель Линзы"}),d.push({label:`Тотал меньше ${a.line}`,odd:a.under,p:c(h.under,h.push),kind:"total",source:"модель Линзы"}))}return d}var Bt={football:{periods:2,minutes:90,stoppage:[2,5],late:1,weights:[.12,.142,.184,.149,.167,.237],trail:.3,lead:.05,redOwn:-.4,redOpp:.45,total:2.7,homeShare:.555,maxGoals:12},hockey:{periods:3,minutes:60,weights:[.297,.344,.359],trail:0,lead:-.1,redOwn:0,redOpp:0,total:6,homeShare:.52,maxGoals:16}},Oe=[1];for(let s=1;s<=40;s+=1)Oe[s]=Oe[s-1]*s;var Fn=(s,r)=>r<=0?s===0?1:0:Math.exp(-r)*r**s/Oe[s];function Oo(s,r){let a=r.weights.length,n=r.minutes/a,m=Math.max(0,Math.min(r.minutes,s)),d=0;for(let c=0;c<a;c+=1){let f=c*n,h=f+n,v=a/(r.periods||1),g=(c+1)%v===0&&r.stoppage?.[Math.floor(c/v)]||0;m<=f?d+=r.weights[c]:m<h&&(d+=r.weights[c]*((h-m+g)/(n+g)))}let u=r.weights.reduce((c,f)=>c+f,0);return d/u}function Tn(s,r,a){let n=[];for(let m=0;m<=a;m+=1){n[m]=[];for(let d=0;d<=a;d+=1)n[m][d]=Fn(m,s)*Fn(d,r)}return n}function Ao(s,r,a,n=null){let m=Tn(s,r,a),d=0,u=0,c=0,f=0;for(let h=0;h<=a;h+=1)for(let v=0;v<=a;v+=1){let g=m[h][v];h>v?d+=g:h===v?u+=g:c+=g,n!=null&&h+v>n&&(f+=g)}return{p1:d,px:u,p2:c,over:f}}function On({p1:s,px:r,p2:a,line:n=null,pOver:m=null},d=Bt.football){let u=d.total,c=(h,v)=>{let g=Ao(h,v,d.maxGoals,n!=null&&m!=null?n:null),x=(g.p1-s)**2+(g.p2-a)**2+(r!=null?(g.px-r)**2:0);return n!=null&&m!=null?x+=(g.over-m)**2:x+=.02*((h+v-u)/u)**2,x},f={lh:u*d.homeShare,la:u*(1-d.homeShare),e:1/0};for(let h=.4;h>=.01;h/=2){let v=f;for(let g=-4;g<=4;g+=1)for(let x=-4;x<=4;x+=1){let y=Math.max(.03,v.lh+g*h),O=Math.max(.03,v.la+x*h),w=c(y,O);w<f.e&&(f={lh:y,la:O,e:w})}}return{lh:f.lh,la:f.la}}function Ae(s,r,a=Bt.football){let[n,m]=s.score.map(Number),d=Oo(Number(s.minute)||0,a),u=n-m,c=Math.sign(u),f=1+(a.late||0)*((Number(s.minute)||0)/a.minutes-.5),h=(Math.abs(u)>=2?.6:1)*Math.max(0,f),v=c<0?a.trail*h:c>0?a.lead*h:0,g=c>0?a.trail*h:c<0?a.lead*h:0,[x,y]=(s.red||[0,0]).map(G=>Math.min(2,Number(G)||0)),O=(G,U)=>(1+a.redOwn)**G*(1+a.redOpp)**U,w=Math.max(0,r.lh*d*(1+v)*O(x,y)),L=Math.max(0,r.la*d*(1+g)*O(y,x)),I=a.maxGoals,P=Tn(w,L,I),E=0,V=0,F=0;for(let G=0;G<=I;G+=1)for(let U=0;U<=I;U+=1){let Q=n+G,Y=m+U;Q>Y?E+=P[G][U]:Q===Y?V+=P[G][U]:F+=P[G][U]}let $=E+V+F||1,_=G=>{let U=0,Q=0;for(let Y=0;Y<=I;Y+=1)for(let nt=0;nt<=I;nt+=1){let J=n+m+Y+nt;J>G?U+=P[Y][nt]:J===G&&(Q+=P[Y][nt])}return{over:U,push:Q,under:Math.max(0,1-U-Q)}},C=G=>{let U=0,Q=0;for(let Y=0;Y<=I;Y+=1)for(let nt=0;nt<=I;nt+=1){let J=n+Y-(m+nt)+G;J>0?U+=P[Y][nt]:J===0&&(Q+=P[Y][nt])}return{home:U,push:Q,away:Math.max(0,1-U-Q)}},j=w+L,B=Math.exp(-j);return{p1:E/$,px:V/$,p2:F/$,lh:w,la:L,share:d,expTotal:n+m+j,nextGoal:{home:j>0?(1-B)*(w/j):0,away:j>0?(1-B)*(L/j):0,none:B},total:_,handicap:C}}var Le=(s,r)=>1/s/(1/s+1/r);function Lo(s,r){let a=Bt[r];if(!a||!s?.odds||s.odds.length!==3)return null;let n=yt(s.odds).fair;if(!n)return null;let m=s.total,d=m&&m.over>1&&m.under>1?Le(m.over,m.under):null;return d==null?null:On({p1:n[0],px:n[1],p2:n[2],line:m.line,pOver:d},a)}function An(s,r,a,n=["Хозяева","Гости"]){let m=Lo(s,a);if(!m)return[];let d=Bt[a],u=Ae({score:[0,0],minute:0},m,d),c=[],f=new Set,h=g=>g>0?`+${g}`:`${g}`,v=g=>{let x=String(g??"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?\d+(?:\.\d+)?/g);return x?Number(x[x.length-1]):NaN};for(let g of r||[]){if(g.kind!=="total"&&g.kind!=="handicap"||g.outcomes?.length!==2)continue;let x=`${g.title||""} ${g.period||""}`;if(/тайм|период|четверт|half|period|инд|команд|угл|карт|corner|card|овертайм|буллит|с уч[её]том|(^|[^а-яё])от([^а-яё]|$)/i.test(x.replace(/осн\.?\s*время/i,"")))continue;if(g.kind==="handicap"){let F=v(g.outcomes[0].label);if(Number.isFinite(F)||(F=v(g.line)),!Number.isFinite(F)||Math.abs(F)>4||f.has(`h${F}`))continue;let $=Number(g.outcomes[0].odd),_=Number(g.outcomes[1].odd);if(!($>1&&_>1))continue;let C=u.handicap(F),j=1-C.push||1;if(Math.abs(C.home/j-Le($,_))>.15)continue;f.add(`h${F}`),c.push({label:`Фора ${n[0]} ${h(F)}`,odd:$,p:C.home/j,kind:"handicap",side:"home",line:F,source:"Fonbet без маржи"},{label:`Фора ${n[1]} ${h(-F)}`,odd:_,p:C.away/j,kind:"handicap",side:"away",line:-F,source:"Fonbet без маржи"});continue}let y=Number(String(g.line||"").replace(",","."));if(!Number.isFinite(y)||y<=0||y>(a==="hockey"?12:9)||f.has(y))continue;let O=Vt(g.outcomes.map(F=>F.label));if(O<0)continue;let w=u.total(y),L=1-w.push||1,I=w.over/L,P=w.under/L,E=Number(g.outcomes[O].odd),V=Number(g.outcomes[1-O].odd);!(E>1&&V>1)||Math.abs(I-Le(E,V))>.2||(f.add(y),c.push({label:`Тотал больше ${y}`,odd:E,p:I,kind:"total",line:y,source:"Fonbet без маржи"},{label:`Тотал меньше ${y}`,odd:V,p:P,kind:"total",line:y,source:"Fonbet без маржи"}))}return c}function Co(s){let r=(s||[]).map(Number);if(!r.length||!r.every(d=>d>1))return null;let a=r.map(d=>1/d),n=a.reduce((d,u)=>d+u,0),m=a.map(d=>d/n);return m.length===3?m[0]+m[1]/2:m[0]}function Ln(s,r){if(!s?.p1)return{ok:!1,reason:"нет прогноза"};if(s.confidence==="очень низкая")return{ok:!1,reason:"мало матчей в архиве — модель почти ничего не знает об участниках"};let a=Co(r);return a!=null&&Math.abs(s.p1-a)>.2?{ok:!1,reason:`модель расходится с ценой конторы на ${Math.round(Math.abs(s.p1-a)*100)} п.п. — скорее всего, она чего-то не знает (квалификация, травма, состав)`}:{ok:!0,reason:""}}var Eo={cs:!1,dota:!1,tennis:!1,basketball:!1,mma:!1,hockey:!1},Cn=s=>Eo[s]===!0;function Ce(s,r){if(!s?.p1||!(s.p2>0))return"";let a=n=>n>.01&&n<.99?(1/n*1.03).toFixed(2):"—";return`По модели Линзы интересная цена от: ${r[0]} — ${a(s.p1)}, ${r[r.length-1]} — ${a(s.p2)} (справочно: модель пока не точнее цены конторы).`}var Pe={atp:{hard:.645,clay:.625,grass:.67},wta:{hard:.565,clay:.55,grass:.585}};function Ot(s,r=0,a=0){let n=1-s,m=s*s/(s*s+n*n),d=new Map,u=(c,f)=>{if(c>=4&&c-f>=2)return 1;if(f>=4&&f-c>=2)return 0;if(c>=3&&f>=3)return c===f?m:c>f?s+n*m:s*m;let h=c*16+f;return d.has(h)||d.set(h,s*u(c+1,f)+n*u(c,f+1)),d.get(h)};return u(r,a)}function de(s,r,a=0,n=0,m=!0,d=7){let u=y=>y?s:1-r,c=s*(1-r)/(s*(1-r)+(1-s)*r),f=y=>y===0?0:Math.floor((y+1)/2),h=f(a+n)%2===0?m:!m,v=y=>f(y)%2===0?h:!h,g=new Map,x=(y,O)=>{if(y>=d&&y-O>=2)return 1;if(O>=d&&O-y>=2)return 0;if(y>=d-1&&O>=d-1&&y===O)return c;let w=y*64+O;if(!g.has(w)){let L=u(v(y+O));g.set(w,L*x(y+1,O)+(1-L)*x(y,O+1))}return g.get(w)};return x(a,n)}function Ee(s,r,a=0,n=0,m=!0,d=7){let u=Ot(s),c=1-Ot(r),f=new Map,h=(v,g,x)=>{if(v>=6&&v-g>=2||v===7)return 1;if(g>=6&&g-v>=2||g===7)return 0;if(v===6&&g===6)return de(s,r,0,0,x,d);let y=v*32+g*2+(x?1:0);if(!f.has(y)){let O=x?u:c;f.set(y,O*h(v+1,g,!x)+(1-O)*h(v,g+1,!x))}return f.get(y)};return h(a,n,m)}function En(s,r,a,n=3,{finalTb:m=7}={}){let d=n>=5?3:2,u=(s.sets||[]).filter(([F,$])=>F>$).length,c=(s.sets||[]).length-u,[f,h]=s.games||[0,0],[v,g]=s.points||[0,0],x=s.aServes!==!1,O=u===d-1&&c===d-1?m:7,w=new Map,L=(F,$)=>{if(F>=d)return 1;if($>=d)return 0;let _=F*8+$;if(!w.has(_)){let C=F===d-1&&$===d-1?m:7,j=(Ee(r,a,0,0,!0,C)+Ee(r,a,0,0,!1,C))/2;w.set(_,j*L(F+1,$)+(1-j)*L(F,$+1))}return w.get(_)},I=f===6&&h===6,P,E;if(I)P=de(r,a,v,g,x,O),E=P;else{E=x?Ot(r,v,g):1-Ot(a,g,v);let F=($,_)=>$>=6&&$-_>=2||$===7?1:_>=6&&_-$>=2||_===7?0:Ee(r,a,$,_,!x,O);P=E*F(f+1,h)+(1-E)*F(f,h+1)}return{match:P*L(u+1,c)+(1-P)*L(u,c+1),set:P,game:E,hold:x?E:1-E}}function Pn(s,r,a=3){return(En({sets:[],games:[0,0],points:[0,0],aServes:!0},s,r,a).match+En({sets:[],games:[0,0],points:[0,0],aServes:!1},s,r,a).match)/2}var Po=.03,At=(s,r,a)=>s.set(r,(s.get(r)||0)+a);function jo(s,r,a=!0){let n=Ot(s),m=Ot(r),d=new Map,u=new Map([[`0,0,${a?1:0}`,1]]);for(;u.size;){let c=new Map;for(let[f,h]of u){let[v,g,x]=f.split(",").map(Number),y=x===1;if(v===6&&g===6){let w=de(s,r,0,0,y);At(d,`7,6,${y?0:1}`,h*w),At(d,`6,7,${y?0:1}`,h*(1-w));continue}let O=y?n:1-m;for(let[w,L,I]of[[v+1,g,O],[v,g+1,1-O]]){let P=(w>=6||L>=6)&&Math.abs(w-L)>=2||w===7||L===7,E=`${w},${L},${y?0:1}`;At(P?d:c,E,h*I)}}u=c}return[...d].map(([c,f])=>{let[h,v,g]=c.split(",").map(Number);return{ga:h,gb:v,nextA:g===1,p:f}})}function jn(s,r,a=3){let n=a===5?3:2,m=new Map,d=g=>{let x=g?1:0;return m.has(x)||m.set(x,jo(s,r,g)),m.get(x)},u=new Map,c=new Map,f=new Map,h=[{sa:0,sb:0,a:!0,t:0,d:0,p:.5},{sa:0,sb:0,a:!1,t:0,d:0,p:.5}];for(;h.length;){let g=new Map;for(let x of h)for(let y of d(x.a)){let O=x.sa+(y.ga>y.gb?1:0),w=x.sb+(y.gb>y.ga?1:0),L=x.t+y.ga+y.gb,I=x.d+y.ga-y.gb,P=x.p*y.p;if(O===n||w===n){At(u,`${O}:${w}`,P),At(c,L,P),At(f,I,P);continue}let E=`${O},${w},${y.nextA?1:0},${L},${I}`,V=g.get(E);V?V.p+=P:g.set(E,{sa:O,sb:w,a:y.nextA,t:L,d:I,p:P})}h=[...g.values()]}let v=(g,x)=>[...g].reduce((y,[O,w])=>y+(x(Number(O))?w:0),0);return{sets:Object.fromEntries(u),win:[...u].reduce((g,[x,y])=>g+(Number(x.split(":")[0])===n?y:0),0),total:c,diff:f,over:g=>({over:v(c,x=>x>g),push:v(c,x=>x===g)}),handicap:g=>({home:v(f,x=>x+g>0),push:v(f,x=>x+g===0)})}}var Io=0,Bo=.04,Do=[[-2.0201828705,.0199532421],[-.9585724646,.3936193232],[0,.9453087205],[.9585724646,.3936193232],[2.0201828705,.0199532421]].map(([s,r])=>[s*Math.SQRT2,r/Math.sqrt(Math.PI)]);function qo(s,{tour:r="atp",surface:a="hard",bestOf:n=3,serveShift:m=Io,daySd:d=Bo}={}){let u=((Pe[r]||Pe.atp)[a]||.63)+m,c=F=>Math.max(-.3,Math.min(.3,F)),f=d>0?Do:[[0,1]],h=F=>f.reduce(($,[_,C])=>$+C*Pn(u+c(F+_*d),u-c(F+_*d),n),0),v=-.3,g=.3,x=Math.min(.995,Math.max(.005,s));for(let F=0;F<30;F+=1){let $=(v+g)/2;h($)<x?v=$:g=$}let y=(v+g)/2;if(f.length===1)return jn(u+y,u-y,n);let O=f.map(([F,$])=>[$,jn(u+c(y+F*d),u-c(y+F*d),n)]),w=F=>{let $=new Map;for(let[_,C]of O)for(let[j,B]of F(C))$.set(j,($.get(j)||0)+_*B);return $},L=w(F=>Object.entries(F.sets)),I=w(F=>F.total),P=w(F=>F.diff),E=(F,$)=>[...F].reduce((_,[C,j])=>_+($(Number(C))?j:0),0),V=n===5?3:2;return{sets:Object.fromEntries(L),win:[...L].reduce((F,[$,_])=>F+(Number($.split(":")[0])===V?_:0),0),total:I,diff:P,over:F=>({over:E(I,$=>$>F),push:E(I,$=>$===F)}),handicap:F=>({home:E(P,$=>$+F>0),push:E(P,$=>$+F===0)})}}var Ro={cs:0,dota:0};function Go(s,{pick:r=0}={}){let a=c=>Math.min(.999,Math.max(.001,c)),n=c=>{let f=a(c+r),h=a(c-r),v=a(c),g=f*h,x=(1-f)*(1-h),y=f*(1-h)+(1-f)*h;return{q:c,s20:g,s02:x,s21:y*v,s12:y*(1-v)}},m=0,d=1;for(let c=0;c<50;c+=1){let f=(m+d)/2,h=n(f);h.s20+h.s21<s?m=f:d=f}let u=n((m+d)/2);return{q:u.q,sets:{"2:0":u.s20,"2:1":u.s21,"1:2":u.s12,"0:2":u.s02},over25:u.s21+u.s12,homeMinus15:u.s20,awayMinus15:u.s02}}var Uo={tennis:!0,cs:!1,dota:!1};function Vo(s=""){let r=String(s),a=/wta|жен|women/i.test(r)?"wta":"atp",n=/грунт|clay/i.test(r)?"clay":/трав|grass/i.test(r)?"grass":"hard",m=/australian open|roland garros|ролан|уимблдон|wimbledon|us open|открытый чемпионат (австралии|сша)/i.test(r);return{tour:a,surface:n,bestOf:m&&a==="atp"?5:3}}function je({sport:s,model:r=null,p:a=null,source:n="модель Линзы",markets:m,names:d=["Хозяева","Гости"],league:u=""}){let c=a??r?.p1;if(!Uo[s]||!(c>0&&c<1))return[];let f=s==="tennis",h=f?qo(c,Vo(u)):Go(c,{pick:Ro[s]||0}),v=P=>{let E=String(P??"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?\d+(?:\.\d+)?/g);return E?Number(E[E.length-1]):NaN},g=(P,E)=>1/P/(1/P+1/E),x=(P,E)=>E>0?P/(1-E):P,y=f?"гейма":"карты",O=P=>String(P||"").toLowerCase().replace(/ё/g,"е"),w=d.flatMap(P=>O(P).split(/[^a-zа-я0-9-]+/)).filter(P=>P.length>=4),L=[],I=new Set;for(let P of m||[]){if(P.scope==="list"||P.main===!1||P.kind!=="total"&&P.kind!=="handicap"||P.outcomes?.length!==2||!P.outcomes.every($=>$.odd>1))continue;let E=`${P.title||""} ${P.period||""}`;if(/сет|set|тай-?брейк|tie|инд|игрок|player|раунд|round|килл|kill|чет|нечет/i.test(E)||w.some($=>O(E).includes($))||!f&&/гейм|game/i.test(E))continue;let[V,F]=P.outcomes;if(P.kind==="total"){let $=Number.isFinite(v(P.line))?v(P.line):v(V.label);if(!Number.isFinite($)||I.has(`t${$}`)||(f?$<12||$>60:$!==2.5))continue;let _=!/меньш|under/i.test(V.label),C,j=0;if(f){let Q=h.over($);C=Q.over,j=Q.push}else if($===2.5)C=h.over25;else continue;let B=_?V:F,G=_?F:V,U=x(C,j);if(Math.abs(U-g(B.odd,G.odd))>.2)continue;I.add(`t${$}`),L.push({label:`Тотал ${f?"геймов":"карт"} больше ${$}`,odd:B.odd,p:U,kind:"total",line:$,source:n}),L.push({label:`Тотал ${f?"геймов":"карт"} меньше ${$}`,odd:G.odd,p:1-U,kind:"total",line:$,source:n})}else{let $=Number.isFinite(v(V.label))?v(V.label):v(P.line);if(!Number.isFinite($)||I.has(`h${$}`)||(f?Math.abs($)>15:Math.abs($)!==1.5))continue;let _,C=0;if(f){let G=h.handicap($);_=G.home,C=G.push}else if($===-1.5)_=h.homeMinus15;else if($===1.5)_=1-h.awayMinus15;else continue;let j=x(_,C);if(Math.abs(j-g(V.odd,F.odd))>.2)continue;I.add(`h${$}`);let B=G=>G>0?`+${G}`:`${G}`;L.push({label:`Фора ${d[0]} ${B($)} ${y}`,odd:V.odd,p:j,kind:"handicap",side:"home",line:$,source:n}),L.push({label:`Фора ${d[1]} ${B(-$)} ${y}`,odd:F.odd,p:1-j,kind:"handicap",side:"away",line:-$,source:n})}}return L}function In({sport:s,model:r,markets:a,names:n,league:m=""}){let d=je({sport:s,model:r,markets:a,names:n,league:m}).filter(c=>c.p>=.15&&c.p<=.85),u=new Map;for(let c of d){let f=`${c.kind}|${Math.abs(c.line)}`;(!u.has(f)||c.p*c.odd>u.get(f).p*u.get(f).odd)&&u.set(f,c)}return[...u.values()].sort((c,f)=>Math.abs(c.p-.5)-Math.abs(f.p-.5)).map(c=>({label:c.label,from:Math.round(1/c.p*(1+Po)*100)/100,odd:c.odd}))}var pe=globalThis.__lzBus,Ie=pe&&window.top===window?sn(location.hostname):null;Ie&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,Zo(Ie.adapter,Ie.book));async function Zo(s,r){let a=await Fe(["lz.settings","lz.positions","lz.express","lz.margins","lz.whatsnew"]),n={settings:{...we,...a["lz.settings"]||{}},positions:(a["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:Ho(a["lz.express"]),margins:ce(a["lz.margins"]),whatsnew:a["lz.whatsnew"]||null,analysis:new Map,compare:new Map,consensus:new Map,model:new Map,facts:new Map,fonbetRef:new Map,live:new Map,edges:{status:"idle",data:null,error:"",at:0},partners:{data:{},at:0},status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},m=new WeakMap,d=new WeakMap,u=cn(),c=bn({bus:pe,brand:te,actions:ve()});c.restore(n.positions);function f(i){let t=i.outcomes.map(p=>p.odd).join("/"),o=m.get(i);if(o?.sig===t)return o.set;let l=yt(i.outcomes.map(p=>p.odd));return m.set(i,{sig:t,set:l}),l}function h(){return n.match?n.analysis.get(n.match.key):null}function v(i){let t=h()?.result;if(!t?.model||i.scope==="list"||!n.match||!Object.values(t.shift||{}).some(b=>Math.abs(b)>=.5))return null;let{home:o,draw:l,away:p}=t.model,k=i.outcomes.length;if(i.kind==="1x2"&&i.main&&k===3)return[o,l,p];if(i.kind==="12"&&i.main&&k===2&&l<.005)return[o,p];if(i.kind==="dc"&&i.main&&k===3)return[o+l,o+p,l+p];if(/^победит\s*\(осн\.?\s*время\)$/i.test(i.title)&&k===2){let b=i.period===n.match.home?o:i.period===n.match.away?p:null;if(b!=null)return[b,1-b]}return null}function g(){let i=n.markets.filter(t=>t.scope!=="list"&&t.main&&(t.kind==="1x2"||t.kind==="12"));return i.find(t=>t.scope==="top")||i[0]||null}function x(i,t){let o=i.outcomes[t].label;return i.scope==="list"?!i.event||!i.main?o:i.kind==="1x2"?[i.event.home,"Ничья",i.event.away][t]||o:i.kind==="12"&&[i.event.home,i.event.away][t]||o:n.match?i.kind==="1x2"?[n.match.home,"Ничья",n.match.away][t]||o:i.kind==="12"&&[n.match.home,n.match.away][t]||o:o}function y(){let i=n.settings.overlay,t=[];for(let l of n.markets){if(l.outcomes.forEach((N,A)=>d.set(N.el,{market:l,index:A})),i==="off")continue;let p=f(l);if(p.kind==="partial")continue;let k=v(l),b=k||p.fair,M=0;for(let N=1;N<p.fair.length;N+=1)p.fair[N]>p.fair[M]&&(M=N);let z="accent";if(k){let N=0;for(let A=1;A<k.length;A+=1)k[A]-p.fair[A]>k[N]-p.fair[N]&&(N=A);k[N]-p.fair[N]>=.015&&(M=N,z="pos")}let S=l.scope!=="list"||l.main&&(l.kind==="1x2"||l.kind==="12");l.outcomes.forEach((N,A)=>{let T=A===M&&S;!T&&i!=="all"||t.push({el:N.el,frame:T,chip:kt(b[A]),tone:T?z:"quiet"})})}let o=O();if(o){let l=t.find(p=>p.el===o.item.el);l?l.selected=!0:t.push({el:o.item.el,frame:!1,selected:!0,chip:null})}u.set(t)}function O(){if(!n.selected)return null;let i=n.markets.find(o=>o.id===n.selected.id),t=i?.outcomes[n.selected.index];return t?.el?.isConnected?{market:i,item:t,index:n.selected.index}:null}function w(){if(n.settings.theme!=="auto")return n.settings.theme;for(let i of[document.body,document.documentElement]){let o=(i?getComputedStyle(i).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!o||o[4]==="0")continue;return(.2126*o[1]+.7152*o[2]+.0722*o[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}let L=0;function I(){clearTimeout(L),L=setTimeout(()=>$t({"lz.margins":n.margins}),1500)}function P(){if(n.pageType!=="match"||!n.match||n.match.live)return;n.margins=ce(n.margins);let i=B();i&&kn(n.margins,{key:n.match.key,book:r.id,margin:i.margin})&&I()}function E(){location.href!==n.url&&(n.url=location.href,n.selected=null,u.hideTip());let i="other",t=[],o=null;try{i=s.pageType(document,location),t=s.collect(document,location),o=s.readMatch(document,location)}catch(p){console.error("[Линза] страница не прочитана",p)}i!==n.pageType&&(n.pageType=i,n.tab!=="settings"&&n.tab!=="express"&&(n.tab=i==="match"?"match":"scan")),n.markets=t,n.match=o,P();let l=w();l!==n.theme&&(n.theme=l),u.setTheme(n.theme),c.setTheme(n.theme),y(),gt(),$(),c.isOpen&&(St(),Wt(),Zt(),_t(),c.render(J()))}let V=new Set,F=null;function $(){if(s.observeTargets)for(let i of s.observeTargets(document))V.has(i)||(V.add(i),F=F||new MutationObserver(j),F.observe(i,{childList:!0,subtree:!0,characterData:!0}))}let _=0,C=0;function j(){let i=Date.now();C||(C=i),clearTimeout(_);let t=i-C>900?0:220;_=setTimeout(()=>{C=0,!document.hidden&&E()},t)}function B(){let i=g();if(!i)return null;let t=f(i);if(t.kind!=="full")return null;let o=v(i);return{title:"Что заложено в цене",margin:t.margin,rows:i.outcomes.map((l,p)=>({name:x(i,p),odd:l.odd,fair:t.fair[p],model:o?o[p]:null})),overtime:G()}}function G(){if(!["hockey","basketball"].includes(n.match?.sport))return null;let i=n.markets.find(o=>o.scope!=="list"&&o.outcomes.length===2&&/овертайм|булл|(^|[^а-яё])от([^а-яё]|$)|\bot\b/i.test(`${o.title} ${o.period}`)&&!/тотал|фора|будет|перв|втор|трет|период|тайм/i.test(`${o.title} ${o.period}`));if(!i)return null;let t=f(i);return t.kind!=="full"?null:{title:[i.title,i.period].filter(Boolean).join(" · "),rows:i.outcomes.map((o,l)=>({name:x(i,l)||[n.match.home,n.match.away][l],odd:o.odd,fair:t.fair[l]}))}}function U(){let i=O();if(!i)return null;let{market:t,item:o,index:l}=i,p=f(t),k=v(t),b=p.fair?p.fair[l]:null,M=t.event?`${t.event.home} — ${t.event.away}`:n.match?`${n.match.home} — ${n.match.away}`:"",z=n.match?n.compare.get(n.match.key):null,S=null;if(z?.rows?.length&&t.main&&(t.kind==="1x2"||t.kind==="12")&&t.scope!=="list")for(let A of z.rows){let T=A.odds[l];T&&(!S||T>S.odd)&&(S={name:A.name,odd:T,book:A.book||""})}S&&(S.partner=S.book&&S.book!==r.id&&n.partners.data?.[S.book]||null,S.gain=Math.round((S.odd-o.odd)*(n.settings.stake||1e3)));let N=`${t.id}#${l}`;return{market:[t.title,t.period,t.line].filter(Boolean).join(" · "),label:[x(t,l),M].filter(Boolean).join(" · "),odd:o.odd,fair:b,margin:p.margin,fairOdd:b?1/b:null,model:k?k[l]:null,ev:k?Ve(k[l],o.odd):null,best:S,canAdd:Number.isFinite(b)&&!n.express.some(A=>A.id===N),inExpress:n.express.some(A=>A.id===N),note:p.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":k?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function Q(){let i=$n(ce(n.margins),r.id);if(!i)return null;let t=i.best&&i.best.there<i.best.here?i.best:null,o=t&&xt().find(l=>l.name===t.name&&(l.url||l.code))||null;return{...i,best:t,partner:o}}function Y(){let i=[];if(n.pageType==="match"?n.markets.forEach((p,k)=>{if(p.scope==="list")return;let b=f(p);if(b.kind!=="full")return;let M=0;for(let z=1;z<b.fair.length;z+=1)b.fair[z]>b.fair[M]&&(M=z);i.push({index:k,name:p.title,sub:[p.period,p.line].filter(Boolean).join(" · "),margin:b.margin,fav:p.outcomes[M].label,favPct:b.fair[M]})}):n.markets.forEach((p,k)=>{if(!p.event||!p.main||p.kind!=="1x2"&&p.kind!=="12")return;let b=f(p);if(b.kind!=="full")return;let M=0;for(let S=1;S<b.fair.length;S+=1)b.fair[S]>b.fair[M]&&(M=S);let z=p.kind==="1x2"?[p.event.home,"Ничья",p.event.away][M]:[p.event.home,p.event.away][M];i.push({index:k,name:`${p.event.home} — ${p.event.away}`,sub:p.event.league||p.event.time,margin:b.margin,fav:z,favPct:b.fair[M]})}),!i.length)return null;let t=new Set;for(let p=i.length-1;p>=0;p-=1){let k=`${i[p].name}|${i[p].sub}`;t.has(k)?i.splice(p,1):t.add(k)}let o=i.reduce((p,k)=>p+k.margin,0)/i.length;i.sort((p,k)=>p.margin-k.margin);let l=i.slice(0,16);return l.forEach(p=>{p.low=p.margin<=o*.8}),{title:n.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:n.pageType==="match"?"Рынок":"Матч",average:o,rows:l,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${l.length} из ${i.length}, сначала самые дешёвые.`}}function nt(){let i=n.status;return i.ready?i.limit?`Разборов сегодня: ${i.used} из ${i.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function J(){let i=n.match?.key,t=i&&n.analysis.get(i)||{status:"idle",steps:[]},o=i&&n.compare.get(i)||{status:"idle"},l=n.match?.live&&s.readEsportsWidget?s.readEsportsWidget(document):null,p=n.status;return{tab:n.tab,backTab:n.backTab,theme:n.theme,bookName:r.name,pageType:n.pageType,match:n.match?{...n.match,sportName:De[n.match.sport]||""}:null,esports:l?{...l,homeName:n.match.home,awayName:n.match.away}:null,line:B(),analysis:{status:t.status,steps:t.steps||[],result:t.result||null,error:t.error||"",needKey:!!t.needKey},compare:o,consensus:i&&n.consensus.get(i)||null,model:i&&n.model.get(i)||null,live:be(i),verdict:fe(i),facts:i&&n.facts.get(i)||null,pick:U(),scan:n.tab==="scan"?Y():null,margins:n.tab==="scan"?Q():null,edges:n.edges,bookId:r.id,partners:xt(),stake:Number(n.settings.stake)||1e3,express:{legs:n.express,stats:Ue(n.express)},quota:nt(),update:n.status.update?{version:n.status.update,url:te.site?`${te.site}#install`:""}:null,whatsnew:n.whatsnew?{version:n.whatsnew.to,changes:zn(n.whatsnew.from,n.whatsnew.to)}:null,settings:{overlay:n.settings.overlay,theme:n.settings.theme,stake:Number(n.settings.stake)||1e3,mode:p.mode,proxy:p.proxy,ready:p.ready,hasKey:p.hasKey,keyMask:p.keyMask,licenseMask:p.licenseMask,plan:p.plan==="free"||!p.plan?"":`Тариф «${{max:"Макс",vip:"VIP",api:"API"}[p.plan]||"Про"}»${p.until?` до ${p.until.split("-").reverse().join(".")}`:""}.`,usage:p.limit?`Сегодня разборов: ${p.used} из ${p.limit}.`:""}}}let ot=()=>{c.isOpen&&c.render(J())};function ht(i){Object.assign(n.settings,i),$t({"lz.settings":n.settings}),E(),c.render(J())}async function zt(i=!1){if(!i&&Date.now()-n.partners.at<3600*1e3)return;n.partners.at=Date.now();let t=await et("lz:partners",{force:i});t.ok&&t.data&&typeof t.data=="object"&&(n.partners.data=t.data,c.isOpen&&c.render(J()),pt())}let xt=()=>Object.values(n.partners.data||{}).filter(i=>i&&i.id!==r.id);function pt(){if(!c.isOpen||n.tab!=="match"||!n.match)return;let i=xt().filter(t=>t.url||t.code).map(t=>t.id);i.length&&et("lz:partner-seen",{ids:i,s:"panel"})}async function ct(){n.edges={...n.edges,status:"loading",error:""};let i=await et("lz:edges",{sport:n.match?.sport||""});n.edges=i.ok?{status:"done",data:i.data,error:"",at:Date.now()}:{status:"error",data:n.edges.data,error:i.error,at:Date.now()},ot()}async function ut(){let i=await et("lz:status");i.ok&&(n.status=i.data),ot()}function Lt(){let i=g(),t=i?f(i):null;return{book:r.name,match:n.match,market:i&&t?.kind==="full"?{kind:i.kind,labels:i.outcomes.map((o,l)=>x(i,l)),odds:i.outcomes.map(o=>o.odd)}:null}}function Ct(){return n.markets.filter(i=>i.scope!=="list"&&i.main!==!1&&(i.kind==="total"||i.kind==="handicap")&&i.outcomes?.length===2).slice(0,40).map(i=>({kind:i.kind,title:i.title||"",period:i.period||"",line:i.line??"",outcomes:i.outcomes.map(t=>({label:t.label||"",odd:Number(t.odd)}))}))}function gt(){if(!n.match||!wt())return;let i=Lt();if(!i.market)return;let t=`${n.match.key}|${i.market.odds.join("/")}`;t!==gt.last&&(gt.last=t,et("lz:quote",i))}async function St(){let i=n.match;if(!i||i.live||n.consensus.has(i.key))return;let t=Lt();if(!t.market?.odds?.length)return;n.consensus.set(i.key,null);let o=await et("lz:consensus",{match:i,size:t.market.odds.length});n.consensus.set(i.key,o.ok&&o.data?.consensus?o.data:null),n.match?.key===i.key&&c.isOpen&&c.render(J())}async function _t(){let i=n.match;if(!i?.live||!["basketball","football","hockey","tennis"].includes(i.sport))return;let t=n.live.get(i.key);if(t&&(t.pending||Date.now()-t.at<3e4))return;n.live.set(i.key,{...t||{},pending:!0});let o=await et("lz:live",{match:i});n.live.set(i.key,{at:Date.now(),data:o.ok&&o.data&&!o.data.error?o.data:null,error:o.ok?o.data?.error||"":o.error||""}),n.match?.key===i.key&&c.isOpen&&c.render(J())}function Et(i,t){n.fonbetRef.set(i,null),et("lz:fonbet-ref",{match:t}).then(o=>{n.fonbetRef.set(i,o.ok&&o.data?.odds?o.data:null),o.ok&&o.data?.odds&&n.match?.key===i&&c.isOpen&&c.render(J())}).catch(()=>{})}function me(i,t,o){let l=n.match,p=`${i}|${[t.best,t.suspect,...t.others].filter(Boolean).map(b=>`${b.label}:${b.odd}`).join(",")}`;if(n.verdictSent===p)return;n.verdictSent=p;let k=[t.best,t.suspect,...t.others].filter(Boolean).map(b=>({label:b.label,odd:b.odd,p:b.p,kind:b.kind||"win",side:b.side||"",line:b.line??null,source:b.source||o,unit:b.unit||""}));et("lz:verdict",{payload:{sport:l.sport,league:l.league||"",home:l.home,away:l.away,book:r.name,source:o,best:t.best?.label||"",options:k}}).then(b=>{b?.ok&&b.data?.track&&b.data.track!==n.verdictTrack&&(n.verdictTrack=b.data.track,c.isOpen&&c.render(J()))}).catch(()=>{})}function fe(i){let t=n.match,o=i&&B();if(!t||!o||t.live)return null;let l=n.consensus.get(i),p=o.rows,k=n.model.get(i),b=k&&Ln(k,p.map(R=>R.odd)).ok?k:null,M=b&&Cn(t.sport)?b:null,z=n.analysis.get(i)?.result,S=[t.home,t.away],N=[],A="";if(l?.consensus?.length===p.length)p.forEach((R,tt)=>N.push({label:R.name,odd:R.odd,p:l.consensus[tt],side:p.length===3?["home","draw","away"][tt]:["home","away"][tt]})),A=`консенсус ${l.count} контор`;else if(!l?.consensus&&M?.sport==="hockey"&&M.regulation&&p.length===3){let R=[M.regulation.p1,M.regulation.px,M.regulation.p2];p.forEach((tt,lt)=>N.push({label:tt.name,odd:tt.odd,p:R[lt],side:["home","draw","away"][lt]})),A="модель Линзы"}else{let R=p.length===2?p:t.sport==="mma"&&p.length===3?[p[0],p[2]]:o.overtime?.rows||null,tt=l?.consensus?.length===2?l.consensus:M?.p1?[M.p1,M.p2]:null;R&&tt&&(R.forEach((lt,at)=>N.push({label:S[at],odd:lt.odd,p:tt[at],side:["home","away"][at]})),A=l?.consensus?.length===2?`консенсус ${l.count} контор`:"модель Линзы")}let T=M?.sport==="mma"?M.durations:null;if(T)for(let R of n.markets){if(R.scope==="list"||R.kind!=="total"||R.outcomes.length!==2)continue;let tt=String(R.line||"").replace(",","."),lt=tt==="1.5"?T.r1+T.r2/2:tt==="2.5"&&T.rounds===3?T.r1+T.r2+T.r3/2:null,at=Vt(R.outcomes.map(bt=>bt.label));lt==null||at<0||N.some(bt=>bt.kind==="total"&&bt.line===tt)||(N.push({label:`Больше ${tt} раунда`,odd:R.outcomes[at].odd,p:1-lt,kind:"total",line:tt}),N.push({label:`Меньше ${tt} раунда`,odd:R.outcomes[1-at].odd,p:lt,kind:"total",line:tt}))}if(M?.sport==="basketball"&&M.lines){let R=Rt=>{let dt=String(Rt||"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?[0-9]+(?:[.][0-9]+)?/);return dt?Number(dt[0]):NaN},tt=Rt=>n.markets.filter(dt=>dt.scope!=="list"&&dt.main&&dt.kind===Rt&&dt.outcomes.length===2&&dt.outcomes.every(Jt=>Jt.odd>1)).sort((dt,Jt)=>Math.abs(dt.outcomes[0].odd-dt.outcomes[1].odd)-Math.abs(Jt.outcomes[0].odd-Jt.outcomes[1].odd))[0]||null,lt=tt("handicap"),at=tt("total"),bt=lt?R(lt.outcomes[0].label):NaN;lt&&!Number.isFinite(bt)&&(bt=R(lt.line));let Yt=at?R(at.line):NaN;at&&!Number.isFinite(Yt)&&(Yt=R(at.outcomes[0].label));let ke=at?Vt(at.outcomes.map(Rt=>Rt.label)):-1;N.push(...Nn(M,{handicap:lt&&Number.isFinite(bt)?{line:bt,home:lt.outcomes[0].odd,away:lt.outcomes[1].odd}:null,total:at&&ke>=0&&Number.isFinite(Yt)?{line:Yt,over:at.outcomes[ke].odd,under:at.outcomes[1-ke].odd}:null},S))}let q=n.markets.filter(R=>R.scope!=="list"),K=p.length===2?yt(p.map(R=>R.odd)):null;K?.fair&&["tennis","cs","dota"].includes(t.sport)&&N.push(...je({sport:t.sport,p:K.fair[0],source:"цена конторы на победу",markets:q,names:S,league:t.league||""}));let H=b?.p1&&["tennis","cs","dota"].includes(t.sport)?In({sport:t.sport,model:b,markets:q,names:S,league:t.league||""}):[];if((t.sport==="football"||t.sport==="hockey")&&r.id!=="fonbet"){let R=n.fonbetRef.get(i);R===void 0?Et(i,t):R&&N.push(...An(R,n.markets.filter(tt=>tt.scope!=="list"),t.sport,S))}if(!N.length)return b?.p1?{best:null,suspect:null,others:[],lines:[Ce(b,S),"Это расчёт, а не обещание: проиграть можно и при перевесе в цене. 18+"],track:n.verdictTrack||""}:null;let st=[...N].filter(R=>R.p*R.odd-1>=.03&&R.p*R.odd-1<=.12).sort((R,tt)=>tt.p*tt.odd-R.p*R.odd)[0]?.side,mt=(z?.factors||[]).filter(R=>st&&R.side===st).slice(0,2).map(R=>R.text),it=Sn(N,{source:A,reasons:mt,risk:z?.risks?.[0]||""});return it&&b?.p1&&!M&&it.lines.splice(it.lines.length-1,0,Ce(b,S)),it&&H.length&&it.lines.splice(it.lines.length-1,0,`По модели Линзы интересная цена от: ${H.slice(0,6).map(R=>`${R.label} — ${R.from.toFixed(2)}${R.odd>=R.from?" ✓ здесь выше":""}`).join(" · ")}.`),it&&me(i,it,A),it&&{...it,track:n.verdictTrack||""}}function he(i,t,o){let l=(M,z)=>t?[z,M]:[M,z],k=B()?.rows||[],b=k.length===2&&k.every(M=>Number.isFinite(M.fair))?k.map(M=>M.fair):null;return{kind:"tennis",names:[n.match.home,n.match.away],score:l(i.score[0],i.score[1]),sets:i.sets.map(([M,z])=>l(M,z)),games:l(i.games[0],i.games[1]),points:l(i.points[0],i.points[1]),tiebreak:i.tiebreak,serving:i.aServes==null?null:i.aServes!==t?0:1,bestOf:i.bestOf,prior:i.prior,serve:l(i.serve.a,i.serve.b),probs:l(i.p1,i.p2),set:l(i.set.p1,1-i.set.p1),game:l(i.game.p1,1-i.game.p1),book:b,compare:i.prior.source==="line"||i.prior.source==="model",at:o}}function ge(i,t,o){let l=(z,S)=>t?[S,z]:[z,S],p=z=>t?[z[2],z[1],z[0]]:z,b=B()?.rows||[],M=b.length===3&&b.every(z=>Number.isFinite(z.fair))?b.map(z=>z.fair):null;return{kind:"goals",sport:i.sport,names:[n.match.home,n.match.away],score:l(i.score[0],i.score[1]),red:l(i.red[0],i.red[1]),minute:i.minute,period:i.period,periods:i.periods,clock:i.clock,prior:i.prior,probs:p([i.p1,i.px,i.p2]),book:M,compare:i.prior.source==="line",expTotal:i.expTotal,nextGoal:p([i.nextGoal.home,i.nextGoal.none,i.nextGoal.away]),total:i.tables.total,handicap:i.tables.handicap.map(z=>t?{line:-z.line,home:z.away,away:z.home}:z).sort((z,S)=>z.line-S.line),bookLines:i.bookLines,at:o}}function be(i){let t=i&&n.live.get(i);if(!t?.data)return t?.error?{error:t.error}:null;let o=t.data,l=!!o.flipped;if(o.kind==="goals")return ge(o,l,t.at);if(o.kind==="tennis")return he(o,l,t.at);let p=(S,N)=>l?[N,S]:[S,N],k=B(),b=k?.overtime?.rows||k?.rows||[],M=b.length===2?b.map(S=>S.fair):b.length===3&&b.every(S=>Number.isFinite(S.fair))?[b[0].fair+b[1].fair/2,b[2].fair+b[1].fair/2]:null,z=o.tables||{};return{names:[n.match.home,n.match.away],score:p(o.score[0],o.score[1]),periods:(o.periods||[]).map(([S,N])=>p(S,N)),period:o.period,elapsed:o.elapsed,left:o.left,clock:o.clock,format:o.format,probs:p(o.p1,o.p2),book:M,prior:o.prior,expMargin:l?-o.expMargin:o.expMargin,sd:o.sd,projTotal:o.projTotal,sdTotal:o.sdTotal,handicap:(z.handicap||[]).map(S=>l?{line:-S.line,home:S.away,away:S.home}:S).sort((S,N)=>S.line-N.line),total:z.total||[],quarterTotal:z.quarterTotal||[],bookLines:o.bookLines?{handicap:o.bookLines.handicap?l?{...o.bookLines.handicap,line:-o.bookLines.handicap.line,odds:[...o.bookLines.handicap.odds].reverse(),fair:[...o.bookLines.handicap.fair].reverse(),p:1-o.bookLines.handicap.p,book:1-o.bookLines.handicap.book,gap:-o.bookLines.handicap.gap}:o.bookLines.handicap:null,total:o.bookLines.total||null}:null,quarter:o.quarter?{...o.quarter,score:p(o.quarter.score[0],o.quarter.score[1]),expMargin:l?-o.quarter.expMargin:o.quarter.expMargin,probs:p(o.quarter.p1,o.quarter.p2)}:null,at:t.at}}async function Wt(){let i=n.match;if(!i||!["cs","dota","tennis","basketball","mma","hockey"].includes(i.sport)||n.model.has(i.key)||i.live&&(i.sport==="tennis"||i.sport==="basketball"||i.sport==="mma"||i.sport==="hockey"))return;n.model.set(i.key,null);let t=await et("lz:model",{match:i});n.model.set(i.key,t.ok&&t.data?.p1?t.data:null),n.match?.key===i.key&&c.isOpen&&c.render(J())}let Kt=new Map;async function Zt(){let i=n.match;if(!i||!["football","hockey","basketball","cs","dota"].includes(i.sport))return;let t=i.live&&Date.now()-(Kt.get(i.key)||0)>60*1e3;if(n.facts.has(i.key)&&!t)return;let o=n.facts.get(i.key)||null;Kt.set(i.key,Date.now()),n.facts.set(i.key,o);let l=await et("lz:facts",{match:i});n.facts.set(i.key,l.ok&&l.data?.facts?.length?l.data:o),n.match?.key===i.key&&c.isOpen&&c.render(J())}async function xe(){let i=n.match;if(!i||n.analysis.has(i.key))return;let t=await et("lz:cached",{match:i});!t.ok||!t.data||n.analysis.has(i.key)||(n.analysis.set(i.key,{status:"done",steps:[],result:t.data}),E(),ot())}function ve(){return{opened(){ut(),E(),xe(),St(),Wt(),Zt(),_t(),zt(),c.render(J()),pt()},tab(i){i==="settings"&&(n.backTab=n.tab==="settings"?n.backTab:n.tab),n.tab=i||"match",i==="edges"&&n.edges.status!=="loading"&&Date.now()-n.edges.at>300*1e3&&ct(),c.render(J())},"edges-refresh"(){ct(),c.render(J())},theme(){ht({theme:n.theme==="dark"?"light":"dark"})},"overlay-toggle"(){ht({overlay:n.settings.overlay==="off"?"picks":"off"})},"set-overlay"(i){ht({overlay:i})},"set-theme"(i){ht({theme:i})},async"set-mode"(i){await et("lz:settings",{mode:i}),ut()},"copy-code"(i){if(!i)return;let t=()=>c.toast("Промокод скопирован");navigator.clipboard?.writeText?navigator.clipboard.writeText(i).then(t,()=>c.toast(`Промокод: ${i}`)):c.toast(`Промокод: ${i}`)},"set-stake"(i,t,o){let l=Math.round(Number(o.getElementById("lz-stake")?.value));if(!Number.isFinite(l)||l<10||l>1e7)return c.toast("Введите сумму от 10 ₽");ht({stake:l}),c.toast("Сумма сохранена")},async"save-key"(i,t,o){let l=o.getElementById("lz-key"),p=(l?.value||"").trim();if(p.length<8)return c.toast("Вставьте ключ целиком");let k=await et("lz:settings",{apiKey:p});c.toast(k.ok?"Ключ сохранён":k.error),l&&(l.value=""),ut()},async"clear-key"(){await et("lz:settings",{apiKey:""}),c.toast("Ключ удалён"),ut()},async"save-license"(i,t,o){let l=o.getElementById("lz-license"),p=(l?.value||"").trim();if(p.length<6)return c.toast("Вставьте ключ целиком");let k=await et("lz:settings",{licenseKey:p});c.toast(k.ok?"Ключ принят":k.error),l&&(l.value=""),ut()},async"clear-license"(){await et("lz:settings",{licenseKey:""}),c.toast("Ключ удалён"),ut()},savePosition(i,t){n.positions[i]=t,Fe(["lz.positions"]).then(o=>{let l=o["lz.positions"]||{};l[location.hostname]=n.positions,$t({"lz.positions":l})})},async analyze(){if(!n.match)return;let i=n.match.key,t={status:"loading",steps:[`${n.match.home} — ${n.match.away}`]};n.analysis.set(i,t),ot();let o=await et("lz:analyze",{...Lt(),markets:Ct(),force:!0}),l=o.ok?o.data?.job:"",p=Date.now();for(;l&&o.ok&&o.data?.status==="running"&&Date.now()-p<420*1e3;){if(t.steps=[t.steps[0],...(o.data.steps||[]).map(k=>k.text)].slice(-8),ot(),await new Promise(k=>setTimeout(k,2e3)),n.analysis.get(i)!==t)return;o=await et("lz:job",{job:l}),!o.ok&&o.code==="retry"&&(o=await et("lz:job",{job:l}))}if(o.ok&&l){let k=o.data?.steps?.length?[t.steps[0],...o.data.steps.map(b=>b.text)].slice(-8):t.steps;o.data.status==="done"?n.analysis.set(i,{status:"done",steps:k,result:{...o.data.result,full:o.data.full||null}}):o.data.status==="error"?n.analysis.set(i,{status:"error",steps:k,error:o.data.error}):n.analysis.set(i,{status:"error",steps:k,error:"Разбор идёт дольше 7 минут. Нажмите ещё раз — собранное уже на сервере, второй раз будет быстрее."})}else o.ok?n.analysis.set(i,{status:"done",steps:t.steps,result:o.data}):n.analysis.set(i,{status:"error",steps:t.steps,error:o.error,needKey:o.code==="no-access"});ut(),E(),c.render(J())},async report(){let i=n.match?n.analysis.get(n.match.key):null,t="";try{t=chrome.runtime.getManifest().version}catch{}let o=await et("lz:report",{where:"panel",url:location.href,book:r.name,version:t,match:n.match?`${n.match.home} — ${n.match.away}`:"",step:i?.steps?.slice(-1)[0]||"",error:i?.error||(i?.status==="done"?"разбор выглядит неправильно":"страница матча не узнана")});c.toast(o.ok?"Спасибо! Сообщение ушло разработчику.":o.error)},async compare(){if(!n.match)return;let i=n.match.key;n.compare.set(i,{status:"loading"}),ot();let t=await et("lz:compare",Lt());n.compare.set(i,t.ok?{status:"done",...t.data}:{status:"done",rows:[],labels:[],note:t.error}),t.ok&&wn(n.margins,i,t.data.rows)&&I(),ot()},"whatsnew-ok"(){n.whatsnew=null,$t({"lz.whatsnew":null}),ot()},"pick-clear"(){n.selected=null,y(),ot()},"leg-add"(){let i=U(),t=O();!i?.canAdd||!t||(n.express.push({id:`${t.market.id}#${t.index}`,title:i.market,label:i.label,odd:i.odd,fair:i.fair,at:Date.now()}),$t({"lz.express":n.express}),c.toast("Добавлено в расчёт экспресса"),ot())},"leg-remove"(i){n.express=n.express.filter(t=>t.id!==i),$t({"lz.express":n.express}),ot()},"leg-clear"(){n.express=[],$t({"lz.express":n.express}),ot()},"scan-go"(i){let t=n.markets[Number(i)],o=t?.outcomes[0]?.el;o?.isConnected&&(o.scrollIntoView({behavior:"smooth",block:"center"}),n.selected={id:t.id,index:0},setTimeout(y,400))}}}function Ht(i){let t=i.composedPath();for(let o=0;o<Math.min(t.length,6);o+=1){let l=t[o]instanceof Element?d.get(t[o]):null;if(l&&l.market.outcomes[l.index]?.el===t[o])return l}return null}let Pt=new Map;function ye(i){if(!i.event||!i.main||!["1x2","12"].includes(i.kind)||i.scope!=="list"||i.event.live)return console.debug("[lz] рынок для списка не запрашивается:",JSON.stringify({event:!!i.event,main:i.main,kind:i.kind,scope:i.scope,live:i.event?.live})),null;let t=i.event.key;if(Pt.has(t))return Pt.get(t);let o={home:i.event.home,away:i.event.away,sport:Xt(i),league:i.event.league||""},l=et("lz:consensus",{match:o,size:i.outcomes.length}).then(p=>((!p.ok||!p.data?.consensus)&&console.debug("[lz] рынок для списка:",p.error||p.data?.error||"нет данных"),p.ok&&p.data?.consensus?p.data:null)).catch(p=>(console.debug("[lz] рынок для списка:",String(p?.message||p)),null));return Pt.set(t,l),l.then(p=>Pt.set(t,p)),l}let Xt=i=>i.event?.sport||n.match?.sport||It(location.pathname,document.title,i.event?.league);function Nt({market:i,index:t},o=null){let l=f(i),p=v(i),k=i.event?`${i.event.home} — ${i.event.away}`:"",b=i.outcomes.map((S,N)=>{let A=l.fair?l.fair[N]:1/S.odd;return e(`div.tip-row${N===t?".hot":""}`,{},e("span",{text:x(i,N)}),e("span.odd",{text:Z(S.odd)}),e("span.pct",{text:kt(A,A<.1?1:0)}),e("span.tip-bar",{},e("i",{style:`width:${Math.round(A*100)}%`})))}),M=l.kind==="partial"?e("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):e("div.tip-foot",{},"Маржа конторы ",e("b",{text:kt(l.margin,1)}),p?e("span",{}," · модель: ",e("b",{text:kt(p[t],1)})):null),z=null;if(o?.consensus){let S=o.consensus.length===i.outcomes.length,N=!S&&o.consensus.length===2&&i.outcomes.length===3;if(S||N){let A=S?o.consensus[t]:null,T=A?i.outcomes[t].odd*A-1:0;z=e("div.tip-foot",{},`Рынок, ${o.count} контор${N?", с овертаймом":""}: `,e("b",{text:o.consensus.map(q=>kt(q,0)).join(" / ")}),T>.005?e("span.pos",{text:` · кэф выше рынка на ${(T*100).toFixed(1)}%`}):null)}}else o===void 0&&(z=e("div.tip-foot",{text:"Рынок: сверяю…"}));return e("div",{},e("div.tip-title",{text:[i.title,i.period,i.line].filter(Boolean).join(" · ")}),k?e("div.tip-sub",{text:k}):e("div.tip-sub",{text:"Шанс по линии без маржи"}),b.slice(0,8),M,z)}let Dt=0,jt=null;pe.on("page:pointerover",i=>{if(n.settings.overlay==="off")return;let t=Ht(i),o=t?t.market.outcomes[t.index].el:null;if(o!==jt){if(jt=o,clearTimeout(Dt),!t)return u.hideTip();Dt=setTimeout(()=>{if(jt!==o||!o.isConnected)return;u.setAvoid(c.rect());let l=ye(t.market);u.showTip(o,Nt(t,l instanceof Promise?void 0:l)),l instanceof Promise&&l.then(p=>{jt===o&&o.isConnected&&u.showTip(o,Nt(t,p))})},280)}}),pe.on("page:click",i=>{let t=Ht(i);t&&(n.selected={id:t.market.id,index:t.index},n.tab==="scan"&&(n.tab="match"),y(),ot())}),vn(i=>{if(i.type!=="lz:progress")return;let t=n.analysis.get(i.key);!t||t.status!=="loading"||(t.steps=[...t.steps,i.text].slice(-7),ot())});let qt=()=>{E(),new MutationObserver(j).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||E()}),setInterval(()=>{!document.hidden&&location.href!==n.url&&E()},600),setInterval(()=>{!document.hidden&&c.isOpen&&j()},4e3),wt()&&chrome.storage.onChanged.addListener(i=>{i["lz.settings"]&&(n.settings={...we,...i["lz.settings"].newValue||{}},E())}),ut()};document.body?qt():document.addEventListener("DOMContentLoaded",qt,{once:!0}),document.documentElement.setAttribute("data-lz",r.id),globalThis.__lz={state:n,view:J,refresh:E,overlay:u,panel:c}}function Ho(s){let r=Date.now()-432e5;return(Array.isArray(s)?s:[]).filter(a=>a&&a.at>r&&a.odd>1)}})();
