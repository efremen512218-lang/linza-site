(()=>{var tt=`/* Цвета, шрифт и радиусы панели — из design/tokens.json (node tools/tokens.mjs). Блоки между метками руками не править. */
:host {
  /* tokens:light */
  --lz-accent: #5b4be6;
  --lz-accent-strong: #4a3bd1;
  --lz-accent-soft: rgba(91, 75, 230, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0b8a4d;
  --lz-pos-soft: rgba(11, 138, 77, 0.14);
  --lz-neg: #c93636;
  --lz-neg-soft: rgba(201, 54, 54, 0.12);
  --lz-warn: #b45309;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6fa;
  --lz-surface-2: #eef0f5;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #555c6b;
  --lz-faint: #666b7f;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  /* /tokens */
  color-scheme: light;
}

:host([data-theme="dark"]) {
  /* tokens:dark */
  --lz-accent: #8f82ff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(143, 130, 255, 0.18);
  --lz-accent-ink: #0f1017;
  --lz-pos: #45d08f;
  --lz-pos-soft: rgba(69, 208, 143, 0.16);
  --lz-neg: #ff7676;
  --lz-neg-soft: rgba(255, 118, 118, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #171a23;
  --lz-surface: #1f2330;
  --lz-surface-2: #272b34;
  --lz-border: #2c3040;
  --lz-text: #eef0f6;
  --lz-muted: #a4a8bb;
  --lz-faint: #8e92a8;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  /* /tokens */
  color-scheme: dark;
}
`;var et=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Длинное имя конторы («Лига Ставок») сокращается многоточием, а не выталкивает кнопки шапки за край. */
.brand {
  min-width: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 72px minmax(60px, max-content);
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  white-space: nowrap;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.partner { margin-top: 8px; }
.partner-text { font-size: 12px; margin-bottom: 4px; }
.partner-links { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
.partner-links a.btn { text-decoration: none; }
.gain { margin-top: 8px; font-size: 12px; color: var(--lz-text); }
.gain b { color: var(--lz-pos); }
td.name .partner-links { margin-top: 3px; }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.card.update { font-size: 12.5px; }
.card.update b { color: var(--lz-accent); }
/* Строка без номера (факторы модели, факты о составах) занимает обе колонки, иначе текст ломается по словам в узкой. */
.facts li > span:only-child { grid-column: 1 / -1; }
.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  margin: 0;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  /* 18+ и предупреждение о зависимости должны читаться: не бледный, а обычный второстепенный цвет. */
  color: var(--lz-muted);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

/* ---- Линза: страница расширения linza.html (боковая панель Chrome, сайдбар Firefox, вкладка) ---- */
.panel.page {
  position: relative;
  top: auto;
  right: auto;
  z-index: auto;
  width: 100%;
  max-width: 760px;
  height: 100vh;
  max-height: none;
  margin: 0 auto;
  border: 0;
  border-radius: 0;
  box-shadow: none;
  animation: none;
}

.panel.page .head {
  cursor: default;
  touch-action: auto;
}

.controls {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.chips {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.chip {
  height: 28px;
  padding: 0 10px;
  border-radius: 8px;
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
  transition: background 0.12s ease, color 0.12s ease;
}

.chip:hover { color: var(--lz-text); }
.chip.on { background: var(--lz-accent-soft); color: var(--lz-accent); }

.mrow {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 10px 12px;
}

.mrow .when {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  color: var(--lz-muted);
  font-size: 11.5px;
  white-space: nowrap;
}

.mrow .when .league {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  text-align: right;
}

.mteams {
  font-size: 13.5px;
  font-weight: 680;
  letter-spacing: -0.005em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.badges {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.sure {
  display: flex;
  align-items: center;
  gap: 5px;
  color: var(--lz-pos);
  font-size: 12px;
  font-weight: 600;
}

.picks {
  display: flex;
  gap: 6px;
}

.pickbtn {
  flex: 1 1 0;
  min-width: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1px;
  padding: 6px 4px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius-sm);
  background: var(--lz-bg);
  transition: border-color 0.12s ease, background 0.12s ease;
}

.pickbtn small {
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--lz-muted);
  font-size: 11px;
}

.pickbtn b { font-size: 14px; font-weight: 700; }
.pickbtn:hover:not([disabled]) { border-color: var(--lz-accent); }
.pickbtn.on { border-color: var(--lz-accent); background: var(--lz-accent-soft); }
.pickbtn.on b { color: var(--lz-accent); }
.pickbtn[disabled] { opacity: 0.5; cursor: default; }

.leg.review {
  row-gap: 3px;
}

.leg.review .why {
  grid-column: 1 / -1;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg.review .why.pos { color: var(--lz-pos); }
.leg.review .why.neg { color: var(--lz-neg); }
.facts.warns li { color: var(--lz-warn); }

/* Верх разбора (src/content/ui/brief.js): «Прогноз Линзы» — с акцентом, «Выбор Линзы» — нейтральная карточка без цвета. */
.badge.warn { background: var(--lz-surface-2); background: color-mix(in srgb, var(--lz-warn) 16%, transparent); color: var(--lz-warn); }
.brief-pick { font-size: 15px; font-weight: 700; letter-spacing: -0.005em; margin-bottom: 4px; }
.brief-head { font-size: 13.5px; font-weight: 650; line-height: 1.35; }
.brief-note { margin-top: 3px; color: var(--lz-muted); font-size: 12px; }
.brief-changed { margin-top: 5px; font-size: 12px; line-height: 1.4; }
.brief-line { margin-top: 5px; font-size: 12.5px; line-height: 1.4; }
.brief-line b { color: var(--lz-muted); font-weight: 650; }
.brief-price { margin-top: 7px; font-size: 12.5px; font-weight: 600; }
.brief-old { margin-top: 3px; color: var(--lz-muted); font-size: 11.5px; }
.brief-foot { margin-top: 8px; color: var(--lz-muted); font-size: 11px; }

/* «Подробный разбор»: всё, кроме верха разбора, — свёрнуто по умолчанию. */
details.more { border-top: 0; margin-top: 0; padding-top: 0; }
details.more > summary {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 34px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-text);
  font-size: 12.5px;
  font-weight: 650;
}
.more-body { display: flex; flex-direction: column; gap: 10px; margin-top: 10px; }

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;function o(t,e,...r){let[n,...l]=t.split("."),s=document.createElement(n||"div");l.length&&(s.className=l.join(" "));for(let[a,c]of Object.entries(e||{}))if(!(c==null||c===!1))if(a==="class")s.className=[s.className,c].filter(Boolean).join(" ");else if(a==="style")s.style.cssText=c;else if(a==="text")s.textContent=c;else{if(a==="html")throw new Error("html запрещён");a.startsWith("data-")||a.startsWith("aria-")||a==="role"||a==="title"||a==="type"||a==="href"||a==="target"||a==="rel"||a==="placeholder"||a==="value"||a==="for"||a==="name"||a==="maxlength"||a==="autocomplete"||a==="spellcheck"||a==="tabindex"?s.setAttribute(a,c===!0?"":String(c)):a==="disabled"||a==="hidden"||a==="checked"||a==="selected"?s[a]=!!c:s[a]=c}return ot(s,r),s}function ot(t,e){for(let r of e)r==null||r===!1||(Array.isArray(r)?ot(t,r):t.appendChild(r instanceof Node?r:document.createTextNode(String(r))))}var rt="http://www.w3.org/2000/svg";function u(t,e=16){let r=document.createElementNS(rt,"svg");r.setAttribute("viewBox","0 0 20 20"),r.setAttribute("width",e),r.setAttribute("height",e),r.setAttribute("fill","none"),r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1.7"),r.setAttribute("stroke-linecap","round"),r.setAttribute("stroke-linejoin","round"),r.setAttribute("aria-hidden","true");for(let n of Rt[t]||[]){let l=document.createElementNS(rt,"path");l.setAttribute("d",n),r.appendChild(l)}return r}var Rt={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"],sidebar:["M4.2 4h11.6A1.7 1.7 0 0 1 17.5 5.7v8.6a1.7 1.7 0 0 1-1.7 1.7H4.2a1.7 1.7 0 0 1-1.7-1.7V5.7A1.7 1.7 0 0 1 4.2 4Z","M12.5 4v12","M14.4 7.2h1.2M14.4 9.6h1.2"]};var nt="Расширение обновилось. Обновите эту вкладку (F5).";function Ot(t){return/signal timed out|timeout|timed out/i.test(t)?"Сервер долго не отвечает — нажмите ещё раз.":/failed to fetch|networkerror|load failed|network request failed/i.test(t)?"Нет связи с сервером Линзы — проверьте интернет.":t}function L(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function T(t,e={}){if(!L())return{ok:!1,error:nt,code:"reload"};try{return await chrome.runtime.sendMessage({type:t,...e})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(r){let n=String(r?.message||r);return/context invalidated/i.test(n)||!L()?{ok:!1,error:nt,code:"reload"}:/message port closed|receiving end does not exist/i.test(n)?{ok:!1,error:"Связь с расширением прервалась — нажмите ещё раз.",code:"retry"}:{ok:!1,error:Ot(n)}}}async function j(t){if(!L())return{};try{return await chrome.storage.local.get(t)}catch{return{}}}function R(t){if(L())try{chrome.storage.local.set(t)}catch{}}var N=t=>typeof t=="string"?t:"",U={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:N("https://linzabet.ru/"),telegram:N("https://t.me/linza_odds"),bot:N("https://t.me/linza_keys_bot?start=ext")},ue=N("https://linzabet.ru"),fe=N("https://185-72-145-3.sslip.io"),Ct={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var Ft={overlay:"picks",theme:"auto",mode:"own",model:Ct.model},Dt=["stake"];function M(t){let e=t&&typeof t=="object"&&!Array.isArray(t)?t:{},r={...Ft,...e};for(let n of Dt)delete r[n];return r}function at(t){let e=(t||[]).filter(l=>l&&l.odd>1&&l.fair>0&&l.fair<1);if(!e.length)return null;let r=e.reduce((l,s)=>l*s.odd,1),n=e.reduce((l,s)=>l*s.fair,1);return{legs:e.length,odd:r,chance:n,fairOdd:1/n,margin:1-r*n}}function x(t){return Number.isFinite(t)?(t>=100?t.toFixed(0):t>=10?t.toFixed(1):t.toFixed(2)).replace(".",","):"—"}function it(t,e=0){if(!Number.isFinite(t))return"—";let r=t*100;return r>0&&r<1&&e===0?"<1%":`${r.toFixed(e).replace(".",",")}%`}var b="lz.express";var v=(t,e)=>`${t}:${e}`,st=t=>t&&Number(t.odd)>1&&Number(t.fair)>0&&Number(t.fair)<1;function w(t,e=Date.now()){return(Array.isArray(t)?t:[]).filter(r=>st(r)&&typeof r.id=="string"&&r.id&&Number(r.at)>e-432e5&&!(Number(r.start)>0&&Number(r.start)<=e))}var lt=(t,e)=>(Array.isArray(t)?t:[]).some(r=>r?.id===e);function dt(t,e){let r=Array.isArray(t)?t:[];if(!st(e)||!e.id)return{legs:r,change:"bad"};if(lt(r,e.id))return{legs:r,change:"same"};let n=e.match?r.filter(l=>l.match!==e.match):r;return n.length>=15?{legs:r,change:"full"}:{legs:[...n,e],change:n.length<r.length?"replaced":"added"}}var O=(t,e)=>(Array.isArray(t)?t:[]).filter(r=>r?.id!==e);function ct(t,e){return lt(t,e?.id)?{legs:O(t,e.id),change:"removed"}:dt(t,e)}var X=t=>(t?.odds||[]).length===3?[t.home,"Ничья",t.away]:[t?.home,t?.away];function Y(t,e,r=Date.now()){return!!t?.id&&!t.live&&Number(t.start)>r&&Number(t.odds?.[e])>1&&Number(t.fair?.[e])>0&&Number(t.fair?.[e])<1}function pt(t,e,r=Date.now()){return Y(t,e,r)?{id:v(t.id,e),match:String(t.id),title:`${t.home} — ${t.away}`,label:X(t)[e]||"",odd:Number(t.odds[e]),fair:Number(t.fair[e]),start:Number(t.start),at:r,sport:t.sport||"",league:t.league||""}:null}function Pt(t,e=Date.now()){let r=Number(t?.odd),n=Number(t?.p);return!t?.id||!(r>1)||!(n>0&&n<1)||Number(t.start)>0&&Number(t.start)<=e?null:{id:v(t.id,t.index>=0?t.index:t.market?.kind||"x"),match:String(t.id),title:`${t.home} — ${t.away}`,label:t.label||"",odd:r,fair:n,start:Number(t.start)||null,at:e,sport:t.sport||"",league:t.league||""}}function ut(t,e,r=Date.now()){let n=Array.isArray(t)?t:[],l=0,s=!1;for(let a of Array.isArray(e)?e:[]){let c=Pt(a,r);if(!c)continue;let d=dt(n,c);if(d.change==="full"){s=!0;break}(d.change==="added"||d.change==="replaced")&&(n=d.legs,l+=1)}return{legs:n,added:l,full:s}}async function ft(t=globalThis.chrome?.storage?.local,e=Date.now()){try{return w((await t.get(b))?.[b],e)}catch{return null}}var W=t=>/^\d{4,12}$/.test(String(t?.match??""))&&String(t?.id||"").startsWith(`${t.match}:`);var H=t=>(Array.isArray(t)?t:[]).map(e=>e.id).join("|");function C(t,{genitive:e=!1}={}){let r=Math.abs(t)%100,n=r%10,l=n===1&&r!==11,s=n>=2&&n<=4&&(r<10||r>=20);return`${t} ${e?l?"конторы":"контор":l?"контора":s?"конторы":"контор"}`}var gt={matches:1915,sport:"football",minBooks:5};function K(t,{sport:e=""}={}){let r=Math.max(0,Number(t?.count)||0),n=t?.fair?.source!=="books",l=!!t&&n&&(Array.isArray(t.betfair)||t.exchange===!0||Array.isArray(t.books)&&t.books.some(p=>/^betfair_ex/.test(p?.key||""))),s=l?r-1:r,a=e===gt.sport&&n&&r>=gt.minBooks,c=s>0?`${C(s)}${l?" и биржа":""}`:l?"биржа":C(0),d=s>0?`${C(s,{genitive:!0})}${l?" и биржи":""}`:l?"биржи":C(0,{genitive:!0});return{who:c,of:d,books:Math.max(0,s),exchange:l,proven:a,note:a?"По проверке на 1 915 матчах футбола такой консенсус точнее любой нашей модели.":""}}var be=[[String.raw`это\s+расч[её]т,?\s+а\s+не\s+совет\s+ставить`,"giu"],[String.raw`ставки\s+не\s+делаются`,"giu"],[String.raw`не\s+зарабатываем\s+на\s+ставках`,"giu"],[String.raw`не\s+обещаем\s+(?:выигрыш|заработок)`,"giu"],[String.raw`не\s+100\s?%`,"giu"]];var m="(?:^|[^а-яёa-z])",V="(?=[^а-яёa-z]|$)",ke=[["верняк",new RegExp(`${m}верняк`,"iu")],["беспроигрыш",/беспроигрыш/iu],["договорной матч",/договорн\S*\s+(матч|игр)/iu],["железная ставка",/железн\S*\s+(ставк|прогноз|экспресс)/iu],["100% проход",/100\s?%\s*(проход|выигрыш|побед|заход)/iu],["сто процентов",/(?<![а-яё])сто\s+процентов/iu],["залетит",/залетит/iu],["выстрелит",/выстрел(ит|ят|ить)/iu],["без добавок конторы",/без\s+добав\S*\s+контор/iu]],$e=[["гарантия",new RegExp(`${m}(гарант\\S*)`,"iu")],["призыв ставить",new RegExp(`${m}(ставьте|ставь|поставьте|поставь)${V}`,"iu")]];var Se=[["вероятнее всего",/вероятнее\s+всего/iu],["скорее всего",/скорее\s+всего/iu],["берём",new RegExp(`${m}(берём|берем)${V}`,"iu")],["заходим",new RegExp(`${m}заходим${V}`,"iu")],["рекомендуем",/рекомендуем/iu],["надёжный",/надёжн|надежн/iu],["сильный или лучший выбор",/(сильн|лучш)\S*\s+выбор/iu],["выбор дня",/выбор\s+дня/iu]];var Ne=[["перевес",new RegExp(`${m}(перевес\\S*)`,"iu")],["выгодно",new RegExp(`${m}(выгодн\\S*)`,"iu")],["цена выше честной",new RegExp(`${m}(цен\\S*\\s+выше\\s+честн\\S*)`,"iu")],["выигрыш больше",new RegExp(`${m}(выигрыш\\S*\\s+больше)`,"iu")],["интересная цена",new RegExp(`${m}(интересн\\S*\\s+цен\\S*)`,"iu")],["расчёта выгоды",new RegExp(`${m}(расч[её]т\\S*\\s+выгод\\S*)`,"iu")]];var xt=t=>`+${(t*100).toFixed(1).replace(".",",")}%`;var D=[["football","Футбол"],["hockey","Хоккей"],["basketball","Баскетбол"],["tennis","Теннис"],["mma","ММА"],["cs","CS"],["dota","Dota 2"]],It=10800*1e3,z=60,ht="18+ · Это расчёт, а не совет ставить. Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость.",g=(t,e=0)=>it(t,e),F=t=>new Date(t).toDateString();function P(t,e=Date.now()){if(!Number.isFinite(Number(t))||!t)return"";let r=new Date(Number(t)),n=r.toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"});return F(t)===F(e)?`Сегодня ${n}`:F(t)===F(e+1440*60*1e3)?`Завтра ${n}`:`${r.toLocaleDateString("ru-RU",{day:"2-digit",month:"2-digit"})} ${n}`}function Bt(t){let e=t?.consensus,r=e?.fair?.p?.length&&e.fair.p.length===e.consensus?.length?e.fair.p:e?.consensus;return Array.isArray(r)&&r.length===(t?.odds||[]).length?r:null}function Gt(t){return t?.level!=="high"?null:o("span.badge.pos",{text:"уверенный прогноз",title:t.headline||"Прогноз Линзы с высокой уверенностью"})}function Zt(t){if(!(Number(t?.count)>=2))return null;let{who:r}=K(t);return o("span.badge.accent",{text:r,title:`Честная цена рынка: ${r}${t.books?.length?` (${t.books.join(", ")})`:""}, маржа убрана`})}function jt(t,{legs:e=[],now:r=Date.now()}={}){let n=X(t),l=new Set(e.map(S=>S.id)),s=t.live||!(Number(t.start)>r),a=Bt(t),c=t.decision?.level==="high"?t.decision:null,d=(t.odds||[]).map((S,k)=>{let E=l.has(v(t.id,k)),Q=Y(t,k,r);return o(`button.pickbtn${E?".on":""}`,{type:"button","data-act":"pick","data-arg":`${t.id}|${k}`,disabled:!Q&&!E,"aria-pressed":E?"true":"false",title:Q?E?"Убрать из экспресса":"Добавить в экспресс":s?"Матч начался: исход не добавить":"У исхода нет цены"},o("small",{text:n[k]||""}),o("b",{text:x(Number(S))}),o("small",{text:Number.isFinite(t.fair?.[k])?g(t.fair[k]):"—"}))}),p=a?o("div.hint",{text:`Рынок без маржи (${K(t.consensus,{sport:t.sport}).who}): ${a.map(S=>g(S)).join(" / ")}`}):t.model?.p1?o("div.hint",{text:`Модель Линзы${t.model.asPrice?"":", справочно"}: ${g(t.model.p1)} / ${g(t.model.p2)}`}):null,h=Zt(t.consensus),y=Gt(t.decision);return o("div.card.mrow",{"data-match":String(t.id)},o("div.when",{},o("span",{text:s?"Матч начался":P(t.start,r)}),o("span.league",{text:t.league||"",title:t.league||""})),o("div.mteams",{text:`${t.home} — ${t.away}`,title:`${t.home} — ${t.away}`}),h||y?o("div.badges",{},h,y):null,c?o("div.sure",{},u("check",13),o("span",{text:c.market?.label?`Прогноз Линзы: ${c.market.label}${Number.isFinite(c.market.p)?` · ${g(c.market.p)}`:""}`:c.headline||"Прогноз Линзы"})):null,o("div.picks",{},d),p)}function mt(t,e="",r=""){return o("div.card",{},o("div.note.warn",{},u("alert"),o("span",{text:t||"Сервер Линзы не ответил."})),e?o("div.row",{style:"margin-top:10px"},o("button.btn.ghost.small",{type:"button","data-act":e,"data-arg":r||null},u("refresh",14),"Повторить")):null)}function Ut(t,e,r="all",n=Date.now()){let l=Array.isArray(t?.matches?.[e])?t.matches[e]:[];return r==="soon"?l.filter(s=>Number(s.start)-n<=It):l}function Xt(t){let{sport:e,filter:r="all",limit:n=z,legs:l=[],now:s=Date.now()}=t,a=t.line||{status:"idle"},c=o("div.controls",{},o("div.chips",{role:"group","aria-label":"Вид спорта"},D.map(([h,y])=>o(`button.chip${h===e?".on":""}`,{type:"button","data-act":"sport","data-arg":h,"aria-pressed":h===e?"true":"false",text:y}))),o("div.seg",{},[["all","Все"],["soon","Скоро"]].map(([h,y])=>o(`button${h===r?".on":""}`,{type:"button","data-act":"filter","data-arg":h,text:y}))));if(!a.data)return a.status==="error"?[c,mt(a.error,"reload")]:[c,o("div.card",{},o("div.hint",{text:"Загружаю линию…"}))];let d=Ut(a.data,e,r,s),p=[c];return a.status==="error"&&p.push(o("div.note.warn",{},u("alert"),o("span",{text:`Не обновилось: ${a.error}`}))),d.length?(p.push(...d.slice(0,n).map(h=>jt(h,{legs:l,now:s}))),d.length>n&&p.push(o("button.btn.ghost.small",{type:"button","data-act":"more",text:`Ещё ${Math.min(z,d.length-n)} · всего ${d.length}`})),p.push(o("div.hint",{text:"Под кэфом — шанс по линии Fonbet без маржи; «N контор» — честная цена рынка. Нажмите на кэф, чтобы добавить исход в экспресс: один исход на матч, только до начала."})),a.data.updated&&p.push(o("div.hint",{text:`Линия на ${new Date(a.data.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"})}.`})),p):(p.push(o("div.empty",{},o("b",{text:"Матчей с ценами нет"}),r==="soon"?"В ближайшие 3 часа матчей с ценами нет.":"В ближайшие 36 часов матчей с ценами по этому виду нет. Загляните позже.")),p)}function Yt(t,{now:e=Date.now()}={}){return o("div.card",{},o("div.kicker",{},o("span",{text:`Экспресс · ${t.length}`}),o("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},u("trash",13),"Очистить")),t.map(r=>o("div.leg",{"data-leg":r.id},o("div.t",{},o("b",{text:r.label,title:r.label}),o("span",{text:[r.title,r.start?P(r.start,e):""].filter(Boolean).join(" · "),title:r.title})),o("span.o",{text:x(r.odd)}),o("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":r.id,title:"Убрать","aria-label":"Убрать исход",style:"width:24px;height:24px"},u("close",13)))))}function Wt(t){return t?o("div.card.soft",{},o("dl.kv",{},o("dt",{text:"Итоговый коэффициент"}),o("dd",{text:x(t.odd)}),o("dt",{text:"Шанс, что сыграют все исходы (без маржи)"}),o("dd",{text:g(t.chance,1)}),o("dt",{text:"Кэф без маржи"}),o("dd",{text:x(t.fairOdd)}),o("dt",{text:"Маржа конторы на всём экспрессе"}),o(`dd${t.margin>0?".neg":""}`,{text:g(t.margin,1)})),o("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Один исход на матч: другой исход того же матча заменяет прежний."})):null}var Ht={ok:["в линии","pos"],started:["матч начался","neg"],live:["матч начался","neg"],gone:["пропал из линии","neg"],missing:["пропал из линии","neg"]};function Kt(t,e,r){if(!e)return o("div.leg.review",{},o("div.t",{},o("b",{text:t.label}),o("span",{text:t.title})),o("span.badge",{text:"не проверяется"}),o("div.why",{text:W(t)?"Сервер не вернул этот исход.":"Исход со страницы конторы: сервер проверяет только исходы из «Линии» и «Уверенного экспресса»."}));let[n,l]=Ht[e.status]||[String(e.status||"нет данных"),""],s=Number(e.odd),a=Number.isFinite(Number(e.oddWas))&&Number(e.oddWas)>1?Number(e.oddWas):Number(t.odd),c=Number.isFinite(s)&&s>1&&Math.abs(s-a)>=.005,d=[];c&&d.push(o(`div.why${s>a?".pos":".neg"}`,{text:`Кэф ${x(a)} → ${x(s)}`})),Number.isFinite(Number(e.p))&&d.push(o("div.why",{text:`Честный шанс ${g(Number(e.p),0)}${e.source?` · ${e.source}`:e.consensus?" · рынок без маржи":" · Fonbet без маржи"}`}));let p=e.decision;return p?.level==="high"&&p.agree===!1?d.push(o("div.why.neg",{text:`Прогноз Линзы — за другой исход${p.headline?`: ${p.headline}`:""}`})):p?.level==="high"&&p.agree&&d.push(o("div.why.pos",{text:"Совпадает с уверенным прогнозом Линзы"})),e.suspicious?d.push(o("div.why.neg",{text:"Расхождение с честной ценой больше 12% — чаще это ошибка данных: проверьте матч."})):Number(e.edge)>=.03&&d.push(o("div.why",{text:`Расхождение с честной ценой ${xt(Number(e.edge))} — это не доход`})),o("div.leg.review",{},o("div.t",{},o("b",{text:e.label||t.label}),o("span",{text:[t.title,e.start?P(e.start,r):""].filter(Boolean).join(" · ")})),o("span.o",{text:Number.isFinite(s)&&s>1?x(s):"—"}),o(`span.badge${l?`.${l}`:""}`,{text:n}),d)}function Vt(t,e,{now:r=Date.now()}={}){if(!t||t.status==="idle")return null;if(t.status==="loading")return o("div.card",{},o("div.kicker",{},o("span",{text:"Анализ экспресса"}),o("span.badge.accent",{text:"проверяю"})),o("div.hint",{text:"Сверяю цены, честные шансы и прогнозы Линзы…"}));if(t.status==="error")return t.code==="not-ready"?o("div.card.soft",{},o("div.note",{},u("info"),o("span",{text:t.error}))):mt(t.error,t.code==="empty"?"":"review");let n=t.data||{},l=new Map((Array.isArray(n.legs)?n.legs:[]).map(d=>[String(d.match??""),d])),s=n.stats,a=Array.isArray(n.warnings)?n.warnings.filter(Boolean):[],c=Number(n.updated)||t.at;return o("div.card",{},o("div.kicker",{},o("span",{text:"Анализ экспресса"}),c?o("span.badge",{text:`на ${new Date(c).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"})}`}):null),e.map(d=>Kt(d,l.get(String(d.match)),r)),s&&Number.isFinite(Number(s.odd))?o("dl.kv",{style:"margin-top:8px"},o("dt",{text:"Кэф сейчас"}),o("dd",{text:x(Number(s.odd))}),Number.isFinite(Number(s.chance))?[o("dt",{text:"Шанс, что сыграют все исходы (честный)"}),o("dd",{text:g(Number(s.chance),1)})]:null,Number.isFinite(Number(s.margin))?[o("dt",{text:"Маржа конторы на всём"}),o(`dd${Number(s.margin)>0?".neg":""}`,{text:g(Number(s.margin),1)})]:null):null,a.length?o("ul.facts.warns",{},a.map(d=>o("li",{},u("alert",13),o("span",{text:String(d)})))):null,o("div.hint",{style:"margin-top:8px",text:"Это расчёт, а не совет ставить: шанс «сыграют все исходы» — произведение честных шансов, исходы считаются независимыми."}))}function qt(t,{now:e=Date.now()}={}){let r=t||{status:"idle"},n=(d,p="")=>o("div.kicker",{},o("span",{text:r.data?.legs?.length?`Уверенный экспресс · ${r.data.legs.length}`:"Уверенный экспресс"}),d?o(`span.badge${p}`,{text:d}):null),l=r.mode==="odds"?"safe":"odds",s=d=>o("div.row",{style:"margin-top:8px"},d,o("button.btn.ghost.small",{type:"button","data-act":"build","data-arg":l},l==="safe"?"Выше шанс":"Выше кэф"));if(r.status==="loading")return o("div.card",{},n("собираю",".accent"),o("div.hint",{text:"Ищу уверенные прогнозы с ценой на ближайшие 36 часов — это до полминуты…"}));if(r.status==="error")return o("div.card",{},n(),o("div.note.warn",{},u("alert"),o("span",{text:r.error})),o("div.row",{style:"margin-top:8px"},o("button.btn.ghost.small",{type:"button","data-act":"build","data-arg":r.mode||"safe"},u("refresh",14),"Ещё раз")));if(r.status!=="done")return o("div.card",{},n("расчёт"),o("div.hint",{text:"Линза соберёт экспресс из уверенных прогнозов (честный шанс от 70%) с ценой Fonbet на ближайшие 36 часов и покажет честный шанс, что сыграют все исходы."}),s(o("button.btn.small",{type:"button","data-act":"build","data-arg":"safe"},"Выше шанс")));let a=Array.isArray(r.data?.legs)?r.data.legs:[];if(!a.length)return o("div.card",{},n(),o("div.hint",{text:"Сейчас уверенных исходов с ценой на ближайшие 36 часов нет — честнее не собирать, чем собрать из монеток."}),s(o("button.btn.small",{type:"button","data-act":"build","data-arg":r.mode||"safe"},"Проверить ещё раз")));let c=r.data.stats;return o("div.card.accent",{},n(c&&Number.isFinite(c.chance)?`шанс ${g(c.chance)}`:"",".pos"),a.map(d=>o("div.leg",{},o("div.t",{},o("b",{text:d.label,title:d.label}),o("span",{text:[`${d.home} — ${d.away}`,P(d.start,e),Number.isFinite(d.p)?g(d.p):"",d.consensus?"":"цена Fonbet"].filter(Boolean).join(" · ")})),o("span.o",{text:x(Number(d.odd))}))),c?o("dl.kv",{style:"margin-top:8px"},o("dt",{text:"Итоговый коэффициент Fonbet"}),o("dd",{text:x(c.odd)}),o("dt",{text:"Честный кэф (без маржи)"}),o("dd",{text:x(c.fairOdd)}),o("dt",{text:"Маржа конторы на всём"}),o("dd",{text:g(c.margin,1)})):null,(r.data.warnings||[]).length?o("ul.facts.warns",{},r.data.warnings.map(d=>o("li",{},u("alert",13),o("span",{text:String(d)})))):null,s(o("button.btn.small",{type:"button","data-act":"build-add"},u("plus",14),"Добавить все")),r.data.note?o("div.hint",{style:"margin-top:6px",text:r.data.note}):null)}function Jt(t){let{legs:e=[],stats:r=null,builder:n,review:l,now:s=Date.now()}=t,a=[];if(!e.length)a.push(o("div.empty",{},o("b",{text:"Экспресс пуст"}),"Выберите исходы во вкладке «Линия» или нажмите на коэффициент на сайте конторы. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе."));else{a.push(Yt(e,{now:s}),Wt(r));let c=e.some(W),d=l?.status==="loading";a.push(o("div.row",{},o("button.btn",{type:"button","data-act":"review",disabled:!c||d},u("spark"),d?"Проверяю…":"Анализ экспресса"))),c||a.push(o("div.hint.center-text",{text:"Анализ работает для исходов из «Линии» и «Уверенного экспресса»."}));let p=Vt(l,e,{now:s});p&&a.push(p)}return a.push(qt(n,{now:s})),a.filter(Boolean)}function bt(t){let e=(t.legs||[]).length;return[["line","Линия"],["express","Экспресс"]].map(([r,n])=>o(`button.tab${t.tab===r?".on":""}`,{type:"button",role:"tab","aria-selected":t.tab===r?"true":"false","data-act":"tab","data-arg":r},n,r==="express"&&e?o("span.count",{text:String(e)}):null))}function vt(t){return t.tab==="express"?Jt(t):Xt(t)}var J="lz.linza",Qt=120*1e3,te=5e3,i={tab:"line",sport:"football",filter:"all",limit:z,line:{},legs:[],builder:{status:"idle",data:null,error:"",mode:"safe"},review:{status:"idle",data:null,error:"",code:"",sig:"",at:0},settings:M(null),theme:"light"},Z=o("div",{id:"lz-linza"});Z.style.cssText="display:block;height:100vh;";var A=Z.attachShadow({mode:"open"});A.appendChild(o("style",{text:tt+et}));var Mt=o("div.tabs",{role:"tablist"}),I=o("div.body"),At=o("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),_t=o("button.iconbtn",{type:"button","data-act":"reload",title:"Обновить линию","aria-label":"Обновить линию"},u("refresh")),ee=o("div.head",{},o("div.brand",{},o("span.logo",{},u("lens",15)),o("span",{text:U.name}),o("small",{text:"линия и экспресс"})),o("span.grow"),_t,At);A.append(o("section.panel.page",{"aria-label":U.name},ee,Mt,I,o("div.foot",{},o("span",{text:ht}))));function re(t=Date.now()){let e=w(i.legs,t),r=i.review.sig&&i.review.sig!==H(e)?{status:"idle"}:i.review;return{tab:i.tab,sport:i.sport,filter:i.filter,limit:i.limit,line:i.line[i.sport]||{status:"idle"},legs:e,stats:at(e),builder:i.builder,review:r,now:t}}var wt="",zt="";function f(){let t=re(),e=JSON.stringify({...t,now:Math.floor(t.now/6e4),theme:i.theme});if(e===wt)return;wt=e;let r=`${i.tab}|${i.sport}|${i.filter}`,n=r===zt?I.scrollTop:0;zt=r,Z.setAttribute("data-theme",i.theme),At.replaceChildren(u(i.theme==="dark"?"sun":"moon")),_t.hidden=i.tab!=="line",Mt.replaceChildren(...bt(t)),I.replaceChildren(...vt(t)),I.scrollTop=n}var yt=0;function _(t){A.querySelector(".toast")?.remove();let e=o("div.toast",{text:t,role:"status"});A.appendChild(e),clearTimeout(yt),yt=setTimeout(()=>e.remove(),2600)}var Et=globalThis.matchMedia?globalThis.matchMedia("(prefers-color-scheme: dark)"):null;function G(){let t=i.settings.theme;i.theme=t==="dark"||t==="light"?t:Et?.matches?"dark":"light",document.documentElement.setAttribute("data-theme",i.theme),f()}Et?.addEventListener?.("change",G);async function $(t=!1){let e=i.sport,r=i.line[e]||{status:"idle",data:null,error:"",at:0};if(r.status==="loading"||!t&&r.data&&Date.now()-r.at<Qt)return;i.line[e]={...r,status:"loading"},f();let n=await T("lz:today",{sport:e,force:t});i.line[e]=n.ok&&n.data?{status:"done",data:n.data,error:"",at:Date.now()}:{...r,status:"error",error:n.error||"Сервер Линзы не ответил."},f()}var kt=Promise.resolve();function B(t){let e=kt.then(async()=>{let r=Date.now(),n=await ft(void 0,r)??w(i.legs,r),l=t(n,r);return l.legs!==n&&R({[b]:l.legs}),i.legs=l.legs,f(),l});return kt=e.catch(()=>{}),e}var $t={added:"Добавлено в экспресс",replaced:"Исход этого матча заменён",removed:"Убрано из экспресса",full:`В экспрессе не больше ${15} исходов`,bad:"Исход не добавить: матч начался или нет цены"};async function oe(t){let[e,r]=String(t).split("|"),n=Number(r),l=(i.line[i.sport]?.data?.matches?.[i.sport]||[]).find(a=>String(a.id)===e);if(!l||!Number.isInteger(n))return;let s=await B((a,c)=>{let d=pt(l,n,c);return d?ct(a,d):a.some(p=>p.id===v(l.id,n))?{legs:O(a,v(l.id,n)),change:"removed"}:{legs:a,change:"bad"}});$t[s.change]&&_($t[s.change])}async function ne(t){if(i.builder.status==="loading")return;i.builder={...i.builder,status:"loading",error:"",mode:t==="odds"?"odds":"safe"},f();let e=await T("lz:build",{n:3,mode:i.builder.mode,sport:""});i.builder=e.ok&&e.data?{status:"done",data:e.data,error:"",mode:i.builder.mode}:{status:"error",data:null,error:e.error||"Сервер Линзы не ответил.",mode:i.builder.mode},f()}var St=0;async function ae(){if(i.review.status==="loading")return;let t=te-(Date.now()-St);if(t>0)return _(`Анализ можно повторить через ${Math.ceil(t/1e3)} с`);St=Date.now();let e=w(i.legs),r=H(e);i.review={status:"loading",data:null,error:"",code:"",sig:r,at:0},f();let n=await T("lz:express-review",{legs:e});i.review=n.ok&&n.data?{status:"done",data:n.data,error:"",code:"",sig:r,at:Date.now()}:{status:"error",data:null,error:n.error||"Сервер Линзы не ответил.",code:n.code||"",sig:r,at:Date.now()},f()}function q(){R({[J]:{tab:i.tab,sport:i.sport,filter:i.filter}})}var ie={tab(t){i.tab=t==="express"?"express":"line",q(),i.tab==="line"&&$(),f()},sport(t){D.some(([e])=>e===t)&&(i.sport=t,i.limit=z,q(),$(),f())},filter(t){i.filter=t==="soon"?"soon":"all",i.limit=z,q(),f()},more(){i.limit+=z,f()},reload(){$(!0)},pick:oe,"leg-remove"(t){B(e=>({legs:O(e,t)}))},"leg-clear"(){B(()=>({legs:[]})).then(()=>_("Экспресс очищен"))},build:ne,async"build-add"(){let t=i.builder.data?.legs||[],e=await B((r,n)=>ut(r,t,n));_(e.full?`Добавлено ${e.added}: в экспрессе не больше ${15} исходов`:e.added?`Добавлено в экспресс: ${e.added}`:"Эти исходы уже в экспрессе")},review:ae,async theme(){let t=(await j(["lz.settings"]))["lz.settings"]||{};i.settings={...M(t),theme:i.theme==="dark"?"light":"dark"},R({"lz.settings":i.settings}),G()}};A.addEventListener("click",t=>{let e=t.target instanceof Element?t.target.closest("[data-act]"):null;if(!e||e.disabled)return;let r=ie[e.dataset.act];r&&(t.preventDefault(),Promise.resolve(r(e.dataset.arg||"")).catch(n=>_(String(n?.message||n))))});async function se(){let t=await j(["lz.settings",b,J]);i.settings=M(t["lz.settings"]),i.legs=w(t[b]);let e=t[J]||{};e.tab==="express"&&(i.tab="express"),D.some(([r])=>r===e.sport)&&(i.sport=e.sport),e.filter==="soon"&&(i.filter="soon"),document.getElementById("boot")?.remove(),document.body.appendChild(Z),G(),i.tab==="line"&&$();try{chrome.storage.onChanged.addListener((r,n)=>{n&&n!=="local"||(r[b]&&(i.legs=w(r[b].newValue),f()),r["lz.settings"]&&(i.settings=M(r["lz.settings"].newValue),G()))})}catch{}document.addEventListener("visibilitychange",()=>{document.hidden||(i.tab==="line"&&$(),f())}),setInterval(()=>{document.hidden||(i.tab==="line"&&$(),f())},3e4)}se();})();
