(()=>{var wt=e=>typeof e=="string"?e:"",Ht={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:wt("https://linzabet.ru/"),telegram:wt("https://t.me/linza_odds"),bot:wt("https://t.me/linza_keys_bot?start=ext")},oi=wt("https://linzabet.ru"),ri=wt("https://185-72-145-3.sslip.io"),Yr={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var Jr=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function co(e){let t=String(e||"").toLowerCase();return Jr.find(o=>o.hosts.some(i=>t===i||t.endsWith(`.${i}`)))||null}var Qr={overlay:"picks",theme:"auto",mode:"own",model:Yr.model},yn=["stake"];function Ut(e){let t=e&&typeof e=="object"&&!Array.isArray(e)?e:{},o={...Qr,...t};for(let i of yn)delete o[i];return o}var uo={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",mma:"ММА",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function je(e){let t=String(e??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(t))return null;let o=parseFloat(t.replace(",","."));return o>=1.001&&o<=1e3?o:null}var po=e=>e.reduce((t,o)=>t+1/o,0),fo="power";function vn(e,{method:t=fo}={}){let o=(e||[]).map(l=>1/Number(l));if(!o.length||!o.every(l=>Number.isFinite(l)&&l>0&&l<1))return null;let i=o.reduce((l,c)=>l+c,0);if(t==="proportional"||i<=1)return o.map(l=>l/i);let n=(l,c,u)=>{for(let d=0;d<60;d+=1){let m=(c+u)/2;l(m).reduce((x,h)=>x+h,0)>1?c=m:u=m}return l((c+u)/2)};return t==="shin"?n(l=>o.map(c=>(Math.sqrt(l*l+4*(1-l)*c*c/i)-l)/(2*(1-l))),0,.5):n(l=>o.map(c=>Math.pow(c,l)),1,4)}function De(e,{method:t=fo}={}){let o=(e||[]).filter(n=>Number.isFinite(n)&&n>1);if(o.length<2||o.length!==(e||[]).length)return{kind:"partial",margin:null,fair:null};let i=po(o);if(i>=.985&&i<=1.3)return{kind:"full",margin:i-1,fair:vn(o,{method:t})};if(o.length===3&&i>=1.97&&i<=2.4){let n=i/2;return{kind:"double",margin:n-1,fair:o.map(l=>Math.min(.995,1/l/n))}}return{kind:"partial",margin:null,fair:null}}function mo(e){let t=(e||[]).map(d=>d||[]).filter(d=>d.length),o=t.flat().filter(Boolean);if(o.length<2)return{sets:[],rest:o};let i=d=>d.length>=2&&d.every(Boolean)&&De(d.map(m=>m.odd)).kind!=="partial",n=d=>{let m=d.filter(b=>b.some(Boolean));if(!m.length)return null;let x=m.filter(i);if(x.length/m.length<.6)return null;let h=new Set(x.flat());return{sets:x,rest:o.filter(b=>!h.has(b))}},l=d=>{let m=[];for(let x=0;x<t.length;x+=d)m.push(t.slice(x,x+d).flat());return m},c=()=>{let d=[];for(let m=0;m+1<t.length;m+=2){let x=Math.max(t[m].length,t[m+1].length);for(let h=0;h<x;h+=1)d.push([t[m][h]??null,t[m+1][h]??null])}return d},u=[()=>l(1)];t.length>=2&&t.length%2===0&&u.push(c,()=>l(2)),t.length>=3&&t.length%3===0&&u.push(()=>l(3)),t.length>1&&u.push(()=>[t.flat()]);for(let d of u){let m=n(d());if(m)return m}return{sets:[],rest:o}}function ho(e,t=1.13){let o=u=>{let d=po(u.map(m=>m.odd));return d>=.995&&d<=t?!0:u.length===3&&d>=1.99&&d<=t*2},i=u=>Math.abs(u*4-Math.round(u*4))<1e-9,n=[],l=[],c=0;for(;c<e.length;){let u=e.slice(c,c+3),d=e.slice(c,c+2);u.length===3&&o(u)?(n.push(u),c+=3):d.length===2&&o(d)?(n.push(d),c+=2):e[c+2]&&i(e[c+1].odd)&&o([e[c],e[c+2]])?(n.push([e[c],e[c+2]]),l.push(e[c+1]),c+=3):(l.push(e[c]),c+=1)}return{sets:n,rest:l}}function go(e){let t=(e||[]).filter(n=>n&&n.odd>1&&n.fair>0&&n.fair<1);if(!t.length)return null;let o=t.reduce((n,l)=>n*l.odd,1),i=t.reduce((n,l)=>n*l.fair,1);return{legs:t.length,odd:o,chance:i,fairOdd:1/i,margin:1-o*i}}function bo(e,t){return e*t-1}function J(e){return Number.isFinite(e)?(e>=100?e.toFixed(0):e>=10?e.toFixed(1):e.toFixed(2)).replace(".",","):"—"}function ve(e,t=0){if(!Number.isFinite(e))return"—";let o=e*100;return o>0&&o<1&&t===0?"<1%":`${o.toFixed(t).replace(".",",")}%`}function rt(e){return String(e??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zа-я0-9]/g,"")}var es=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function xo(e){return String(e??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[\u0300-\u036f]/g,"").split(/[^a-zа-я0-9]+/).filter(t=>t.length>=2&&!es.has(t))}var Mn=new Map([["bbteam","BetBoom Team"],["pvision","PARIVISION"],["lfo10","Sökerorg"]].map(([e,t])=>[e,{name:t,folded:rt(t)}]));function yt(e,t){let o=rt(e),i=rt(t),n=Mn.get(o),l=Mn.get(i);if(n&&(e=n.name,o=n.folded),l&&(t=l.name,i=l.folded),o.length<2||i.length<2)return 0;if(o===i)return 1;let c=o.length<=i.length?o:i,u=c===o?i:o;if(c.length>=4&&u.includes(c))return .85;let d=xo(e),m=xo(t),x=b=>String(b??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[̀-ͯ]/g,"").match(/^\s*([a-zа-я-]{3,})\s+([a-zа-я])\.?\s*$/);for(let[b,$]of[[e,m],[t,d]]){let y=x(b);if(y&&$.length>=2&&$.includes(y[1])&&$.some(v=>v!==y[1]&&v[0]===y[2]))return .8}if(d.length&&m.length){let $=d.filter(y=>m.some(v=>v===y||y.length>=5&&v.startsWith(y.slice(0,5)))).length/Math.max(d.length,m.length);if($>=.5)return .6+.3*$}let h=0;for(;h<o.length&&h<i.length&&o[h]===i[h];)h+=1;return h>=5?Math.min(.8,.45+h*.04):0}function ts(e){let t=String(e??"").toLowerCase(),o=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(t)&&o.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(t)&&o.push("women"),/\(рез|\(р\)|резерв|reserve/.test(t)&&o.push("reserve"),/люб/.test(t)&&o.push("amateur"),/кибер|\(e-?sports?\)|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(t)&&o.push("cyber"),o.join("+")}function Ke(e,t){let o=l=>{let c=rt(l),u=Mn.get(c)?.folded??c,d=ts(l);return u.length<2?"":d?`${u}~${d}`:u},i=o(e),n=o(t);return!i||!n?"":[i,n].sort().join("|")}var ns=[["Бавария","Бавария Мюнхен","Bayern","Bayern Munich","Bayern München","FC Bayern"],["ПСЖ","Пари Сен-Жермен","PSG","Paris Saint Germain","Paris Saint-Germain","Paris SG"],["Интер","Интер Милан","Inter","Inter Milan","Internazionale"],["Милан","AC Milan","Milan"],["Манчестер Юнайтед","Ман Юнайтед","Manchester United","Manchester Utd","Man United","Man Utd"],["Манчестер Сити","Ман Сити","Manchester City","Man City"],["Тоттенхэм","Тоттенхэм Хотспур","Tottenham","Tottenham Hotspur","Spurs"],["Вулверхэмптон","Вулверхэмптон Уондерерс","Wolverhampton","Wolverhampton Wanderers","Wolves"],["Брайтон","Brighton","Brighton and Hove Albion","Brighton & Hove Albion"],["Боруссия Д","Боруссия Дортмунд","Borussia Dortmund","Dortmund","BVB"],["Боруссия М","Боруссия Менхенгладбах","Borussia Monchengladbach","Borussia Mönchengladbach","Borussia M'gladbach","Gladbach"],["Байер","Байер Леверкузен","Bayer Leverkusen","Leverkusen","Bayer 04 Leverkusen"],["Айнтрахт Ф","Айнтрахт Франкфурт","Eintracht Frankfurt","Frankfurt"],["Гамбург","Hamburger SV","Hamburg","HSV"],["Кёльн","Кельн","FC Koln","FC Köln","Koln","Köln","FC Cologne","1. FC Köln"],["Герта","Hertha","Hertha BSC","Hertha Berlin"],["Реал Мадрид","Real Madrid"],["Реал Сосьедад","Real Sociedad"],["Бетис","Реал Бетис","Real Betis","Betis"],["Атлетико","Атлетико Мадрид","Atletico Madrid","Atlético Madrid"],["Атлетик","Атлетик Бильбао","Athletic Bilbao","Athletic Club"],["Вильярреал","Villarreal"],["Хетафе","Getafe"],["Жирона","Хирона","Girona"],["Сельта","Celta Vigo","Celta"],["Селтик","Celtic"],["Брюгге","Club Brugge","Brugge","Club Bruges"],["Спортинг","Спортинг Лиссабон","Sporting CP","Sporting Lisbon"],["Црвена Звезда","Crvena Zvezda","KK Crvena zvezda","FK Crvena zvezda","Red Star Belgrade"],["ПСВ","PSV","PSV Eindhoven"],["Лидс","Лидс Юнайтед","Leeds","Leeds United"],["Борнмут","Bournemouth","AFC Bournemouth"],["Фулхэм","Fulham"],["Дженоа","Genoa"],["Марсель","Olympique Marseille","Olympique de Marseille","Marseille"],["Ницца","Nice","OGC Nice"],["Ланс","Lens","RC Lens"],["Анже","Angers","Angers SCO"],["Лорьян","Lorient","FC Lorient"],["Гавр","Le Havre","Le Havre AC"],["Осер","Auxerre","AJ Auxerre"]],os=new Map;for(let e of ns){let t=rt(e[0]);for(let o of e)os.set(rt(o),t)}var V=e=>(e?.textContent||"").replace(/[ \s]+/g," ").trim(),Sn=e=>e.offsetParent===null&&e.tagName!=="BODY";function rs(e){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(e||"").trim())}function ss(e){let t=String(e||"").match(/(\d+)\s*[-‑–]?\s*(?:го|й|м|ой|ий|я|ая|ья|ый)?\s+(период|тайм|сет|четверт|половин|карт|гейм|иннинг)/i);return t?t[0]:""}function vt(e,t){let o=String(e||"").toLowerCase();return/двойной шанс/.test(o)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(o)?"other":/фор[аы]|гандикап/.test(o)?"handicap":/тотал/.test(o)?"total":/обе забьют/.test(o)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(o)?t===3?"1x2":t===2?"12":"other":"other"}var as=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/(^|[^а-яёa-z])(мма|mma|ufc|юфс)([^а-яёa-z]|$)|смешанн|единоборств|mixed martial|бои без правил/i,"mma"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function st(...e){let t=e.filter(Boolean).join(" ");for(let[o,i]of as)if(o.test(t))return i;return""}function zn(e){if(!e)return null;let t=je(V(e));if(t)return t;let o=V(e).split(" ");return je(o[o.length-1])}var is=0;function We({scope:e,title:t,period:o="",line:i="",kind:n,outcomes:l,event:c=null,anchor:u=null,eventKey:d=""}){let m=l.length;return{id:`${e}|${d}|${t}|${o}|${i}|${l.map(x=>x.label).join("/")}`,serial:is+=1,scope:e,title:t,period:o,line:i,kind:n||vt(t,m),main:rs(o)&&!ss(t),outcomes:l,event:c,anchor:u||l[0]?.el||null}}var ne=(e,t)=>[...e.querySelectorAll(t)];function vo(e){return(String(e||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function Nn(e){return e.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":e.querySelector(".card")?"list":"other"}var $o={win:"В",loose:"П",lose:"П",draw:"Н"};function ko(e){return ne(e,".competitor-form__value").map(t=>$o[[...t.classList].find(o=>$o[o])]||V(t).slice(0,1)).filter(Boolean).join("")}function ls(e){let t=e.querySelector(".marketbook-header--live");if(t){let i=ne(t,".game-scoring__item").map(c=>V(c)),n=ne(t,".game-periods .period").map(c=>{let u=ne(c,"span");return{label:V(c.querySelector("i")),home:V(u[0]),away:V(u[1])}}).filter(c=>c.home!==""&&c.away!==""),l=ne(t,".game-specials > div").map(c=>{let u=ne(c,"span"),d=c.querySelector("i"),m=d?.classList.contains("yellow-card")?"жёлтые":d?.classList.contains("red-card")?"красные":d?.classList.contains("penalty-card")?"угловые":"";return m?{kind:m,home:V(u[0]),away:V(u[1])}:null}).filter(Boolean);return{state:V(t.querySelector(".game-timing-state")),score:i.length===2?i:[],periods:n,extras:l}}let o=e.querySelector(".match-card");if(o&&!o.querySelector(".match-card__timer--prematch")){let i=V(o.querySelector(".match-card__main-score")).replace(/\s/g,""),n=ne(o,".match-card__score").map(c=>V(c)).filter(c=>/^\d{1,2}$/.test(c)),l=ne(e,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(c=>V(c)).filter(c=>/\d\s*:\s*\d/.test(c)).slice(0,5);return{state:V(o.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(i)?i.split(":"):[],rounds:n.length>=2?n.slice(0,2):[],periods:l.map((c,u)=>({label:`${u+1} карта`,raw:c})),extras:[]}}return null}function wo(e,t){if(Nn(e)!=="match")return null;let o=ne(e,".breadcrumbs .breadcrumbs__item").map(m=>V(m)).filter(Boolean),i=V(e.querySelector(".event-breadcrumbs")),n=ne(e,".marketbook-header--prematch .competitor-name").map(m=>V(m));if(n.length<2&&(n=ne(e,".marketbook-header--live .competitors-desc__name").map(m=>V(m))),n.length<2&&(n=ne(e,".match-card .match-card__team-name").map(m=>V(m))),n.length<2||!n[0]||!n[1])return null;let l=st(o[1]&&/киберспорт/i.test(o[0])?o[1]:"",o[0],i),c=/киберспорт/i.test(o[0]||"")?o.slice(2).join(", ")||i.split(",").slice(1).join(",").trim():o.slice(1).join(", "),u=[V(e.querySelector(".prematch-date")),V(e.querySelector(".prematch-time"))].filter(Boolean).join(" ")||V(e.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),d=ls(e);return{book:"Winline",id:vo(t?.pathname),key:Ke(n[0],n[1]),home:n[0],away:n[1],sport:l,league:c,start:d?"":u,live:d,form:{home:ko(e.querySelector(".competitor-form--left")||e.createElement("div")),away:ko(e.querySelector(".competitor-form--right")||e.createElement("div"))},stats:ms(hs(e),n[0],n[1]),url:t?.href||""}}function cs(e,t){let o=[];for(let i of ne(e,".bet-line")){if(Sn(i))continue;let n=V(i.querySelector(".bet-line__market-name")),l=V(i.querySelector(".bet-line__period")),c=ne(i,".odd-btn"),u=c.map((m,x)=>{let h=V(m.querySelector(".odd-btn__label")),b=ne(m,"span").map($=>je(V($))).find(Boolean)||null;return b?{el:m,odd:b,label:h||_n(c.length,x,n),locked:!1}:null});if(u.length<2||u.some(m=>!m))continue;let d=V(i.querySelector(".coef-btn")).replace(/\s+/g," ");o.push(We({scope:"top",title:n,period:l,line:d,outcomes:u,anchor:i,eventKey:t}))}return o}function _n(e,t,o){return/тотал/i.test(o)?["Меньше","Больше"][t]||"":e===3?["П1","Х","П2"][t]:e===2?["1","2"][t]:String(t+1)}function us(e,t){let o=[];for(let i of ne(e,".market")){let n=ne(i,".market__row");if(!n.length)continue;let l=V(i.querySelector(".market-title")),c=n.map(d=>{let m=V(d.querySelector(".market__row-text"));return ne(d,".market-row-btn").map(x=>{let h=je(V(x.querySelector(".market-row-btn__coef")));if(!h||x.hasAttribute("disabled"))return null;let b=x.getAttribute("title")||V(x.querySelector(".market-row-btn__text"));return{el:x,odd:h,label:b.replace(/\s+/g," ").trim(),rowLabel:m,locked:!1}})}),{sets:u}=mo(c);for(let d of u){let m=[...new Set(d.map($=>$.rowLabel).filter(Boolean))],x=m.length<=1,h=x?"":(d[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],b=d.map($=>({el:$.el,odd:$.odd,label:x?$.label:$.rowLabel||$.label,locked:!1}));o.push(We({scope:"board",title:l,period:x&&m[0]||"",line:h,kind:vt(l,b.length),outcomes:b,anchor:i,eventKey:t}))}}return o}var ps=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function ds(e){let t=ne(e,".card__competitors .name .name, .half__names .name").map(i=>V(i));if(t.length<2)return null;let o=e.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:vo(o),key:Ke(t[0],t[1]),home:t[0],away:t[1],href:o,live:/card--live/.test(e.className)||!!e.querySelector(".card__body-live"),time:V(e.querySelector(".header-left__time, .footer__time")),league:V(e.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:e}}function yo(e){let t=[];for(let o of ne(e,".card")){if(Sn(o))continue;let i=ds(o);if(i){for(let n of ne(o,".card__body")){let l=V(n.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(n.className)?"отрезок":"");for(let c of ne(n,".card__market")){let u=ne(c,".coefficient-button");if(u.length<2)continue;let d=(ps.find(([x])=>x.test(u[0].className))||[])[1]||"other",m=u.map((x,h)=>{let b=/--is-blank/.test(x.className)?null:zn(x);return b?{el:x,odd:b,label:d==="total"?["Меньше","Больше"][h]:_n(u.length,h,""),locked:/coefficient-button_locked/.test(x.className)}:null});m.some(x=>!x)||t.push(We({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[d]||"Рынок",period:/^матч$/i.test(l)?"":l,line:V(c.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:d,outcomes:m,event:i,anchor:o,eventKey:i.key}))}}for(let n of ne(o,".half__coef-buttons")){let l=ne(n,".coef-buttons__button"),c=l.map((u,d)=>{let m=zn(u.querySelector(".button__coef-title")||u);return m?{el:u,odd:m,label:_n(l.length,d,""),locked:!1}:null});c.length<2||c.some(u=>!u)||t.push(We({scope:"list",title:c.length===3?"Исход":"Победитель",kind:c.length===3?"1x2":"12",outcomes:c,event:i,anchor:o,eventKey:i.key}))}}}return t}function fs(e){if(!e?.body)return null;let t=d=>/^\d{1,3}\s?%$/.test(d),o=ne(e,"h4").map(d=>{let m=[...d.nextElementSibling?.children||[]],x=V(m[0]),h=V(m[m.length-1]);return t(x)&&t(h)?{label:V(d),home:x.replace(/\s/g,""),away:h.replace(/\s/g,"")}:null}).filter(Boolean);if(!o.length)return null;let i=(e.body.innerText||e.body.textContent||"").replace(/\s+/g," "),n=[...i.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(d=>Number(d[1])),c=[...(i.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(d=>d[1].replace(/\s/g,""));return{names:V(e.querySelector("h3")).split(/\s+vs\s+/i).map(d=>d.trim()).filter(Boolean),rows:o,samples:n.slice(0,2),form:c.length>=2?{home:c[0],away:c[1]}:null}}function ms(e,t,o){if(!e||e.names.length<2)return e;let i=yt(e.names[0],t)+yt(e.names[1],o);return yt(e.names[0],o)+yt(e.names[1],t)<=i?e:{names:[e.names[1],e.names[0]],rows:e.rows.map(l=>({label:l.label,home:l.away,away:l.home})),samples:e.samples.slice().reverse(),form:e.form?{home:e.form.away,away:e.form.home}:null}}function hs(e){let t=e.querySelector("iframe.stats__iframe");if(!t)return null;try{return fs(t.contentDocument)}catch{return null}}function gs(e){let t=["one","two"].map(l=>e.querySelector(`.event-live-center__team-widget--${l}`));if(!t[0]||!t[1])return null;let o=l=>{let c=l;try{c=l.querySelector("iframe")?.contentDocument?.body||l}catch{c=l}let u=ne(c,'[class*="player"]').filter(m=>!ne(m,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(m.className)),d=[];for(let m of u){let x=V(m).split(" ").filter(Boolean),h=x.find($=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test($)&&/[A-Za-z]/.test($));if(!h||d.some($=>$.nick===h))continue;let b=x.filter($=>/^\d{1,3}$/.test($)).map(Number);d.push({nick:h,numbers:b.slice(0,4)})}return d.slice(0,5)},i=o(t[0]),n=o(t[1]);return i.length<3||n.length<3?null:{home:i,away:n}}var Mo={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:Nn,readMatch:wo,readEsportsWidget:gs,observeTargets(e){try{let t=e.querySelector("iframe.stats__iframe")?.contentDocument?.body;return t?[t]:[]}catch{return[]}},collect(e,t){if(Nn(e)==="match"){let n=wo(e,t)?.key||"";return[...cs(e,n),...us(e,n),...yo(e)]}return yo(e)}};var Wt=(e,t)=>{try{return[...e.querySelectorAll(t)]}catch{return[]}};function So(e,t){let o=[e];if(t.shadow)for(let i of Wt(e,t.shadow))i.shadowRoot&&o.push(i.shadowRoot);return o}var Kt=e=>(e.defaultView?.innerWidth||0)>0,bs='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function xs(e){let t=[],o=e.ownerDocument.createTreeWalker(e,4);for(;o.nextNode();){let i=o.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(i&&t.push(...i.split(" ")),t.length>5)return null}return t}function $s(e,t){if(t.label){let o=e.querySelector(t.label),i=o?o.textContent.replace(/[ \s]+/g," ").trim():"";if(i&&!/^\d{1,3}[.,]\d{1,3}$/.test(i))return i}if(t.cell&&t.headerRow){let o=e.closest(t.cell),i=o?.parentElement,n=i?.parentElement?.querySelector(t.headerRow);if(n&&n!==i){let l=[...i.children].indexOf(o),c=n.children[l]?.textContent.replace(/[ \s]+/g," ").trim()||"";if(c)return c.charAt(0).toUpperCase()+c.slice(1).toLowerCase()}}return""}function ks(e,t){if(!t.cell||!t.lineCell)return"";let o=e.closest(t.cell);for(;o&&(o=o.previousElementSibling);){if(!o.matches?.(t.lineCell))continue;let i=o.textContent.replace(/[ \s]+/g," ").trim().match(/([+\-−–]?\d+(?:[.,]\d+)?)\s*\)?\s*$/);return i?i[1].replace(",",".").replace(/[−–]/,"-"):""}return""}function ws(e,t){if(e.disabled||e.hasAttribute?.("disabled"))return null;let o=t.value&&e.querySelector(t.value)||e,i=xs(o);if(!i||!i.length||i.join(" ").length>28)return null;let n=i[i.length-1];if(!(t.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(n))return null;let l=je(n);if(!l||l>500||i.slice(0,-1).some(u=>/^\d{1,3}[.,]\d{1,3}$/.test(u)))return null;let c=i.slice(0,-1).join(" ");return!t.outcome&&/[+−]|^-/.test(c)?null:{odd:l,label:c}}function ys(e,t){let o=[],i=new Set,n=So(e,t).flatMap(l=>Wt(l,t.outcome||bs));for(let l of n){if(i.has(l)||t.skip&&l.closest(t.skip)||l.closest("#lz-root, #lz-marks"))continue;let c=ws(l,t);if(c){if(!t.outcome&&Kt(e)){let u=l.getBoundingClientRect();if(u.width<26||u.width>320||u.height<16||u.height>90)continue}i.add(l),o.push({el:l,odd:c.odd,label:c.label||$s(l,t),line:ks(l,t),locked:!1})}}return t.outcome?o:o.filter(l=>!o.some(c=>c.el!==l.el&&c.el.contains(l.el)))}function vs(e,t,o){if(t.row)return e.closest(t.row);let i=e.parentElement;for(let n=0;n<6&&i&&i!==i.ownerDocument.body;n+=1){let l=o(i);if(l>=2&&l<=16){if(!Kt(i.ownerDocument))return i;let c=i.getBoundingClientRect();if(c.height<=130&&c.width>=120)return i}if(l>16)break;i=i.parentElement}return null}var zo=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось|окко|okko|матч тв|match tv|кинопоиск|трансляция|видео|статистика|stats)$/i;function Ms(e,t){let o=t.length,i=e;for(let x=0;x<7;x+=1){let h=i.parentElement;if(!h||t.some(y=>!h.contains(y.el))||h.querySelectorAll("*").length>400||[...h.querySelectorAll('button, a, td, [role="button"]')].filter(y=>!t.some(v=>v.el===y||v.el.contains(y)||y.contains(v.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(V(y))).length>o)break;i=h}let n=t[0].el,l=[],c=i.ownerDocument.createTreeWalker(i,4);for(;c.nextNode();){let x=c.currentNode;if(n.contains(x))break;let h=x.textContent.replace(/[ \s]+/g," ").trim();h.length<2||h.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(h)||/\d{1,2}:\d{2}|^\d|['′]$/.test(h)||zo.test(h)||l.push(h)}let u=l.slice(-2),d=l.map(x=>x.split(/\s+[—–-]\s+/)).filter(x=>x.length===2).pop();if(d&&(u=d),u.length<2||u[0]===u[1])return null;let m=i.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:Ke(u[0],u[1]),home:u[0],away:u[1],href:m,live:!1,time:"",league:"",card:i}}function Ss(e,t,o){if(!t.names)return Ms(e,o);let i=t.event&&e.closest(t.event)||e,n=[...new Set(Wt(i,t.names).map(u=>V(u)).filter(Boolean))],l=n;if(n.length===1&&(l=n[0].split(/\s+[—–-]\s+/)),l.length<2||!l[0]||!l[1])return null;let c=i.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:Ke(l[0],l[1]),home:l[0],away:l[1],href:c,live:!1,time:"",league:"",card:i}}function zs(e){let o=String(e.title||"").replace(/^\s*(ставки на (матч|игру|бой)|матч)\s+/i,"").match(/^(.{2,40}?)\s+(?:[—–-]|x|vs|против)\s+(.{2,40}?)(?=\s*[:,|.(📅]|\s+[—–-]\s|\s+ставк|\s+прогноз|\s+коэффиц|\s+live\b|\s+лайв\b|\s+\d{1,2}(?:[./]\d|\s+[а-я]{3,})|$)/i);if(!o)return null;let i=[o[1].trim(),o[2].trim()];return i.some(n=>/ставк|контор|онлайн|букмекер|прогноз|коэффиц|!$/i.test(n))?null:i}function No(e,t={}){function o(b,$){return t.matchUrl&&t.matchUrl.test($?.pathname||"")||t.matchPage&&b.querySelector(t.matchPage)?"match":"list"}function i(b){let $=b.defaultView;if(!$||!Kt(b))return[];let y=[];for(let v of b.querySelectorAll("h1, h2, h3, div, span, p, a")){if(v.children.length)continue;let _=V(v);if(_.length<3||_.length>40||!/[A-Za-zА-Яа-яЁё]{3}/.test(_)||/\d{1,2}[:.]\d{2}/.test(_)||zo.test(_))continue;let F=v.getBoundingClientRect();if(!(F.top<60||F.top>450||F.width<30||parseFloat($.getComputedStyle(v).fontSize)<15)&&(y.includes(_)||y.push(_),y.length===2))break}return y}function n(b,$){if(o(b,$)!=="match")return null;let y=t.matchNames?Wt(b,t.matchNames).map(_=>V(_)).filter(Boolean):[];if(y.length===1&&(y=y[0].split(/\s+[—–-]\s+/)),y.length<2&&(y=zs(b)||[]),y.length<2&&(y=i(b)),y.length<2)return null;let v=t.matchLeague?V(b.querySelector(t.matchLeague)):"";return{book:e.name,id:(String($?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:Ke(y[0],y[1]),home:y[0],away:y[1],sport:st($?.pathname,v,b.title,V(b.querySelector('[class*="breadcrumb" i], nav[aria-label*="крошк" i]'))),league:v,start:"",live:/(^|\/)live(\/|$)/i.test($?.pathname||"")?!0:null,form:{home:"",away:""},url:$?.href||""}}function l(b,$){return!b||!$?"":$.startsWith("attr:")?String(b.getAttribute($.slice(5))||"").trim():V(b.querySelector($))}function c(b,$){if(!Kt($))return[b];let y=b.map(_=>{let F=_.el.getBoundingClientRect();return{cell:_,top:F.top,left:F.left}}).sort((_,F)=>Math.abs(_.top-F.top)>8?_.top-F.top:_.left-F.left),v=[];for(let _ of y){let F=v[v.length-1];F&&Math.abs(F.top-_.top)<=8?F.cells.push(_.cell):v.push({top:_.top,cells:[_.cell]})}return v.map(_=>_.cells)}let u=[[/^(п1|1)\/(х|x|ничья)\/(п2|2)$/i,"1x2"],[/^(п1|1)\/(п2|2)$/i,"12"],[/^(1х|1x)\/12\/(х2|x2)$/i,"dc"]],d=b=>(u.find(([$])=>$.test(b.join("/").toLowerCase()))||[])[1]||"other";function m(b,$){let y=o(b,$),v=y==="match"&&t.match?{...t,...t.match}:t;return x(b,$,y,v)}function x(b,$,y,v){let _=ys(b,v);if(_.length<2)return[];let F=new Set(_.map(M=>M.el)),k=M=>{let A=0;for(let B of F)M.contains(B)&&(A+=1);return A},R=new Map;for(let M of _){let A=vs(M.el,v,k);A&&(R.has(A)||R.set(A,[]),R.get(A).push(M))}let P=y==="match"?n(b,$):null,L=[];for(let[M,A]of R){let B=y==="match"?null:Ss(M,v,A),O=v.group?M.closest(v.group):null,I=l(O,v.groupTitle),G=l(O,v.groupPeriod),E=v.visualRows?c(A,b):[A],q=0;for(let Y of E)for(let H of ho(Y).sets){let te=q===0,Q=H.length,U=Q===3?["П1","Х","П2"]:["1","2"],re=H.map((pe,ge)=>({...pe,label:pe.label||U[ge]||String(ge+1)})),le=te&&Q===3?"Исход":te?"Победитель":`Рынок ${q+1}`,ue=te?Q===3?"1x2":"12":"other";I&&(le=I,ue=vt(I,Q),ue==="other"&&(ue=d(re.map(pe=>pe.label)))),Q===3&&re.every(pe=>/\sили\s/i.test(pe.label))&&(ue="dc"),L.push(We({scope:y==="match"?"board":"list",title:le,period:G,line:H[0].line&&H.every(pe=>pe.line===H[0].line)?H[0].line:"",kind:ue,outcomes:re,event:B,anchor:M,eventKey:B?.key||P?.key||`row${L.length}`})),q+=1}}return L}let h=b=>So(b,t).slice(1);return{id:e.id,name:e.name,hosts:e.hosts,generic:!0,pageType:o,readMatch:n,collect:m,observeTargets:h,readEsportsWidget:()=>null}}var _o={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]',match:{group:'[class*="market-group-box--"]',groupTitle:'[class*="header--"] [class*="text--"]',label:'[class*="text--"]',cell:'[class*="cell--"]',headerRow:'[class*="header-row--"]',lineCell:'[class*="_align-left--"]'}},Ao={fonbet:_o,pari:_o,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd, .dg_euv_stake",value:".dg_euv_stake_factor_new",row:".euv_event_home, .dg_euv_stake_grid",names:".euv_event_name_team",integers:!0,matchUrl:/\/sport\/event-details\//,matchNames:"h1"},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name",matchUrl:/\/su\/betting\/.*vs.*\d{5,}/i},leon:{matchUrl:/\/bets\/.+\/\d{10,}-/},olimp:{matchUrl:/\/line\/[^/]+\/[^/]+-\d{4,}\/[^/]+/,match:{outcome:'[data-testid^="bet-button"]',row:'[data-testid="accordion-content"]',group:'[data-testid="accordion"]',groupTitle:'[class*="title--"]',visualRows:!0}},betcity:{matchUrl:/\/ru\/(live|line)\/[^/]+\/\d+\/\d+/},betboom:{matchUrl:/\/sport\/(?:live\/)?[^/]+\/\d+\/\d+\/\d+/},liga:{matchUrl:/\/sports\/[^/]+\/.+-id-\d+/,match:{outcome:"button[outcomeid]",row:"[data-t-market]",group:"[data-t-market]",groupTitle:"attr:data-t-market",groupPeriod:'[class*="header__description"]',visualRows:!0}}};function Oo(e){let t=co(e);return t?t.id==="winline"?{adapter:Mo,book:t}:{adapter:No(t,Ao[t.id]||{}),book:t}:null}var Vt=`/* Цвета, шрифт и радиусы панели — из design/tokens.json (node tools/tokens.mjs). Блоки между метками руками не править. */
:host {
  /* tokens:light */
  --lz-accent: #5b4be6;
  --lz-accent-strong: #4a3bd1;
  --lz-accent-soft: rgba(91, 75, 230, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0b8a4d;
  --lz-pos-soft: rgba(11, 138, 77, 0.14);
  --lz-neg: #c93636;
  --lz-neg-soft: rgba(201, 54, 54, 0.12);
  --lz-warn: #b45309;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6fa;
  --lz-surface-2: #eef0f5;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #555c6b;
  --lz-faint: #666b7f;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  /* /tokens */
  color-scheme: light;
}

:host([data-theme="dark"]) {
  /* tokens:dark */
  --lz-accent: #8f82ff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(143, 130, 255, 0.18);
  --lz-accent-ink: #0f1017;
  --lz-pos: #45d08f;
  --lz-pos-soft: rgba(69, 208, 143, 0.16);
  --lz-neg: #ff7676;
  --lz-neg-soft: rgba(255, 118, 118, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #171a23;
  --lz-surface: #1f2330;
  --lz-surface-2: #272b34;
  --lz-border: #2c3040;
  --lz-text: #eef0f6;
  --lz-muted: #a4a8bb;
  --lz-faint: #8e92a8;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  /* /tokens */
  color-scheme: dark;
}
`;var Eo=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}

.tip-foot .pos {
  color: var(--lz-pos);
  font-weight: 600;
}
`;function s(e,t,...o){let[i,...n]=e.split("."),l=document.createElement(i||"div");n.length&&(l.className=n.join(" "));for(let[c,u]of Object.entries(t||{}))if(!(u==null||u===!1))if(c==="class")l.className=[l.className,u].filter(Boolean).join(" ");else if(c==="style")l.style.cssText=u;else if(c==="text")l.textContent=u;else{if(c==="html")throw new Error("html запрещён");c.startsWith("data-")||c.startsWith("aria-")||c==="role"||c==="title"||c==="type"||c==="href"||c==="target"||c==="rel"||c==="placeholder"||c==="value"||c==="for"||c==="name"||c==="maxlength"||c==="autocomplete"||c==="spellcheck"||c==="tabindex"?l.setAttribute(c,u===!0?"":String(u)):c==="disabled"||c==="hidden"||c==="checked"||c==="selected"?l[c]=!!u:l[c]=u}return To(l,o),l}function To(e,t){for(let o of t)o==null||o===!1||(Array.isArray(o)?To(e,o):e.appendChild(o instanceof Node?o:document.createTextNode(String(o))))}var Fo="http://www.w3.org/2000/svg";function ce(e,t=16){let o=document.createElementNS(Fo,"svg");o.setAttribute("viewBox","0 0 20 20"),o.setAttribute("width",t),o.setAttribute("height",t),o.setAttribute("fill","none"),o.setAttribute("stroke","currentColor"),o.setAttribute("stroke-width","1.7"),o.setAttribute("stroke-linecap","round"),o.setAttribute("stroke-linejoin","round"),o.setAttribute("aria-hidden","true");for(let i of As[e]||[]){let n=document.createElementNS(Fo,"path");n.setAttribute("d",i),o.appendChild(n)}return o}var As={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"],sidebar:["M4.2 4h11.6A1.7 1.7 0 0 1 17.5 5.7v8.6a1.7 1.7 0 0 1-1.7 1.7H4.2a1.7 1.7 0 0 1-1.7-1.7V5.7A1.7 1.7 0 0 1 4.2 4Z","M12.5 4v12","M14.4 7.2h1.2M14.4 9.6h1.2"]};function Co(){let e=document.createElement("div");e.id="lz-marks",e.style.cssText="position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;overflow:hidden!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let t=e.attachShadow({mode:"open"});t.appendChild(s("style",{text:Vt+Eo}));let o=s("div.layer"),i=s("div.tip");t.append(o,i);let n=new Map,l=new Set,c=0,u=null,d=null,m=new IntersectionObserver(M=>{for(let A of M)A.isIntersecting?l.add(A.target):(l.delete(A.target),n.get(A.target)?.node.classList.remove("on"));h()},{rootMargin:"120px"});function x(){e.isConnected||document.documentElement.appendChild(e)}function h(){c||(c=requestAnimationFrame(()=>{c=0,y()}))}let b=(M,A)=>{for(let B=A;B;B=B.parentNode||B.host)if(B===M)return!0;return!1};function $(M,A){let B=A.left+A.width/2,O=A.top+A.height/2;if(B<0||O<0||B>window.innerWidth||O>window.innerHeight)return!1;let I=document.elementFromPoint(B,O);for(;I?.shadowRoot?.elementFromPoint;){let G=I.shadowRoot.elementFromPoint(B,O);if(!G||G===I)break;I=G}return!!I&&I!==M&&!b(M,I)&&!b(I,M)}function y(){for(let M of l){let A=n.get(M);if(!A)continue;if(!M.isConnected){v(M);continue}let B=M.getBoundingClientRect();if(B.width<6||B.height<6||$(M,B)){A.node.classList.remove("on");continue}let O=Math.round(B.left),I=Math.round(B.top),G=Math.round(B.width),E=Math.round(B.height);(A.x!==O||A.y!==I)&&(A.node.style.transform=`translate3d(${O}px, ${I}px, 0)`,A.x=O,A.y=I),(A.w!==G||A.h!==E)&&(A.node.style.width=`${G}px`,A.node.style.height=`${E}px`,A.w=G,A.h=E,A.node.classList.toggle("small",E<26)),A.node.classList.add("on")}u&&F()}function v(M){let A=n.get(M);A&&(m.unobserve(M),l.delete(M),A.node.remove(),n.delete(M))}function _(M){x();let A=new Map;for(let B of M)B.el?.isConnected&&A.set(B.el,B);for(let B of[...n.keys()])A.has(B)||v(B);for(let[B,O]of A){let I=n.get(B);if(!I){let E=s("div.mark"),q=parseFloat(getComputedStyle(B).borderTopLeftRadius);E.style.borderRadius=`${Number.isFinite(q)&&q>0?Math.min(q,16):6}px`;let Y=s("span.chip");E.appendChild(Y),o.appendChild(E),I={node:E,chip:Y,sig:""},n.set(B,I),m.observe(B)}let G=`${O.frame?1:0}|${O.selected?1:0}|${O.tone||""}|${O.chip||""}`;G!==I.sig&&(I.sig=G,I.node.classList.toggle("frame",!!O.frame),I.node.classList.toggle("selected",!!O.selected),I.node.classList.toggle("pos",O.tone==="pos"&&!!O.frame),I.chip.hidden=!O.chip,I.chip.textContent=O.chip||"",I.chip.className=`chip${O.tone&&O.tone!=="accent"?" "+O.tone:""}`)}h()}function F(){if(!u?.isConnected)return R();let M=u.getBoundingClientRect(),A=264,B=i.offsetHeight||140,O=M.left+M.width/2-A/2;O=Math.max(8,Math.min(O,window.innerWidth-A-8)),d&&O+A>d.left-8&&O<d.right&&(O=Math.max(8,d.left-A-10));let I=M.bottom+10;I+B>window.innerHeight-8&&(I=M.top-B-10),I<8&&(I=8),i.style.transform=`translate3d(${Math.round(O)}px, ${Math.round(I)}px, 0)`}function k(M,A){x(),u=M,i.replaceChildren(A),F(),i.classList.add("on")}function R(){u=null,i.classList.remove("on")}function P(M){d=M}function L(M){e.setAttribute("data-theme",M)}return window.addEventListener("scroll",h,{capture:!0,passive:!0}),window.addEventListener("resize",h,{passive:!0}),setInterval(()=>{n.size&&!document.hidden&&h()},700),{set:_,schedule:h,showTip:k,hideTip:R,setTheme:L,setAvoid:P,get tipTarget(){return u},count:()=>n.size}}var Lo=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Длинное имя конторы («Лига Ставок») сокращается многоточием, а не выталкивает кнопки шапки за край. */
.brand {
  min-width: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 72px minmax(60px, max-content);
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  white-space: nowrap;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.partner { margin-top: 8px; }
.partner-text { font-size: 12px; margin-bottom: 4px; }
.partner-links { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
.partner-links a.btn { text-decoration: none; }
.gain { margin-top: 8px; font-size: 12px; color: var(--lz-text); }
.gain b { color: var(--lz-pos); }
td.name .partner-links { margin-top: 3px; }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.card.update { font-size: 12.5px; }
.card.update b { color: var(--lz-accent); }
/* Строка без номера (факторы модели, факты о составах) занимает обе колонки, иначе текст ломается по словам в узкой. */
.facts li > span:only-child { grid-column: 1 / -1; }
.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  margin: 0;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  /* 18+ и предупреждение о зависимости должны читаться: не бледный, а обычный второстепенный цвет. */
  color: var(--lz-muted);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

/* ---- Линза: страница расширения linza.html (боковая панель Chrome, сайдбар Firefox, вкладка) ---- */
.panel.page {
  position: relative;
  top: auto;
  right: auto;
  z-index: auto;
  width: 100%;
  max-width: 760px;
  height: 100vh;
  max-height: none;
  margin: 0 auto;
  border: 0;
  border-radius: 0;
  box-shadow: none;
  animation: none;
}

.panel.page .head {
  cursor: default;
  touch-action: auto;
}

.controls {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.chips {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.chip {
  height: 28px;
  padding: 0 10px;
  border-radius: 8px;
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
  transition: background 0.12s ease, color 0.12s ease;
}

.chip:hover { color: var(--lz-text); }
.chip.on { background: var(--lz-accent-soft); color: var(--lz-accent); }

.mrow {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 10px 12px;
}

.mrow .when {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  color: var(--lz-muted);
  font-size: 11.5px;
  white-space: nowrap;
}

.mrow .when .league {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  text-align: right;
}

.mteams {
  font-size: 13.5px;
  font-weight: 680;
  letter-spacing: -0.005em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.badges {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.sure {
  display: flex;
  align-items: center;
  gap: 5px;
  color: var(--lz-pos);
  font-size: 12px;
  font-weight: 600;
}

.picks {
  display: flex;
  gap: 6px;
}

.pickbtn {
  flex: 1 1 0;
  min-width: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1px;
  padding: 6px 4px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius-sm);
  background: var(--lz-bg);
  transition: border-color 0.12s ease, background 0.12s ease;
}

.pickbtn small {
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--lz-muted);
  font-size: 11px;
}

.pickbtn b { font-size: 14px; font-weight: 700; }
.pickbtn:hover:not([disabled]) { border-color: var(--lz-accent); }
.pickbtn.on { border-color: var(--lz-accent); background: var(--lz-accent-soft); }
.pickbtn.on b { color: var(--lz-accent); }
.pickbtn[disabled] { opacity: 0.5; cursor: default; }

.leg.review {
  row-gap: 3px;
}

.leg.review .why {
  grid-column: 1 / -1;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg.review .why.pos { color: var(--lz-pos); }
.leg.review .why.neg { color: var(--lz-neg); }
.facts.warns li { color: var(--lz-warn); }

/* Верх разбора (src/content/ui/brief.js): «Прогноз Линзы» — с акцентом, «Выбор Линзы» — нейтральная карточка без цвета. */
.badge.warn { background: var(--lz-surface-2); background: color-mix(in srgb, var(--lz-warn) 16%, transparent); color: var(--lz-warn); }
.brief-pick { font-size: 15px; font-weight: 700; letter-spacing: -0.005em; margin-bottom: 4px; }
.brief-head { font-size: 13.5px; font-weight: 650; line-height: 1.35; }
.brief-note { margin-top: 3px; color: var(--lz-muted); font-size: 12px; }
.brief-changed { margin-top: 5px; font-size: 12px; line-height: 1.4; }
.brief-line { margin-top: 5px; font-size: 12.5px; line-height: 1.4; }
.brief-line b { color: var(--lz-muted); font-weight: 650; }
.brief-price { margin-top: 7px; font-size: 12.5px; font-weight: 600; }
.brief-old { margin-top: 3px; color: var(--lz-muted); font-size: 11.5px; }
.brief-foot { margin-top: 8px; color: var(--lz-muted); font-size: 11px; }

/* «Подробный разбор»: всё, кроме верха разбора, — свёрнуто по умолчанию. */
details.more { border-top: 0; margin-top: 0; padding-top: 0; }
details.more > summary {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 34px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-text);
  font-size: 12.5px;
  font-weight: 650;
}
.more-body { display: flex; flex-direction: column; gap: 10px; margin-top: 10px; }

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;function Mt(e,{genitive:t=!1}={}){let o=Math.abs(e)%100,i=o%10,n=i===1&&o!==11,l=i>=2&&i<=4&&(o<10||o>=20);return`${e} ${t?n?"конторы":"контор":n?"контора":l?"конторы":"контор"}`}var Ro={matches:1915,sport:"football",minBooks:5};function Xt(e,{sport:t=""}={}){let o=Math.max(0,Number(e?.count)||0),i=e?.fair?.source!=="books",n=!!e&&i&&(Array.isArray(e.betfair)||e.exchange===!0||Array.isArray(e.books)&&e.books.some(m=>/^betfair_ex/.test(m?.key||""))),l=n?o-1:o,c=t===Ro.sport&&i&&o>=Ro.minBooks,u=l>0?`${Mt(l)}${n?" и биржа":""}`:n?"биржа":Mt(0),d=l>0?`${Mt(l,{genitive:!0})}${n?" и биржи":""}`:n?"биржи":Mt(0,{genitive:!0});return{who:u,of:d,books:Math.max(0,l),exchange:n,proven:c,note:c?"По проверке на 1 915 матчах футбола такой консенсус точнее любой нашей модели.":""}}var St="Это расчёт, а не совет ставить. 18+";var Ti=[[String.raw`это\s+расч[её]т,?\s+а\s+не\s+совет\s+ставить`,"giu"],[String.raw`ставки\s+не\s+делаются`,"giu"],[String.raw`не\s+зарабатываем\s+на\s+ставках`,"giu"],[String.raw`не\s+обещаем\s+(?:выигрыш|заработок)`,"giu"],[String.raw`не\s+100\s?%`,"giu"]];var Me="(?:^|[^а-яёa-z])",An="(?=[^а-яёa-z]|$)",Pi=[["верняк",new RegExp(`${Me}верняк`,"iu")],["беспроигрыш",/беспроигрыш/iu],["договорной матч",/договорн\S*\s+(матч|игр)/iu],["железная ставка",/железн\S*\s+(ставк|прогноз|экспресс)/iu],["100% проход",/100\s?%\s*(проход|выигрыш|побед|заход)/iu],["сто процентов",/(?<![а-яё])сто\s+процентов/iu],["залетит",/залетит/iu],["выстрелит",/выстрел(ит|ят|ить)/iu],["без добавок конторы",/без\s+добав\S*\s+контор/iu]],Bi=[["гарантия",new RegExp(`${Me}(гарант\\S*)`,"iu")],["призыв ставить",new RegExp(`${Me}(ставьте|ставь|поставьте|поставь)${An}`,"iu")]];var Po=[["вероятнее всего",/вероятнее\s+всего/iu],["скорее всего",/скорее\s+всего/iu],["берём",new RegExp(`${Me}(берём|берем)${An}`,"iu")],["заходим",new RegExp(`${Me}заходим${An}`,"iu")],["рекомендуем",/рекомендуем/iu],["надёжный",/надёжн|надежн/iu],["сильный или лучший выбор",/(сильн|лучш)\S*\s+выбор/iu],["выбор дня",/выбор\s+дня/iu]];var Ii=[["перевес",new RegExp(`${Me}(перевес\\S*)`,"iu")],["выгодно",new RegExp(`${Me}(выгодн\\S*)`,"iu")],["цена выше честной",new RegExp(`${Me}(цен\\S*\\s+выше\\s+честн\\S*)`,"iu")],["выигрыш больше",new RegExp(`${Me}(выигрыш\\S*\\s+больше)`,"iu")],["интересная цена",new RegExp(`${Me}(интересн\\S*\\s+цен\\S*)`,"iu")],["расчёта выгоды",new RegExp(`${Me}(расч[её]т\\S*\\s+выгод\\S*)`,"iu")]];var Es=.2;function Fs(e){let t=vn((e||[]).map(Number));return t?t.length===3?t[0]+t[1]/2:t[0]:null}function On(e,t){if(!e?.p1)return{ok:!1,reason:"нет прогноза"};if(e.confidence==="очень низкая")return{ok:!1,reason:"мало матчей в архиве — модель почти ничего не знает об участниках"};let o=Fs(t);return o!=null&&Math.abs(e.p1-o)>Es?{ok:!1,reason:`модель расходится с ценой конторы на ${Math.round(Math.abs(e.p1-o)*100)} п.п. — скорее всего, она чего-то не знает (квалификация, травма, состав)`}:{ok:!0,reason:""}}var Ts={cs:!1,dota:!1,tennis:!1,basketball:!1,mma:!1,hockey:!1},En=e=>Ts[e]===!0,Cs="Честный кэф по модели Линзы (справочно, она не точнее рынка)",Ls=e=>e>.01&&e<.99?J(1/e):"—";function Fn(e,t=6){let o=(Array.isArray(e)?e:[]).filter(i=>i?.label&&i.p>0).slice(0,t);return o.length?`${Cs}: ${o.map(i=>`${i.label} — ${Ls(i.p)}`).join(" · ")}.`:""}function Tn(e,t){return!e?.p1||!(e.p2>0)?"":Fn([{label:t[0],p:e.p1},{label:t[t.length-1],p:e.p2}])}var zt=.03,it=.12,Zt=.15,Ge=e=>Number.isFinite(e)?(Math.round(e*100)/100).toFixed(2).replace(".",","):"—",at=e=>`${Math.round(e*100)}%`;var Cn=`Исход может не сбыться при любой цене. ${St}`,Rs="это не выигрыш: по журналу «Итогов» такие цены к закрытию в среднем хуже на 9–13%",Ps=Cn,Bs=(e,t)=>e*t-1;function Is(e){return e<zt?null:e<.06?"небольшая — примерно половина обычной":e<it?"обычная":"расхождение слишком большое — сначала проверьте травмы, замены и что это тот же матч"}function Bo(e,{source:t="",reasons:o=[],risk:i=""}={}){let n=(e||[]).filter(k=>Number(k.odd)>1&&k.p>.01&&k.p<.99).map(k=>({...k,fairOdd:1/k.p,edge:Bs(k.p,Number(k.odd))}));if(!n.length)return null;let l=[...n].sort((k,R)=>R.edge-k.edge),c=k=>k.edge>=zt&&k.edge<=it,u=l.find(k=>c(k)&&k.p>=Zt)||null,d=u?{...u,size:Is(u.edge)}:null,m=l.find(k=>k.edge>it)||null,x=m?{...m}:null,h=l.find(k=>c(k)&&k.p<Zt)||null,b=h?{...h,outsider:!0}:null,$=n.filter(k=>k!==u&&k!==m).map(k=>({...k,...c(k)&&k.p<Zt?{outsider:!0}:{},note:k.edge>it?`расхождение ${at(k.edge)} — слишком большое, проверьте данные`:c(k)&&k.p<Zt?`цена аутсайдера (шанс ${at(k.p)}): расхождение ${at(k.edge)} не считаем — у таких цен погрешность очистки маржи больше расхождения`:k.edge>=zt?`расхождение ${at(k.edge)} с честной ценой ${Ge(k.fairOdd)}`:k.edge>-.02?`честная цена (${Ge(k.fairOdd)}), расхождения нет`:`цена ниже честной (${Ge(k.fairOdd)})`})),y=[],v=k=>k.source||t;if(d){let k=v(d);y.push(`Лучшая цена: ${d.label} по ${Ge(d.odd)} — расхождение около ${at(d.edge)} с честной ценой ${Ge(d.fairOdd)}${k?` (${k})`:""} — ${Rs}.`),o.length&&y.push(`За: ${o.join(" ")}`),i&&y.push(`Главный риск: ${i}`)}else{let k=x?"остальные":b?"кроме аутсайдера остальные":"все";y.push(`${x||b?"Расхождения без оговорок нет":"Расхождения нет"}: ${k} цены близки к честным или ниже${t?` (${t})`:""} — разумнее пропустить.`)}if(x){let k=v(x);y.push(`Проверьте данные: ${x.label} по ${Ge(x.odd)} — расхождение ${at(x.edge)} с честной ценой ${Ge(x.fairOdd)}${k?` (${k})`:""} слишком большое. Чаще это ошибка данных или модели (травма, состав, чужой матч) — лучшей ценой не считаем.`)}let _=[...$].sort((k,R)=>R.edge-k.edge).slice(0,6),F=$.length-_.length;return $.length&&y.push(`${d?"Остальное":"По рынкам"}: ${_.map(k=>`${k.label} по ${Ge(k.odd)} — ${k.note}`).join("; ")}${F>0?`; ещё ${F} — с меньшим расхождением или без него`:""}.`),y.push(Ps),{best:d,suspect:x,outsider:b,others:$,lines:y}}var Io=new Set(["standin","injury","model_gap"]);function Nt(e){let t=i=>/^(б|больше|бол|over|o\b|тб)/i.test(String(i||"").trim()),o=i=>/^(м|меньше|мен|under|u\b|тм)/i.test(String(i||"").trim());return t(e[0])&&o(e[1])?0:o(e[0])&&t(e[1])?1:-1}var ut={HIGH:.7,MID:.6,DOUBLE:.75};function _e(e,t="win"){let o=Number(e),i=Math.round(Math.round(o*100*1e6)/1e6);for(let n of qs)!n.cap||!(n.kinds==="*"||n.kinds.includes(t)!==!!n.except)||o<n.p&&i>=n.pct&&(i=n.pct-1);return i}var js=3,Ds=6*36e5,Gs=3,qo=["средняя","высокая"];var Ne={MID:.6,FLOOR:.5,WIN_FIRST:.6,REVERSE:!1,COIN:.55},qs=Object.freeze([{pct:70,p:ut.HIGH,cap:!0,kinds:["double"],except:!0,what:"«Прогноз Линзы» (уверенность высокая); экспресс дня; лесенка и банк по консенсусу контор"},{pct:75,p:ut.DOUBLE,cap:!0,kinds:["double"],what:"«Прогноз Линзы» у «не проиграет»"},{pct:60,p:Ne.MID,cap:!0,kinds:"*",what:"уверенность «средняя» у «Выбора Линзы»; рамка на кнопке исхода в расширении"},{pct:55,p:Ne.COIN,cap:!0,kinds:"*",what:"«почти монетка» у «Выбора Линзы» (шанс ниже 55%)"},{pct:74,p:.74,cap:!1,kinds:[],what:"лесенка и банк без консенсуса (server/bank.mjs pMinSingle)",why:"ноги с консенсусом от 70% законно печатаются 70–73%; ниже 74% без консенсуса нога не попадает в купон"},{pct:65,p:.65,cap:!1,kinds:[],what:"changelog: проверка модели КХЛ «при уверенности от 65%»",why:"итог проверки модели, не уровень разбора; шанс матча с этим порогом не печатается"}]),Rn=["win","total","maps","sets","double"],lt={high:"высокая",mid:"средняя",low:"низкая"},tl=Object.values(lt),_t={WHY_MAX:200,AGAINST_MAX:160,REASON_MAX:80},ke=(e,t)=>`${_e(e,t)}%`,Ho=e=>String(Math.round(e*10)/10).replace(".",","),Hs=e=>String(e).replace(".",","),Jt=(e,t)=>{let o=String(e||"").replace(/\s+/g," ").trim();return o.length>t?`${o.slice(0,t-1).trimEnd()}…`:o},In=(e,t)=>e==="home"?0:e==="draw"?t===3?1:-1:e==="away"?t-1:-1,ct=(e,t)=>t==="home"?e[0]:t==="away"?e[e.length-1]:"ничья",Us={high:"mid",mid:"none",none:"none"},Ln={none:0,mid:1,high:2},Ks={high:"mid",mid:"low",low:"low"},Uo=e=>Math.min(.99,Math.max(.01,e)),jo=-.05,Do=null,Ko="margin_cap",Ws=1e-9,Wo=(e,t)=>Number.isFinite(e)&&e>1&&Number.isFinite(t)&&t>0&&t<1?e*t-1:null;function Vs(e,t){if(!e||Do&&!Do.includes(e.kind))return null;let o=Wo(t,e.p);return o==null||o>=jo-Ws?null:{level:"mid",reason:Ko,margin:Math.round(o*1e4)/1e4,odd:t,text:`маржа конторы на этот исход ${Ho(-o*100)}% — для уверенного прогноза нужна не больше ${Math.round(-jo*100)}%`}}var Pn=1.1,Vo="odds_floor",Xs=1e-9,Bn=e=>(Math.floor(e*100+1e-6)/100).toFixed(2).replace(".",",");function Zs(e,t){if(!e||!Number.isFinite(t)||t<=1||t>=Pn-Xs)return null;let o=Wo(t,e.p);return{level:"mid",reason:Vo,margin:o==null?null:Math.round(o*1e4)/1e4,odd:t,text:`кэф ${Bn(t)} — выигрыш меньше риска: для уверенного прогноза нужен кэф от ${Bn(Pn)}`}}var Xo=e=>t=>{if(!t||(t.kind||"win")!=="win"||!Array.isArray(e))return null;let o=t.side==="home"?0:t.side==="away"?e.length-1:t.side==="draw"&&e.length===3?1:-1;return o>=0&&e[o]>1?e[o]:null};var Ys={[Ko]:"margin",[Vo]:"odds"},Js=(e,t)=>Vs(e,t)||Zs(e,t),Qs=(e,t)=>{try{return typeof e=="function"&&t?e(t):null}catch{return null}};function jn(e,{probs:t=[]}={}){if(!e||!Number.isFinite(e.p)||!e.pick)return[];let o=t.length===3,i=[{kind:"win",side:e.side,label:`победа ${e.pick}`,p:e.p}],n=e.check;return n?.kind==="total"&&Number.isFinite(n.p)&&Number.isFinite(n.line)&&i.push({kind:"total",side:"",line:n.line,over:!!n.over,label:`тотал ${n.over?"больше":"меньше"} ${Hs(n.line)}`,p:n.p}),n?.kind==="sets"&&Number.isFinite(n.p)&&n.score&&i.push({kind:"sets",side:e.side,score:n.score,label:`${e.pick} ${n.score} по сетам`,p:n.p}),n?.kind==="maps"&&Number.isFinite(n.p)&&i.push({kind:"maps",side:n.three?"":n.side||"",three:!!n.three,label:n.three?"три карты в серии":n.side?`${e.pick} 2:0`:"серия 2:0",p:n.p}),o&&e.side!=="draw"&&i.push({kind:"double",side:e.side,label:`${e.pick} не проиграет`,p:e.p+(t[1]||0),threeWay:!0}),i.map(l=>({...l,p:Uo(l.p)}))}var ea=new Set(["lineup","absence","injury","rotation","motivation","fatigue","travel","weather","coach","rumor"]),ta=new Set(["roster_gap"]);var na=/лидер|капитан|вратар|голкипер|бомбардир|звезд|ключев|основн|лучш|(^|[^a-z])star([^a-z]|$)|superstar|captain|goalkeeper|leader|ключевой/i,oa=new Set(["tennis","mma"]),Yt=(e,t="")=>!!e&&(Io.has(e.kind)&&(e.kind!=="injury"||oa.has(t)||e.key===!0||na.test(String(e.text||"")))||e.kind==="lineup"&&e.key===!0);function Dn({side:e="",kind:t="win",sport:o="",labels:i=[],signals:n=[],movement:l=null,priceAt:c=null,now:u=Date.now(),analysis:d=null,others:m=null}={}){let x=(n||[]).filter(Boolean),h=x.filter(E=>E.soft),b=h.length?[`пресса о матче: ${h.slice(0,2).map(E=>E.text).join("; ")}`]:[],$=x.filter(E=>!E.soft),y=E=>!E.side||!e||E.side===e,v=E=>E.side&&e&&E.side!==e,_=$.filter(E=>Yt(E,o)&&y(E)),F=$.filter(E=>Yt(E,o)&&v(E)).map(E=>`у соперника: ${E.text}`),k=[],R=$.filter(E=>ea.has(E.kind)&&!Yt(E,o)),P=R.filter(y);P.length&&k.push({kind:"press",text:`пресса: ${P.slice(0,3).map(E=>E.text).join("; ")}`});for(let E of R.filter(v).slice(0,2))F.push(`у соперника: ${E.text}`);let L=$.filter(E=>ta.has(E.kind)),M=L.filter(y);M.length&&k.push({kind:"roster_gap",text:M.map(E=>E.text).join("; ")});for(let E of L.filter(v))F.push(`у соперника: ${E.text}`);let A=Array.isArray(l?.shift)&&e?l.shift[In(e,l.shift.length)]:null;Number.isFinite(A)&&A<=-js&&t!=="total"&&k.push({kind:"move",text:`линия ушла против ${ct(i,e)} на ${Ho(-A)} п.п. с открытия`}),$.some(E=>E.kind==="spread")&&k.push({kind:"spread",text:"конторы расходятся в оценке матча"}),Number.isFinite(c)&&u-c>Ds&&k.push({kind:"age",text:`цена старше ${Math.round((u-c)/36e5)} ч`});let B=d?.proposed?.lean??d?.lean??"none",O=String(d?.confidence||""),I={side:B&&B!=="none"?B:"",conf:O,agrees:B&&B!=="none"&&e&&t!=="total"?B===e:null};I.side&&e&&t!=="total"&&I.side!==e&&qo.includes(O)&&k.push({kind:"lean",text:`факты тянут к ${ct(i,I.side)}${d?.summary?`: ${Jt(d.summary,140)}`:""}`});let G=m?.for||{};return m?.nWin>=Gs&&m.favourite&&e&&t!=="total"&&m.favourite!==e&&(G[m.favourite]||0)*2>m.nWin&&k.push({kind:"others",text:`большинство чужих прогнозов (${G[m.favourite]} из ${m.nWin}) за ${ct(i,m.favourite)}`}),{drops:k,blockers:_,rival:F,lean:I,notes:b}}var ra=e=>e&&e.confidence||lt[e?.conf]||(e?.p>=Ne.MID?lt.mid:lt.low);function Gn(e){return!e?.label||!Number.isFinite(e.p)?"":e.blocked&&e.reason?`${e.label} (по цене ${ke(e.p,e.kind)}) · уверенность низкая: ${Jt(e.reason,_t.REASON_MAX)} — цена могла это не учесть`:`${e.label} (${ke(e.p,e.kind)}) · уверенность ${ra(e)}${e.p<Ne.COIN?" — почти монетка":""}`}function Zo(e){if(!e||e.journal==="forecast"||!Number.isFinite(e.p))return"";let t=e.kind==="double"?ut.DOUBLE:ut.HIGH,o=100-_e(e.p,e.kind),i=`${o} ${o%10===1&&o%100!==11?"случае":"случаях"} из 100`,n=e.p>=t&&Array.isArray(e.dropKinds)&&e.dropKinds.length===1&&e.dropKinds[0]==="odds",l=`Для прогноза нужен шанс от ${Math.round(t*100)}%${n?` и кэф от ${Bn(Pn)}`:e.p>=t?" без сигналов против":""}.`;return e.p<.5?`${l} Чаще такой исход не сбывается: примерно в ${i}.`:`${l} Такой исход не сбывается примерно в ${i}.`}function sa({market:e,labels:t=[],probs:o=[],lean:i=null,reason:n="",three:l=!1,withPrice:c=!0}){if(!e)return"";let u=ct(t,e.side||"home"),d=e.kind==="win"?e.p:o[In(e.side,o.length)]??e.p,m=[];return c&&m.push(`по цене ${u} ${ke(d)}${l&&o[1]!=null?`, ничья ${ke(o[1])}`:""}`),i?.side&&i.side!==e.side&&m.push(`факты тянут к ${ct(t,i.side)}`),n&&m.push(n),m.join("; ")}function aa({level:e,market:t,labels:o=[],probs:i=[],lean:n=null,reason:l="",three:c=!1,choice:u=null}){if(!t)return"нет данных для прогноза";if(e==="high")return`${t.label} (${ke(t.p,t.kind)}) · уверенность высокая`;let d=u?.label?u:{kind:t.kind,side:t.side,label:t.label,p:t.p},m=Gn(d);if(e==="mid")return m;let x=!c&&(d.kind||"win")==="win"&&(d.side||"home")===(t.side||"home");return[m,sa({market:t,labels:o,probs:i,lean:n,reason:d.blocked?"":l,three:c,withPrice:!x})].filter(Boolean).join("; ")}var ia=e=>String(e||"").replace(/\s+/g," ").trim().replace(/[.;]+$/,"");function Go(e,t){let o="";for(let i of e.map(ia).filter(Boolean)){if(o&&o.split("; ").length>=2)break;let n=o?`${o}; ${i}`:i;if(n.length<=t)o=n;else if(!o){o=Jt(i,t);break}}return o}function Yo({f:e,level:t="none",base:o=t,market:i=null,candidates:n=null,labels:l=[],probs:c=[],signals:u=[],sport:d="",analysis:m=null,others:x=null,movement:h=null,priceAt:b=null,now:$=Date.now(),live:y=null,extraDrops:v=[]}={}){if(y||!e||!i)return null;let _=c.length,F=_===3,k=n||jn(e,{probs:c}),R=W=>{let ae=In(W,_);return ae>=0&&Number.isFinite(c[ae])?c[ae]:null},P=W=>ct(l,W),L=e.side,M=k.find(W=>W.kind==="win")||null,A=M?.p??e.p,B=W=>{let ae=Rn.indexOf(W.kind);return ae<0?Rn.length:ae},O,I;if(t==="high")O=i,I="forecast";else if(o==="high")O=i,I="dropped";else if(M&&M.p>=Ne.WIN_FIRST)O=M,I="win";else{let W=k.filter(ae=>ae.p>=Ne.FLOOR);O=(W.length?W:[M||i]).reduce((ae,Ie)=>Ie.p>ae.p+1e-12||Math.abs(Ie.p-ae.p)<=1e-12&&B(Ie)<B(ae)?Ie:ae),I="max"}let G=Uo(O.p),E=O.side||"",q=Dn({side:E,kind:O.kind,sport:d,labels:l,signals:u,movement:h,priceAt:b,now:$,analysis:m,others:x});if(O===i)for(let W of v||[])W?.kind&&W.text&&q.drops.push({kind:W.kind,text:W.text});let Y=q.blockers.length>0,H=I==="forecast"||I==="dropped"?"high":G>=Ne.MID?"mid":"low",te=H;for(let W=0;W<q.drops.length;W+=1)te=Ks[te];Y&&(te="low"),t==="high"?te="high":te==="high"&&(te="mid");let Q=Jt(Y?q.blockers.map(W=>W.text).join("; "):q.drops[0]?.text||"",_t.REASON_MAX),U=L==="home"?"away":L==="away"?"home":"",re=(u||[]).some(W=>Yt(W,d)&&W.side===L),le=!Ne.REVERSE&&U&&re&&A<Ne.COIN&&Number.isFinite(R(U))?{side:U,p:R(U)}:null,ue=W=>!!W&&!Po.some(([,ae])=>ae.test(W)),pe=(m?.factors||[]).filter(W=>ue(W?.text)),ge=E?pe.find(W=>W.side===E):pe.find(W=>!W.side||W.side==="neutral"),Pe=E?pe.find(W=>W.side&&W.side!=="neutral"&&W.side!==E):null,ht=F&&Number.isFinite(c[1])?c[1]:null,gt=O.kind==="win"?E===L?"фаворит по цене без маржи":`по цене без маржи ${P(E)} ${ke(G)}`:O.kind==="double"?`победа ${P(E)} ${ke(R(E)??0)} и ничья ${ke(ht??0)} — вместе ${ke(G,"double")}`:I==="max"?`честный шанс ${ke(G)} — выше, чем у других рынков разбора`:`честный шанс ${ke(G)} по цене без маржи`,Be=q.lean.side&&E&&O.kind!=="total",et=[ge?.text,gt,Be&&q.lean.side===E?`разбор нейросети тоже за ${P(E)}`:""],ze=[...q.blockers.map(W=>W.text),Pe?.text,...q.drops.map(W=>W.text),...q.notes,Be&&q.lean.side!==E&&!qo.includes(q.lean.conf)?`разбор нейросети тянет к ${P(q.lean.side)}${q.lean.conf?` (уверенность ${q.lean.conf})`:""}`:"",e.risk,`шанс другого исхода — ${100-_e(G,O.kind)}%`],$e={kind:O.kind,side:E,label:O.label,p:G,confidence:lt[te],conf:te,confBase:H,why:Go(et.filter(ue),_t.WHY_MAX),against:Go(ze.filter(ue),_t.AGAINST_MAX),byFacts:!1,journal:t==="high"?"forecast":"choice",rule:I,drops:q.drops.length,dropKinds:q.drops.map(W=>W.kind),blocked:Y,reason:Q,pFav:A,lean:q.lean.side,leanConf:q.lean.conf,leanAgrees:q.lean.agrees,...le?{shadow:le}:{},...Number.isFinite(O.line)?{line:O.line,over:!!O.over}:{},...O.score?{score:O.score}:{},...O.kind==="maps"?{three:!!O.three}:{},...O.threeWay?{threeWay:!0}:{}};return $e.text=t==="high"?`${O.label} (${ke(G,O.kind)}) · уверенность высокая`:Gn($e),$e.note=Zo($e),$e}function qn({f:e,sport:t="",labels:o=[],probs:i=[],signals:n=[],movement:l=null,priceAt:c=null,now:u=Date.now(),analysis:d=null,others:m=null,live:x=null,source:h="",cap:b=null,oddOf:$=e?.oddOf??null}={}){if(!e)return null;let y=jn(e,{probs:i}),v=i.length===3,_=H=>y.find(te=>te.kind===H)||null,F=_("win");if(x)return{level:"none",base:"none",market:F,headline:"матч идёт — оценка по ходу матча ниже",how:e.how||[],why:[],against:[],caveats:[],reason:"матч идёт",lean:null,candidates:y,source:h,choice:null};let k=ut,R=F,P="none";for(let[H,te]of[["win",k.HIGH],["total",k.HIGH],["maps",k.HIGH],["sets",k.HIGH],["double",k.DOUBLE]]){let Q=_(H);if(Q&&Q.p>=te){R=Q,P="high";break}}P==="none"&&F&&F.p>=k.MID&&(R=F,P="mid");let L=P,M=R?.side||"",A=Dn({side:M,kind:R?.kind,sport:t,labels:o,signals:n,movement:l,priceAt:c,now:u,analysis:d,others:m}),B="";if(A.blockers.length)P="none",B=A.blockers.map(H=>H.text).join("; ");else for(let H=0;H<A.drops.length;H+=1)P=Us[P];let O=[...A.drops.map(H=>H.text),...A.rival];b&&b.level in Ln&&Ln[b.level]<Ln[P]&&(P=b.level,O.push(`уровень понижен разбором матча${b.reason?`: ${b.reason}`:""}`),P==="none"&&!B&&(B=b.reason||"уровень понижен разбором матча"));let I=P==="high"?Js(R,Qs($,R)):null;I&&(P=I.level,O.push(I.text));let G=A.lean,E=[...(d?.factors||[]).filter(H=>H?.text&&H.side&&H.side!=="neutral"&&M&&H.side!==M).slice(0,2).map(H=>H.text),...A.notes],q=Yo({f:e,level:P,base:L,market:R,candidates:y,labels:o,probs:i,signals:n,sport:t,analysis:d,others:m,movement:l,priceAt:c,now:u,extraDrops:I?[{kind:Ys[I.reason],text:I.text}]:[]}),Y=aa({level:P,market:R,labels:o,probs:i,lean:G,reason:B,three:v,choice:q});return{level:P,base:L,market:R,headline:Y,how:e.how||[],why:e.why||[],against:E,caveats:O,reason:B,lean:G,candidates:y,source:h,choice:q,...I?{marginCap:I}:{}}}function pt(e,t="win"){return Number.isFinite(e)?e>=.01?`${_e(e,t)}%`:ve(e):ve(e)}var nn=e=>Math.min(.999,Math.max(.001,e));function Hn(e,t,o=0,i=0){let n=Math.ceil(t/2),l=new Map,c=(u,d)=>{if(u>=n)return 1;if(d>=n)return 0;let m=u*16+d;return l.has(m)||l.set(m,e*c(u+1,d)+(1-e)*c(u,d+1)),l.get(m)};return c(o,i)}function on(e,t){let o=.001,i=.999;for(let n=0;n<50;n++){let l=(o+i)/2;e(l)<t?o=l:i=l}return(o+i)/2}function la(e,t){let o=nn(e);return Math.ceil(t/2)<=1?o:on(i=>Hn(i,t),o)}function en(e,t,o,i=new Map){if(t>=4)return[1,0];if(o>=4)return[0,0];if(t===3&&o===3)return[0,1];let n=t*8+o;if(!i.has(n)){let[l,c]=en(e,t+1,o,i),[u,d]=en(e,t,o+1,i);i.set(n,[e*l+(1-e)*u,e*c+(1-e)*d])}return i.get(n)}function tn(e){let[t,o]=en(e,0,0);return t/(1-o)}function Qt(e,t,o){if(t=Math.max(0,Math.floor(t)),o=Math.max(0,Math.floor(o)),Math.min(t,o)>=12){let l=Math.floor((Math.min(t,o)-12)/3),c=t-12-3*l,u=o-12-3*l,[d,m]=en(e,c,u);return d+m*tn(e)}let i=new Map,n=(l,c)=>{if(l>=13)return 1;if(c>=13)return 0;if(l===12&&c===12)return tn(e);let u=l*32+c;return i.has(u)||i.set(u,e*n(l+1,c)+(1-e)*n(l,c+1)),i.get(u)};return n(t,o)}function ca(e){return on(t=>Qt(t,0,0),nn(e))}var Ot=24,At=Array.from({length:101},(e,t)=>(t+.5)/101),Jo=null;function Ve(e,t){let o=At.map(c=>(e-1)*Math.log(c)+(t-1)*Math.log(1-c)),i=Math.max(...o),n=o.map(c=>Math.exp(c-i)),l=n.reduce((c,u)=>c+u,0);return n.map(c=>c/l)}var Et=()=>At;function Qo(e,t,o=0,i=0){if(!Number.isFinite(t))return Qt(e,o,i);let n=Ve(e*t+o,(1-e)*t+i);return!o&&!i?(Jo||=At.map(l=>Qt(l,0,0)),n.reduce((l,c,u)=>l+c*Jo[u],0)):n.reduce((l,c,u)=>l+c*Qt(At[u],o,i),0)}function Ft(e,t){return Number.isFinite(t)?on(o=>Qo(o,t),nn(e)):ca(e)}var Un={cs:8,dota:1/0};function er(e,t,o,i=0,n=0){return Number.isFinite(t)?Ve(e*t+i,(1-e)*t+n).reduce((c,u,d)=>c+u*Hn(At[d],o,i,n),0):Hn(e,o,i,n)}function Xe(e,t,o){return Number.isFinite(o)?on(i=>er(i,o,t),nn(e)):la(e,t)}function rn(e,t){let o=Math.max(e,t),i=Math.min(e,t);return i<12?o>=13:o-12-3*Math.floor((i-12)/3)>=4}function Tt({pre:e,bo:t=3,maps:o=[0,0],rounds:i=null,game:n="cs",kappa:l=Ot,kappaMap:c=Un[n]??1/0}){let u=Math.ceil(t/2),[d,m]=(o||[0,0]).map(_=>Math.max(0,Number(_)||0));if(d>=u)return{p:1,map:null};if(m>=u)return{p:0,map:null};let x=Xe(e,t,c),h=(_,F)=>er(x,c,t,_,F),[b,$]=Array.isArray(i)&&i.length===2?i.map(Number):[NaN,NaN];if(!Number.isFinite(b)||!Number.isFinite($)||b===0&&$===0||rn(b,$))return{p:h(d,m),map:null};let y=Number.isFinite(c)?(x*c+d)/(c+d+m):x,v=Qo(Ft(y,l),l,b,$);return{p:v*h(d+1,m)+(1-v)*h(d,m+1),map:v}}var Ze=[{id:"fonbet",kind:"licensed",names:["fonbet","фонбет"]},{id:"winline",kind:"licensed",names:["winline","винлайн"]},{id:"betboom",kind:"licensed",names:["bet boom","бет бум"]},{id:"pari",kind:"licensed",names:[],caps:["PARI","ПАРИ"],ambiguous:["pari","пари"]},{id:"ligastavok",kind:"licensed",names:["лига ставок","лиги ставок","лиге ставок","лигу ставок","лигой ставок","liga stavok"]},{id:"betcity",kind:"licensed",names:["bet city","бет сити"]},{id:"olimp",kind:"licensed",names:["olimp bet","олимп бет"],ambiguous:["olimp","олимп"]},{id:"marathon",kind:"licensed",names:["marathon bet","марафон бет"],ambiguous:["marathon","марафон"]},{id:"tennisi",kind:"licensed",names:["tennisi","тенниси"]},{id:"leon",kind:"licensed",names:["leon bets","леон бетс"],ambiguous:["leon","леон"]},{id:"zenit",kind:"licensed",names:["zenitbet","зенитбет"]},{id:"baltbet",kind:"licensed",names:["baltbet","балтбет"]},{id:"bettery",kind:"licensed",names:["bettery","беттери"]},{id:"sportbet",kind:"licensed",names:["sportbet","спортбет"]},{id:"1win",kind:"offshore",names:["1win","1вин","1w"]},{id:"1xbet",kind:"offshore",names:["1x bet","1х бет","1xbit"]},{id:"thunderpick",kind:"offshore",names:["thunderpick","тандерпик"],short:[["TP","world championship"]]},{id:"stake",kind:"offshore",names:["stake"],short:[["St","pulse beat"],["St","ranked"]]},{id:"ggbet",kind:"offshore",names:["gg bet","гг бет"]},{id:"parimatch",kind:"offshore",names:["pari match","пари матч"]},{id:"pinnacle",kind:"offshore",names:["pinnacle","пиннакл"]},{id:"betfair",kind:"offshore",names:["betfair","бетфейр","бетфэйр"]},{id:"bet365",kind:"offshore",names:["bet 365","бет 365"]},{id:"betway",kind:"offshore",names:["betway","бетвей"]},{id:"22bet",kind:"offshore",names:["22 bet","22 бет"]},{id:"mostbet",kind:"offshore",names:["mostbet","мостбет"]},{id:"melbet",kind:"licensed",names:["melbet","мелбет"]},{id:"cloudbet",kind:"offshore",names:["cloudbet"]},{id:"rollbit",kind:"offshore",names:["rollbit"]},{id:"roobet",kind:"offshore",names:["roobet"]},{id:"bcgame",kind:"offshore",names:["bc game"],caps:["BCG"]},{id:"betclic",kind:"offshore",names:["betclic","бетклик"]},{id:"betwinner",kind:"offshore",names:["betwinner"]},{id:"wolfbet",kind:"offshore",names:["wolfbet"]},{id:"rivalry",kind:"offshore",names:["rivalry"]},{id:"csgoempire",kind:"offshore",names:["csgo empire"]},{id:"esportsbet",kind:"offshore",names:["esportsbet"]}],ua=["кубок","суперкубок","чемпионат","первенство","лига","суперлига","турнир","cup","league","championship","series","masters","trophy","invitational","open","premier"];var Kn="[\\s.\\-]{0,2}",dt="(?<![\\p{L}\\p{N}])",Ct="(?![\\p{L}\\p{N}])",pa="(?:[аеуыо]|ом|ой|ов|ам|ами|ах)?";function Se(e){return[...String(e)].map(t=>{if(t===" ")return Kn;let o=t.toLowerCase(),i=t.toUpperCase();return o!==i?`[${o}${i}]`:/[\w]/.test(t)?t:`\\${t}`}).join("")}var da=e=>`${Se(e)}${/[бвгджзклмнпрстфхцчшщ]$/i.test(e)&&!/ставок$/i.test(e)?pa:""}`,or=e=>e.map(da).join("|");var fa=or(Ze.flatMap(e=>e.names)),rr=e=>e.flatMap(t=>t.short||[]).map(([t,o])=>`${t}(?=[\\s.\\-]{1,2}${Se(o)}(?![\\p{L}\\p{N}]))`).join("|"),tr=rr(Ze),ma=rr(Ze.filter(e=>e.kind==="offshore")),ha=Ze.flatMap(e=>e.caps||[]).join("|"),ga=Ze.filter(e=>e.kind==="offshore").flatMap(e=>e.caps||[]).join("|"),sn=[or(Ze.filter(e=>e.kind==="offshore").flatMap(e=>e.names)),ma,ga].filter(Boolean).join("|"),sr=Ze.flatMap(e=>e.ambiguous||[]).map(Se).join("|"),ar=ua.map(Se).join("|"),ba=`${dt}(?:${sr})(?=(?:\\s*[—–\\-:]\\s*|\\s+)(?:${ar})${Ct})`,xa=`(?<=(?:^|[^\\p{L}\\p{N}])(?:${ar})\\s+)(?:${sr})${Ct}`,ir=`${dt}(?:${fa}|${ha}${tr?`|${tr}`:""})${Ct}|${ba}|${xa}`,il=new RegExp(ir,"u"),ll=new RegExp(ir,"gu"),cl=new RegExp(`${dt}(?:${sn})${Ct}`,"u");var ul=[{re:new RegExp(`^(?:${Se("bet boom")}|${Se("бет бум")})(?:${Kn}(?:${Se("team")}|${Se("тим")}))?$`,"u"),name:"BetBoom Team"},{re:new RegExp(`^${Se("bb")}${Kn}(?:${Se("team")}|${Se("тим")})$`,"u"),name:"BetBoom Team"}];var Wn="",pl=new RegExp(`\\s*\\(?\\s*${dt}(?:(?:powered|presented|sponsored|supported)\\s+by|by|при\\s+поддержке)\\s*${Wn}`,"giu");var dl=new RegExp(`(^|[.,:;(|/—–]\\s*)${Wn}\\s*[-–—:]\\s*`,"gu"),fl=new RegExp(`\\s*${Wn}\\s*`,"gu");var ml=new RegExp(`${dt}(?:${sn})(?:(?:[\\s:\\-]|\\.(?!\\s))+(?:[A-Z0-9][\\p{L}\\p{N}'’&]*))+`,"gu"),hl=new RegExp(`^(?:${sn})(?:[\\s:\\-]|\\.(?!\\s))*`,"u"),gl=new RegExp(`\\s*\\(?\\s*${dt}(?:(?:powered|presented|sponsored|supported)\\s+by|при\\s+поддержке)\\s+(?:${sn})${Ct}\\)?`,"giu"),nr="",bl=new RegExp(`${nr}(\\d+)${nr}`,"g");var $a={mirage:"Mirage",inferno:"Inferno",nuke:"Nuke",ancient:"Ancient",anubis:"Anubis",dust2:"Dust2",vertigo:"Vertigo",train:"Train",overpass:"Overpass",cache:"Cache",cobblestone:"Cobblestone",tuscan:"Tuscan"};var ka=Object.freeze(["mirage","ancient","dust2","cache","nuke","inferno","anubis"]),wa=e=>ka.includes(String(e||"").replace(/^de_/i,"").toLowerCase()),lr="(?<![\\p{L}\\d])",cr="(?![\\p{L}\\d])",Ae=(e,t)=>new RegExp(`${lr}(?:de_)?(?:${e})${cr}|${lr}(?:${t})${cr}`,"iu"),wl=Object.freeze([["mirage",Ae("mirage","мираж[а-яё]*")],["ancient",Ae("ancient","(?:эншент|энщент|энциент|анциент|эйншент)[а-яё]*")],["dust2",Ae("dust\\s?(?:2|ii)","даст\\s?2")],["nuke",Ae("nuke","(?:нюк|ньюк)[а-яё]*")],["inferno",Ae("inferno","инферно")],["anubis",Ae("anubis","анубис[а-яё]*")],["train",Ae("train","трейн(?:е|а|ом|у)?")],["overpass",Ae("overpass","оверпасс?[а-яё]*")],["vertigo",Ae("vertigo","вертиго")],["cache",Ae("cache","к[эе]ш(?:е|а|ем|у)?")]]);var ft=e=>{let t=String(e||"").replace(/^de_/,"").toLowerCase();return $a[t]||(t?t[0].toUpperCase()+t.slice(1):"")};var Vn=e=>(e||[]).filter(t=>t.type==="pick"||t.type==="decider").map((t,o)=>({n:o+1,map:t.map,pick:t.type==="decider"?"":t.team}));function ur(e,t=null){let o=h=>String(h||"").replace(/^de_/,"").toLowerCase(),i=new Map((t?.perMap||[]).map(h=>[o(h.name),h])),n=h=>new Set(((t?.profiles||[])[h]?.bestMaps||[]).map(b=>o(b.map))),l={home:n(0),away:n(1)},c=(h,b)=>({map:h,title:ft(h),p:i.get(h)?.p??null,strong:["home","away"].filter($=>l[$].has(h)),...b}),u=Vn(e?.veto);if(u.length)return{known:!0,rows:u.map(h=>c(h.map,{n:h.n,pick:h.pick})),bans:(e.veto||[]).filter(h=>h.type==="ban").map(h=>({map:h.map,title:ft(h.map),team:h.team}))};let d=["home","away"].flatMap(h=>(e?.firstBans?.[h]?.maps||[]).map(b=>({map:o(b),title:ft(b),team:h}))),m=new Set(d.map(h=>h.map)),x=[...i.values()].filter(h=>(h.wf??h.w)>0&&wa(h.name)&&!m.has(o(h.name))).sort((h,b)=>(b.wf??b.w)-(h.wf??h.w)).slice(0,3).map((h,b)=>c(o(h.name),{n:b+1,pick:"",w:h.wf??h.w}));return x.length?{known:!1,rows:x,bans:[],...d.length?{usual:d}:{}}:null}var pr="Как Линза зарабатывает",ya="Платные тарифы: больше разборов матчей в день.",va=["Партнёрские ссылки контор: если вы откроете контору по ссылке из Линзы и зарегистрируетесь, контора заплатит Линзе. Вам это ничего не стоит.","На сравнение ссылки не влияют: лучшая цена выбирается только по коэффициентам и показывается, даже если у этой конторы нет нашей ссылки. На сайте самой конторы ссылок нет."],dr=e=>[ya,...e?va:[]];var Lt=e=>`+${(e*100).toFixed(1).replace(".",",")}%`,fr="Расхождение — на сколько кэф конторы выше цены рынка без маржи. Это не доход: по проверке Линзы расхождение с рынком дохода не дало, и Линза его не обещает.";var Ma=e=>ve(e),mr=e=>J(e),hr="Подробный разбор",Ce={why:200,against:160,old:160,foot:St,high:70,double:75,coin:55,stop:/вероятнее всего|скорее всего|(^|[^а-яё])берём(?![а-яё])|рекоменду|надёжн|надежн|лучший выбор/i};var Ol=Ce.stop;function gr(e,{book:t="",odds:o=null,fair:i=null,live:n=!1}={}){if(!e||!e.level)return null;let l=(U,re)=>{let le=String(U??"").replace(/\s+/g," ").trim();return le.length>re?`${le.slice(0,re-1).trimEnd()}…`:le},c=U=>U?U[0].toUpperCase()+U.slice(1):"",u=U=>Number.isFinite(U)&&U>0&&U<1,d=U=>Array.isArray(U)&&U.find(re=>typeof re=="string"&&re.trim())||"",m=U=>typeof U=="string"&&!Ce.stop.test(U)?U:"",x=U=>m(U).replace(/\s+/g," ").trim(),h=!n&&e.choice&&typeof e.choice=="object"&&e.choice.label?e.choice:null,b=e.market&&e.market.label?e.market:null;if(!h&&!b&&!e.headline)return null;let $=U=>!!U&&!!b&&(U.side||"")===(b.side||"")&&(U.kind||"win")===(b.kind||"win"),y=e.level==="high"?"forecast":h?"choice":"legacy",v=y==="forecast"?b||h:y==="choice"?h:b,_=y!=="choice"||$(h),F=e.source?`по честной цене (${e.source})`:"по честной цене рынка",k=m(h&&(y==="choice"||$(h))?h.why:"")||(_?m(d(e.why)):""),R=m(h&&(y==="choice"||$(h))?h.against:"")||(_?m(d(e.against))||m(d(e.caveats)):"");!k&&e.source&&(y==="forecast"||y==="legacy"&&e.level==="mid")&&(k=F);let P="",L="",M="",A="",B="",O=h&&u(h.p)?_e(h.p,h.kind):null,I=h?x(h.text):"";if(y==="choice"){k||(k=h.byFacts?"факты разбора за этот исход — подробности ниже":F),R||(R=h.byFacts?"цена рынка — за другой исход":O!=null?`шанс другого исхода — ${100-O}%`:"явных доводов против в данных нет");let U=h.byFacts?"низкая":["средняя","низкая"].includes(h.confidence)?h.confidence:e.level==="mid"?"средняя":"низкая",re=O==null?0:100-O,le=`${re} ${re%10===1&&re%100!==11?"случае":"случаях"} из 100`,ue=h.kind==="double"?Ce.double:Ce.high;P="Выбор Линзы",L=`уверенность ${U}`,A=`Выбор Линзы: ${I||`${String(h.label).trim()}${O!=null?` (${O}%${h.byFacts?" по цене рынка":""})`:""} · уверенность ${U}${h.byFacts?" · против цены":O!=null&&O<Ce.coin?" — почти монетка":""}`}`,B=x(h.note)||`Для прогноза нужен шанс от ${ue}%${O!=null&&O>=ue?" без сигналов против":""}.${O==null?"":O<50?` Чаще такой исход не сбывается: примерно в ${le}.`:` Такой исход не сбывается примерно в ${le}.`}`}else y==="forecast"?(P="Прогноз Линзы",L="уверенность высокая",M="pos",A=v?`${c(v.label)}${u(v.p)?` · ${Ma(v.p)}`:""}`:String(e.headline||"")):(P=e.level==="mid"?"Склоняемся":"Шансы без маржи",L=e.level==="mid"?"уверенность средняя":"не прогноз",M=e.level==="mid"?"":"warn",A=String(e.headline||""));let G="",E=Array.isArray(o)?o.length:0;if(v&&(v.kind||"win")==="win"&&E>=2){let U=v.side==="home"?0:v.side==="away"?E-1:v.side==="draw"&&E===3?1:-1,re=Number(o[U]),le=Array.isArray(i)&&i.length===E?Number(i[U]):NaN;G=[U>=0&&re>1?`${t||"Кэф"} ${mr(re)}`:"",U>=0&&u(le)?`честная цена ${mr(1/le)} (${_e(le)}%)`:""].filter(Boolean).join(" · ")}let q=String(e.headline||"").replace(/\s*[—-]\s*уверенности для прогноза нет\s*$/i,"").trim();I&&q.startsWith(I)&&(q=q.slice(I.length).replace(/^\s*;\s*/,"").trim());let Y=y==="choice"&&q&&!($(h)&&!q.includes(";"))?l(/^по цене/i.test(q)?c(q):`По цене: ${q}`,Ce.old):"",H=h&&h.changed&&typeof h.changed=="object"&&h.changed.was?h.changed:null,te=H?x(String(H.reason||"")).replace(/[.\s]+$/,""):"",Q=H?`Выбор изменён: было ${String(H.was).replace(/\s+/g," ").trim()}, стало ${String(h.label).trim()}${O!=null?` (${O}%)`:""}. Причина: ${te||(H.reason?"изменились данные разбора":"изменилась цена")}.`:"";return{mode:y,level:e.level,title:P,badge:L,tone:M,pick:A,note:B,changed:Q,why:l(k,Ce.why),against:l(R,Ce.against),price:G,old:Y,foot:Ce.foot}}function Xn(e,t,{live:o=!1}={}){if(!e?.level||!(t===2||t===3))return-1;let i=!o&&e.choice&&e.choice.label?e.choice:null,n=e.level==="high"?e.market||i:i||e.market;return!n||(n.kind||"win")!=="win"?-1:n.side==="home"?0:n.side==="away"?t-1:n.side==="draw"&&t===3?1:-1}var an=(e,{live:t=!1}={})=>!t&&!!e?.level&&e.level!=="high"&&!!e.choice?.label;function br(e,t,{live:o=!1}={}){if(o||!e?.level)return-1;let i=e.choice&&e.choice.label?e.choice:null,n=e.level==="high"?"высокая":i?i.byFacts?"низкая":i.confidence:e.level==="mid"?"средняя":"низкая";return n!=="высокая"&&n!=="средняя"?-1:Xn(e,t)}function xr(e){if(!e)return null;let t=(n,l)=>l?s("div.brief-line",{},s("b",{text:`${n}: `}),s("span",{text:l})):null,o=e.changed?s("div.brief-changed",{text:e.changed}):null,i=[t("Почему",e.why),t("Против",e.against),e.price?s("div.brief-price",{text:e.price}):null,e.old?s("div.brief-old",{text:e.old}):null,s("div.brief-foot",{text:e.foot})];return e.mode==="choice"?s("div.card.brief.choice",{"data-brief":"choice"},s("div.brief-head",{text:e.pick}),e.note?s("div.brief-note",{text:e.note}):null,o,i):s(`div.card.brief${e.mode==="forecast"?".accent":""}`,{"data-brief":e.mode},s("div.kicker",{},s("span",{text:e.title}),s(`span.badge${e.tone?`.${e.tone}`:""}`,{text:e.badge})),s("div.brief-pick",{text:e.pick}),o,i)}function $r(e){if(!e?.level)return null;let t=!!e.choice?.label&&!!e.market&&(e.choice.side||"")!==(e.market.side||""),o=[...(e.how||[]).slice(0,3),...(e.against||[]).length?[`${t?"Против фаворита цены":"Против"}: ${e.against.slice(0,2).join("; ")}`]:[],...(e.caveats||[]).slice(0,3).map(i=>`Осторожно: ${i}`)];return s("div.card",{},s("div.kicker",{},s("span",{text:"Как считала Линза"})),o.length?s("ul.facts",{},o.map(i=>s("li",{},s("span",{text:i})))):null,s("div.hint",{style:"margin-top:6px",text:"«Выбор Линзы» есть в каждом разборе, «Прогноз Линзы» — только при уверенности высокой (честный шанс от 70%, у «не проиграет» — от 75%). Уровень — по честному шансу выбранного рынка и сигналам; сбываемость по уровням — на странице «Точность». Это расчёт, а не обещание."}))}function kr(e,t,o){let i=(o||[]).filter(Boolean);return i.length?s("details.more",{"data-key":e,open:!!t},s("summary",{text:hr}),s("div.more-body",{},i)):null}var be=(e,t=0)=>ve(e,t),fe=e=>pt(e),Le=e=>`${e>0?"+":e<0?"−":""}${Math.abs(e).toFixed(1)}`;function wr({bus:e,actions:t,brand:o}){let i=document.createElement("div");i.id=e.rootId,i.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let n=i.attachShadow({mode:"open"});n.appendChild(s("style",{text:Vt+Lo}));let l=s("span.dot"),c=s("button.fab",{type:"button","data-act":"toggle",title:`${o.name}: открыть панель`,"aria-label":`${o.name}: открыть панель`},ce("lens",18),s("span",{text:o.name}),l),u=s("div.tabs",{role:"tablist"}),d=s("div.body"),m=s("div.foot"),x=s("small"),h=s("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),b=s("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),$=s("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},ce("gear")),y=s("button.iconbtn",{type:"button","data-act":"open-linza",title:"Открыть Линзу: линия и экспресс в боковой панели","aria-label":"Открыть Линзу"},ce("sidebar")),v=s("div.head",{},s("div.brand",{},s("span.logo",{},ce("lens",15)),s("span",{text:o.name}),x),s("span.grow"),y,b,h,$,s("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},ce("close"))),_=s("section.panel",{hidden:!0,role:"dialog","aria-label":o.name},v,u,d,m);n.append(c,_);let F=()=>{i.isConnected||document.documentElement.appendChild(i)};F(),new MutationObserver(F).observe(document.documentElement,{childList:!0});let k="",R=null,P=new Map,L=r=>{for(let a of r.composedPath()){if(a===i)break;if(a?.dataset?.act)return a}return null},M=null;e.on("ui:pointerdown",r=>{if(r.button!==0)return;let a=r.composedPath(),f=a.includes(c),g=a.includes(v)&&!a.some(z=>z?.dataset?.act);if(!f&&!g)return;let w=f?c:_,S=w.getBoundingClientRect();M={target:w,key:f?"fab":"panel",sx:r.clientX,sy:r.clientY,ox:S.left,oy:S.top,moved:!1},e.setDragging(!0)}),e.on("drag:move",r=>{if(!M)return;let a=r.clientX-M.sx,f=r.clientY-M.sy;!M.moved&&Math.hypot(a,f)<5||(M.moved=!0,M.target.classList.add("dragging"),B(M.target,M.ox+a,M.oy+f))}),e.on("drag:end",()=>{if(M){if(e.setDragging(!1),M.target.classList.remove("dragging"),M.moved){let r=M.target.getBoundingClientRect();t.savePosition(M.key,{left:r.left,top:r.top}),A=!0,setTimeout(()=>{A=!1},60)}M=null}});let A=!1;function B(r,a,f){let g=r.offsetWidth||120,w=r.offsetHeight||40,S=Math.max(6,Math.min(a,window.innerWidth-g-6)),z=Math.max(6,Math.min(f,window.innerHeight-Math.min(w,60)-6));r.style.left=`${Math.round(S)}px`,r.style.top=`${Math.round(z)}px`,r.style.right="auto"}e.on("ui:click",r=>{if(A)return;let a=L(r);if(!a||a.disabled)return;r.preventDefault();let f=a.dataset.act;if(f==="toggle")return xt();if(f==="close")return Ue();let g=t[f];g&&g(a.dataset.arg,a,n)}),e.on("ui:keydown",r=>{if(r.key==="Escape"&&Ue(),r.key==="Enter"){let a=r.composedPath()[0];a?.dataset?.enter&&t[a.dataset.enter]?.(a.value,a,n)}}),n.addEventListener("toggle",r=>{let a=r.target;a?.dataset?.key?.startsWith("more:")&&(P.set(a.dataset.key,a.open),!!R?.more!==a.open&&t.more?.(a.open))},!0);let O=(r,a)=>s("span.form",{},[...String(r||"")].slice(0,5).map(f=>s(`i${f==="В"?".w":f==="П"?".l":""}`,{text:f,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[f]||""})),a);function I(r,a=null){let f=r.live,g=f?s("div.center",{},f.score?.length===2?s("span.score",{text:`${f.score[0]} : ${f.score[1]}`}):null,s("span.badge.live",{text:f.state||"Лайв"})):s("div.center",{},s("span",{text:r.start||"до матча"})),w=f?.periods?.length?s("div.periods",{text:f.periods.map(z=>z.raw?`${z.label} ${z.raw}`:`${/^\d+$/.test(z.label)?`${z.label}-й отрезок`:z.label} ${z.home}:${z.away}`).join(" · ")}):null,S=f?.extras?.length?s("div.periods",{text:f.extras.map(z=>`${z.kind} ${z.home}:${z.away}`).join(" · ")}):null;return s("div.card",{},s("div.league",{text:r.league||r.sportName||"",title:r.league||""}),a?.stage?.title?s("div.periods",{text:`${a.stage.title}${a.stage.playoff?" · плей-офф":""}${a.lan===!0?" · LAN":a.lan===!1?" · онлайн":""}`}):null,s("div.teams",{},s("div.team",{},s("b",{text:r.home,title:r.home}),r.form?.home?O(r.form.home):null),g,s("div.team.away",{},s("b",{text:r.away,title:r.away}),r.form?.away?O(r.form.away):null)),w,S)}function G(r){let a=r.rows.some(f=>Number.isFinite(f.model));return s("div.card",{},s("div.kicker",{},s("span",{text:r.title}),Number.isFinite(r.margin)?s("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${be(r.margin,1)}`}):null),r.rows.map(f=>{let g=a&&Number.isFinite(f.model)?(f.model-f.fair)*100:null;return s("div.prob",{},s("span.name",{text:f.name,title:f.name}),s("span.odd",{text:J(f.odd)}),s("span.track",{},s("i",{style:`width:${Math.round((f.fair||0)*100)}%`}),Number.isFinite(f.model)?s("u",{style:`left:${Math.round(f.model*100)}%`}):null),s("span.pct",{},fe(a&&Number.isFinite(f.model)?f.model:f.fair),g!=null&&Math.abs(g)>=.05?s(`small${g>0?".pos":".neg"}`,{text:`${Le(g)} п.п.`}):null))}),s("div.legend",{},s("span",{text:"шанс по линии без маржи"}),a?s("span.model",{text:"оценка модели"}):null))}function E(r){let a=r.analysis;if(a.status==="loading")return s("div.card",{},s("div.kicker",{},s("span",{text:"Разбор"}),s("span.badge.accent",{text:"собираю данные"})),s("div.steps",{},a.steps.map((z,N)=>s(`div.step${N===a.steps.length-1?".now":".done"}`,{},s("span.mark"),s("span",{text:z})))));if(a.status==="error")return s("div.card",{},s("div.note.warn",{},ce("alert"),s("span",{text:a.error})),s("div.row",{style:"margin-top:10px"},a.needKey?s("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},ce("gear"),"Открыть настройки"):null,s("button.btn.ghost",{type:"button","data-act":"report"},"Сообщить об ошибке")));if(a.status!=="done"||!a.result)return null;let f=a.result,g={home:r.match?.home,away:r.match?.away,draw:"ничья"}[f.lean],w=f.proposed?.lean&&f.proposed.lean!=="none"&&f.lean==="none"?{name:{home:r.match?.home,away:r.match?.away,draw:"ничью"}[f.proposed.lean],by:Math.abs(f.proposed.shift[f.proposed.lean]||0)}:null,S=new Map((f.facts||[]).map(z=>[z.id,z]));return s("div.card",{},s("div.kicker",{},s("span",{text:"Разбор"}),s("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${f.confidence||"низкая"}`})),s("div.verdict",{text:g?`Данные сдвигают оценку в сторону: ${g}`:w?`Данные слегка склоняют в сторону: ${w.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),w?s("div.note",{style:"margin-bottom:10px"},ce("info"),s("span",{text:`Модель предложила сдвиг на ${w.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,f.summary?s("p.summary",{text:f.summary}):null,f.factors?.length?s("ul.factors",{},f.factors.map(z=>s(`li.factor${z.side==="home"?".home":z.side==="away"?".away":""}`,{},s("div",{},s("p",{text:z.text}),s("div.src",{},(z.facts||[]).map(N=>S.get(N)).filter(Boolean).map(N=>s("span.tag",{text:`${N.id} · ${N.source}`,title:N.text}))))))):null,f.scenarios?.length?s("div",{style:"margin-top:10px"},s("div.kicker",{},s("span",{text:"Как может пойти игра"})),s("ul.facts",{},f.scenarios.map(z=>s("li",{},s("span",{text:z.text})," ",s("em",{text:`— ${z.facts.join(", ")}`}))))):null,f.risks?.length?s("div.note",{style:"margin-top:10px"},ce("info"),s("span",{text:`Что может сломать вывод: ${f.risks.join(" ")}`})):null,(f.full?.sections||[]).some(z=>z?.lines?.length)?s("details",{"data-key":"full",open:P.get("full")||!1,style:"margin-top:8px"},s("summary",{text:"Показать полностью: итог по всем рынкам, профили, факты"}),(f.full.sections||[]).filter(z=>z?.title&&z.lines?.length).map(z=>s("div",{style:"margin-top:6px"},s("div.kicker",{},s("span",{text:z.title})),s("ul.facts",{},z.lines.map(N=>s("li",{text:N})))))):null,s("div.row",{style:"margin-top:8px"},s("button.btn.ghost.small",{type:"button","data-act":"report",title:"Разбор выглядит неправильно — сообщить разработчику"},"Сообщить об ошибке")),s("details",{"data-key":"facts",open:P.get("facts")||!1},s("summary",{text:`Данные, на которых стоит разбор (${f.facts?.length||0})`}),s("ul.facts",{},(f.facts||[]).map(z=>s("li",{},s("b",{text:z.id}),s("span",{},z.text," ",s("em",{text:`— ${z.source}`})))))),q(f.research),s("div.hint",{style:"margin-top:8px",text:f.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function q(r){return r?r.skipped==="plan"?s("div.hint",{style:"margin-top:8px",text:"Поиск превью, травм и судей в прессе — в тарифах «Макс» и VIP."}):r.sources?.length?s("div.hint",{style:"margin-top:8px"},`${r.note} Прочитано: `,r.sources.map((a,f)=>[f?", ":"",s("a",{href:a.url,target:"_blank",rel:"noopener",text:a.domain})])):r.note?s("div.hint",{style:"margin-top:8px",text:r.note}):null:null}function Y(r){let a=r.compare?.consensus||r.analysis?.result?.consensus||r.consensus;if(!a?.consensus||!r.line?.rows?.length)return null;let f=a.consensus.length===2&&r.line.rows.length===3;if(!f&&r.line.rows.length!==a.consensus.length)return null;let g=f?r.line.overtime:null,w=g?g.rows:f?[r.line.rows[0],r.line.rows[2]].map(j=>({...j,odd:null,fair:null})):r.line.rows,S=r.match?.sport==="mma",z=a.updated?new Date(a.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"",N=a.fair?.p?.length===a.consensus.length?a.fair.p:a.consensus,C=Xt(a,{sport:r.match?.sport||""});return s("div.card",{},s("div.kicker",{},s("span",{text:f?S?"Прогноз рынка · без ничьей":"Прогноз рынка · с овертаймом":"Прогноз рынка"}),s("span.badge",{text:C.who})),w.map((j,T)=>{let D=N[T],K=j.odd?j.odd*D-1:0,ee=Number.isFinite(j.fair)?(j.fair-D)*100:0;return s("div.prob",{},s("span.name",{text:j.name,title:j.name}),s("span.odd",{text:J(1/D),title:"Кэф без маржи по консенсусу"}),s("span.track",{},s("i",{style:`width:${Math.round(D*100)}%`}),s("u",{style:`left:${Math.round((j.fair||0)*100)}%`,title:"Шанс по линии этой конторы"})),s("span.pct",{},fe(D),K>.005?s("small",{text:`расхождение ${Lt(K)}`,title:`Кэф этой конторы выше цены рынка без маржи на ${Lt(K).slice(1)}. Это расхождение, а не доход.`}):Math.abs(ee)>=2?s(`small${ee>0?".neg":""}`,{text:`${Le(ee)} п.п. к рынку`,title:ee>0?"Шанс этого исхода у конторы больше, чем у рынка, — кэф ниже":"Шанс этого исхода у конторы меньше, чем у рынка"}):null))}),s("div.legend",{},s("span",{text:"шанс по консенсусу"}),f&&!g?null:s("span.model",{text:g?`шанс по рынку «${g.title}» этой конторы`:"шанс по линии этой конторы"})),s("div.hint",{style:"margin-top:8px",text:`${f&&S?"Ничьи в ММА — доли процента, поэтому рынок двухисходный; ничья этой конторы не сравнивается. ":f?g?"Победитель с учётом овертайма и буллитов: сравнивается с одноимённым рынком этой конторы, а не с трёхисходным. ":"Победитель с учётом овертайма и буллитов; ничья в основное время сюда не входит, поэтому с трёхисходным рынком конторы напрямую не сравнивается. ":""}${a.pinnacle?`Острый рынок ${a.pinnacle.map(J).join(" / ")}. `:""}${a.betfair?`Биржа ${a.betfair.map(J).join(" / ")}. `:""}Цены ${C.of} без маржи${z?`, обновлено в ${z}`:""}${a.stale?" (данные старше шести часов)":""}.${C.note?` ${C.note} Фаворит по нему выиграл 54% этих матчей.`:""}${w.some((j,T)=>j.odd&&j.odd*N[T]-1>.005)?` ${fr}`:""}`}))}let H=new Map;function te(r,a){let f=r.match?.live;if(!f||!["cs","dota"].includes(a.game)||f.score?.length!==2)return null;let g=f.score.map(Number),w=Number(a.bo)||3;if(g.some(N=>!Number.isFinite(N)||N<0)||Math.max(...g)>=Math.ceil(w/2))return null;let S=a.game==="cs"&&f.rounds?.length===2&&f.rounds.every(N=>/^[0-9]{1,2}$/.test(String(N)))?f.rounds.map(Number):null,z=`${a.p1}|${w}|${g}|${S}`;return H.has(z)||(H.size>50&&H.clear(),H.set(z,{...Tt({pre:a.p1,bo:w,maps:g,rounds:S,game:a.game}),bo:w,maps:g,rounds:S})),H.get(z)}function Q(r){let a=r.compare?.model||r.analysis?.result?.model||r.model;if(!a?.p1||!r.line?.rows?.length)return null;let f=r.line.rows.length===3&&(a.overtime||a.drawless);if(!f&&r.line.rows.length!==2)return null;let g=f?r.line.overtime:null,w=g?g.rows:f?[r.line.rows[0],r.line.rows[2]].map(K=>({...K,fair:null})):r.line.rows,S=te(r,a),z=S?[S.p,1-S.p]:[a.p1,a.p2],N=a.sport==="tennis"?`Рейтинги Линзы по покрытиям, форме, нагрузке и очным встречам (архив ATP/WTA, ${a.samples} матчей у менее опытного игрока)`:a.sport==="hockey"?`Рейтинги Линзы по матчам КХЛ: атака и оборона команд, дом, усталость (приложение КХЛ, 2023–2026; ${a.samples} игр у менее опытной команды)${a.regulation?`. Основное время: ${Math.round(a.regulation.p1*100)}% / ничья ${Math.round(a.regulation.px*100)}% / ${Math.round(a.regulation.p2*100)}%`:""}`:a.sport==="mma"?`Рейтинги Линзы по боям UFC: Elo с весом досрочных побед, форма, возраст, размах рук, простой (ESPN; ${a.samples} боёв в UFC у менее опытного бойца)`:a.sport==="basketball"?`Рейтинги Линзы по разнице очков, дому и усталости (НБА, Евролига, Еврокубок, АСВ, Серия А, Адриатическая лига, ВТБ, Лига чемпионов FIBA; ${a.samples} игр у менее опытной команды)`:a.game==="dota"?`Рейтинги Линзы по матчам, форме и очным встречам (bo3.gg, ${a.samples} ${ze(a.samples,"матч","матча","матчей")} у менее опытной команды)`:`Рейтинги Линзы по картам, форме и очным встречам (bo3.gg, ${a.samples} ${ze(a.samples,"карта","карты","карт")} у менее опытной команды)`,C=a.backtest,j=(C?.calibration||[]).filter(K=>[60,70,80].includes(K.threshold)),T=C?.labels?.[a.confidence],D=(T?`С подписью «${a.confidence}» на проверке сбывалось ${be(T.hit/100,1)} (${T.n} ${ze(T.n,"матч","матча","матчей")}). `:"")+(j.length?`На проверке ${C.test} сыгранных матчей: ${j.map(K=>`при уверенности ≥${K.threshold}% сбывалось ${K.hit}%`).join(", ")}`:C?`На проверке ${C.test} матчей угадано ${Math.round(C.acc*100)}%`:"Точность ещё измеряется");return s("div.card",{},s("div.kicker",{},s("span",{text:S?`Модель по счёту · bo${S.bo}`:f?a.drawless?"Прогноз модели · без ничьей":"Прогноз модели · с овертаймом":"Прогноз модели"}),s("span.badge",{text:S?`до матча: ${a.confidence}`:`уверенность: ${a.confidence}`})),w.map((K,ee)=>{let oe=z[ee],me=Number.isFinite(K.fair)?(oe-K.fair)*100:0;return s("div.prob",{},s("span.name",{text:K.name,title:K.name}),s("span.odd",{text:J(1/oe),title:"Кэф без маржи по модели"}),s("span.track",{},s("i",{style:`width:${Math.round(oe*100)}%`}),s("u",{style:`left:${Math.round((K.fair||0)*100)}%`,title:"Шанс по линии конторы"})),s("span.pct",{},fe(oe),Math.abs(me)>=3?s(`small${me>0?".pos":".neg"}`,{text:`${Le(me)} п.п. к линии`}):null))}),s("div.legend",{},s("span",{text:S?"шанс серии по счёту":"оценка модели"}),s("span.model",{text:"шанс по линии конторы"})),S?s("div.hint",{style:"margin-top:6px",text:`Счёт по картам ${S.maps.join(":")}${S.rounds?`, на карте ${S.rounds.join(":")} — шанс текущей карты ${fe(S.map??.5)}`:""}. До матча модель давала ${fe(a.p1)} / ${fe(a.p2)}.`}):null,ht(a,w),a.factors?.length?s("ul.facts",{style:"margin-top:8px"},a.factors.slice(0,a.sport==="mma"?12:4).map(K=>s("li",{},s("span",{text:K})))):null,s("div.hint",{style:"margin-top:8px",text:S?`Шанс по ходу матча пересчитывается из прогноза до матча и счёта: выигранные карты${a.game==="cs"?" и раунды":""} уточняют силу команд. ${a.game==="cs"?"Проверка на сыгранных сериях CS: при 1:0 в bo3 модель давала в среднем 82%, сбылось 83% (2 905 серий)":"Проверка на сыгранных сериях Dota: при 1:1 модель давала в среднем 53%, сбылось 55% (516 серий)"}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`:`${N}. ${D}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`}))}function U(r){let[a,f]=r.names,g=["0","15","30","40","Б"],w=r.tiebreak?r.points.join(":"):r.points.map(N=>g[Math.min(4,N)]||N).join(":"),S=r.sets.map(([N,C])=>`${N}:${C}`).concat(`${r.games[0]}:${r.games[1]}`).join(" "),z=r.serving==null?"":` · подаёт ${r.names[r.serving]}`;return s("div.card",{},s("div.kicker",{},s("span",{text:"Лайв по счёту"}),s("span.badge",{text:`${r.score.join(":")} по сетам · ${S} · ${w}${r.tiebreak?" (тай-брейк)":""}`})),r.names.map((N,C)=>{let j=r.probs[C],T=r.book?r.book[C]:null,D=r.compare&&Number.isFinite(T)?(j-T)*100:0;return s("div.prob",{},s("span.name",{text:N,title:N}),s("span.odd",{text:J(1/j),title:"Честный кэф на матч по счёту"}),s("span.track",{},s("i",{style:`width:${Math.round(j*100)}%`}),Number.isFinite(T)?s("u",{style:`left:${Math.round(T*100)}%`,title:"Шанс по цене этой конторы"}):null),s("span.pct",{},fe(j),Math.abs(D)>=3?s(`small${D>0?".pos":".neg"}`,{text:`${Le(D)} п.п. к цене`}):null))}),s("div.legend",{},s("span",{text:"шанс матча по счёту"}),r.book?s("span.model",{text:"шанс по цене этой конторы"}):null),s("ul.facts",{style:"margin-top:8px"},s("li",{},s("span",{text:`Текущий сет: ${a} ${fe(r.set[0])} (кэф ${J(1/r.set[0])}) · ${f} ${fe(r.set[1])} (${J(1/r.set[1])})`})),s("li",{},s("span",{text:`Текущий ${r.tiebreak?"тай-брейк":"гейм"}${z}: ${a} ${fe(r.game[0])} · ${f} ${fe(r.game[1])}`})),s("li",{},s("span",{text:`Очко на своей подаче (под довоенную силу): ${a} ${r.serve[0]}%, ${f} ${r.serve[1]}%; матч до ${r.bestOf===5?"трёх":"двух"} выигранных сетов.`}))),s("div.hint",{style:"margin-top:8px",text:`Счёт, очки и подача — лайв Fonbet. Довоенная сила: ${r.prior.note}.${r.compare?"":" Без довоенной цены оценка подстроена под текущую цену Fonbet — как сигнал против конторы её не используйте."} Проверено на 10 064 моментах матчей ATP/WTA 2025–2026 (после каждого сета): при оценке 80–85% сбылось 82,9%, 85–90% — 87,8%. Это расчёт, а не обещание.`}))}function re(r){let[a,f]=r.names,g=T=>T?J(T):"—",w=r.sport==="hockey"?"период":"тайм",S=`${r.minute}' · ${Math.min(r.period,r.periods)}-й ${w}`,z=[a,"Ничья",f],N=T=>T>0?`+${T}`:`${T}`,C=(T,D,K,ee,oe,me)=>D?.length?s("details",{"data-key":`live-${T}`,open:P.get(`live-${T}`)||!1},s("summary",{text:T}),s("ul.facts",{},D.map(Fe=>s("li",{},s("span",{text:`${oe(Fe)} — ${g(Fe[K])} · ${me(Fe)} — ${g(Fe[ee])}`}))))):null,j=r.red[0]||r.red[1]?` · удаления ${r.red.join(":")}`:"";return s("div.card",{},s("div.kicker",{},s("span",{text:"Лайв по счёту"}),s("span.badge",{text:`${r.score.join(":")} · ${S}${j}`})),z.map((T,D)=>{let K=r.probs[D],ee=r.book?r.book[D]:null,oe=r.compare&&Number.isFinite(ee)?(K-ee)*100:0;return s("div.prob",{},s("span.name",{text:T,title:T}),s("span.odd",{text:J(1/K),title:"Честный кэф по счёту"}),s("span.track",{},s("i",{style:`width:${Math.round(K*100)}%`}),Number.isFinite(ee)?s("u",{style:`left:${Math.round(ee*100)}%`,title:"Шанс по цене этой конторы"}):null),s("span.pct",{},fe(K),Math.abs(oe)>=3?s(`small${oe>0?".pos":".neg"}`,{text:`${Le(oe)} п.п. к цене`}):null))}),s("div.legend",{},s("span",{text:"шанс по счёту (основное время)"}),r.book?s("span.model",{text:"шанс по цене этой конторы"}):null),s("ul.facts",{style:"margin-top:8px"},s("li",{},s("span",{text:`Следующий гол: ${a} ${fe(r.nextGoal[0])} · не будет ${fe(r.nextGoal[1])} · ${f} ${fe(r.nextGoal[2])}. Ожидаемый итоговый тотал ≈${r.expTotal}.`})),r.bookLines?.total?s("li",{},s("span",{text:`Тотал ${r.bookLines.total.line}: Fonbet ${r.bookLines.total.odds.map(J).join(" / ")}, честно ${r.bookLines.total.fair.map(g).join(" / ")}`}),Math.abs(r.bookLines.total.gap)>=5?s(`small${r.bookLines.total.gap>0?".pos":".neg"}`,{text:` ${Le(r.bookLines.total.gap)} п.п. к «больше»`}):null):null),C("Тотал — честные кэфы",r.total,"over","under",T=>`больше ${T.line}`,T=>`меньше ${T.line}`),C("Фора — честные кэфы",r.handicap,"home","away",T=>`${a} ${N(T.line)}`,T=>`${f} ${N(-T.line)}`),s("div.hint",{style:"margin-top:8px",text:`Счёт, время${r.sport==="football"?" и удаления":""} — лайв Fonbet${r.clock==="timer"?"":" (время приблизительное)"}. Довоенная сила: ${r.prior.note}.${r.compare?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на ${r.sport==="hockey"?"1 407 играх НХЛ":"1 837 матчах 5 топ-лиг (11 тыс. точек)"}: при оценке 80–85% сбылось 82,5%. Это расчёт, а не обещание.`}))}function le(r,a,f,g){let w=r.bookLines;if(!w)return null;let S=N=>N>0?`+${N}`:`${N}`,z=(N,C,j,T)=>s("li",{},s("span",{text:`${N}: Fonbet ${C.map(J).join(" / ")}, честно ${j.map(D=>D?J(D):"—").join(" / ")}`}),g&&Math.abs(T)>=5?s(`small${T>0?".pos":".neg"}`,{text:` ${Le(T)} п.п. к первой стороне`}):null);return s("ul.facts",{style:"margin-top:8px"},w.handicap?z(`Фора ${a} ${S(w.handicap.line)} / ${f} ${S(-w.handicap.line)}`,w.handicap.odds,w.handicap.fair,w.handicap.gap):null,w.total?z(`Тотал ${w.total.line} больше / меньше`,w.total.odds,w.total.fair,w.total.gap):null)}function ue(r){let a=r.live;if(!a)return null;if(a.kind==="goals")return re(a);if(a.kind==="tennis")return U(a);if(a.error)return s("div.card",{},s("div.kicker",{},s("span",{text:"Лайв по счёту"})),s("div.hint",{text:a.error}));let[f,g]=a.names,w=D=>D?J(D):"—",S=a.book&&(a.prior.source==="line"||a.prior.source==="model"),z=a.left>0?`${a.period>a.format.periods?"ОТ":`${a.period}-я четв.`} · осталось ≈${Math.max(1,Math.round(a.left))} мин`:"конец игры",N=(D,K,ee,oe,me,Fe)=>K.length?s("details",{"data-key":`live-${D}`,open:P.get(`live-${D}`)||!1},s("summary",{text:D}),s("ul.facts",{},K.map(ot=>s("li",{},s("span",{text:`${me(ot)} — ${w(ot[ee])} · ${Fe(ot)} — ${w(ot[oe])}`}))))):null,C=D=>D>0?`+${D}`:`${D}`,j=a.quarter,T=j&&j.left>0?`${j.index}-я четверть (${j.score.join(":")}, осталось ≈${Math.max(1,Math.round(j.left))} мин): ${f} ${w(j.probs[0]?1/j.probs[0]:null)} · ничья ${w(j.draw?1/j.draw:null)} · ${g} ${w(j.probs[1]?1/j.probs[1]:null)}; разница ${j.expMargin>=0?f:g} ${Math.abs(j.expMargin).toFixed(1)}, тотал четверти ≈${j.projTotal}.`:"";return s("div.card",{},s("div.kicker",{},s("span",{text:"Лайв по счёту"}),s("span.badge",{text:`${a.score.join(":")} · ${z}`})),a.names.map((D,K)=>{let ee=a.probs[K],oe=a.book?a.book[K]:null,me=S&&Number.isFinite(oe)?(ee-oe)*100:0;return s("div.prob",{},s("span.name",{text:D,title:D}),s("span.odd",{text:J(1/ee),title:"Честный кэф по счёту"}),s("span.track",{},s("i",{style:`width:${Math.round(ee*100)}%`}),Number.isFinite(oe)?s("u",{style:`left:${Math.round(oe*100)}%`,title:"Шанс по цене этой конторы"}):null),s("span.pct",{},fe(ee),Math.abs(me)>=3?s(`small${me>0?".pos":".neg"}`,{text:`${Le(me)} п.п. к цене`}):null))}),s("div.legend",{},s("span",{text:"шанс по счёту (с ОТ)"}),a.book?s("span.model",{text:"шанс по цене этой конторы"}):null),le(a,f,g,S),s("ul.facts",{style:"margin-top:8px"},s("li",{},s("span",{text:`Ожидаемая итоговая разница: ${a.expMargin>=0?f:g} ${Math.abs(a.expMargin).toFixed(1)} (разброс ±${a.sd}). Тотал ≈${a.projTotal} (±${a.sdTotal}).`})),T?s("li",{},s("span",{text:T})):null),N("Фора — честные кэфы",a.handicap,"home","away",D=>`${f} ${C(D.line)}`,D=>`${g} ${C(-D.line)}`),N("Тотал матча — честные кэфы",a.total,"over","under",D=>`больше ${D.line}`,D=>`меньше ${D.line}`),N("Тотал четверти — честные кэфы",a.quarterTotal,"over","under",D=>`больше ${D.line}`,D=>`меньше ${D.line}`),s("div.hint",{style:"margin-top:8px",text:`Счёт и время — лайв Fonbet${a.clock==="timer"?"":" (время в четверти оценено по очкам — приблизительно)"}. Довоенная сила: ${a.prior.note}.${S?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на 8 923 играх Евролиги, Еврокубка и НБА: в перерыве при оценке 75–80% побеждали в 78% случаев. Это расчёт, а не обещание; задержка табло у конторы бывает до минуты.`}))}let pe=r=>r.analysis?.result?.decision||r.forecast||null;function ge(r){let a=r.line?.rows||[],f=r.compare?.consensus||r.analysis?.result?.consensus||r.consensus,g=f?.fair?.p?.length===a.length?f.fair.p:f?.consensus?.length===a.length?f.consensus:null;return{book:r.bookName||"",odds:a.map(w=>w.odd),fair:g||a.map(w=>w.fair),live:!!r.match?.live}}function Pe(r){let a=r.verdict;return a?.lines?.length?s("div.card",{},s("div.kicker",{},s("span",{text:"Итог"}),s("span.badge",{text:a.best?`расхождение ${Math.round(a.best.edge*100)}%`:"лучшей цены нет"})),s("ul.facts",{},a.lines.map(f=>s("li",{},s("span",{text:f})))),a.track?s("div.hint",{style:"margin-top:6px",text:a.track}):null,r.analysis.status!=="done"?s("div.hint",{style:"margin-top:6px",text:"Доводы «за» и главный риск появятся после «Разобрать матч»."}):null):null}function ht(r,a){let f=r.durations;if(r.sport!=="mma"||!f)return null;let g=S=>S?J(S):"—",w=a.map(S=>S.name);return s("div",{style:"margin-top:10px"},s("div.kicker",{},s("span",{text:"Честные кэфы"}),s("span.badge",{text:`${f.rounds} ${f.rounds===5?"раундов":"раунда"}`})),s("ul.facts",{},s("li",{},s("span",{text:`Победа: ${w[0]||"первый"} ${g(r.fair?.p1)} · ${w[1]||"второй"} ${g(r.fair?.p2)}`})),f.lines.map(S=>s("li",{},s("span",{text:`Тотал ${String(S.line).replace(".",",")} раунда: больше ${g(S.over)} · меньше ${g(S.under)}`}))),s("li",{},s("span",{text:`Дойдёт до решения: да ${g(f.decision.yes)} · нет ${g(f.decision.no)}`})),s("li",{},s("span",{text:`Конец боя: 1-й раунд ${Math.round(f.r1*100)}%, 2-й ${Math.round(f.r2*100)}%, позже ${Math.round(f.r3*100)}%, решение ${Math.round(f.dec*100)}%`}))),s("div.hint",{text:"Честные кэфы — по модели Линзы, справочно: она не точнее рыночной цены, и расхождение кэфа конторы с ними — не доход. Длительность считается по всем боям бойцов в UFC и их весовой; проверка на 565 боях: точнее, чем средние цифры по весовой."}))}function gt(r){let a=r.facts?.cs||r.analysis?.result?.cs||null,f=r.compare?.model||r.analysis?.result?.model||r.model;if(!a&&(r.match?.sport||f?.game)!=="cs")return null;let g=ur(a,f?.untrusted?null:f);if(!g)return null;let w=S=>S==="home"?r.match.home:r.match.away;return s("div.card",{},s("div.kicker",{},s("span",{text:"Карты серии"}),s("span.badge",{text:g.known?"вето bo3.gg":"до вето: вероятные карты"})),s("ul.facts",{},g.rows.map(S=>s("li",{},s("span",{text:`${S.n}. ${S.title}${g.known?` — ${S.pick?`пик ${w(S.pick)}`:"решающая"}`:""}${S.p!=null?` · ${r.match.home} ${fe(S.p)}`:""}${S.strong.length?` · сильная у ${S.strong.map(w).join(" и ")}`:""}`})))),g.bans.length?s("div.hint",{style:"margin-top:6px",text:`Убраны: ${g.bans.map(S=>`${S.title}${S.team?` (${w(S.team)})`:""}`).join(", ")}.`}):null,s("div.hint",{style:"margin-top:6px",text:`${g.known?"":"Пики и баны появятся перед матчем. "}Шанс на карте — по рейтингам карт модели Линзы, справочно; в «Итог» карты не идут.`}))}function Be(r){let f=((r.compare?.model||r.analysis?.result?.model||r.model)?.profiles||[]).filter(g=>g?.lines?.length);return f.length?s("div.card",{},s("div.kicker",{},s("span",{text:"Профили"}),s("span.badge",{text:"модель Линзы"})),f.map((g,w)=>s("details",{"data-key":`profile-${w}`,open:P.get(`profile-${w}`)??w===0},s("summary",{text:g.name}),s("ul.facts",{},g.lines.map(S=>s("li",{},s("span",{text:S})))))),s("div.hint",{style:"margin-top:8px",text:"Из рейтингов Линзы по открытым данным (ESPN, архив ATP/WTA, результаты Fonbet, bo3.gg). Это описание, а не прогноз."})):null}function et(r){let a=r.facts;if(!a?.facts?.length)return null;let f=a.facts.filter(z=>/травм|отсутств|не играет|стенд-ин|замен|дисквалиф/i.test(z.text)),g=a.facts.filter(z=>!f.includes(z)&&/состав|стартов/i.test(z.text)),w=a.facts.filter(z=>!f.includes(z)&&!g.includes(z)),S=(z,N,C)=>N.length?s("details",{"data-key":`facts-${z}`,open:C||P.get(`facts-${z}`)||!1},s("summary",{text:`${z} (${N.length})`}),s("ul.facts",{},N.map(j=>s("li",{},s("span",{text:j.text}))))):null;return s("div.card",{},s("div.kicker",{},s("span",{text:"Составы, травмы, форма"}),s("span.badge",{text:a.source||a.facts[0].source||"источник"})),S("Травмы и отсутствующие",f,!0),S("Составы",g,!0),S("Форма, таблица, очные встречи",w,!f.length&&!g.length),s("div.hint",{style:"margin-top:8px"},"Факты из открытых данных, как есть. ",a.url?s("a",{href:a.url,target:"_blank",rel:"noopener",text:"Источник"}):null))}let ze=(r,a,f,g)=>{let w=r%100,S=r%10;return w>10&&w<20?g:S===1?a:S>=2&&S<=4?f:g},$e=r=>(r.erid?["Реклама",r.legal,`erid ${r.erid}`].filter(Boolean).join(" · "):["Партнёрская ссылка",r.legal].filter(Boolean).join(" · "))+" · 18+",W=(r,a)=>s("a.btn.ghost.small",{href:r.go?`${r.go}?s=panel`:r.url,target:"_blank",rel:"noopener sponsored"},ce("link",13),a||`Открыть у ${r.name}`),ae=r=>r.code?s("button.btn.ghost.small",{type:"button","data-act":"copy-code","data-arg":r.code,title:r.bonus||"Скопировать промокод"},`Промокод ${r.code}`):null;function Ie(r){let a=(r.partners||[]).filter(f=>f.url||f.code);return a.length?s("div.card.soft",{},s("div.kicker",{},s("span",{text:a.length===1?`Промокод ${a[0].name}`:"Промокоды контор"})),a.map(f=>s("div.partner",{},s("div.partner-text",{},s("b",{text:f.name}),f.bonus?s("span",{text:` — ${f.bonus}`}):null),s("div.partner-links",{},ae(f),f.url?W(f):null),s("div.hint",{text:$e(f)})))):null}function hn(r,a={}){if(r.status==="idle")return null;if(r.status==="loading")return s("div.card",{},s("div.kicker",{},s("span",{text:"Цены других контор"})),s("div.hint",{text:"Смотрю открытые линии…"}));let f=r.labels||[];if(!r.rows?.length)return s("div.card",{},s("div.kicker",{},s("span",{text:"Цены других контор"})),s("div.hint",{text:r.note||"В открытых линиях этой пары нет."}));let g=f.map((T,D)=>Math.max(...r.rows.map(K=>K.odds[D]||0))),w=Object.fromEntries((a.partners||[]).map(T=>[T.id,T])),S=T=>!a.noPartners&&T.book&&T.book!==a.bookId&&!T.sharp&&w[T.book]||null,z=r.rows.find(T=>T.here)||r.rows[0],C=f.map((T,D)=>{let K=z?.odds?.[D],ee=r.rows.filter(oe=>oe!==z&&!oe.sharp&&oe.odds[D]).sort((oe,me)=>me.odds[D]-oe.odds[D])[0];return!K||!ee||ee.odds[D]<=K?null:{label:T,row:ee,odd:ee.odds[D],mine:K,gain:ee.odds[D]-K}}).filter(Boolean).sort((T,D)=>D.gain-T.gain)[0],j=r.rows.map(S).filter(Boolean);return s("div.card",{},s("div.kicker",{},s("span",{text:"Цены других контор"}),s("span.badge",{text:"лучшая цена выделена"})),s("table",{},s("tr",{},s("th",{text:"Контора"}),f.map(T=>s("th",{text:T}))),r.rows.map(T=>{let D=S(T);return s("tr",{},s("td.name",{title:T.sharp?"Цена с мирового рынка, для сравнения":""},T.name,D?s("div.partner-links",{},D.url?W(D):null,ae(D)):null),T.odds.map((K,ee)=>s(`td${K&&K===g[ee]&&r.rows.length>1?".best":""}`,{text:K?J(K):"—"})))})),C&&J(C.odd)!==J(C.mine)&&!a.noPartners?s("div.gain",{text:`На «${C.label}» лучшая цена — ${J(C.odd)} против ${J(C.mine)}: маржа на этом исходе меньше.`}):null,j.length?s("div.hint",{style:"margin-top:6px",text:[...new Set(j.map($e))].join(" ")}):null,r.note?s("div.hint",{style:"margin-top:8px",text:r.note}):null)}function gn(r){let a=[],f=(w,S,z)=>a.push(s("dt",{text:w}),s(`dd${z?"."+z:""}`,{text:S}));Number.isFinite(r.fair)?(f("Шанс по линии без маржи",be(r.fair,1)),f("Кэф без маржи конторы",J(r.fairOdd)),f("Маржа конторы в этом рынке",be(r.margin,1))):f("Заложено в кэфе (с маржой)",be(1/r.odd,1)),Number.isFinite(r.model)&&(f("Оценка модели",be(r.model,1)),f("Ожидание на рубль по модели",`${Le(r.ev*100)}%`,r.ev>.005?"pos":r.ev<-.005?"neg":"")),r.best&&f(`Лучшая цена: ${r.best.name}`,J(r.best.odd),r.best.odd>r.odd?"pos":"");let g=!r.noPartners&&r.best?.partner&&(r.best.partner.url||r.best.partner.code)?r.best.partner:null;return s(r.isChoice?"div.card":"div.card.accent",{},s("div.kicker",{},s("span",{text:r.market}),s("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},ce("close",13))),s("div.pick-head",{},s("span.big",{text:J(r.odd)}),s("span.what",{text:r.label,title:r.label})),s("dl.kv",{},a),r.note?s("div.hint",{style:"margin-top:8px",text:r.note}):null,r.isChoice?null:s("div.row",{style:"margin-top:10px"},s("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!r.canAdd,title:r.canAdd?"":"Нужен рынок с полным набором исходов"},ce("plus",14),r.inExpress?"Уже в экспрессе":"В расчёт экспресса")),g?s("div.partner",{style:"margin-top:10px"},s("div.partner-links",{},g.url?W(g):null,ae(g)),s("div.hint",{text:$e(g)})):null)}function bn(r){let a=(f,g)=>s("div",{style:"min-width:0"},s("b",{text:f,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),g.map(w=>s("div",{style:"display:flex;justify-content:space-between;gap:8px"},s("span",{text:w.nick}),s("span",{style:"color:var(--lz-muted)",text:w.numbers.slice(0,2).join(" / ")}))));return s("div.card",{},s("div.kicker",{},s("span",{text:"Игроки сейчас"}),s("span.badge",{text:"с табло конторы"})),s("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},a(r.homeName,r.home),a(r.awayName,r.away)))}function Bt(r,a){return s("div.card",{},s("div.kicker",{},s("span",{text:"Статистика команд"}),s("span.badge",{text:"со страницы конторы"})),s("table",{},s("tr",{},s("th",{text:"Показатель"}),s("th",{text:a.home}),s("th",{text:a.away})),r.rows.map(f=>s("tr",{},s("td",{text:f.label}),s("td",{text:f.home}),s("td",{text:f.away})))),r.samples?.length===2?s("div.hint",{style:"margin-top:8px",text:`Выборка: ${r.samples[0]} и ${r.samples[1]} карт.`}):null)}function It(r){let a=[],f=r.match?pe(r):null,g=r.match?ge(r):{},w=an(f,{live:g.live});if(r.pick&&a.push(gn({...r.pick,noPartners:w,isChoice:w&&!!r.pick.choice})),!r.match)return a.push(s("div.empty",{},s("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),a;a.push(I(r.match,r.facts?.cs));let S=xr(gr(f,g));S&&a.push(S);let z=ue(r);z&&a.push(z);let N=r.analysis.status==="loading";a.push(s("div.row",{},s("button.btn",{type:"button","data-act":"analyze",disabled:N},ce("spark"),N?"Разбираю…":r.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),s("button.btn.ghost",{type:"button","data-act":"compare",disabled:r.compare.status==="loading"},ce("scale"),"Сравнить цены"))),r.quota&&a.push(s("div.hint.center-text",{text:r.quota}));let C=E(r);C&&r.analysis.status!=="done"&&a.push(C);let j=hn(r.compare,{...r,noPartners:w});j&&a.push(j);let T=`more:${r.match.key||`${r.match.home}|${r.match.away}`}`,D=kr(T,P.has(T)?P.get(T):!!r.more,[f?$r(g.live?{...f,choice:null}:f):null,r.esports?bn(r.esports):null,r.match.stats?.rows?.length?Bt(r.match.stats,r.match):null,r.line?G(r.line):null,Y(r),Q(r),gt(r),Pe(r),Be(r),et(r),C&&r.analysis.status==="done"?C:null,w?null:Ie(r)]);return D&&a.push(D),a}function jt(r){let a=r.margins;if(!a)return null;let f=[s("div",{},`Сегодня вы открыли ${a.n} ${ze(a.n,"матч","матча","матчей")} до начала: в основной исход ${r.bookName||"контора"} закладывает в среднем `,s("b",{text:be(a.here,1)})," маржи.")];return a.best?(f.push(s("div",{style:"margin-top:6px"},`На тех же ${a.best.n} ${ze(a.best.n,"матче","матчах","матчах")} у ${a.best.name} — `,s("b",{text:be(a.best.there,1)}),` против ${be(a.best.here,1)} здесь: с каждой ставки вы отдавали бы конторе меньше примерно на ${((a.best.here-a.best.there)*100).toFixed(1)} п.п.`)),a.partner&&f.push(s("div.partner-links",{style:"margin-top:8px"},a.partner.url?W(a.partner):null,ae(a.partner)),s("div.hint",{text:$e(a.partner)}))):f.push(s("div.hint",{style:"margin-top:6px",text:"Нажмите «Сравнить цены» на странице матча — Линза запомнит маржу других контор на тех же матчах и покажет, где отдаёте меньше."})),s("div.card",{},s("div.kicker",{},s("span",{text:"Сколько маржи вы отдаёте"}),s("span.badge",{text:"сегодня"})),...f)}function xn(r){let a=r.scan,f=jt(r);return a?.rows?.length?[f,s("div.card",{},s("div.kicker",{},s("span",{text:a.title}),s("span.badge",{text:`средняя маржа ${be(a.average,1)}`})),s("table",{},s("tr",{},s("th",{text:a.first}),s("th",{text:"Фаворит"}),s("th",{text:"Маржа"})),a.rows.map(g=>s("tr.click",{"data-act":"scan-go","data-arg":String(g.index),title:"Показать на странице"},s("td.name",{},g.name,g.sub?s("span.sub",{text:g.sub}):null),s("td",{},g.fav,s("span.sub",{text:be(g.favPct)})),s(`td${g.low?".best":""}`,{text:be(g.margin,1)})))),s("div.hint",{style:"margin-top:8px",text:a.note}))]:[f,s("div.empty",{},s("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function $n(r){let a=r.express;if(!a.legs.length)return[s("div.empty",{},s("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда — или выберите исходы в «Линии» Линзы (кнопка в шапке панели). Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let f=a.stats;return[s("div.card",{},s("div.kicker",{},s("span",{text:`Экспресс · ${a.legs.length}`}),s("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},ce("trash",13),"Очистить")),a.legs.map(g=>s("div.leg",{},s("div.t",{},s("b",{text:g.label,title:g.label}),s("span",{text:g.title,title:g.title})),s("span.o",{text:J(g.odd)}),s("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":g.id,title:"Убрать",style:"width:24px;height:24px"},ce("close",13))))),f?s("div.card.soft",{},s("dl.kv",{},s("dt",{text:"Итоговый коэффициент"}),s("dd",{text:J(f.odd)}),s("dt",{text:"Шанс, что сыграют все исходы (без маржи)"}),s("dd",{text:be(f.chance,1)}),s("dt",{text:"Кэф без маржи"}),s("dd",{text:J(f.fairOdd)}),s("dt",{text:"Маржа конторы на всём экспрессе"}),s("dd.neg",{text:be(f.margin,1)})),s("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Один исход на матч: другой исход того же матча заменяет прежний. Экспресс общий с Линзой в боковой панели."})):null]}function Dt(r){let a=r.settings,f=(g,w,S)=>s("div.seg",{},S.map(([z,N])=>s(`button${w===z?".on":""}`,{type:"button","data-act":g,"data-arg":z,text:N})));return[s("div.card",{},s("div.field",{},s("label",{text:"Отметки на странице"}),f("set-overlay",a.overlay,[["picks","Выбор"],["all","Все шансы"],["off","Выкл"]]),s("div.hint",{text:"Рамка — только на исходе «Выбора Линзы» или «Прогноза Линзы» на странице матча и только при уверенности средней и выше. «Все шансы» — число на каждом исходе: шанс по линии без маржи конторы."})),s("div.field",{},s("label",{text:"Тема"}),f("set-theme",a.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]]))),s("div.card",{},s("div.kicker",{},s("span",{text:"Разбор матчей"}),s(`span.badge${a.ready?".pos":""}`,{text:a.ready?"подключён":"не подключён"})),a.proxy?s("div.field",{},s("label",{text:"Доступ"}),f("set-mode",a.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,a.mode==="license"&&a.proxy?s("div.field",{},s("label",{for:"lz-license",text:"Лицензионный ключ"}),s("input",{type:"text",id:"lz-license",placeholder:a.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),s("div.row",{},s("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),a.licenseMask?s("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),s("div.hint",{},[a.licenseMask?`Ключ ${a.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",a.plan,a.usage].filter(Boolean).join(" "),o.bot&&!a.licenseMask?[" ",s("a",{href:o.bot,target:"_blank",rel:"noopener",text:"Получить ключ «Про»"})]:null)):s("div.field",{},s("label",{for:"lz-key",text:"API-ключ Clodex"}),s("input",{type:"password",id:"lz-key",placeholder:a.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),s("div.row",{},s("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),a.hasKey?s("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),s("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${a.usage}`}))),s("div.card.soft",{},s("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной.")),s("div.card.soft",{},s("div.kicker",{},s("span",{text:pr})),dr(r.earnLinks).map(g=>s("div.hint",{text:g})))]}function tt(r){R=r;let a=JSON.stringify(r);if(a===k)return;k=a;for(let N of d.querySelectorAll("details[data-key]"))P.set(N.dataset.key,N.open);let f=d.scrollTop;x.textContent=r.bookName?`· ${r.bookName}`:"",l.classList.toggle("off",r.settings.overlay==="off"),h.replaceChildren(ce(r.theme==="dark"?"sun":"moon")),b.replaceChildren(ce(r.settings.overlay==="off"?"eyeOff":"eye")),b.classList.toggle("on",r.settings.overlay!=="off"),$.classList.toggle("on",r.tab==="settings"),$.dataset.arg=r.tab==="settings"?r.backTab:"settings";let g=[["match","Матч"],["scan","Маржа"],["express","Экспресс"]];u.replaceChildren(...g.map(([N,C])=>s(`button.tab${r.tab===N?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":N},C,N==="express"&&r.express.legs.length?s("span.count",{text:String(r.express.legs.length)}):null)));let w=r.tab==="settings"?Dt(r):r.tab==="scan"?xn(r):r.tab==="express"?$n(r):It(r),S=r.update?s("div.card.soft.update",{},s("b",{text:`Вышла Линза ${r.update.version}`})," — ",r.update.url?s("a",{href:r.update.url,target:"_blank",rel:"noopener",text:"скачать архив на сайте"}):"архив на сайте Линзы"," и заменить папку расширения."):null,z=r.whatsnew?.changes?.length&&r.tab!=="settings"?s("div.card.soft.update",{},s("b",{text:`Линза обновилась до ${r.whatsnew.version}`}),s("ul.facts",{style:"margin-top:6px"},r.whatsnew.changes.flatMap(N=>N.items).slice(0,6).map(N=>s("li",{},s("span",{text:N})))),s("div.row",{style:"margin-top:8px"},s("button.btn.ghost.small",{type:"button","data-act":"whatsnew-ok"},"Понятно"))):null;d.replaceChildren(...[S,z,...w].filter(Boolean)),d.scrollTop=f,m.replaceChildren(s("span",{text:"18+ · Это расчёт, а не совет ставить. Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function kn(r){i.setAttribute("data-theme",r)}function bt(){_.hidden=!1,t.opened?.()}function Ue(){_.hidden=!0}function xt(){_.hidden?bt():Ue()}function nt(r){r?.fab&&B(c,r.fab.left,r.fab.top),r?.panel&&B(_,r.panel.left,r.panel.top)}let $t=0;function p(r){n.querySelector(".toast")?.remove();let a=s("div.toast",{text:r,role:"status"});n.appendChild(a),clearTimeout($t),$t=setTimeout(()=>a.remove(),2600)}return{render:tt,setTheme:kn,open:bt,close:Ue,toggle:xt,restore:nt,toast:p,shadow:n,rect:()=>_.hidden?null:_.getBoundingClientRect(),get isOpen(){return!_.hidden},get view(){return R}}}var yr="Расширение обновилось. Обновите эту вкладку (F5).";function Sa(e){return/signal timed out|timeout|timed out/i.test(e)?"Сервер долго не отвечает — нажмите ещё раз.":/failed to fetch|networkerror|load failed|network request failed/i.test(e)?"Нет связи с сервером Линзы — проверьте интернет.":e}function qe(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function ie(e,t={}){if(!qe())return{ok:!1,error:yr,code:"reload"};try{return await chrome.runtime.sendMessage({type:e,...t})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(o){let i=String(o?.message||o);return/context invalidated/i.test(i)||!qe()?{ok:!1,error:yr,code:"reload"}:/message port closed|receiving end does not exist/i.test(i)?{ok:!1,error:"Связь с расширением прервалась — нажмите ещё раз.",code:"retry"}:{ok:!1,error:Sa(i)}}}function vr(e){if(qe())try{chrome.runtime.onMessage.addListener(t=>{e(t)})}catch{}}async function Zn(e){if(!qe())return{};try{return await chrome.storage.local.get(e)}catch{return{}}}function Oe(e){if(qe())try{chrome.storage.local.set(e)}catch{}}var Mr=(e=Date.now())=>new Date(e).toISOString().slice(0,10);function ln(e,t=Date.now()){return e&&e.day===Mr(t)&&e.items&&typeof e.items=="object"?e:{day:Mr(t),items:{}}}function Sr(e,{key:t,book:o,margin:i}){if(!t||!Number.isFinite(i)||i<=0||i>.5)return!1;let n=Math.round(i*1e4)/1e4,l=e.items[t];return l&&l.here===n&&l.book===o?!1:(e.items[t]={book:o,here:n,others:l?.others||{}},!0)}function zr(e,t,o){let i=e.items[t];if(!i)return!1;let n=!1;for(let l of o||[]){if(l.here||l.sharp||!l.odds?.length||l.odds.some(d=>!(d>1)))continue;let c=De(l.odds);if(c.kind!=="full"||!(c.margin>0))continue;let u=Math.round(c.margin*1e4)/1e4;i.others[l.name]!==u&&(i.others[l.name]=u,n=!0)}return n}function Nr(e,t){let o=Object.values(e?.items||{}).filter(c=>c.book===t);if(!o.length)return null;let i=c=>c.reduce((u,d)=>u+d,0)/c.length,l=[...new Set(o.flatMap(c=>Object.keys(c.others||{})))].map(c=>{let u=o.filter(d=>Number.isFinite(d.others?.[c]));return u.length>=2?{name:c,n:u.length,there:i(u.map(d=>d.others[c])),here:i(u.map(d=>d.here))}:null}).filter(Boolean).sort((c,u)=>c.there-u.there);return{n:o.length,here:i(o.map(c=>c.here)),best:l[0]||null,others:l}}var za=[{version:"1.0.25",items:["Шанс в панели и на плашке у кнопки исхода печатается одинаково. Если точный шанс ниже порога уровня, число не доходит до порога: 69,99% — это «69%», а не «70%».","Так же считаются шансы в списке контор, в строках про счёт и в подсказке на кнопке, а в верху разбора — «честная цена» и «шанс другого исхода».","Сумма напечатанных шансов в списке может дать 99%: до 100 числа не добираются. Сами расчёты и прогнозы не менялись."]},{version:"1.0.24",items:["Вкладки «Выше рынка» больше нет. Подборка расхождений по всем матчам читалась как подсказка, где ставить. Дохода по таким ценам проверка Линзы не показала.","В карточке матча разница между кэфом конторы и ценой рынка без маржи теперь называется «расхождение». Она без цвета и со сноской «это не доход». Число считается так же, как раньше.","«Цены других контор» показывают, у какой конторы кэф на исход выше, а маржа на нём меньше. В рубли разница больше не пересчитывается, поле суммы в настройках убрано."]},{version:"1.0.23",items:["«Выбор Линзы» в каждом разборе до матча: один исход с честным шансом и уровнем уверенности, даже когда уверенного прогноза нет. «Прогноз Линзы» — как прежде, только от 70%.","Разбор в панели — сжатый: сверху выбор или прогноз, «Почему», «Против» и цена одной строкой; остальное — в «Подробном разборе», он свёрнут.","Рамка на кнопке исхода конторы — только у исхода выбора или прогноза при уверенности от средней; при низкой уверенности, в лайве и в списках матчей рамки нет.","Если выбор сменился до начала матча, в карточке видно, каким он был и почему изменился. В «Уверенном экспрессе» кнопки «Выше шанс» и «Выше кэф».","Подпись рынка — по виду спорта: у CS, тенниса и КХЛ «2 конторы» (Fonbet и Бетсити без маржи), у футбола — сколько контор и есть ли биржа."]},{version:"1.0.22",items:["Линза в боковой панели браузера: кнопка «Линия и экспресс» в окне расширения и значок в шапке панели на сайте конторы. В Firefox — сайдбар, в Яндекс.Браузере — отдельная вкладка.","«Линия»: матчи ближайших 36 часов по видам спорта с кэфами Fonbet и шансом без маржи, бейджи «N контор» и «уверенный прогноз». Нажмите на кэф — исход уйдёт в экспресс.","Экспресс общий для Линзы и панели на сайте конторы. Один исход на матч: другой исход того же матча заменяет прежний; не больше 15 исходов.","«Уверенный экспресс» из прогнозов с честным шансом от 70% добавляется одной кнопкой; «Анализ экспресса» показывает текущую цену, честный шанс и прогноз Линзы по каждому исходу."]},{version:"1.0.19",items:["У «Прогноза Линзы» появился уровень. Прогноз — только при честном шансе выбранного рынка от 70% (уверенность высокая); при 60–70% — «Склоняемся», ниже — «Уверенного прогноза нет».","Рынок прогноза выбирается тот, где уверенность есть: победа, «не проиграет», тотал, счёт по сетам или картам. Фаворит с шансом 45% прогнозом больше не называется.","Под прогнозом — «Против» (доводы другой стороны) и «Осторожно» (что понизило уровень: линия ушла против, цена старше 6 часов, стенд-ин, факты тянут к сопернику).","Каждый показанный прогноз записывается с уровнем до матча и закрывается по результату; сбываемость по уровням — на странице «Точность» и в профиле приложения.","Рамка на кнопке исхода конторы — только при честном шансе от 60%; на матчах-монетках подсветки нет."]},{version:"1.0.18",items:["Шанс без маржи считается точнее: прежний способ завышал аутсайдеров (на 25 тыс. матчей исходы с шансом до 10% сбывались в 5%, а «обещали» 7,5%). Фавориты чуть выше, аутсайдеры ниже.","«Итог» больше не называет лучшей ценой аутсайдера с шансом меньше 15%: у таких кэфов погрешность расчёта больше перевеса. Такой вариант показывается отдельной строкой."]},{version:"1.0.17",items:["В настройках панели и в окне расширения — «Как Линза зарабатывает»: платные тарифы и партнёрские ссылки контор. На сравнение цен ссылки не влияют."]},{version:"1.0.16",items:["Новый адрес Линзы — linzabet.ru: сайт, мини-приложение и сервер разборов. Если он вдруг недоступен, расширение само переходит на запасной.","В разборе — «Прогноз Линзы»: кто, как и почему, до матча и в лайве.","Лайв CS и Dota: счёт карт и раундов с панели уходит в разбор, сервер учитывает, кто забирает текущую карту."]},{version:"1.0.15",items:["Разбор на сервере видит тоталы и форы этой страницы: в теннисе «Показать полностью» — итог и по геймам, по цене самой конторы."]},{version:"1.0.14",items:["«Лучшая цена» — только если цена выше честной на 3–12%. Больше 12% — строка «Проверьте данные»: чаще это ошибка в данных, чем подарок конторы.","Модель Линзы пока справочно: «по модели интересная цена от…». Перевес считается по ценам рынка, пока модель не докажет, что она точнее.","Карты в CS и Dota временно убраны из итога: вернём после проверки на честных ценах."]},{version:"1.0.13",items:["Под разбором — «Показать полностью»: итог по всем рынкам, доводы, как может пойти игра, профили и факты.","Итог по рынкам этой страницы: в теннисе — тотал и фора геймов, в CS и Dota — карты, по цене самой конторы на победу."]},{version:"1.0.12",items:["Под разбором — «Сообщить об ошибке»: что сломалось, уходит разработчику без личных данных.","Итог не строится по модели, которой нельзя верить как цене: если она сильно расходится с рынком или у неё мало матчей в архиве."]},{version:"1.0.11",items:["Разобрать матч: разбор идёт на сервере — видно, что происходит (цены, новости, модель), и он не обрывается на «Обновите вкладку».","Разбор работает на всех конторах: если матча нет в линии Fonbet, Линза разбирает по ценам страницы и свежим новостям.","Новости, травмы и составы из прессы — в разборе для всех тарифов; у «Макс» и VIP поиск подробнее.","Бесплатные 3 разбора в день считаются для вашего браузера, а не для всех с одного адреса; истёкший ключ не отключает бесплатные разборы.","Исправлено: счётчик «Разборов сегодня» больше не пропадает, ошибки связи — понятными словами."]},{version:"1.0.10",items:["Исправлено: в доводах моделей имена команд и игроков — как на странице конторы."]},{version:"1.0.9",items:["Лайв тенниса по счёту: шанс матча, текущего сета и гейма от очков и подачи.","Прогноз модели для КХЛ: атака и оборона команд, исход основного времени и победитель с ОТ; на проверке при уверенности от 65% сбылось 70%.","Итог: форы футбола и хоккея против честной цены по Fonbet."]},{version:"1.0.8",items:["Лайв по счёту для футбола и хоккея: шанс исхода основного времени, следующий гол, тоталы и форы по счёту, времени и удалениям; точное игровое время.","Итог для футбола и хоккея: тоталы этой конторы против честной цены по Fonbet без маржи на любой линии.","Журнал итогов: точность прошлых итогов — в карточке и в приложении."]},{version:"1.0.7",items:["ММА (UFC): прогноз модели по бойцам — возраст, размах рук, форма, простой; как скорее всего закончится бой и честные кэфы на тоталы раундов и решение судей; прогноз рынка 5+ контор.","Итог: в конце карточек — лучшая цена против честной, перевес и размер суммы, доводы и главный риск из разбора; каждый итог записывается и потом сверяется с результатом — точность видна в приложении.","Баскетбол: фора и тотал по модели — ожидаемая разница очков и тотал с разбросом, честные кэфы основных линий конторы в «Итоге».","Теннис: подача и приём в модели — шанс матча по доле выигранных очков на своей подаче и на приёме соперника.","Исправлено: бойцы и теннисисты в формате «Фамилия И.» находятся, если полное имя из трёх слов.","Одна палитра у панели, попапа, мини-приложения и сайта; в тёмной теме приложения — светлый акцент."]},{version:"1.0.6",items:["Лайв по счёту: в баскетболе — честный шанс, фора и тотал против цены конторы; в CS и Dota — шанс серии по счёту карт и раундов текущей карты.","Профили участников: теннисисты (покрытия, подача и приём, нагрузка, последние матчи), команды баскетбола и киберспорта (динамика рейтинга, форма, состав с рейтингом каждого игрока).","Баскетбол: Еврокубок, АСВ, Серия А, Адриатическая лига, Единая лига ВТБ и Лига чемпионов FIBA — в модели и в фактах.","Футбол: ход матча и судьи (УЕФА) в карточке «Составы, травмы, форма».","Киберспорт: у подписи уверенности — как часто такие прогнозы сбывались на проверке; модель Dota точнее.","Вкладка «Маржа»: сколько маржи вы отдаёте этой конторе по открытым сегодня матчам и сколько отдавали бы у других контор.","Новая версия подхватывается сама, когда вы заменили файлы в папке расширения."]},{version:"1.0.5",items:["Карточка «Составы, травмы, форма» на странице матча: травмы по именам, составы, форма и очные встречи (ESPN, bo3.gg) — без разбора и без лимита.","Подсказка в панели, когда на сайте вышла новая версия.","Dota 2: точнее вероятность победы в серии до двух побед."]}];function _r(e,t){let o=String(e||"").split(".").map(Number),i=String(t||"").split(".").map(Number);for(let n=0;n<Math.max(o.length,i.length);n++){let l=(o[n]||0)-(i[n]||0);if(l)return l>0}return!1}function Ar(e,t){return za.filter(o=>_r(o.version,e)&&!_r(o.version,t))}var Na=e=>{let t=e<0?-1:1,o=Math.abs(e),i=1/(1+.3275911*o);return t*(1-((((1.061405429*i-1.453152027)*i+1.421413741)*i-.284496736)*i+.254829592)*i*Math.exp(-o*o))},Yn=e=>.5*(1+Na(e/Math.SQRT2));function Or(e,t,o){if(!(Math.abs(o-Math.round(o))<1e-9)){let c=1-Yn((o-e)/t);return{win:c,push:0,lose:1-c}}let n=1-Yn((o+.5-e)/t),l=Yn((o-.5-e)/t);return{win:n,push:Math.max(0,1-n-l),lose:l}}function _a(e,t,o){let i=Or(e,t,-o);return{home:i.win,away:i.lose,push:i.push}}function Aa(e,t,o){let i=Or(e,t,o);return{over:i.win,under:i.lose,push:i.push}}function Er(e,{handicap:t=null,total:o=null}={},i=["Хозяева","Гости"]){let n=e?.lines;if(!n||!Number.isFinite(n.margin)||!(n.sigma>0))return[];let l=[],c=m=>m>0?`+${m}`:`${m}`,u=(m,x)=>m/(1-x||1),d=(m,x)=>1/m/(1/m+1/x);if(t&&Number.isFinite(t.line)&&Math.abs(t.line)<60&&t.home>1&&t.away>1){let m=_a(n.margin,n.sigma,t.line);Math.abs(u(m.home,m.push)-d(t.home,t.away))<=.3&&l.push({label:`Фора ${i[0]} ${c(t.line)}`,odd:t.home,p:u(m.home,m.push),kind:"handicap",side:"home",source:"модель Линзы"}),l.length&&l.push({label:`Фора ${i[1]} ${c(-t.line)}`,odd:t.away,p:u(m.away,m.push),kind:"handicap",side:"away",source:"модель Линзы"})}if(o&&Number.isFinite(n.total)&&n.sigmaT>0&&Number.isFinite(o.line)&&o.line>50&&o.over>1&&o.under>1){let m=Aa(n.total,n.sigmaT,o.line);Math.abs(u(m.over,m.push)-d(o.over,o.under))<=.3&&(l.push({label:`Тотал больше ${o.line}`,odd:o.over,p:u(m.over,m.push),kind:"total",source:"модель Линзы"}),l.push({label:`Тотал меньше ${o.line}`,odd:o.under,p:u(m.under,m.push),kind:"total",source:"модель Линзы"}))}return l}var Re={football:{periods:2,minutes:90,stoppage:[2,5],late:1,weights:[.12,.142,.184,.149,.167,.237],trail:.3,lead:.05,redOwn:-.4,redOpp:.45,total:2.7,homeShare:.555,maxGoals:12},hockey:{periods:3,minutes:60,weights:[.297,.344,.359],trail:0,lead:-.1,redOwn:0,redOpp:0,total:6,homeShare:.52,maxGoals:16}},Jn=[1];for(let e=1;e<=40;e+=1)Jn[e]=Jn[e-1]*e;var Fr=(e,t)=>t<=0?e===0?1:0:Math.exp(-t)*t**e/Jn[e];function Oa(e,t){let o=t.weights.length,i=t.minutes/o,n=Math.max(0,Math.min(t.minutes,e)),l=0;for(let u=0;u<o;u+=1){let d=u*i,m=d+i,x=o/(t.periods||1),h=(u+1)%x===0&&t.stoppage?.[Math.floor(u/x)]||0;n<=d?l+=t.weights[u]:n<m&&(l+=t.weights[u]*((m-n+h)/(i+h)))}let c=t.weights.reduce((u,d)=>u+d,0);return l/c}function Tr(e,t,o){let i=[];for(let n=0;n<=o;n+=1){i[n]=[];for(let l=0;l<=o;l+=1)i[n][l]=Fr(n,e)*Fr(l,t)}return i}function Ea(e,t,o,i=null){let n=Tr(e,t,o),l=0,c=0,u=0,d=0;for(let m=0;m<=o;m+=1)for(let x=0;x<=o;x+=1){let h=n[m][x];m>x?l+=h:m===x?c+=h:u+=h,i!=null&&m+x>i&&(d+=h)}return{p1:l,px:c,p2:u,over:d}}function cn({p1:e,px:t,p2:o,line:i=null,pOver:n=null},l=Re.football){let c=l.total,u=(m,x)=>{let h=Ea(m,x,l.maxGoals,i!=null&&n!=null?i:null),b=(h.p1-e)**2+(h.p2-o)**2+(t!=null?(h.px-t)**2:0);return i!=null&&n!=null?b+=(h.over-n)**2:b+=.02*((m+x-c)/c)**2,b},d={lh:c*l.homeShare,la:c*(1-l.homeShare),e:1/0};for(let m=.4;m>=.01;m/=2){let x=d;for(let h=-4;h<=4;h+=1)for(let b=-4;b<=4;b+=1){let $=Math.max(.03,x.lh+h*m),y=Math.max(.03,x.la+b*m),v=u($,y);v<d.e&&(d={lh:$,la:y,e:v})}}return{lh:d.lh,la:d.la}}function Rt(e,t,o=Re.football){let[i,n]=e.score.map(Number),l=Oa(Number(e.minute)||0,o),c=i-n,u=Math.sign(c),d=1+(o.late||0)*((Number(e.minute)||0)/o.minutes-.5),m=(Math.abs(c)>=2?.6:1)*Math.max(0,d),x=u<0?o.trail*m:u>0?o.lead*m:0,h=u>0?o.trail*m:u<0?o.lead*m:0,[b,$]=(e.red||[0,0]).map(G=>Math.min(2,Number(G)||0)),y=(G,E)=>(1+o.redOwn)**G*(1+o.redOpp)**E,v=Math.max(0,t.lh*l*(1+x)*y(b,$)),_=Math.max(0,t.la*l*(1+h)*y($,b)),F=o.maxGoals,k=Tr(v,_,F),R=0,P=0,L=0;for(let G=0;G<=F;G+=1)for(let E=0;E<=F;E+=1){let q=i+G,Y=n+E;q>Y?R+=k[G][E]:q===Y?P+=k[G][E]:L+=k[G][E]}let M=R+P+L||1,A=G=>{let E=0,q=0;for(let Y=0;Y<=F;Y+=1)for(let H=0;H<=F;H+=1){let te=i+n+Y+H;te>G?E+=k[Y][H]:te===G&&(q+=k[Y][H])}return{over:E,push:q,under:Math.max(0,1-E-q)}},B=G=>{let E=0,q=0;for(let Y=0;Y<=F;Y+=1)for(let H=0;H<=F;H+=1){let te=i+Y-(n+H)+G;te>0?E+=k[Y][H]:te===0&&(q+=k[Y][H])}return{home:E,push:q,away:Math.max(0,1-E-q)}},O=v+_,I=Math.exp(-O);return{p1:R/M,px:P/M,p2:L/M,lh:v,la:_,share:l,expTotal:i+n+O,nextGoal:{home:O>0?(1-I)*(v/O):0,away:O>0?(1-I)*(_/O):0,none:I},total:A,handicap:B}}var Qn=(e,t)=>1/e/(1/e+1/t);function Fa(e,t){let o=Re[t];if(!o||!e?.odds||e.odds.length!==3)return null;let i=De(e.odds,{method:"proportional"}).fair;if(!i)return null;let n=e.total,l=n&&n.over>1&&n.under>1?Qn(n.over,n.under):null;return l==null?null:cn({p1:i[0],px:i[1],p2:i[2],line:n.line,pOver:l},o)}function Cr(e,t,o,i=["Хозяева","Гости"]){let n=Fa(e,o);if(!n)return[];let l=Re[o],c=Rt({score:[0,0],minute:0},n,l),u=[],d=new Set,m=h=>h>0?`+${h}`:`${h}`,x=h=>{let b=String(h??"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?\d+(?:\.\d+)?/g);return b?Number(b[b.length-1]):NaN};for(let h of t||[]){if(h.kind!=="total"&&h.kind!=="handicap"||h.outcomes?.length!==2)continue;let b=`${h.title||""} ${h.period||""}`;if(/тайм|период|четверт|half|period|инд|команд|угл|карт|corner|card|овертайм|буллит|с уч[её]том|(^|[^а-яё])от([^а-яё]|$)/i.test(b.replace(/осн\.?\s*время/i,"")))continue;if(h.kind==="handicap"){let L=x(h.outcomes[0].label);if(Number.isFinite(L)||(L=x(h.line)),!Number.isFinite(L)||Math.abs(L)>4||d.has(`h${L}`))continue;let M=Number(h.outcomes[0].odd),A=Number(h.outcomes[1].odd);if(!(M>1&&A>1))continue;let B=c.handicap(L),O=1-B.push||1;if(Math.abs(B.home/O-Qn(M,A))>.15)continue;d.add(`h${L}`),u.push({label:`Фора ${i[0]} ${m(L)}`,odd:M,p:B.home/O,kind:"handicap",side:"home",line:L,source:"Fonbet без маржи"},{label:`Фора ${i[1]} ${m(-L)}`,odd:A,p:B.away/O,kind:"handicap",side:"away",line:-L,source:"Fonbet без маржи"});continue}let $=Number(String(h.line||"").replace(",","."));if(!Number.isFinite($)||$<=0||$>(o==="hockey"?12:9)||d.has($))continue;let y=Nt(h.outcomes.map(L=>L.label));if(y<0)continue;let v=c.total($),_=1-v.push||1,F=v.over/_,k=v.under/_,R=Number(h.outcomes[y].odd),P=Number(h.outcomes[1-y].odd);!(R>1&&P>1)||Math.abs(F-Qn(R,P))>.2||(d.add($),u.push({label:`Тотал больше ${$}`,odd:R,p:F,kind:"total",line:$,source:"Fonbet без маржи"},{label:`Тотал меньше ${$}`,odd:P,p:k,kind:"total",line:$,source:"Fonbet без маржи"}))}return u}var to={atp:{hard:.645,clay:.625,grass:.67},wta:{hard:.565,clay:.55,grass:.585}};function Ye(e,t=0,o=0){let i=1-e,n=e*e/(e*e+i*i),l=new Map,c=(u,d)=>{if(u>=4&&u-d>=2)return 1;if(d>=4&&d-u>=2)return 0;if(u>=3&&d>=3)return u===d?n:u>d?e+i*n:e*n;let m=u*16+d;return l.has(m)||l.set(m,e*c(u+1,d)+i*c(u,d+1)),l.get(m)};return c(t,o)}function un(e,t,o=0,i=0,n=!0,l=7){let c=$=>$?e:1-t,u=e*(1-t)/(e*(1-t)+(1-e)*t),d=$=>$===0?0:Math.floor(($+1)/2),m=d(o+i)%2===0?n:!n,x=$=>d($)%2===0?m:!m,h=new Map,b=($,y)=>{if($>=l&&$-y>=2)return 1;if(y>=l&&y-$>=2)return 0;if($>=l-1&&y>=l-1&&$===y)return u;let v=$*64+y;if(!h.has(v)){let _=c(x($+y));h.set(v,_*b($+1,y)+(1-_)*b($,y+1))}return h.get(v)};return b(o,i)}function eo(e,t,o=0,i=0,n=!0,l=7){let c=Ye(e),u=1-Ye(t),d=new Map,m=(x,h,b)=>{if(x>=6&&x-h>=2||x===7)return 1;if(h>=6&&h-x>=2||h===7)return 0;if(x===6&&h===6)return un(e,t,0,0,b,l);let $=x*32+h*2+(b?1:0);if(!d.has($)){let y=b?c:u;d.set($,y*m(x+1,h,!b)+(1-y)*m(x,h+1,!b))}return d.get($)};return m(o,i,n)}function Lr(e,t,o,i=3,{finalTb:n=7}={}){let l=i>=5?3:2,c=(e.sets||[]).filter(([L,M])=>L>M).length,u=(e.sets||[]).length-c,[d,m]=e.games||[0,0],[x,h]=e.points||[0,0],b=e.aServes!==!1,y=c===l-1&&u===l-1?n:7,v=new Map,_=(L,M)=>{if(L>=l)return 1;if(M>=l)return 0;let A=L*8+M;if(!v.has(A)){let B=L===l-1&&M===l-1?n:7,O=(eo(t,o,0,0,!0,B)+eo(t,o,0,0,!1,B))/2;v.set(A,O*_(L+1,M)+(1-O)*_(L,M+1))}return v.get(A)},F=d===6&&m===6,k,R;if(F)k=un(t,o,x,h,b,y),R=k;else{R=b?Ye(t,x,h):1-Ye(o,h,x);let L=(M,A)=>M>=6&&M-A>=2||M===7?1:A>=6&&A-M>=2||A===7?0:eo(t,o,M,A,!b,y);k=R*L(d+1,m)+(1-R)*L(d,m+1)}return{match:k*_(c+1,u)+(1-k)*_(c,u+1),set:k,game:R,hold:b?R:1-R}}function Rr(e,t,o=3){return(Lr({sets:[],games:[0,0],points:[0,0],aServes:!0},e,t,o).match+Lr({sets:[],games:[0,0],points:[0,0],aServes:!1},e,t,o).match)/2}var Je=(e,t,o)=>e.set(t,(e.get(t)||0)+o);function Ta(e,t,o=!0){let i=Ye(e),n=Ye(t),l=new Map,c=new Map([[`0,0,${o?1:0}`,1]]);for(;c.size;){let u=new Map;for(let[d,m]of c){let[x,h,b]=d.split(",").map(Number),$=b===1;if(x===6&&h===6){let v=un(e,t,0,0,$);Je(l,`7,6,${$?0:1}`,m*v),Je(l,`6,7,${$?0:1}`,m*(1-v));continue}let y=$?i:1-n;for(let[v,_,F]of[[x+1,h,y],[x,h+1,1-y]]){let k=(v>=6||_>=6)&&Math.abs(v-_)>=2||v===7||_===7,R=`${v},${_},${$?0:1}`;Je(k?l:u,R,m*F)}}c=u}return[...l].map(([u,d])=>{let[m,x,h]=u.split(",").map(Number);return{ga:m,gb:x,nextA:h===1,p:d}})}function Pr(e,t,o=3){let i=o===5?3:2,n=new Map,l=h=>{let b=h?1:0;return n.has(b)||n.set(b,Ta(e,t,h)),n.get(b)},c=new Map,u=new Map,d=new Map,m=[{sa:0,sb:0,a:!0,t:0,d:0,p:.5},{sa:0,sb:0,a:!1,t:0,d:0,p:.5}];for(;m.length;){let h=new Map;for(let b of m)for(let $ of l(b.a)){let y=b.sa+($.ga>$.gb?1:0),v=b.sb+($.gb>$.ga?1:0),_=b.t+$.ga+$.gb,F=b.d+$.ga-$.gb,k=b.p*$.p;if(y===i||v===i){Je(c,`${y}:${v}`,k),Je(u,_,k),Je(d,F,k);continue}let R=`${y},${v},${$.nextA?1:0},${_},${F}`,P=h.get(R);P?P.p+=k:h.set(R,{sa:y,sb:v,a:$.nextA,t:_,d:F,p:k})}m=[...h.values()]}let x=(h,b)=>[...h].reduce(($,[y,v])=>$+(b(Number(y))?v:0),0);return{sets:Object.fromEntries(c),win:[...c].reduce((h,[b,$])=>h+(Number(b.split(":")[0])===i?$:0),0),total:u,diff:d,over:h=>({over:x(u,b=>b>h),push:x(u,b=>b===h)}),handicap:h=>({home:x(d,b=>b+h>0),push:x(d,b=>b+h===0)})}}var Ca=0,La=.04,Ra=[[-2.0201828705,.0199532421],[-.9585724646,.3936193232],[0,.9453087205],[.9585724646,.3936193232],[2.0201828705,.0199532421]].map(([e,t])=>[e*Math.SQRT2,t/Math.sqrt(Math.PI)]);function no(e,{tour:t="atp",surface:o="hard",bestOf:i=3,serveShift:n=Ca,daySd:l=La}={}){let c=((to[t]||to.atp)[o]||.63)+n,u=L=>Math.max(-.3,Math.min(.3,L)),d=l>0?Ra:[[0,1]],m=L=>d.reduce((M,[A,B])=>M+B*Rr(c+u(L+A*l),c-u(L+A*l),i),0),x=-.3,h=.3,b=Math.min(.995,Math.max(.005,e));for(let L=0;L<30;L+=1){let M=(x+h)/2;m(M)<b?x=M:h=M}let $=(x+h)/2;if(d.length===1)return Pr(c+$,c-$,i);let y=d.map(([L,M])=>[M,Pr(c+u($+L*l),c-u($+L*l),i)]),v=L=>{let M=new Map;for(let[A,B]of y)for(let[O,I]of L(B))M.set(O,(M.get(O)||0)+A*I);return M},_=v(L=>Object.entries(L.sets)),F=v(L=>L.total),k=v(L=>L.diff),R=(L,M)=>[...L].reduce((A,[B,O])=>A+(M(Number(B))?O:0),0),P=i===5?3:2;return{sets:Object.fromEntries(_),win:[..._].reduce((L,[M,A])=>L+(Number(M.split(":")[0])===P?A:0),0),total:F,diff:k,over:L=>({over:R(F,M=>M>L),push:R(F,M=>M===L)}),handicap:L=>({home:R(k,M=>M+L>0),push:R(k,M=>M+L===0)})}}var Pa={cs:0,dota:0},Pt={cs:8,dota:12},He=new Map;function Ba(e,t){let o=`${t}|${Math.round(Math.min(.999,Math.max(.001,e))*1e3)}`,i=He.get(o);if(i)return i;let n=Xe(e,3,t),l=Ve(n*t,(1-n)*t),c=Et(),u=0,d=0,m=0,x=0;for(let b=0;b<c.length;b+=1){let $=c[b],y=2*$*(1-$);u+=l[b]*$*$,d+=l[b]*(1-$)*(1-$),m+=l[b]*y*$,x+=l[b]*y*(1-$)}let h={q:n,sets:{"2:0":u,"2:1":m,"1:2":x,"0:2":d},over25:m+x,homeMinus15:u,awayMinus15:d};return He.size>5e3&&He.clear(),He.set(o,h),h}function Dr({bo:e=null,cs:t=null,model:o=null,league:i=""}={}){let n=m=>[1,3,5].includes(Number(m))?Number(m):0,l=o?.format?.source==="по умолчанию"?0:n(o?.bo),c=String(i||""),u=c.match(/(?:^|[^a-z])bo\s?([135])(?![0-9])/i)||c.match(/best\s+of\s+([135])(?![0-9])/i),d=c.match(/до\s+([123])\s*побед/i);return n(e)||n(t?.bo)||l||(u?Number(u[1]):d?Number(d[1])*2-1:0)||null}var Br=(e,t)=>{let o=1;for(let i=1;i<=t;i+=1)o=o*(e-t+i)/i;return o};function Ir(e,t){let o=Math.ceil(t/2),i={};for(let n=0;n<o;n+=1)i[`${o}:${n}`]=Br(o-1+n,n)*e**o*(1-e)**n;for(let n=o-1;n>=0;n-=1)i[`${n}:${o}`]=Br(o-1+n,n)*(1-e)**o*e**n;return i}function Ia(e,t,o){let i=`${t}|bo${o}|${Math.round(Math.min(.999,Math.max(.001,e))*1e3)}`,n=He.get(i);if(n)return n;let l=Xe(e,o,t),c;if(Number.isFinite(t)){let d=Ve(l*t,(1-l)*t),m=Et();c={};for(let x=0;x<m.length;x+=1)for(let[h,b]of Object.entries(Ir(m[x],o)))c[h]=(c[h]||0)+d[x]*b}else c=Ir(l,o);let u={q:l,bo:o,sets:c};return He.size>5e3&&He.clear(),He.set(i,u),u}function pn(e,{pick:t=0,kappaMap:o=1/0,bo:i=3}={}){if([1,5].includes(Number(i)))return Ia(e,o,Number(i));if(Number.isFinite(o)&&!t)return Ba(e,o);let n=m=>Math.min(.999,Math.max(.001,m)),l=m=>{let x=n(m+t),h=n(m-t),b=n(m),$=x*h,y=(1-x)*(1-h),v=x*(1-h)+(1-x)*h;return{q:m,s20:$,s02:y,s21:v*b,s12:v*(1-b)}},c=0,u=1;for(let m=0;m<50;m+=1){let x=(c+u)/2,h=l(x);h.s20+h.s21<e?c=x:u=x}let d=l((c+u)/2);return{q:d.q,sets:{"2:0":d.s20,"2:1":d.s21,"1:2":d.s12,"0:2":d.s02},over25:d.s21+d.s12,homeMinus15:d.s20,awayMinus15:d.s02}}var jr=e=>e>.005&&e<.995?Math.round(1/e*100)/100:null;var ja={tennis:!0,cs:!1,dota:!1};function oo(e=""){let t=String(e),o=/wta|жен|women/i.test(t)?"wta":"atp",i=/грунт|clay/i.test(t)?"clay":/трав|grass/i.test(t)?"grass":"hard",n=/australian open|roland garros|ролан|уимблдон|wimbledon|us open|открытый чемпионат (австралии|сша)/i.test(t);return{tour:o,surface:i,bestOf:n&&o==="atp"?5:3}}function ro({sport:e,model:t=null,p:o=null,source:i="модель Линзы",markets:n,names:l=["Хозяева","Гости"],league:c=""}){let u=o??t?.p1;if(!ja[e]||!(u>0&&u<1))return[];let d=e==="tennis",m=d?no(u,oo(c)):pn(u,{pick:Pa[e]||0,kappaMap:Pt[e]??1/0}),x=k=>{let R=String(k??"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?\d+(?:\.\d+)?/g);return R?Number(R[R.length-1]):NaN},h=(k,R)=>1/k/(1/k+1/R),b=(k,R)=>R>0?k/(1-R):k,$=d?"гейма":"карты",y=k=>String(k||"").toLowerCase().replace(/ё/g,"е"),v=l.flatMap(k=>y(k).split(/[^a-zа-я0-9-]+/)).filter(k=>k.length>=4),_=[],F=new Set;for(let k of n||[]){if(k.scope==="list"||k.main===!1||k.kind!=="total"&&k.kind!=="handicap"||k.outcomes?.length!==2||!k.outcomes.every(M=>M.odd>1))continue;let R=`${k.title||""} ${k.period||""}`;if(/сет|set|тай-?брейк|tie|инд|игрок|player|раунд|round|килл|kill|чет|нечет/i.test(R)||v.some(M=>y(R).includes(M))||!d&&/гейм|game/i.test(R))continue;let[P,L]=k.outcomes;if(k.kind==="total"){let M=Number.isFinite(x(k.line))?x(k.line):x(P.label);if(!Number.isFinite(M)||F.has(`t${M}`)||(d?M<12||M>60:M!==2.5))continue;let A=!/меньш|under/i.test(P.label),B,O=0;if(d){let q=m.over(M);B=q.over,O=q.push}else if(M===2.5)B=m.over25;else continue;let I=A?P:L,G=A?L:P,E=b(B,O);if(Math.abs(E-h(I.odd,G.odd))>.2)continue;F.add(`t${M}`),_.push({label:`Тотал ${d?"геймов":"карт"} больше ${M}`,odd:I.odd,p:E,kind:"total",line:M,source:i}),_.push({label:`Тотал ${d?"геймов":"карт"} меньше ${M}`,odd:G.odd,p:1-E,kind:"total",line:M,source:i})}else{let M=Number.isFinite(x(P.label))?x(P.label):x(k.line);if(!Number.isFinite(M)||F.has(`h${M}`)||(d?Math.abs(M)>15:Math.abs(M)!==1.5))continue;let A,B=0;if(d){let G=m.handicap(M);A=G.home,B=G.push}else if(M===-1.5)A=m.homeMinus15;else if(M===1.5)A=1-m.awayMinus15;else continue;let O=b(A,B);if(Math.abs(O-h(P.odd,L.odd))>.2)continue;F.add(`h${M}`);let I=G=>G>0?`+${G}`:`${G}`;_.push({label:`Фора ${l[0]} ${I(M)} ${$}`,odd:P.odd,p:O,kind:"handicap",side:"home",line:M,source:i}),_.push({label:`Фора ${l[1]} ${I(-M)} ${$}`,odd:L.odd,p:1-O,kind:"handicap",side:"away",line:-M,source:i})}}return _}function Gr({sport:e,model:t,markets:o,names:i,league:n=""}){let l=ro({sport:e,model:t,markets:o,names:i,league:n}).filter(u=>u.p>=.15&&u.p<=.85),c=new Map;for(let u of l){let d=`${u.kind}|${Math.abs(u.line)}`;(!c.has(d)||u.p*u.odd>c.get(d).p*c.get(d).odd)&&c.set(d,u)}return[...c.values()].sort((u,d)=>Math.abs(u.p-.5)-Math.abs(d.p-.5)).map(u=>({label:u.label,p:u.p,fair:jr(u.p),from:jr(u.p),odd:u.odd}))}var Da=e=>Math.min(.999,Math.max(.001,e)),fn={total:32,handicap:48,map:32},Ga=3,dn=new Map;function qr(e){let t=Math.round(Da(e)*1e4),o=dn.get(t);if(o)return o;let i=[],n=new Map([["0,0",1]]);for(let l=0;l<80&&n.size;l+=1){let c=new Map;for(let[u,d]of n){let[m,x]=u.split(",").map(Number);if(rn(m,x)){i.push({win:m>x?1:0,a:m,b:x,p:d});continue}if(Math.min(m,x)>=12+3*Ga){let h=tn(e);i.push({win:1,a:m+4,b:x+2,p:d*h},{win:0,a:m+2,b:x+4,p:d*(1-h)});continue}c.set(`${m+1},${x}`,(c.get(`${m+1},${x}`)||0)+d*e),c.set(`${m},${x+1}`,(c.get(`${m},${x+1}`)||0)+d*(1-e))}n=c}return dn.size>2e3&&dn.clear(),dn.set(t,i),i}function Hr(e,t=fn.map){if(!Number.isFinite(t))return qr(e);let o=Et(),i=Ve(e*t+0,(1-e)*t+0),n=new Map;for(let l=0;l<o.length;l+=1)if(!(i[l]<1e-7))for(let c of qr(o[l])){let u=`${c.win}|${c.a}|${c.b}`;n.set(u,(n.get(u)||0)+i[l]*c.p)}return[...n].map(([l,c])=>{let[u,d,m]=l.split("|").map(Number);return{win:u,a:d,b:m,p:c}})}function Ur(e,t=0,o=0){let i=new Map,n=new Map([[`${t},${o}`,1]]);for(let u=0;u<60&&n.size;u+=1){let d=new Map;for(let[m,x]of n){let[h,b]=m.split(",").map(Number);if(rn(h,b)){i.set(h+b,(i.get(h+b)||0)+x);continue}for(let[$,y]of[[`${h+1},${b}`,e],[`${h},${b+1}`,1-e]])d.set($,(d.get($)||0)+x*y)}n=d}let l=[...i.values()].reduce((u,d)=>u+d,0)||1;return{mean:[...i].reduce((u,[d,m])=>u+d*m,0)/l,over:u=>[...i].reduce((d,[m,x])=>d+(m>u?x:0),0)/l}}var X=(e,t)=>`${_e(e,t)}%`,xe=(e,t=1)=>Number.isFinite(e)?(Math.round(e*10**t)/10**t).toString().replace(".",","):"—",ao=e=>Math.floor(e)+.5,Qe=e=>String(e).replace(".",","),so=(e,t)=>e>1&&t>1?1/e/(1/e+1/t):null,qa=(e,t)=>e===0?"home":e===t-1?"away":"draw",Kr=e=>{let t=Math.abs(Math.round(e));return t%10===1&&t%100!==11?"очко":t%10>=2&&t%10<=4&&(t%100<10||t%100>=20)?"очка":"очков"};function Ha(e,t,o){let i=Re[e];if(!i||t?.length!==3)return null;let n=o?so(o.over,o.under):null,l=n!=null&&Number.isFinite(o.line);return{...cn({p1:t[0],px:t[1],p2:t[2],line:l?o.line:null,pOver:l?n:null},i),withTotal:l}}function Ua(e,t,o=8){let i=[1];for(let c=1;c<=o;c+=1)i[c]=i[c-1]*c;let n=(c,u)=>Math.exp(-u)*u**c/i[c],l={h:0,a:0,p:0};for(let c=0;c<=o;c+=1)for(let u=0;u<=o;u+=1){let d=n(c,e)*n(u,t);d>l.p&&(l={h:c,a:u,p:d})}return l}function Ka(e,t,o,i){let n=Ha(e,o,i?.total);if(!n)return{how:[],note:"",check:null};let l=Re[e],c=Rt({score:[0,0],minute:0},n,l),u=[],d=`${xe(c.expTotal)} ${e==="hockey"?"шайбы":"гола"} за матч`,m=v=>{let _=c.total(v);return _.over/(1-_.push||1)},x=v=>{let _=m(v);return{line:v,over:_>=.5,p:Math.max(_,1-_)}},h=x(Number.isFinite(i?.total?.line)?i.total.line:ao(c.expTotal)),b=h.p>=.54?h:[x(h.line-1),x(h.line+1)].filter(v=>v.line>0&&v.p>=.58&&v.p<=.85).sort((v,_)=>Math.abs(v.p-.65)-Math.abs(_.p-.65))[0],$=n.withTotal&&b?{kind:"total",line:b.line,over:b.over,p:b.p}:null;if(u.push(n.withTotal?b?`Тотал: скорее ${b.over?"больше":"меньше"} ${Qe(b.line)} (${X(b.p)}), ожидаемо ≈ ${d}`:`Тотал: ожидаемо ≈ ${d}`:`Тотал: ожидаемо ≈ ${d} — грубо, тотала в линии нет`),e==="football"){let v=(1-Math.exp(-n.lh))*(1-Math.exp(-n.la));u.push(`Обе забьют: ${v>=.5?"да":"нет"} (${X(Math.max(v,1-v))})`)}let y=Ua(n.lh,n.la);if(u.push(`Самый частый счёт по расчёту: ${y.h}:${y.a} (${X(y.p)}) — точный счёт угадывается редко`),e==="hockey"){let[v,_,F]=o;u.unshift(`Основное время: ${t[0]} ${X(v)} · ничья ${X(_)} · ${t[2]} ${X(F)}; ОТ или буллиты — ${X(_)}`)}return{how:u,check:$,note:n.withTotal?"по исходу и тоталу Fonbet без маржи":"по исходу без маржи (тотала в линии нет)"}}function Wa(e,t,o,i){let n=[],l=null,c=o?.handicap,u=o?.total;if(c&&Number.isFinite(c.line)&&c.line!==0){let d=c.line<0?e[0]:e[e.length-1],m=Math.abs(c.line),x=so(c.home,c.away);n.push(`Разница: рынок ждёт победу ${d} примерно на ${Math.round(m)} ${Kr(m)} (фора −${Qe(m)}${x!=null?`, шанс пройти ${X(c.line<0?x:1-x)}`:""})`)}if(u&&Number.isFinite(u.line)){let d=so(u.over,u.under);d!=null&&Math.abs(d-.5)>=.03&&(l={kind:"total",line:u.line,over:d>.5,p:Math.max(d,1-d)}),n.push(d!=null&&Math.abs(d-.5)>=.03?`Тотал: скорее ${d>.5?"больше":"меньше"} ${Qe(u.line)} (${X(Math.max(d,1-d))})`:`Тотал: ожидаемо ≈ ${Qe(u.line)} очка (основная линия Fonbet — середина рынка)`)}if(i?.lines&&Number.isFinite(i.lines.margin)){let d=i.lines.margin>=0?e[0]:e[e.length-1];n.push(`Модель Линзы (справочно): ${d} сильнее на ${xe(Math.abs(i.lines.margin))} ${Kr(i.lines.margin)}${Number.isFinite(i.lines.total)?`, тотал ≈ ${xe(i.lines.total)}`:""}`)}return n.length||n.push("По форе и тоталу у Линзы нет проверенной оценки — только исход"),{how:n,check:l}}function Va(e,t,o,i){let n=oo(o),l=no(t[0],n),c=t[0]>=.5,u=n.bestOf===5?3:2,d=Object.entries(l.sets).filter(([R])=>Number(R.split(":")[0])===u===c).sort((R,P)=>P[1]-R[1]),[m,x]=d[0]||["",0],h=m?m.split(":").map(Number).reduce((R,P)=>R+P,0):0,b=c?e[0]:e[e.length-1],$=["","","двух","трёх","четырёх","пяти"][h]||h,y=n.bestOf===5?(l.sets["3:2"]||0)+(l.sets["2:3"]||0):(l.sets["2:1"]||0)+(l.sets["1:2"]||0),v=[...l.total].reduce((R,[P,L])=>R+Number(P)*L,0),_=Number.isFinite(i?.total?.line)&&i.total.line>12&&i.total.line<60?i.total.line:ao(v),F=l.over(_),k=F.over/(1-F.push||1);return{how:[`Сеты: скорее ${b} в ${$} сетах — счёт ${m} (${X(x)}); до решающего сета — ${X(y)}`,`Тотал геймов ≈ ${xe(v)}; ${k>=.5?"больше":"меньше"} ${Qe(_)} — ${X(Math.max(k,1-k))}`],check:m?{kind:"sets",score:m,p:x}:null}}function Xa(e){let t=e?.durations;if(!t||!Number.isFinite(t.dec))return{how:["По длительности боя у Линзы нет оценки: у бойцов мало боёв в UFC"],check:null};let o=1-t.dec,i=[["в 1-м раунде",t.r1],["во 2-м раунде",t.r2],[t.rounds===5?"в 3-м раунде и позже":"в 3-м раунде",t.r3]].sort((c,u)=>u[1]-c[1]),n=t.r1+t.r2/2,l=t.r1+t.r2+t.r3/2;return{check:{kind:"decision",dec:t.dec>=.5},how:[t.dec>=.5?`Как: скорее решение судей (${X(t.dec)}); досрочно — ${X(o)}`:`Как: скорее досрочно (${X(o)}), чаще всего ${i[0][0]} (${X(i[0][1])}); решение — ${X(t.dec)}`,`Тотал раундов: 1,5 — ${n>=.5?"меньше":"больше"} (${X(Math.max(n,1-n))})${t.rounds===3?`; 2,5 — ${l>=.5?"меньше":"больше"} (${X(Math.max(l,1-l))})`:""}`]}}function Za(e,t="cs"){let o=pn(e,{kappaMap:Pt[t]??1/0});return{q:o.q,s20:o.sets["2:0"],s02:o.sets["0:2"],three:o.over25}}function Ya(e,t,o,{cs:i=null,bo:n=3}={}){let l=o[0]>=.5?0:1,c=t[l===0?0:t.length-1],u=l===0?"home":"away",d=l===0?o[0]:1-o[0],m=Vn(i?.veto),x=y=>y==="home"?t[0]:t[t.length-1],h=[],b=null,$;if(n===1){let y=m.length?`Карта: ${m.map(v=>ft(v.map)).join(", ")}.`:"Карты ещё нет (пики и баны — перед матчем).";h.push(`${y} Формат bo1 — одна карта: ${c} скорее заберёт её (${X(d)})`),$=d}else{let y=m.length?`Карты серии: ${m.map(v=>`${ft(v.map)} (${v.pick?`пик ${x(v.pick)}`:"решающая"})`).join(", ")}.`:"Карт ещё нет (пики и баны — перед матчем).";if(n===5){let v=pn(o[0],{kappaMap:Pt[e]??1/0,bo:5}),_=(F,k)=>v.sets[l===0?`${F}:${k}`:`${k}:${F}`]||0;h.push(`${y} ${c} скорее заберёт серию (bo5): 3:0 — ${X(_(3,0))}, 3:1 — ${X(_(3,1))}, 3:2 — ${X(_(3,2))}`),$=l===0?v.q:1-v.q}else{let v=Za(o[0],e),_=l===0?v.s20:v.s02,F=_<v.three;h.push(`${y} ${c} скорее заберёт серию; ${_>=v.three?`вероятнее 2:0 (${X(_)}), в три карты — ${X(v.three)}`:`вероятнее три карты (${X(v.three)}), 2:0 — ${X(_)}`}`),b={kind:"maps",three:F,side:F?"":u,p:F?v.three:_},$=l===0?v.q:1-v.q}}if(e==="cs"){let y=Hr(Ft($,fn.map),fn.map),v=y.reduce((F,k)=>F+(k.a+k.b)*k.p,0),_=y.reduce((F,k)=>F+(k.a+k.b>21.5?k.p:0),0);h.push(n===1?`Раунды карты: в среднем ≈ ${xe(v)}; больше 21,5 — ${X(_)}`:`Отдельная карта: ${c} берёт ≈ ${X($)}, в среднем ≈ ${xe(v)} раунда; больше 21,5 — ${X(_)}`)}return{how:h,check:b}}function Ja(e,t,o){let[i,n]=[t[0],t[t.length-1]],l=[];if(o.kind==="goals"){let c=e==="hockey"?`${o.period}-й период`:`${o.minute}′`;l.push(`Сейчас ${o.score[0]}:${o.score[1]} (${c}): основное время — ${i} ${X(o.p1)} · ничья ${X(o.px)} · ${n} ${X(o.p2)}`),o.nextGoal&&l.push(`Следующий гол: ${i} ${X(o.nextGoal.home)} · ${n} ${X(o.nextGoal.away)} · не будет ${X(o.nextGoal.none)}`);let u=o.tables?.total?.[0];return u&&Number.isFinite(u.pOver)&&l.push(`Тотал до конца: ожидаемо ≈ ${xe(o.expTotal)}; больше ${Qe(u.line)} — ${X(u.pOver)}`),l}if(o.kind==="tennis"){let c=Array.isArray(o.score)?o.score.join(":"):"",u=Array.isArray(o.games)?o.games.join(":"):"";return l.push(`Сейчас по сетам ${c}${u?`, в сете ${u}`:""}: матч — ${o.p1>=.5?i:n} ${X(Math.max(o.p1,1-o.p1))}`),o.set?.p1!=null&&l.push(`Текущий сет — ${o.set.p1>=.5?i:n} (${X(Math.max(o.set.p1,1-o.set.p1))})`),o.game?.p1!=null&&l.push(`Этот гейм — ${o.game.p1>=.5?i:n} (${X(Math.max(o.game.p1,1-o.game.p1))})`),l}if(o.kind==="esports"){let c=o.bo||3,u=(o.maps||[0,0]).map(Number),d=e==="dota"?"dota":"cs",m=Tt({pre:o.pre,bo:c,maps:u,rounds:o.rounds,game:d}),x=u[0]+u[1]+1;if(m.map!=null&&d==="cs"){let[h,b]=o.rounds.map(Number),$=Un.cs,v=(Xe(o.pre,c,$)*$+u[0])/($+u[0]+u[1]),F=(Ft(v,Ot)*Ot+h)/(Ot+h+b),k=Ur(F,h,b),R=Math.max(ao(k.mean),h+b+.5);l.push(`Карта ${x}, раунды ${h}:${b}: карту забирает ${m.map>=.5?i:n} (${X(Math.max(m.map,1-m.map))}); тотал раундов ≈ ${xe(k.mean)}, больше ${Qe(R)} — ${X(k.over(R))}`)}else d==="dota"&&l.push(`Карта ${x}: по золоту и убийствам текущую карту Линза не оценивает — только по счёту карт`);return l.push(`Серия при счёте по картам ${u[0]}:${u[1]} — ${m.p>=.5?i:n} (${X(Math.max(m.p,1-m.p))})`),l}if(Number.isFinite(o.expMargin)){let c=o.quarter;l.push(`Сейчас ${o.score[0]}:${o.score[1]}${o.period?`, ${o.period}-я четверть`:""}: победа ${o.p1>=.5?i:n} (${X(Math.max(o.p1,1-o.p1))})`),l.push(`Итог: ${o.expMargin>=0?i:n} на ≈ ${xe(Math.abs(o.expMargin))} (±${xe(o.sd)}), тотал ≈ ${xe(o.projTotal)} (±${xe(o.sdTotal)})`),c&&l.push(`${c.index}-я четверть: ${c.expMargin>=0?i:n} ≈ +${xe(Math.abs(c.expMargin))}, тотал четверти ≈ ${xe(c.projTotal)}`)}return l}function Qa(e,t,o){let i=new Map((e?.facts||[]).map(u=>[u.id,u])),n=(e?.factors||[]).filter(u=>u?.text),c=[...n.filter(u=>u.side===o),...n.filter(u=>u.side==="neutral"||!u.side),...n.filter(u=>u.side&&u.side!==o&&u.side!=="neutral")].slice(0,3).map(u=>{let d=[...new Set((u.facts||[]).map(m=>i.get(m)?.source).filter(Boolean))];return`${u.text}${d.length?` [${d.join(", ")}]`:""}`});if(!c.length)for(let u of(t?.factors||[]).slice(0,3))c.push(`${u} [модель Линзы]`);return c}function Wr({sport:e,labels:t,probs:o,source:i="",lines:n=null,model:l=null,league:c="",live:u=null,analysis:d=null,bo:m=null,decision:x=null,oddOf:h=null}){if(!Array.isArray(o)||o.length<2||!o.every(Number.isFinite)||t?.length!==o.length)return null;let b=o;if(u?.kind==="goals"&&[u.p1,u.px,u.p2].every(Number.isFinite)&&o.length===3)b=[u.p1,u.px,u.p2];else if(u&&Number.isFinite(u.p1)&&o.length===2&&u.kind!=="esports")b=[u.p1,1-u.p1];else if(u?.kind==="esports"&&o.length===2){let G=e==="dota"?"dota":"cs",E=H=>Tt({pre:H,bo:u.bo||3,maps:u.maps,rounds:u.rounds,game:G}).p,q=u.pre;if(!Number.isFinite(q)){let H=.01,te=.99;for(let Q=0;Q<30;Q+=1){let U=(H+te)/2;E(U)<o[0]?H=U:te=U}q=(H+te)/2}let Y=E(q);b=[Y,1-Y],u={...u,pre:q}}let $=b.length,y=b.indexOf(Math.max(...b));$===3&&y===1&&(y=b[0]>=b[2]?0:2);let v=t[y],_=qa(y,$),F=`победа ${v} (${X(b[y])})`;$===3&&(e==="hockey"?F=`победа ${v}: в основное время ${X(b[y])}, с учётом ОТ и буллитов ≈ ${X(b[y]+b[1]*b[y]/(b[0]+b[2]||1))}`:b[y]<.5&&(F+=`; надёжнее «${v} или ничья» — ${X(b[y]+b[1])}`));let k=[],R="",P=null;u||(e==="football"||e==="hockey"?{how:k,note:R,check:P}=Ka(e,t,o,n):e==="basketball"?{how:k,check:P}=Wa(t,o,n,l):e==="tennis"&&$===2?{how:k,check:P}=Va(t,o,c,n):e==="mma"?{how:k,check:P}=Xa(l):(e==="cs"||e==="dota"||e==="valorant")&&$===2&&({how:k,check:P}=Ya(e==="valorant"?"dota":e,t,o,{cs:d?.cs||null,bo:Dr({bo:m,cs:d?.cs,model:l,league:c})||3})),k.length||(k=["По счёту и тоталу у Линзы нет проверенной оценки — только исход"]));let L=u?Ja(e,t,u):[],M=Qa(d,l,_),A=(d?.scenarios||[]).map(G=>G?.text||G).filter(Boolean),B=A.find(G=>String(G).includes(v))||A[0]||"",O=(d?.risks||[])[0]||"";if(d?.others?.nWin??d?.others?.n){let G=d.others,E=G.nWin??G.n,q=G.favourite==="home"?t[0]:G.favourite==="away"?t[t.length-1]:"ничья";k.push(`Другие разборы: ${q} — ${G.agree} из ${E}${G.agree*2>=E?" (совпадает с ценой)":" (большинство против цены — см. риски)"}`)}d?.others?.tipsters?.short&&k.push(d.others.tipsters.short);let I={pick:v,p:b[y],index:y,side:_,who:F,how:k,check:P,why:M,scenario:B,risk:O,live:L,source:[i,R].filter(Boolean).join("; ")};return typeof h=="function"&&Object.defineProperty(I,"oddOf",{value:h,enumerable:!1}),x&&(I.decision=qn({f:I,sport:e,labels:t,probs:b,signals:x.signals||[],movement:x.movement||null,priceAt:x.priceAt??null,now:x.now??Date.now(),analysis:d,others:d?.others||null,live:u,source:I.source,cap:x.cap||null})),I}var Ee="lz.express";var Vr=e=>e&&Number(e.odd)>1&&Number(e.fair)>0&&Number(e.fair)<1;function mt(e,t=Date.now()){return(Array.isArray(e)?e:[]).filter(o=>Vr(o)&&typeof o.id=="string"&&o.id&&Number(o.at)>t-432e5&&!(Number(o.start)>0&&Number(o.start)<=t))}var ei=(e,t)=>(Array.isArray(e)?e:[]).some(o=>o?.id===t);function Xr(e,t){let o=Array.isArray(e)?e:[];if(!Vr(t)||!t.id)return{legs:o,change:"bad"};if(ei(o,t.id))return{legs:o,change:"same"};let i=t.match?o.filter(n=>n.match!==t.match):o;return i.length>=15?{legs:o,change:"full"}:{legs:[...i,t],change:i.length<o.length?"replaced":"added"}}var Zr=(e,t)=>(Array.isArray(e)?e:[]).filter(o=>o?.id!==t);async function io(e=globalThis.chrome?.storage?.local,t=Date.now()){try{return mt((await e.get(Ee))?.[Ee],t)}catch{return null}}var mn=globalThis.__lzBus,lo=mn&&window.top===window?Oo(location.hostname):null;lo&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,ni(lo.adapter,lo.book));async function ni(e,t){let o=await Zn(["lz.settings","lz.positions",Ee,"lz.margins","lz.whatsnew","lz.more"]),i=o["lz.settings"];i&&typeof i=="object"&&yn.some(p=>p in i)&&Oe({"lz.settings":Ut(i)});let n={settings:Ut(o["lz.settings"]),positions:(o["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:mt(o[Ee]),margins:ln(o["lz.margins"]),whatsnew:o["lz.whatsnew"]||null,more:o["lz.more"]||null,analysis:new Map,compare:new Map,consensus:new Map,model:new Map,facts:new Map,fonbetRef:new Map,live:new Map,partners:{data:{},at:0},status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},l=new WeakMap,c=new WeakMap,u=Co(),d=wr({bus:mn,brand:Ht,actions:$n()});d.restore(n.positions);function m(p){let r=p.outcomes.map(g=>g.odd).join("/"),a=l.get(p);if(a?.sig===r)return a.set;let f=De(p.outcomes.map(g=>g.odd));return l.set(p,{sig:r,set:f}),f}function x(){return n.match?n.analysis.get(n.match.key):null}function h(p){let r=x()?.result;if(!r?.model||p.scope==="list"||!n.match||!Object.values(r.shift||{}).some(S=>Math.abs(S)>=.5))return null;let{home:a,draw:f,away:g}=r.model,w=p.outcomes.length;if(p.kind==="1x2"&&p.main&&w===3)return[a,f,g];if(p.kind==="12"&&p.main&&w===2&&f<.005)return[a,g];if(p.kind==="dc"&&p.main&&w===3)return[a+f,a+g,f+g];if(/^победит\s*\(осн\.?\s*время\)$/i.test(p.title)&&w===2){let S=p.period===n.match.home?a:p.period===n.match.away?g:null;if(S!=null)return[S,1-S]}return null}function b(){let p=n.markets.filter(r=>r.scope!=="list"&&r.main&&(r.kind==="1x2"||r.kind==="12"));return p.find(r=>r.scope==="top")||p[0]||null}function $(p,r){let a=p.outcomes[r].label;return p.scope==="list"?!p.event||!p.main?a:p.kind==="1x2"?[p.event.home,"Ничья",p.event.away][r]||a:p.kind==="12"&&[p.event.home,p.event.away][r]||a:n.match?p.kind==="1x2"?[n.match.home,"Ничья",n.match.away][r]||a:p.kind==="12"&&[n.match.home,n.match.away][r]||a:a}function y(){let p=n.settings.overlay,r=[],a=p==="off"||!n.match||n.match.live?null:b(),f=a?br(ae(n.match.key),a.outcomes.length):-1;for(let w of n.markets){if(w.outcomes.forEach((N,C)=>c.set(N.el,{market:w,index:C})),p==="off")continue;let S=m(w);if(S.kind==="partial")continue;let z=h(w)||S.fair;w.outcomes.forEach((N,C)=>{let j=w===a&&C===f;!j&&p!=="all"||r.push({el:N.el,frame:j,chip:pt(z[C]),tone:j?"accent":"quiet"})})}let g=v();if(g){let w=r.find(S=>S.el===g.item.el);w?w.selected=!0:r.push({el:g.item.el,frame:!1,selected:!0,chip:null})}u.set(r)}function v(){if(!n.selected)return null;let p=n.markets.find(a=>a.id===n.selected.id),r=p?.outcomes[n.selected.index];return r?.el?.isConnected?{market:p,item:r,index:n.selected.index}:null}function _(){if(n.settings.theme!=="auto")return n.settings.theme;for(let p of[document.body,document.documentElement]){let a=(p?getComputedStyle(p).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!a||a[4]==="0")continue;return(.2126*a[1]+.7152*a[2]+.0722*a[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}let F=0;function k(){clearTimeout(F),F=setTimeout(()=>Oe({"lz.margins":n.margins}),1500)}function R(){if(n.pageType!=="match"||!n.match||n.match.live)return;n.margins=ln(n.margins);let p=G();p&&Sr(n.margins,{key:n.match.key,book:t.id,margin:p.margin})&&k()}function P(){location.href!==n.url&&(n.url=location.href,n.selected=null,u.hideTip());let p="other",r=[],a=null;try{p=e.pageType(document,location),r=e.collect(document,location),a=e.readMatch(document,location)}catch(g){console.error("[Линза] страница не прочитана",g)}p!==n.pageType&&(n.pageType=p,n.tab!=="settings"&&n.tab!=="express"&&(n.tab=p==="match"?"match":"scan")),n.markets=r,n.match=a,R();let f=_();f!==n.theme&&(n.theme=f),u.setTheme(n.theme),d.setTheme(n.theme),y(),Be(),A(),d.isOpen&&(et(),Bt(),jt(),ze(),d.render(Q()))}let L=new Set,M=null;function A(){if(e.observeTargets)for(let p of e.observeTargets(document))L.has(p)||(L.add(p),M=M||new MutationObserver(I),M.observe(p,{childList:!0,subtree:!0,characterData:!0}))}let B=0,O=0;function I(){let p=Date.now();O||(O=p),clearTimeout(B);let r=p-O>900?0:220;B=setTimeout(()=>{O=0,!document.hidden&&P()},r)}function G(){let p=b();if(!p)return null;let r=m(p);if(r.kind!=="full")return null;let a=h(p);return{title:"Что заложено в цене",margin:r.margin,rows:p.outcomes.map((f,g)=>({name:$(p,g),odd:f.odd,fair:r.fair[g],model:a?a[g]:null})),overtime:E()}}function E(){if(!["hockey","basketball"].includes(n.match?.sport))return null;let p=n.markets.find(a=>a.scope!=="list"&&a.outcomes.length===2&&/овертайм|булл|(^|[^а-яё])от([^а-яё]|$)|\bot\b/i.test(`${a.title} ${a.period}`)&&!/тотал|фора|будет|перв|втор|трет|период|тайм/i.test(`${a.title} ${a.period}`));if(!p)return null;let r=m(p);return r.kind!=="full"?null:{title:[p.title,p.period].filter(Boolean).join(" · "),rows:p.outcomes.map((a,f)=>({name:$(p,f)||[n.match.home,n.match.away][f],odd:a.odd,fair:r.fair[f]}))}}function q(){let p=v();if(!p)return null;let{market:r,item:a,index:f}=p,g=m(r),w=h(r),S=g.fair?g.fair[f]:null,z=r.event?`${r.event.home} — ${r.event.away}`:n.match?`${n.match.home} — ${n.match.away}`:"",N=n.match?n.compare.get(n.match.key):null,C=null;if(N?.rows?.length&&r.main&&(r.kind==="1x2"||r.kind==="12")&&r.scope!=="list")for(let D of N.rows){let K=D.odds[f];K&&(!C||K>C.odd)&&(C={name:D.name,odd:K,book:D.book||""})}C&&(C.partner=C.book&&C.book!==t.id&&n.partners.data?.[C.book]||null);let j=`${r.id}#${f}`,T=n.match&&!n.match.live&&r===b()?ae(n.match.key):null;return{choice:an(T)&&f===Xn(T,r.outcomes.length),market:[r.title,r.period,r.line].filter(Boolean).join(" · "),label:[$(r,f),z].filter(Boolean).join(" · "),odd:a.odd,fair:S,margin:g.margin,fairOdd:S?1/S:null,model:w?w[f]:null,ev:w?bo(w[f],a.odd):null,best:C,canAdd:Number.isFinite(S)&&!n.express.some(D=>D.id===j),inExpress:n.express.some(D=>D.id===j),note:g.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":w?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function Y(){let p=Nr(ln(n.margins),t.id);if(!p)return null;let r=p.best&&p.best.there<p.best.here?p.best:null,a=r&&ue().find(f=>f.name===r.name&&(f.url||f.code))||null;return{...p,best:r,partner:a}}function H(){let p=[];if(n.pageType==="match"?n.markets.forEach((g,w)=>{if(g.scope==="list")return;let S=m(g);if(S.kind!=="full")return;let z=0;for(let N=1;N<S.fair.length;N+=1)S.fair[N]>S.fair[z]&&(z=N);p.push({index:w,name:g.title,sub:[g.period,g.line].filter(Boolean).join(" · "),margin:S.margin,fav:g.outcomes[z].label,favPct:S.fair[z]})}):n.markets.forEach((g,w)=>{if(!g.event||!g.main||g.kind!=="1x2"&&g.kind!=="12")return;let S=m(g);if(S.kind!=="full")return;let z=0;for(let C=1;C<S.fair.length;C+=1)S.fair[C]>S.fair[z]&&(z=C);let N=g.kind==="1x2"?[g.event.home,"Ничья",g.event.away][z]:[g.event.home,g.event.away][z];p.push({index:w,name:`${g.event.home} — ${g.event.away}`,sub:g.event.league||g.event.time,margin:S.margin,fav:N,favPct:S.fair[z]})}),!p.length)return null;let r=new Set;for(let g=p.length-1;g>=0;g-=1){let w=`${p[g].name}|${p[g].sub}`;r.has(w)?p.splice(g,1):r.add(w)}let a=p.reduce((g,w)=>g+w.margin,0)/p.length;p.sort((g,w)=>g.margin-w.margin);let f=p.slice(0,16);return f.forEach(g=>{g.low=g.margin<=a*.8}),{title:n.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:n.pageType==="match"?"Рынок":"Матч",average:a,rows:f,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${f.length} из ${p.length}, сначала самые дешёвые.`}}function te(){let p=n.status;return p.ready?p.limit?`Разборов сегодня: ${p.used} из ${p.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function Q(){let p=n.match?.key,r=p&&n.analysis.get(p)||{status:"idle",steps:[]},a=p&&n.compare.get(p)||{status:"idle"},f=n.match?.live&&e.readEsportsWidget?e.readEsportsWidget(document):null,g=n.status;return{tab:n.tab,backTab:n.backTab,theme:n.theme,bookName:t.name,pageType:n.pageType,match:n.match?{...n.match,sportName:uo[n.match.sport]||""}:null,esports:f?{...f,homeName:n.match.home,awayName:n.match.away}:null,line:G(),analysis:{status:r.status,steps:r.steps||[],result:r.result||null,error:r.error||"",needKey:!!r.needKey},compare:a,consensus:p&&n.consensus.get(p)||null,model:p&&n.model.get(p)||null,live:bn(p),verdict:Ie(p),forecast:ae(p),more:!!(p&&n.more?.open&&n.more.key===p),facts:p&&n.facts.get(p)||null,pick:q(),scan:n.tab==="scan"?H():null,margins:n.tab==="scan"?Y():null,bookId:t.id,partners:ue(),earnLinks:Object.values(n.partners.data||{}).some(w=>w&&(w.url||w.code)),express:(()=>{let w=mt(n.express);return{legs:w,stats:go(w)}})(),quota:te(),update:n.status.update?{version:n.status.update,url:Ht.site?`${Ht.site}#install`:""}:null,whatsnew:n.whatsnew?{version:n.whatsnew.to,changes:Ar(n.whatsnew.from,n.whatsnew.to)}:null,settings:{overlay:n.settings.overlay,theme:n.settings.theme,mode:g.mode,proxy:g.proxy,ready:g.ready,hasKey:g.hasKey,keyMask:g.keyMask,licenseMask:g.licenseMask,plan:g.plan==="free"||!g.plan?"":`Тариф «${{max:"Макс",vip:"VIP",api:"API"}[g.plan]||"Про"}»${g.until?` до ${g.until.split("-").reverse().join(".")}`:""}.`,usage:g.limit?`Сегодня разборов: ${g.used} из ${g.limit}.`:""}}}let U=()=>{d.isOpen&&d.render(Q())};function re(p){Object.assign(n.settings,p),Oe({"lz.settings":n.settings}),P(),d.render(Q())}async function le(p=!1){if(!p&&Date.now()-n.partners.at<3600*1e3)return;n.partners.at=Date.now();let r=await ie("lz:partners",{force:p});r.ok&&r.data&&typeof r.data=="object"&&(n.partners.data=r.data,d.isOpen&&d.render(Q()),pe())}let ue=()=>Object.values(n.partners.data||{}).filter(p=>p&&p.id!==t.id);function pe(){if(!d.isOpen||n.tab!=="match"||!n.match)return;let p=ue().filter(r=>r.url||r.code).map(r=>r.id);p.length&&ie("lz:partner-seen",{ids:p,s:"panel"})}async function ge(){let p=await ie("lz:status");p.ok&&(n.status=p.data),U()}function Pe(){let p=b(),r=p?m(p):null;return{book:t.name,match:n.match,market:p&&r?.kind==="full"?{kind:p.kind,labels:p.outcomes.map((a,f)=>$(p,f)),odds:p.outcomes.map(a=>a.odd)}:null}}function ht(){return n.markets.filter(p=>p.scope!=="list"&&p.main!==!1&&(p.kind==="total"||p.kind==="handicap")&&p.outcomes?.length===2).slice(0,40).map(p=>({kind:p.kind,title:p.title||"",period:p.period||"",line:p.line??"",outcomes:p.outcomes.map(r=>({label:r.label||"",odd:Number(r.odd)}))}))}function gt(){let p=n.match?.live&&e.readEsportsWidget?e.readEsportsWidget(document):null;return p?{home:p.home.map(r=>r.nick),away:p.away.map(r=>r.nick)}:null}function Be(){if(!n.match||!qe())return;let p=Pe();if(!p.market)return;let r=`${n.match.key}|${p.market.odds.join("/")}`;r!==Be.last&&(Be.last=r,ie("lz:quote",p))}async function et(){let p=n.match;if(!p||p.live||n.consensus.has(p.key))return;let r=Pe();if(!r.market?.odds?.length)return;n.consensus.set(p.key,null);let a=await ie("lz:consensus",{match:p,size:r.market.odds.length});n.consensus.set(p.key,a.ok&&a.data?.consensus?a.data:null),n.match?.key===p.key&&d.isOpen&&d.render(Q())}async function ze(){let p=n.match;if(!p?.live||!["basketball","football","hockey","tennis"].includes(p.sport))return;let r=n.live.get(p.key);if(r&&(r.pending||Date.now()-r.at<3e4))return;n.live.set(p.key,{...r||{},pending:!0});let a=await ie("lz:live",{match:p});n.live.set(p.key,{at:Date.now(),data:a.ok&&a.data&&!a.data.error?a.data:null,error:a.ok?a.data?.error||"":a.error||""}),n.match?.key===p.key&&d.isOpen&&d.render(Q())}function $e(p,r){n.fonbetRef.set(p,null),ie("lz:fonbet-ref",{match:r}).then(a=>{n.fonbetRef.set(p,a.ok&&a.data?.odds?a.data:null),a.ok&&a.data?.odds&&n.match?.key===p&&d.isOpen&&d.render(Q())}).catch(()=>{})}function W(p,r,a){let f=n.match,g=`${p}|${[r.best,r.suspect,...r.others].filter(Boolean).map(z=>`${z.label}:${z.odd}`).join(",")}`;if(n.verdictSent===g)return;n.verdictSent=g;let w=[r.best,r.suspect,...r.others].filter(Boolean).map(z=>({label:z.label,odd:z.odd,p:z.p,kind:z.kind||"win",side:z.side||"",line:z.line??null,source:z.source||a,unit:z.unit||""})),S=/консенсус/.test(a)&&n.consensus.get(p)?.fair?.method||"";ie("lz:verdict",{payload:{sport:f.sport,league:f.league||"",home:f.home,away:f.away,book:t.name,source:a,best:r.best?.label||"",options:w,fairMethod:S}}).then(z=>{z?.ok&&z.data?.track&&z.data.track!==n.verdictTrack&&(n.verdictTrack=z.data.track,d.isOpen&&d.render(Q()))}).catch(()=>{})}function ae(p){let r=n.match,a=p&&G();if(!r||!a||r.live)return null;let f=n.analysis.get(p)?.result;if(f?.decision)return f.decision;let g=n.consensus.get(p),w=a.rows,S=g?.fair?.p&&g.fair.p.length===w.length?g.fair.p:g?.consensus?.length===w.length?g.consensus:null,z=S||w.map(j=>j.fair);if(!z?.length||z.some(j=>!(j>0)))return null;let N=n.model.get(p),C=N&&On(N,w.map(j=>j.odd)).ok?N:null;try{return Wr({sport:r.sport,labels:w.map(T=>T.name),probs:z,source:S?`консенсус ${g.count} контор`:`${t.name} без маржи`,model:C,league:r.league||"",oddOf:Xo(w.map(T=>T.odd)),decision:{priceAt:S?g.fair?.at??g.updated??null:Date.now(),now:Date.now()}})?.decision||null}catch{return null}}function Ie(p){let r=n.match,a=p&&G();if(!r||!a||r.live)return null;let f=n.consensus.get(p),g=f?.fair?.p&&f.fair.p.length===f.consensus?.length?f.fair.p:f?.consensus||null,w=a.rows,S=n.model.get(p),z=S&&On(S,w.map(Z=>Z.odd)).ok?S:null,N=z&&En(r.sport)?z:null,C=n.analysis.get(p)?.result,j=[r.home,r.away],T=[],D="";if(g?.length===w.length)w.forEach((Z,se)=>T.push({label:Z.name,odd:Z.odd,p:g[se],side:w.length===3?["home","draw","away"][se]:["home","away"][se]})),D=`консенсус ${f.count} контор`;else if(!f?.consensus&&N?.sport==="hockey"&&N.regulation&&w.length===3){let Z=[N.regulation.p1,N.regulation.px,N.regulation.p2];w.forEach((se,he)=>T.push({label:se.name,odd:se.odd,p:Z[he],side:["home","draw","away"][he]})),D="модель Линзы"}else{let Z=w.length===2?w:r.sport==="mma"&&w.length===3?[w[0],w[2]]:a.overtime?.rows||null,se=g?.length===2?g:N?.p1?[N.p1,N.p2]:null;Z&&se&&(Z.forEach((he,de)=>T.push({label:j[de],odd:he.odd,p:se[de],side:["home","away"][de]})),D=g?.length===2?`консенсус ${f.count} контор`:"модель Линзы")}let K=N?.sport==="mma"?N.durations:null;if(K)for(let Z of n.markets){if(Z.scope==="list"||Z.kind!=="total"||Z.outcomes.length!==2)continue;let se=String(Z.line||"").replace(",","."),he=se==="1.5"?K.r1+K.r2/2:se==="2.5"&&K.rounds===3?K.r1+K.r2+K.r3/2:null,de=Nt(Z.outcomes.map(Te=>Te.label));he==null||de<0||T.some(Te=>Te.kind==="total"&&Te.line===se)||(T.push({label:`Больше ${se} раунда`,odd:Z.outcomes[de].odd,p:1-he,kind:"total",line:se}),T.push({label:`Меньше ${se} раунда`,odd:Z.outcomes[1-de].odd,p:he,kind:"total",line:se}))}if(N?.sport==="basketball"&&N.lines){let Z=kt=>{let ye=String(kt||"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?[0-9]+(?:[.][0-9]+)?/);return ye?Number(ye[0]):NaN},se=kt=>n.markets.filter(ye=>ye.scope!=="list"&&ye.main&&ye.kind===kt&&ye.outcomes.length===2&&ye.outcomes.every(qt=>qt.odd>1)).sort((ye,qt)=>Math.abs(ye.outcomes[0].odd-ye.outcomes[1].odd)-Math.abs(qt.outcomes[0].odd-qt.outcomes[1].odd))[0]||null,he=se("handicap"),de=se("total"),Te=he?Z(he.outcomes[0].label):NaN;he&&!Number.isFinite(Te)&&(Te=Z(he.line));let Gt=de?Z(de.line):NaN;de&&!Number.isFinite(Gt)&&(Gt=Z(de.outcomes[0].label));let wn=de?Nt(de.outcomes.map(kt=>kt.label)):-1;T.push(...Er(N,{handicap:he&&Number.isFinite(Te)?{line:Te,home:he.outcomes[0].odd,away:he.outcomes[1].odd}:null,total:de&&wn>=0&&Number.isFinite(Gt)?{line:Gt,over:de.outcomes[wn].odd,under:de.outcomes[1-wn].odd}:null},j))}let ee=n.markets.filter(Z=>Z.scope!=="list"),oe=w.length===2?De(w.map(Z=>Z.odd)):null;oe?.fair&&["tennis","cs","dota"].includes(r.sport)&&T.push(...ro({sport:r.sport,p:oe.fair[0],source:"цена конторы на победу",markets:ee,names:j,league:r.league||""}));let me=z?.p1&&["tennis","cs","dota"].includes(r.sport)?Gr({sport:r.sport,model:z,markets:ee,names:j,league:r.league||""}):[];if((r.sport==="football"||r.sport==="hockey")&&t.id!=="fonbet"){let Z=n.fonbetRef.get(p);Z===void 0?$e(p,r):Z&&T.push(...Cr(Z,n.markets.filter(se=>se.scope!=="list"),r.sport,j))}if(!T.length)return z?.p1?{best:null,suspect:null,others:[],lines:[Tn(z,j),Cn],track:n.verdictTrack||""}:null;let Fe=[...T].filter(Z=>Z.p*Z.odd-1>=zt&&Z.p*Z.odd-1<=it).sort((Z,se)=>se.p*se.odd-Z.p*Z.odd)[0]?.side,ot=(C?.factors||[]).filter(Z=>Fe&&Z.side===Fe).slice(0,2).map(Z=>Z.text),we=Bo(T,{source:D,reasons:ot,risk:C?.risks?.[0]||""});return we&&z?.p1&&!N&&we.lines.splice(we.lines.length-1,0,Tn(z,j)),we&&me.length&&we.lines.splice(we.lines.length-1,0,Fn(me)),we&&W(p,we,D),we&&{...we,track:n.verdictTrack||""}}function hn(p,r,a){let f=(z,N)=>r?[N,z]:[z,N],w=G()?.rows||[],S=w.length===2&&w.every(z=>Number.isFinite(z.fair))?w.map(z=>z.fair):null;return{kind:"tennis",names:[n.match.home,n.match.away],score:f(p.score[0],p.score[1]),sets:p.sets.map(([z,N])=>f(z,N)),games:f(p.games[0],p.games[1]),points:f(p.points[0],p.points[1]),tiebreak:p.tiebreak,serving:p.aServes==null?null:p.aServes!==r?0:1,bestOf:p.bestOf,prior:p.prior,serve:f(p.serve.a,p.serve.b),probs:f(p.p1,p.p2),set:f(p.set.p1,1-p.set.p1),game:f(p.game.p1,1-p.game.p1),book:S,compare:p.prior.source==="line"||p.prior.source==="model",at:a}}function gn(p,r,a){let f=(N,C)=>r?[C,N]:[N,C],g=N=>r?[N[2],N[1],N[0]]:N,S=G()?.rows||[],z=S.length===3&&S.every(N=>Number.isFinite(N.fair))?S.map(N=>N.fair):null;return{kind:"goals",sport:p.sport,names:[n.match.home,n.match.away],score:f(p.score[0],p.score[1]),red:f(p.red[0],p.red[1]),minute:p.minute,period:p.period,periods:p.periods,clock:p.clock,prior:p.prior,probs:g([p.p1,p.px,p.p2]),book:z,compare:p.prior.source==="line",expTotal:p.expTotal,nextGoal:g([p.nextGoal.home,p.nextGoal.none,p.nextGoal.away]),total:p.tables.total,handicap:p.tables.handicap.map(N=>r?{line:-N.line,home:N.away,away:N.home}:N).sort((N,C)=>N.line-C.line),bookLines:p.bookLines,at:a}}function bn(p){let r=p&&n.live.get(p);if(!r?.data)return r?.error?{error:r.error}:null;let a=r.data,f=!!a.flipped;if(a.kind==="goals")return gn(a,f,r.at);if(a.kind==="tennis")return hn(a,f,r.at);let g=(C,j)=>f?[j,C]:[C,j],w=G(),S=w?.overtime?.rows||w?.rows||[],z=S.length===2?S.map(C=>C.fair):S.length===3&&S.every(C=>Number.isFinite(C.fair))?[S[0].fair+S[1].fair/2,S[2].fair+S[1].fair/2]:null,N=a.tables||{};return{names:[n.match.home,n.match.away],score:g(a.score[0],a.score[1]),periods:(a.periods||[]).map(([C,j])=>g(C,j)),period:a.period,elapsed:a.elapsed,left:a.left,clock:a.clock,format:a.format,probs:g(a.p1,a.p2),book:z,prior:a.prior,expMargin:f?-a.expMargin:a.expMargin,sd:a.sd,projTotal:a.projTotal,sdTotal:a.sdTotal,handicap:(N.handicap||[]).map(C=>f?{line:-C.line,home:C.away,away:C.home}:C).sort((C,j)=>C.line-j.line),total:N.total||[],quarterTotal:N.quarterTotal||[],bookLines:a.bookLines?{handicap:a.bookLines.handicap?f?{...a.bookLines.handicap,line:-a.bookLines.handicap.line,odds:[...a.bookLines.handicap.odds].reverse(),fair:[...a.bookLines.handicap.fair].reverse(),p:1-a.bookLines.handicap.p,book:1-a.bookLines.handicap.book,gap:-a.bookLines.handicap.gap}:a.bookLines.handicap:null,total:a.bookLines.total||null}:null,quarter:a.quarter?{...a.quarter,score:g(a.quarter.score[0],a.quarter.score[1]),expMargin:f?-a.quarter.expMargin:a.quarter.expMargin,probs:g(a.quarter.p1,a.quarter.p2)}:null,at:r.at}}async function Bt(){let p=n.match;if(!p||!["cs","dota","tennis","basketball","mma","hockey"].includes(p.sport)||n.model.has(p.key)||p.live&&(p.sport==="tennis"||p.sport==="basketball"||p.sport==="mma"||p.sport==="hockey"))return;n.model.set(p.key,null);let r=await ie("lz:model",{match:p});n.model.set(p.key,r.ok&&r.data?.p1?r.data:null),n.match?.key===p.key&&d.isOpen&&d.render(Q())}let It=new Map;async function jt(){let p=n.match;if(!p||!["football","hockey","basketball","cs","dota"].includes(p.sport))return;let r=p.live&&Date.now()-(It.get(p.key)||0)>60*1e3;if(n.facts.has(p.key)&&!r)return;let a=n.facts.get(p.key)||null;It.set(p.key,Date.now()),n.facts.set(p.key,a);let f=await ie("lz:facts",{match:p});n.facts.set(p.key,f.ok&&f.data?.facts?.length?f.data:a),n.match?.key===p.key&&d.isOpen&&d.render(Q())}async function xn(){let p=n.match;if(!p||n.analysis.has(p.key))return;let r=await ie("lz:cached",{match:p});!r.ok||!r.data||n.analysis.has(p.key)||(n.analysis.set(p.key,{status:"done",steps:[],result:r.data}),P(),U())}function $n(){return{more(p){n.match?.key&&(n.more={key:n.match.key,open:!!p},Oe({"lz.more":n.more}))},opened(){ge(),P(),xn(),et(),Bt(),jt(),ze(),le(),d.render(Q()),pe()},tab(p){p==="settings"&&(n.backTab=n.tab==="settings"?n.backTab:n.tab),n.tab=p||"match",d.render(Q())},theme(){re({theme:n.theme==="dark"?"light":"dark"})},"overlay-toggle"(){re({overlay:n.settings.overlay==="off"?"picks":"off"})},"set-overlay"(p){re({overlay:p})},"set-theme"(p){re({theme:p})},async"set-mode"(p){await ie("lz:settings",{mode:p}),ge()},"copy-code"(p){if(!p)return;let r=()=>d.toast("Промокод скопирован");navigator.clipboard?.writeText?navigator.clipboard.writeText(p).then(r,()=>d.toast(`Промокод: ${p}`)):d.toast(`Промокод: ${p}`)},async"save-key"(p,r,a){let f=a.getElementById("lz-key"),g=(f?.value||"").trim();if(g.length<8)return d.toast("Вставьте ключ целиком");let w=await ie("lz:settings",{apiKey:g});d.toast(w.ok?"Ключ сохранён":w.error),f&&(f.value=""),ge()},async"clear-key"(){await ie("lz:settings",{apiKey:""}),d.toast("Ключ удалён"),ge()},async"save-license"(p,r,a){let f=a.getElementById("lz-license"),g=(f?.value||"").trim();if(g.length<6)return d.toast("Вставьте ключ целиком");let w=await ie("lz:settings",{licenseKey:g});d.toast(w.ok?"Ключ принят":w.error),f&&(f.value=""),ge()},async"clear-license"(){await ie("lz:settings",{licenseKey:""}),d.toast("Ключ удалён"),ge()},savePosition(p,r){n.positions[p]=r,Zn(["lz.positions"]).then(a=>{let f=a["lz.positions"]||{};f[location.hostname]=n.positions,Oe({"lz.positions":f})})},async analyze(){if(!n.match)return;let p=n.match.key,r={status:"loading",steps:[`${n.match.home} — ${n.match.away}`]};n.analysis.set(p,r),U();let a=await ie("lz:analyze",{...Pe(),markets:ht(),players:gt(),force:!0}),f=a.ok?a.data?.job:"",g=Date.now();for(;f&&a.ok&&a.data?.status==="running"&&Date.now()-g<420*1e3;){if(r.steps=[r.steps[0],...(a.data.steps||[]).map(w=>w.text)].slice(-8),U(),await new Promise(w=>setTimeout(w,2e3)),n.analysis.get(p)!==r)return;a=await ie("lz:job",{job:f}),!a.ok&&a.code==="retry"&&(a=await ie("lz:job",{job:f}))}if(a.ok&&f){let w=a.data?.steps?.length?[r.steps[0],...a.data.steps.map(S=>S.text)].slice(-8):r.steps;a.data.status==="done"?n.analysis.set(p,{status:"done",steps:w,result:{...a.data.result,full:a.data.full||null}}):a.data.status==="error"?n.analysis.set(p,{status:"error",steps:w,error:a.data.error}):n.analysis.set(p,{status:"error",steps:w,error:"Разбор идёт дольше 7 минут. Нажмите ещё раз — собранное уже на сервере, второй раз будет быстрее."})}else a.ok?n.analysis.set(p,{status:"done",steps:r.steps,result:a.data}):n.analysis.set(p,{status:"error",steps:r.steps,error:a.error,needKey:a.code==="no-access"});ge(),P(),d.render(Q())},async report(){let p=n.match?n.analysis.get(n.match.key):null,r="";try{r=chrome.runtime.getManifest().version}catch{}let a=await ie("lz:report",{where:"panel",url:location.href,book:t.name,version:r,match:n.match?`${n.match.home} — ${n.match.away}`:"",step:p?.steps?.slice(-1)[0]||"",error:p?.error||(p?.status==="done"?"разбор выглядит неправильно":"страница матча не узнана")});d.toast(a.ok?"Спасибо! Сообщение ушло разработчику.":a.error)},async compare(){if(!n.match)return;let p=n.match.key;n.compare.set(p,{status:"loading"}),U();let r=await ie("lz:compare",Pe());n.compare.set(p,r.ok?{status:"done",...r.data}:{status:"done",rows:[],labels:[],note:r.error}),r.ok&&zr(n.margins,p,r.data.rows)&&k(),U()},"whatsnew-ok"(){n.whatsnew=null,Oe({"lz.whatsnew":null}),U()},"pick-clear"(){n.selected=null,y(),U()},async"leg-add"(){let p=q(),r=v();if(!p?.canAdd||!r)return;let a=r.market.event,f={id:`${r.market.id}#${r.index}`,match:a?.key||n.match?.key||"",title:p.market,label:p.label,odd:p.odd,fair:p.fair,start:null,at:Date.now(),sport:bt(r.market)||"",league:a?.league||n.match?.league||""},{legs:g,change:w}=Xr(await io()??mt(n.express),f);if(w==="full")return d.toast(`В экспрессе не больше ${15} исходов`);n.express=g,Oe({[Ee]:g}),d.toast(w==="replaced"?"Исход этого матча заменён в экспрессе":"Добавлено в расчёт экспресса"),U()},async"leg-remove"(p){n.express=Zr(await io()??n.express,p),Oe({[Ee]:n.express}),U()},"leg-clear"(){n.express=[],Oe({[Ee]:n.express}),U()},"open-linza"(){ie("lz:open").then(p=>{p.ok||d.toast(p.error)})},"scan-go"(p){let r=n.markets[Number(p)],a=r?.outcomes[0]?.el;a?.isConnected&&(a.scrollIntoView({behavior:"smooth",block:"center"}),n.selected={id:r.id,index:0},setTimeout(y,400))}}}function Dt(p){let r=p.composedPath();for(let a=0;a<Math.min(r.length,6);a+=1){let f=r[a]instanceof Element?c.get(r[a]):null;if(f&&f.market.outcomes[f.index]?.el===r[a])return f}return null}let tt=new Map;function kn(p){if(!p.event||!p.main||!["1x2","12"].includes(p.kind)||p.scope!=="list"||p.event.live)return console.debug("[lz] рынок для списка не запрашивается:",JSON.stringify({event:!!p.event,main:p.main,kind:p.kind,scope:p.scope,live:p.event?.live})),null;let r=p.event.key;if(tt.has(r))return tt.get(r);let a={home:p.event.home,away:p.event.away,sport:bt(p),league:p.event.league||""},f=ie("lz:consensus",{match:a,size:p.outcomes.length}).then(g=>((!g.ok||!g.data?.consensus)&&console.debug("[lz] рынок для списка:",g.error||g.data?.error||"нет данных"),g.ok&&g.data?.consensus?g.data:null)).catch(g=>(console.debug("[lz] рынок для списка:",String(g?.message||g)),null));return tt.set(r,f),f.then(g=>tt.set(r,g)),f}let bt=p=>p.event?.sport||n.match?.sport||st(location.pathname,document.title,p.event?.league);function Ue({market:p,index:r},a=null){let f=m(p),g=h(p),w=p.event?`${p.event.home} — ${p.event.away}`:"",S=p.outcomes.map((C,j)=>{let T=f.fair?f.fair[j]:1/C.odd;return s(`div.tip-row${j===r?".hot":""}`,{},s("span",{text:$(p,j)}),s("span.odd",{text:J(C.odd)}),s("span.pct",{text:T<.1?ve(T,1):pt(T)}),s("span.tip-bar",{},s("i",{style:`width:${Math.round(T*100)}%`})))}),z=f.kind==="partial"?s("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):s("div.tip-foot",{},"Маржа конторы ",s("b",{text:ve(f.margin,1)}),g?s("span",{}," · модель: ",s("b",{text:ve(g[r],1)})):null),N=null;if(a?.consensus){let C=a.fair?.p?.length===a.consensus.length?a.fair.p:a.consensus,j=C.length===p.outcomes.length,T=!j&&C.length===2&&p.outcomes.length===3;if(j||T){let D=j?C[r]:null,K=D?p.outcomes[r].odd*D-1:0;N=s("div.tip-foot",{},`Рынок, ${Xt(a).who}${T?", с овертаймом":""}: `,s("b",{text:C.map(ee=>pt(ee)).join(" / ")}),K>.005?s("span",{text:` · расхождение ${Lt(K)} — не доход`}):null)}}else a===void 0&&(N=s("div.tip-foot",{text:"Рынок: сверяю…"}));return s("div",{},s("div.tip-title",{text:[p.title,p.period,p.line].filter(Boolean).join(" · ")}),w?s("div.tip-sub",{text:w}):s("div.tip-sub",{text:"Шанс по линии без маржи"}),S.slice(0,8),z,N)}let xt=0,nt=null;mn.on("page:pointerover",p=>{if(n.settings.overlay==="off")return;let r=Dt(p),a=r?r.market.outcomes[r.index].el:null;if(a!==nt){if(nt=a,clearTimeout(xt),!r)return u.hideTip();xt=setTimeout(()=>{if(nt!==a||!a.isConnected)return;u.setAvoid(d.rect());let f=kn(r.market);u.showTip(a,Ue(r,f instanceof Promise?void 0:f)),f instanceof Promise&&f.then(g=>{nt===a&&a.isConnected&&u.showTip(a,Ue(r,g))})},280)}}),mn.on("page:click",p=>{let r=Dt(p);r&&(n.selected={id:r.market.id,index:r.index},n.tab==="scan"&&(n.tab="match"),y(),U())}),vr(p=>{if(p.type!=="lz:progress")return;let r=n.analysis.get(p.key);!r||r.status!=="loading"||(r.steps=[...r.steps,p.text].slice(-7),U())});let $t=()=>{P(),new MutationObserver(I).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||P()}),setInterval(()=>{!document.hidden&&location.href!==n.url&&P()},600),setInterval(()=>{!document.hidden&&d.isOpen&&I()},4e3),qe()&&chrome.storage.onChanged.addListener(p=>{p[Ee]&&(n.express=mt(p[Ee].newValue),U()),p["lz.settings"]&&(n.settings=Ut(p["lz.settings"].newValue),P())}),ge()};document.body?$t():document.addEventListener("DOMContentLoaded",$t,{once:!0}),document.documentElement.setAttribute("data-lz",t.id),globalThis.__lz={state:n,view:Q,refresh:P,overlay:u,panel:d}}})();
