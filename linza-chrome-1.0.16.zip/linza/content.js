(()=>{var qt=s=>typeof s=="string"?s:"",ee={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:qt("https://linzabet.ru/"),telegram:qt("https://t.me/linza_odds"),bot:qt("https://t.me/linza_keys_bot?start=ext")},Yo=qt("https://linzabet.ru"),Jo=qt("https://185-72-145-3.sslip.io"),Dn={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var Rn=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function De(s){let r=String(s||"").toLowerCase();return Rn.find(a=>a.hosts.some(n=>r===n||r.endsWith(`.${n}`)))||null}var $e={overlay:"picks",theme:"auto",mode:"own",model:Dn.model,stake:1e3},Re={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",mma:"ММА",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function xt(s){let r=String(s??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(r))return null;let a=parseFloat(r.replace(",","."));return a>=1.001&&a<=1e3?a:null}var qe=s=>s.reduce((r,a)=>r+1/a,0);function vt(s){let r=(s||[]).filter(n=>Number.isFinite(n)&&n>1);if(r.length<2||r.length!==(s||[]).length)return{kind:"partial",margin:null,fair:null};let a=qe(r);if(a>=.985&&a<=1.3)return{kind:"full",margin:a-1,fair:r.map(n=>1/n/a)};if(r.length===3&&a>=1.97&&a<=2.4){let n=a/2;return{kind:"double",margin:n-1,fair:r.map(p=>Math.min(.995,1/p/n))}}return{kind:"partial",margin:null,fair:null}}function Ge(s){let r=(s||[]).map(m=>m||[]).filter(m=>m.length),a=r.flat().filter(Boolean);if(a.length<2)return{sets:[],rest:a};let n=m=>m.length>=2&&m.every(Boolean)&&vt(m.map(h=>h.odd)).kind!=="partial",p=m=>{let h=m.filter(v=>v.some(Boolean));if(!h.length)return null;let y=h.filter(n);if(y.length/h.length<.6)return null;let g=new Set(y.flat());return{sets:y,rest:a.filter(v=>!g.has(v))}},u=m=>{let h=[];for(let y=0;y<r.length;y+=m)h.push(r.slice(y,y+m).flat());return h},c=()=>{let m=[];for(let h=0;h+1<r.length;h+=2){let y=Math.max(r[h].length,r[h+1].length);for(let g=0;g<y;g+=1)m.push([r[h][g]??null,r[h+1][g]??null])}return m},l=[()=>u(1)];r.length>=2&&r.length%2===0&&l.push(c,()=>u(2)),r.length>=3&&r.length%3===0&&l.push(()=>u(3)),r.length>1&&l.push(()=>[r.flat()]);for(let m of l){let h=p(m());if(h)return h}return{sets:[],rest:a}}function Ue(s,r=1.13){let a=l=>{let m=qe(l.map(h=>h.odd));return m>=.995&&m<=r?!0:l.length===3&&m>=1.99&&m<=r*2},n=l=>Math.abs(l*4-Math.round(l*4))<1e-9,p=[],u=[],c=0;for(;c<s.length;){let l=s.slice(c,c+3),m=s.slice(c,c+2);l.length===3&&a(l)?(p.push(l),c+=3):m.length===2&&a(m)?(p.push(m),c+=2):s[c+2]&&n(s[c+1].odd)&&a([s[c],s[c+2]])?(p.push([s[c],s[c+2]]),u.push(s[c+1]),c+=3):(u.push(s[c]),c+=1)}return{sets:p,rest:u}}function Ve(s){let r=(s||[]).filter(p=>p&&p.odd>1&&p.fair>0&&p.fair<1);if(!r.length)return null;let a=r.reduce((p,u)=>p*u.odd,1),n=r.reduce((p,u)=>p*u.fair,1);return{legs:r.length,odd:a,chance:n,fairOdd:1/n,margin:1-a*n}}function We(s,r){return s*r-1}function K(s){return Number.isFinite(s)?s>=100?s.toFixed(0):s>=10?s.toFixed(1):s.toFixed(2):"—"}function yt(s,r=0){if(!Number.isFinite(s))return"—";let a=s*100;return a>0&&a<1&&r===0?"<1%":`${a.toFixed(r)}%`}function Me(s){return String(s??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zа-я0-9]/g,"")}var qn=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function Ke(s){return String(s??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[\u0300-\u036f]/g,"").split(/[^a-zа-я0-9]+/).filter(r=>r.length>=2&&!qn.has(r))}function Gt(s,r){let a=Me(s),n=Me(r);if(a.length<2||n.length<2)return 0;if(a===n)return 1;let p=a.length<=n.length?a:n,u=p===a?n:a;if(p.length>=4&&u.includes(p))return .85;let c=Ke(s),l=Ke(r),m=y=>String(y??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[̀-ͯ]/g,"").match(/^\s*([a-zа-я-]{3,})\s+([a-zа-я])\.?\s*$/);for(let[y,g]of[[s,l],[r,c]]){let v=m(y);if(v&&g.length>=2&&g.includes(v[1])&&g.some(k=>k!==v[1]&&k[0]===v[2]))return .8}if(c.length&&l.length){let g=c.filter(v=>l.some(k=>k===v||v.length>=5&&k.startsWith(v.slice(0,5)))).length/Math.max(c.length,l.length);if(g>=.5)return .6+.3*g}let h=0;for(;h<a.length&&h<n.length&&a[h]===n[h];)h+=1;return h>=5?Math.min(.8,.45+h*.04):0}function Gn(s){let r=String(s??"").toLowerCase(),a=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(r)&&a.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(r)&&a.push("women"),/\(рез|\(р\)|резерв|reserve/.test(r)&&a.push("reserve"),/люб/.test(r)&&a.push("amateur"),/кибер|esport|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(r)&&a.push("cyber"),a.join("+")}function Ft(s,r){let a=u=>{let c=Me(u),l=Gn(u);return c.length<2?"":l?`${c}~${l}`:c},n=a(s),p=a(r);return!n||!p?"":[n,p].sort().join("|")}var D=s=>(s?.textContent||"").replace(/[ \s]+/g," ").trim(),ze=s=>s.offsetParent===null&&s.tagName!=="BODY";function Un(s){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(s||"").trim())}function Vn(s){let r=String(s||"").match(/(\d+)\s*[-‑–]?\s*(?:го|й|м|ой|ий|я|ая|ья|ый)?\s+(период|тайм|сет|четверт|половин|карт|гейм|иннинг)/i);return r?r[0]:""}function Ut(s,r){let a=String(s||"").toLowerCase();return/двойной шанс/.test(a)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(a)?"other":/фор[аы]|гандикап/.test(a)?"handicap":/тотал/.test(a)?"total":/обе забьют/.test(a)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(a)?r===3?"1x2":r===2?"12":"other":"other"}var Wn=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/(^|[^а-яёa-z])(мма|mma|ufc|юфс)([^а-яёa-z]|$)|смешанн|единоборств|mixed martial|бои без правил/i,"mma"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function Bt(...s){let r=s.filter(Boolean).join(" ");for(let[a,n]of Wn)if(a.test(r))return n;return""}function Se(s){if(!s)return null;let r=xt(D(s));if(r)return r;let a=D(s).split(" ");return xt(a[a.length-1])}var Kn=0;function Lt({scope:s,title:r,period:a="",line:n="",kind:p,outcomes:u,event:c=null,anchor:l=null,eventKey:m=""}){let h=u.length;return{id:`${s}|${m}|${r}|${a}|${n}|${u.map(y=>y.label).join("/")}`,serial:Kn+=1,scope:s,title:r,period:a,line:n,kind:p||Ut(r,h),main:Un(a)&&!Vn(r),outcomes:u,event:c,anchor:l||u[0]?.el||null}}var H=(s,r)=>[...s.querySelectorAll(r)];function Je(s){return(String(s||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function _e(s){return s.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":s.querySelector(".card")?"list":"other"}var Ze={win:"В",loose:"П",lose:"П",draw:"Н"};function He(s){return H(s,".competitor-form__value").map(r=>Ze[[...r.classList].find(a=>Ze[a])]||D(r).slice(0,1)).filter(Boolean).join("")}function Zn(s){let r=s.querySelector(".marketbook-header--live");if(r){let n=H(r,".game-scoring__item").map(c=>D(c)),p=H(r,".game-periods .period").map(c=>{let l=H(c,"span");return{label:D(c.querySelector("i")),home:D(l[0]),away:D(l[1])}}).filter(c=>c.home!==""&&c.away!==""),u=H(r,".game-specials > div").map(c=>{let l=H(c,"span"),m=c.querySelector("i"),h=m?.classList.contains("yellow-card")?"жёлтые":m?.classList.contains("red-card")?"красные":m?.classList.contains("penalty-card")?"угловые":"";return h?{kind:h,home:D(l[0]),away:D(l[1])}:null}).filter(Boolean);return{state:D(r.querySelector(".game-timing-state")),score:n.length===2?n:[],periods:p,extras:u}}let a=s.querySelector(".match-card");if(a&&!a.querySelector(".match-card__timer--prematch")){let n=D(a.querySelector(".match-card__main-score")).replace(/\s/g,""),p=H(a,".match-card__score").map(c=>D(c)).filter(c=>/^\d{1,2}$/.test(c)),u=H(s,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(c=>D(c)).filter(c=>/\d\s*:\s*\d/.test(c)).slice(0,5);return{state:D(a.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(n)?n.split(":"):[],rounds:p.length>=2?p.slice(0,2):[],periods:u.map((c,l)=>({label:`${l+1} карта`,raw:c})),extras:[]}}return null}function Xe(s,r){if(_e(s)!=="match")return null;let a=H(s,".breadcrumbs .breadcrumbs__item").map(h=>D(h)).filter(Boolean),n=D(s.querySelector(".event-breadcrumbs")),p=H(s,".marketbook-header--prematch .competitor-name").map(h=>D(h));if(p.length<2&&(p=H(s,".marketbook-header--live .competitors-desc__name").map(h=>D(h))),p.length<2&&(p=H(s,".match-card .match-card__team-name").map(h=>D(h))),p.length<2||!p[0]||!p[1])return null;let u=Bt(a[1]&&/киберспорт/i.test(a[0])?a[1]:"",a[0],n),c=/киберспорт/i.test(a[0]||"")?a.slice(2).join(", ")||n.split(",").slice(1).join(",").trim():a.slice(1).join(", "),l=[D(s.querySelector(".prematch-date")),D(s.querySelector(".prematch-time"))].filter(Boolean).join(" ")||D(s.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),m=Zn(s);return{book:"Winline",id:Je(r?.pathname),key:Ft(p[0],p[1]),home:p[0],away:p[1],sport:u,league:c,start:m?"":l,live:m,form:{home:He(s.querySelector(".competitor-form--left")||s.createElement("div")),away:He(s.querySelector(".competitor-form--right")||s.createElement("div"))},stats:to(eo(s),p[0],p[1]),url:r?.href||""}}function Hn(s,r){let a=[];for(let n of H(s,".bet-line")){if(ze(n))continue;let p=D(n.querySelector(".bet-line__market-name")),u=D(n.querySelector(".bet-line__period")),c=H(n,".odd-btn"),l=c.map((h,y)=>{let g=D(h.querySelector(".odd-btn__label")),v=H(h,"span").map(k=>xt(D(k))).find(Boolean)||null;return v?{el:h,odd:v,label:g||Ne(c.length,y,p),locked:!1}:null});if(l.length<2||l.some(h=>!h))continue;let m=D(n.querySelector(".coef-btn")).replace(/\s+/g," ");a.push(Lt({scope:"top",title:p,period:u,line:m,outcomes:l,anchor:n,eventKey:r}))}return a}function Ne(s,r,a){return/тотал/i.test(a)?["Меньше","Больше"][r]||"":s===3?["П1","Х","П2"][r]:s===2?["1","2"][r]:String(r+1)}function Xn(s,r){let a=[];for(let n of H(s,".market")){let p=H(n,".market__row");if(!p.length)continue;let u=D(n.querySelector(".market-title")),c=p.map(m=>{let h=D(m.querySelector(".market__row-text"));return H(m,".market-row-btn").map(y=>{let g=xt(D(y.querySelector(".market-row-btn__coef")));if(!g||y.hasAttribute("disabled"))return null;let v=y.getAttribute("title")||D(y.querySelector(".market-row-btn__text"));return{el:y,odd:g,label:v.replace(/\s+/g," ").trim(),rowLabel:h,locked:!1}})}),{sets:l}=Ge(c);for(let m of l){let h=[...new Set(m.map(k=>k.rowLabel).filter(Boolean))],y=h.length<=1,g=y?"":(m[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],v=m.map(k=>({el:k.el,odd:k.odd,label:y?k.label:k.rowLabel||k.label,locked:!1}));a.push(Lt({scope:"board",title:u,period:y&&h[0]||"",line:g,kind:Ut(u,v.length),outcomes:v,anchor:n,eventKey:r}))}}return a}var Yn=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function Jn(s){let r=H(s,".card__competitors .name .name, .half__names .name").map(n=>D(n));if(r.length<2)return null;let a=s.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:Je(a),key:Ft(r[0],r[1]),home:r[0],away:r[1],href:a,live:/card--live/.test(s.className)||!!s.querySelector(".card__body-live"),time:D(s.querySelector(".header-left__time, .footer__time")),league:D(s.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:s}}function Ye(s){let r=[];for(let a of H(s,".card")){if(ze(a))continue;let n=Jn(a);if(n){for(let p of H(a,".card__body")){let u=D(p.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(p.className)?"отрезок":"");for(let c of H(p,".card__market")){let l=H(c,".coefficient-button");if(l.length<2)continue;let m=(Yn.find(([y])=>y.test(l[0].className))||[])[1]||"other",h=l.map((y,g)=>{let v=/--is-blank/.test(y.className)?null:Se(y);return v?{el:y,odd:v,label:m==="total"?["Меньше","Больше"][g]:Ne(l.length,g,""),locked:/coefficient-button_locked/.test(y.className)}:null});h.some(y=>!y)||r.push(Lt({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[m]||"Рынок",period:/^матч$/i.test(u)?"":u,line:D(c.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:m,outcomes:h,event:n,anchor:a,eventKey:n.key}))}}for(let p of H(a,".half__coef-buttons")){let u=H(p,".coef-buttons__button"),c=u.map((l,m)=>{let h=Se(l.querySelector(".button__coef-title")||l);return h?{el:l,odd:h,label:Ne(u.length,m,""),locked:!1}:null});c.length<2||c.some(l=>!l)||r.push(Lt({scope:"list",title:c.length===3?"Исход":"Победитель",kind:c.length===3?"1x2":"12",outcomes:c,event:n,anchor:a,eventKey:n.key}))}}}return r}function Qn(s){if(!s?.body)return null;let r=m=>/^\d{1,3}\s?%$/.test(m),a=H(s,"h4").map(m=>{let h=[...m.nextElementSibling?.children||[]],y=D(h[0]),g=D(h[h.length-1]);return r(y)&&r(g)?{label:D(m),home:y.replace(/\s/g,""),away:g.replace(/\s/g,"")}:null}).filter(Boolean);if(!a.length)return null;let n=(s.body.innerText||s.body.textContent||"").replace(/\s+/g," "),p=[...n.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(m=>Number(m[1])),c=[...(n.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(m=>m[1].replace(/\s/g,""));return{names:D(s.querySelector("h3")).split(/\s+vs\s+/i).map(m=>m.trim()).filter(Boolean),rows:a,samples:p.slice(0,2),form:c.length>=2?{home:c[0],away:c[1]}:null}}function to(s,r,a){if(!s||s.names.length<2)return s;let n=Gt(s.names[0],r)+Gt(s.names[1],a);return Gt(s.names[0],a)+Gt(s.names[1],r)<=n?s:{names:[s.names[1],s.names[0]],rows:s.rows.map(u=>({label:u.label,home:u.away,away:u.home})),samples:s.samples.slice().reverse(),form:s.form?{home:s.form.away,away:s.form.home}:null}}function eo(s){let r=s.querySelector("iframe.stats__iframe");if(!r)return null;try{return Qn(r.contentDocument)}catch{return null}}function no(s){let r=["one","two"].map(u=>s.querySelector(`.event-live-center__team-widget--${u}`));if(!r[0]||!r[1])return null;let a=u=>{let c=u;try{c=u.querySelector("iframe")?.contentDocument?.body||u}catch{c=u}let l=H(c,'[class*="player"]').filter(h=>!H(h,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(h.className)),m=[];for(let h of l){let y=D(h).split(" ").filter(Boolean),g=y.find(k=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test(k)&&/[A-Za-z]/.test(k));if(!g||m.some(k=>k.nick===g))continue;let v=y.filter(k=>/^\d{1,3}$/.test(k)).map(Number);m.push({nick:g,numbers:v.slice(0,4)})}return m.slice(0,5)},n=a(r[0]),p=a(r[1]);return n.length<3||p.length<3?null:{home:n,away:p}}var Qe={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:_e,readMatch:Xe,readEsportsWidget:no,observeTargets(s){try{let r=s.querySelector("iframe.stats__iframe")?.contentDocument?.body;return r?[r]:[]}catch{return[]}},collect(s,r){if(_e(s)==="match"){let p=Xe(s,r)?.key||"";return[...Hn(s,p),...Xn(s,p),...Ye(s)]}return Ye(s)}};var oe=(s,r)=>{try{return[...s.querySelectorAll(r)]}catch{return[]}};function tn(s,r){let a=[s];if(r.shadow)for(let n of oe(s,r.shadow))n.shadowRoot&&a.push(n.shadowRoot);return a}var ne=s=>(s.defaultView?.innerWidth||0)>0,oo='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function so(s){let r=[],a=s.ownerDocument.createTreeWalker(s,4);for(;a.nextNode();){let n=a.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(n&&r.push(...n.split(" ")),r.length>5)return null}return r}function ro(s,r){if(r.label){let a=s.querySelector(r.label),n=a?a.textContent.replace(/[ \s]+/g," ").trim():"";if(n&&!/^\d{1,3}[.,]\d{1,3}$/.test(n))return n}if(r.cell&&r.headerRow){let a=s.closest(r.cell),n=a?.parentElement,p=n?.parentElement?.querySelector(r.headerRow);if(p&&p!==n){let u=[...n.children].indexOf(a),c=p.children[u]?.textContent.replace(/[ \s]+/g," ").trim()||"";if(c)return c.charAt(0).toUpperCase()+c.slice(1).toLowerCase()}}return""}function ao(s,r){if(!r.cell||!r.lineCell)return"";let a=s.closest(r.cell);for(;a&&(a=a.previousElementSibling);){if(!a.matches?.(r.lineCell))continue;let n=a.textContent.replace(/[ \s]+/g," ").trim().match(/([+\-−–]?\d+(?:[.,]\d+)?)\s*\)?\s*$/);return n?n[1].replace(",",".").replace(/[−–]/,"-"):""}return""}function io(s,r){if(s.disabled||s.hasAttribute?.("disabled"))return null;let a=r.value&&s.querySelector(r.value)||s,n=so(a);if(!n||!n.length||n.join(" ").length>28)return null;let p=n[n.length-1];if(!(r.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(p))return null;let u=xt(p);if(!u||u>500||n.slice(0,-1).some(l=>/^\d{1,3}[.,]\d{1,3}$/.test(l)))return null;let c=n.slice(0,-1).join(" ");return!r.outcome&&/[+−]|^-/.test(c)?null:{odd:u,label:c}}function lo(s,r){let a=[],n=new Set,p=tn(s,r).flatMap(u=>oe(u,r.outcome||oo));for(let u of p){if(n.has(u)||r.skip&&u.closest(r.skip)||u.closest("#lz-root, #lz-marks"))continue;let c=io(u,r);if(c){if(!r.outcome&&ne(s)){let l=u.getBoundingClientRect();if(l.width<26||l.width>320||l.height<16||l.height>90)continue}n.add(u),a.push({el:u,odd:c.odd,label:c.label||ro(u,r),line:ao(u,r),locked:!1})}}return r.outcome?a:a.filter(u=>!a.some(c=>c.el!==u.el&&c.el.contains(u.el)))}function co(s,r,a){if(r.row)return s.closest(r.row);let n=s.parentElement;for(let p=0;p<6&&n&&n!==n.ownerDocument.body;p+=1){let u=a(n);if(u>=2&&u<=16){if(!ne(n.ownerDocument))return n;let c=n.getBoundingClientRect();if(c.height<=130&&c.width>=120)return n}if(u>16)break;n=n.parentElement}return null}var en=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось|окко|okko|матч тв|match tv|кинопоиск|трансляция|видео|статистика|stats)$/i;function uo(s,r){let a=r.length,n=s;for(let y=0;y<7;y+=1){let g=n.parentElement;if(!g||r.some(T=>!g.contains(T.el))||g.querySelectorAll("*").length>400||[...g.querySelectorAll('button, a, td, [role="button"]')].filter(T=>!r.some(w=>w.el===T||w.el.contains(T)||T.contains(w.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(D(T))).length>a)break;n=g}let p=r[0].el,u=[],c=n.ownerDocument.createTreeWalker(n,4);for(;c.nextNode();){let y=c.currentNode;if(p.contains(y))break;let g=y.textContent.replace(/[ \s]+/g," ").trim();g.length<2||g.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(g)||/\d{1,2}:\d{2}|^\d|['′]$/.test(g)||en.test(g)||u.push(g)}let l=u.slice(-2),m=u.map(y=>y.split(/\s+[—–-]\s+/)).filter(y=>y.length===2).pop();if(m&&(l=m),l.length<2||l[0]===l[1])return null;let h=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:Ft(l[0],l[1]),home:l[0],away:l[1],href:h,live:!1,time:"",league:"",card:n}}function po(s,r,a){if(!r.names)return uo(s,a);let n=r.event&&s.closest(r.event)||s,p=[...new Set(oe(n,r.names).map(l=>D(l)).filter(Boolean))],u=p;if(p.length===1&&(u=p[0].split(/\s+[—–-]\s+/)),u.length<2||!u[0]||!u[1])return null;let c=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:Ft(u[0],u[1]),home:u[0],away:u[1],href:c,live:!1,time:"",league:"",card:n}}function mo(s){let a=String(s.title||"").replace(/^\s*(ставки на (матч|игру|бой)|матч)\s+/i,"").match(/^(.{2,40}?)\s+(?:[—–-]|x|vs|против)\s+(.{2,40}?)(?=\s*[:,|.(📅]|\s+[—–-]\s|\s+ставк|\s+прогноз|\s+коэффиц|\s+live\b|\s+лайв\b|\s+\d{1,2}(?:[./]\d|\s+[а-я]{3,})|$)/i);if(!a)return null;let n=[a[1].trim(),a[2].trim()];return n.some(p=>/ставк|контор|онлайн|букмекер|прогноз|коэффиц|!$/i.test(p))?null:n}function nn(s,r={}){function a(v,k){return r.matchUrl&&r.matchUrl.test(k?.pathname||"")||r.matchPage&&v.querySelector(r.matchPage)?"match":"list"}function n(v){let k=v.defaultView;if(!k||!ne(v))return[];let T=[];for(let w of v.querySelectorAll("h1, h2, h3, div, span, p, a")){if(w.children.length)continue;let A=D(w);if(A.length<3||A.length>40||!/[A-Za-zА-Яа-яЁё]{3}/.test(A)||/\d{1,2}[:.]\d{2}/.test(A)||en.test(A))continue;let B=w.getBoundingClientRect();if(!(B.top<60||B.top>450||B.width<30||parseFloat(k.getComputedStyle(w).fontSize)<15)&&(T.includes(A)||T.push(A),T.length===2))break}return T}function p(v,k){if(a(v,k)!=="match")return null;let T=r.matchNames?oe(v,r.matchNames).map(A=>D(A)).filter(Boolean):[];if(T.length===1&&(T=T[0].split(/\s+[—–-]\s+/)),T.length<2&&(T=mo(v)||[]),T.length<2&&(T=n(v)),T.length<2)return null;let w=r.matchLeague?D(v.querySelector(r.matchLeague)):"";return{book:s.name,id:(String(k?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:Ft(T[0],T[1]),home:T[0],away:T[1],sport:Bt(k?.pathname,w,v.title,D(v.querySelector('[class*="breadcrumb" i], nav[aria-label*="крошк" i]'))),league:w,start:"",live:/(^|\/)live(\/|$)/i.test(k?.pathname||"")?!0:null,form:{home:"",away:""},url:k?.href||""}}function u(v,k){return!v||!k?"":k.startsWith("attr:")?String(v.getAttribute(k.slice(5))||"").trim():D(v.querySelector(k))}function c(v,k){if(!ne(k))return[v];let T=v.map(A=>{let B=A.el.getBoundingClientRect();return{cell:A,top:B.top,left:B.left}}).sort((A,B)=>Math.abs(A.top-B.top)>8?A.top-B.top:A.left-B.left),w=[];for(let A of T){let B=w[w.length-1];B&&Math.abs(B.top-A.top)<=8?B.cells.push(A.cell):w.push({top:A.top,cells:[A.cell]})}return w.map(A=>A.cells)}let l=[[/^(п1|1)\/(х|x|ничья)\/(п2|2)$/i,"1x2"],[/^(п1|1)\/(п2|2)$/i,"12"],[/^(1х|1x)\/12\/(х2|x2)$/i,"dc"]],m=v=>(l.find(([k])=>k.test(v.join("/").toLowerCase()))||[])[1]||"other";function h(v,k){let T=a(v,k),w=T==="match"&&r.match?{...r,...r.match}:r;return y(v,k,T,w)}function y(v,k,T,w){let A=lo(v,w);if(A.length<2)return[];let B=new Set(A.map($=>$.el)),E=$=>{let N=0;for(let O of B)$.contains(O)&&(N+=1);return N},C=new Map;for(let $ of A){let N=co($.el,w,E);N&&(C.has(N)||C.set(N,[]),C.get(N).push($))}let V=T==="match"?p(v,k):null,L=[];for(let[$,N]of C){let O=T==="match"?null:po($,w,N),P=w.group?$.closest(w.group):null,I=u(P,w.groupTitle),q=u(P,w.groupPeriod),G=w.visualRows?c(N,v):[N],J=0;for(let X of G)for(let et of Ue(X).sets){let Y=J===0,nt=et.length,ft=nt===3?["П1","Х","П2"]:["1","2"],Mt=et.map((it,lt)=>({...it,label:it.label||ft[lt]||String(lt+1)})),gt=Y&&nt===3?"Исход":Y?"Победитель":`Рынок ${J+1}`,pt=Y?nt===3?"1x2":"12":"other";I&&(gt=I,pt=Ut(I,nt),pt==="other"&&(pt=m(Mt.map(it=>it.label)))),nt===3&&Mt.every(it=>/\sили\s/i.test(it.label))&&(pt="dc"),L.push(Lt({scope:T==="match"?"board":"list",title:gt,period:q,line:et[0].line&&et.every(it=>it.line===et[0].line)?et[0].line:"",kind:pt,outcomes:Mt,event:O,anchor:$,eventKey:O?.key||V?.key||`row${L.length}`})),J+=1}}return L}let g=v=>tn(v,r).slice(1);return{id:s.id,name:s.name,hosts:s.hosts,generic:!0,pageType:a,readMatch:p,collect:h,observeTargets:g,readEsportsWidget:()=>null}}var on={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]',match:{group:'[class*="market-group-box--"]',groupTitle:'[class*="header--"] [class*="text--"]',label:'[class*="text--"]',cell:'[class*="cell--"]',headerRow:'[class*="header-row--"]',lineCell:'[class*="_align-left--"]'}},sn={fonbet:on,pari:on,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd, .dg_euv_stake",value:".dg_euv_stake_factor_new",row:".euv_event_home, .dg_euv_stake_grid",names:".euv_event_name_team",integers:!0,matchUrl:/\/sport\/event-details\//,matchNames:"h1"},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name",matchUrl:/\/su\/betting\/.*vs.*\d{5,}/i},leon:{matchUrl:/\/bets\/.+\/\d{10,}-/},olimp:{matchUrl:/\/line\/[^/]+\/[^/]+-\d{4,}\/[^/]+/,match:{outcome:'[data-testid^="bet-button"]',row:'[data-testid="accordion-content"]',group:'[data-testid="accordion"]',groupTitle:'[class*="title--"]',visualRows:!0}},betcity:{matchUrl:/\/ru\/(live|line)\/[^/]+\/\d+\/\d+/},betboom:{matchUrl:/\/sport\/(?:live\/)?[^/]+\/\d+\/\d+\/\d+/},liga:{matchUrl:/\/sports\/[^/]+\/.+-id-\d+/,match:{outcome:"button[outcomeid]",row:"[data-t-market]",group:"[data-t-market]",groupTitle:"attr:data-t-market",groupPeriod:'[class*="header__description"]',visualRows:!0}}};function rn(s){let r=De(s);return r?r.id==="winline"?{adapter:Qe,book:r}:{adapter:nn(r,sn[r.id]||{}),book:r}:null}var se=`/* Цвета, шрифт и радиусы панели — из design/tokens.json (node tools/tokens.mjs). Блоки между метками руками не править. */
:host {
  /* tokens:light */
  --lz-accent: #5b4be6;
  --lz-accent-strong: #4a3bd1;
  --lz-accent-soft: rgba(91, 75, 230, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0b8a4d;
  --lz-pos-soft: rgba(11, 138, 77, 0.14);
  --lz-neg: #c93636;
  --lz-neg-soft: rgba(201, 54, 54, 0.12);
  --lz-warn: #b45309;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6fa;
  --lz-surface-2: #eef0f5;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #555c6b;
  --lz-faint: #666b7f;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  /* /tokens */
  color-scheme: light;
}

:host([data-theme="dark"]) {
  /* tokens:dark */
  --lz-accent: #8f82ff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(143, 130, 255, 0.18);
  --lz-accent-ink: #0f1017;
  --lz-pos: #45d08f;
  --lz-pos-soft: rgba(69, 208, 143, 0.16);
  --lz-neg: #ff7676;
  --lz-neg-soft: rgba(255, 118, 118, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #171a23;
  --lz-surface: #1f2330;
  --lz-surface-2: #272b34;
  --lz-border: #2c3040;
  --lz-text: #eef0f6;
  --lz-muted: #a4a8bb;
  --lz-faint: #8e92a8;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  /* /tokens */
  color-scheme: dark;
}
`;var an=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}

.tip-foot .pos {
  color: var(--lz-pos);
  font-weight: 600;
}
`;function e(s,r,...a){let[n,...p]=s.split("."),u=document.createElement(n||"div");p.length&&(u.className=p.join(" "));for(let[c,l]of Object.entries(r||{}))if(!(l==null||l===!1))if(c==="class")u.className=[u.className,l].filter(Boolean).join(" ");else if(c==="style")u.style.cssText=l;else if(c==="text")u.textContent=l;else{if(c==="html")throw new Error("html запрещён");c.startsWith("data-")||c.startsWith("aria-")||c==="role"||c==="title"||c==="type"||c==="href"||c==="target"||c==="rel"||c==="placeholder"||c==="value"||c==="for"||c==="name"||c==="maxlength"||c==="autocomplete"||c==="spellcheck"||c==="tabindex"?u.setAttribute(c,l===!0?"":String(l)):c==="disabled"||c==="hidden"||c==="checked"||c==="selected"?u[c]=!!l:u[c]=l}return cn(u,a),u}function cn(s,r){for(let a of r)a==null||a===!1||(Array.isArray(a)?cn(s,a):s.appendChild(a instanceof Node?a:document.createTextNode(String(a))))}var ln="http://www.w3.org/2000/svg";function st(s,r=16){let a=document.createElementNS(ln,"svg");a.setAttribute("viewBox","0 0 20 20"),a.setAttribute("width",r),a.setAttribute("height",r),a.setAttribute("fill","none"),a.setAttribute("stroke","currentColor"),a.setAttribute("stroke-width","1.7"),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),a.setAttribute("aria-hidden","true");for(let n of go[s]||[]){let p=document.createElementNS(ln,"path");p.setAttribute("d",n),a.appendChild(p)}return a}var go={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"]};function un(){let s=document.createElement("div");s.id="lz-marks",s.style.cssText="position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;overflow:hidden!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let r=s.attachShadow({mode:"open"});r.appendChild(e("style",{text:se+an}));let a=e("div.layer"),n=e("div.tip");r.append(a,n);let p=new Map,u=new Set,c=0,l=null,m=null,h=new IntersectionObserver($=>{for(let N of $)N.isIntersecting?u.add(N.target):(u.delete(N.target),p.get(N.target)?.node.classList.remove("on"));g()},{rootMargin:"120px"});function y(){s.isConnected||document.documentElement.appendChild(s)}function g(){c||(c=requestAnimationFrame(()=>{c=0,T()}))}let v=($,N)=>{for(let O=N;O;O=O.parentNode||O.host)if(O===$)return!0;return!1};function k($,N){let O=N.left+N.width/2,P=N.top+N.height/2;if(O<0||P<0||O>window.innerWidth||P>window.innerHeight)return!1;let I=document.elementFromPoint(O,P);for(;I?.shadowRoot?.elementFromPoint;){let q=I.shadowRoot.elementFromPoint(O,P);if(!q||q===I)break;I=q}return!!I&&I!==$&&!v($,I)&&!v(I,$)}function T(){for(let $ of u){let N=p.get($);if(!N)continue;if(!$.isConnected){w($);continue}let O=$.getBoundingClientRect();if(O.width<6||O.height<6||k($,O)){N.node.classList.remove("on");continue}let P=Math.round(O.left),I=Math.round(O.top),q=Math.round(O.width),G=Math.round(O.height);(N.x!==P||N.y!==I)&&(N.node.style.transform=`translate3d(${P}px, ${I}px, 0)`,N.x=P,N.y=I),(N.w!==q||N.h!==G)&&(N.node.style.width=`${q}px`,N.node.style.height=`${G}px`,N.w=q,N.h=G,N.node.classList.toggle("small",G<26)),N.node.classList.add("on")}l&&B()}function w($){let N=p.get($);N&&(h.unobserve($),u.delete($),N.node.remove(),p.delete($))}function A($){y();let N=new Map;for(let O of $)O.el?.isConnected&&N.set(O.el,O);for(let O of[...p.keys()])N.has(O)||w(O);for(let[O,P]of N){let I=p.get(O);if(!I){let G=e("div.mark"),J=parseFloat(getComputedStyle(O).borderTopLeftRadius);G.style.borderRadius=`${Number.isFinite(J)&&J>0?Math.min(J,16):6}px`;let X=e("span.chip");G.appendChild(X),a.appendChild(G),I={node:G,chip:X,sig:""},p.set(O,I),h.observe(O)}let q=`${P.frame?1:0}|${P.selected?1:0}|${P.tone||""}|${P.chip||""}`;q!==I.sig&&(I.sig=q,I.node.classList.toggle("frame",!!P.frame),I.node.classList.toggle("selected",!!P.selected),I.node.classList.toggle("pos",P.tone==="pos"&&!!P.frame),I.chip.hidden=!P.chip,I.chip.textContent=P.chip||"",I.chip.className=`chip${P.tone&&P.tone!=="accent"?" "+P.tone:""}`)}g()}function B(){if(!l?.isConnected)return C();let $=l.getBoundingClientRect(),N=264,O=n.offsetHeight||140,P=$.left+$.width/2-N/2;P=Math.max(8,Math.min(P,window.innerWidth-N-8)),m&&P+N>m.left-8&&P<m.right&&(P=Math.max(8,m.left-N-10));let I=$.bottom+10;I+O>window.innerHeight-8&&(I=$.top-O-10),I<8&&(I=8),n.style.transform=`translate3d(${Math.round(P)}px, ${Math.round(I)}px, 0)`}function E($,N){y(),l=$,n.replaceChildren(N),B(),n.classList.add("on")}function C(){l=null,n.classList.remove("on")}function V($){m=$}function L($){s.setAttribute("data-theme",$)}return window.addEventListener("scroll",g,{capture:!0,passive:!0}),window.addEventListener("resize",g,{passive:!0}),setInterval(()=>{p.size&&!document.hidden&&g()},700),{set:A,schedule:g,showTip:E,hideTip:C,setTheme:L,setAvoid:V,get tipTarget(){return l},count:()=>p.size}}var dn=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 72px minmax(60px, max-content);
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  white-space: nowrap;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.partner { margin-top: 8px; }
.partner-text { font-size: 12px; margin-bottom: 4px; }
.partner-links { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
.partner-links a.btn { text-decoration: none; }
.gain { margin-top: 8px; font-size: 12px; color: var(--lz-text); }
.gain b { color: var(--lz-pos); }
td.name .partner-links { margin-top: 3px; }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.card.update { font-size: 12.5px; }
.card.update b { color: var(--lz-accent); }
/* Строка без номера (факторы модели, факты о составах) занимает обе колонки, иначе текст ломается по словам в узкой. */
.facts li > span:only-child { grid-column: 1 / -1; }
.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  /* 18+ и предупреждение о зависимости должны читаться: не бледный, а обычный второстепенный цвет. */
  color: var(--lz-muted);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;var le=s=>Math.min(.999,Math.max(.001,s));function Fe(s,r,a=0,n=0){let p=Math.ceil(r/2),u=new Map,c=(l,m)=>{if(l>=p)return 1;if(m>=p)return 0;let h=l*16+m;return u.has(h)||u.set(h,s*c(l+1,m)+(1-s)*c(l,m+1)),u.get(h)};return c(a,n)}function ce(s,r){let a=.001,n=.999;for(let p=0;p<50;p++){let u=(a+n)/2;s(u)<r?a=u:n=u}return(a+n)/2}function xo(s,r){let a=le(s);return Math.ceil(r/2)<=1?a:ce(n=>Fe(n,r),a)}function ae(s,r,a,n=new Map){if(r>=4)return[1,0];if(a>=4)return[0,0];if(r===3&&a===3)return[0,1];let p=r*8+a;if(!n.has(p)){let[u,c]=ae(s,r+1,a,n),[l,m]=ae(s,r,a+1,n);n.set(p,[s*u+(1-s)*l,s*c+(1-s)*m])}return n.get(p)}function pn(s){let[r,a]=ae(s,0,0);return r/(1-a)}function re(s,r,a){if(r=Math.max(0,Math.floor(r)),a=Math.max(0,Math.floor(a)),Math.min(r,a)>=12){let u=Math.floor((Math.min(r,a)-12)/3),c=r-12-3*u,l=a-12-3*u,[m,h]=ae(s,c,l);return m+h*pn(s)}let n=new Map,p=(u,c)=>{if(u>=13)return 1;if(c>=13)return 0;if(u===12&&c===12)return pn(s);let l=u*32+c;return n.has(l)||n.set(l,s*p(u+1,c)+(1-s)*p(u,c+1)),n.get(l)};return p(r,a)}function vo(s){return ce(r=>re(r,0,0),le(s))}var yo=24,ie=Array.from({length:101},(s,r)=>(r+.5)/101),mn=null;function fn(s,r){let a=ie.map(c=>(s-1)*Math.log(c)+(r-1)*Math.log(1-c)),n=Math.max(...a),p=a.map(c=>Math.exp(c-n)),u=p.reduce((c,l)=>c+l,0);return p.map(c=>c/u)}function hn(s,r,a=0,n=0){if(!Number.isFinite(r))return re(s,a,n);let p=fn(s*r+a,(1-s)*r+n);return!a&&!n?(mn||=ie.map(u=>re(u,0,0)),p.reduce((u,c,l)=>u+c*mn[l],0)):p.reduce((u,c,l)=>u+c*re(ie[l],a,n),0)}function ko(s,r){return Number.isFinite(r)?ce(a=>hn(a,r),le(s)):vo(s)}var wo={cs:8,dota:1/0};function gn(s,r,a,n=0,p=0){return Number.isFinite(r)?fn(s*r+n,(1-s)*r+p).reduce((c,l,m)=>c+l*Fe(ie[m],a,n,p),0):Fe(s,a,n,p)}function $o(s,r,a){return Number.isFinite(a)?ce(n=>gn(n,a,r),le(s)):xo(s,r)}function Mo(s,r){let a=Math.max(s,r),n=Math.min(s,r);return n<12?a>=13:a-12-3*Math.floor((n-12)/3)>=4}function bn({pre:s,bo:r=3,maps:a=[0,0],rounds:n=null,game:p="cs",kappa:u=yo,kappaMap:c=wo[p]??1/0}){let l=Math.ceil(r/2),[m,h]=(a||[0,0]).map(A=>Math.max(0,Number(A)||0));if(m>=l)return{p:1,map:null};if(h>=l)return{p:0,map:null};let y=$o(s,r,c),g=(A,B)=>gn(y,c,r,A,B),[v,k]=Array.isArray(n)&&n.length===2?n.map(Number):[NaN,NaN];if(!Number.isFinite(v)||!Number.isFinite(k)||v===0&&k===0||Mo(v,k))return{p:g(m,h),map:null};let T=Number.isFinite(c)?(y*c+m)/(c+m+h):y,w=hn(ko(T,u),u,v,k);return{p:w*g(m+1,h)+(1-w)*g(m,h+1),map:w}}var W=(s,r=0)=>yt(s,r),mt=s=>`${s>0?"+":s<0?"−":""}${Math.abs(s).toFixed(1)}`;function xn({bus:s,actions:r,brand:a}){let n=document.createElement("div");n.id=s.rootId,n.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let p=n.attachShadow({mode:"open"});p.appendChild(e("style",{text:se+dn}));let u=e("span.dot"),c=e("button.fab",{type:"button","data-act":"toggle",title:`${a.name}: открыть панель`,"aria-label":`${a.name}: открыть панель`},st("lens",18),e("span",{text:a.name}),u),l=e("div.tabs",{role:"tablist"}),m=e("div.body"),h=e("div.foot"),y=e("small"),g=e("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),v=e("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),k=e("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},st("gear")),T=e("div.head",{},e("div.brand",{},e("span.logo",{},st("lens",15)),e("span",{text:a.name}),y),e("span.grow"),v,g,k,e("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},st("close"))),w=e("section.panel",{hidden:!0,role:"dialog","aria-label":a.name},T,l,m,h);p.append(c,w);let A=()=>{n.isConnected||document.documentElement.appendChild(n)};A(),new MutationObserver(A).observe(document.documentElement,{childList:!0});let B="",E=null,C=new Map,V=t=>{for(let o of t.composedPath()){if(o===n)break;if(o?.dataset?.act)return o}return null},L=null;s.on("ui:pointerdown",t=>{if(t.button!==0)return;let o=t.composedPath(),i=o.includes(c),d=o.includes(T)&&!o.some(b=>b?.dataset?.act);if(!i&&!d)return;let f=i?c:w,x=f.getBoundingClientRect();L={target:f,key:i?"fab":"panel",sx:t.clientX,sy:t.clientY,ox:x.left,oy:x.top,moved:!1},s.setDragging(!0)}),s.on("drag:move",t=>{if(!L)return;let o=t.clientX-L.sx,i=t.clientY-L.sy;!L.moved&&Math.hypot(o,i)<5||(L.moved=!0,L.target.classList.add("dragging"),N(L.target,L.ox+o,L.oy+i))}),s.on("drag:end",()=>{if(L){if(s.setDragging(!1),L.target.classList.remove("dragging"),L.moved){let t=L.target.getBoundingClientRect();r.savePosition(L.key,{left:t.left,top:t.top}),$=!0,setTimeout(()=>{$=!1},60)}L=null}});let $=!1;function N(t,o,i){let d=t.offsetWidth||120,f=t.offsetHeight||40,x=Math.max(6,Math.min(o,window.innerWidth-d-6)),b=Math.max(6,Math.min(i,window.innerHeight-Math.min(f,60)-6));t.style.left=`${Math.round(x)}px`,t.style.top=`${Math.round(b)}px`,t.style.right="auto"}s.on("ui:click",t=>{if($)return;let o=V(t);if(!o||o.disabled)return;t.preventDefault();let i=o.dataset.act;if(i==="toggle")return Dt();if(i==="close")return Pt();let d=r[i];d&&d(o.dataset.arg,o,p)}),s.on("ui:keydown",t=>{if(t.key==="Escape"&&Pt(),t.key==="Enter"){let o=t.composedPath()[0];o?.dataset?.enter&&r[o.dataset.enter]?.(o.value,o,p)}});let O=(t,o)=>e("span.form",{},[...String(t||"")].slice(0,5).map(i=>e(`i${i==="В"?".w":i==="П"?".l":""}`,{text:i,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[i]||""})),o);function P(t){let o=t.live,i=o?e("div.center",{},o.score?.length===2?e("span.score",{text:`${o.score[0]} : ${o.score[1]}`}):null,e("span.badge.live",{text:o.state||"Лайв"})):e("div.center",{},e("span",{text:t.start||"до матча"})),d=o?.periods?.length?e("div.periods",{text:o.periods.map(x=>x.raw?`${x.label} ${x.raw}`:`${/^\d+$/.test(x.label)?`${x.label}-й отрезок`:x.label} ${x.home}:${x.away}`).join(" · ")}):null,f=o?.extras?.length?e("div.periods",{text:o.extras.map(x=>`${x.kind} ${x.home}:${x.away}`).join(" · ")}):null;return e("div.card",{},e("div.league",{text:t.league||t.sportName||"",title:t.league||""}),e("div.teams",{},e("div.team",{},e("b",{text:t.home,title:t.home}),t.form?.home?O(t.form.home):null),i,e("div.team.away",{},e("b",{text:t.away,title:t.away}),t.form?.away?O(t.form.away):null)),d,f)}function I(t){let o=t.rows.some(i=>Number.isFinite(i.model));return e("div.card",{},e("div.kicker",{},e("span",{text:t.title}),Number.isFinite(t.margin)?e("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${W(t.margin,1)}`}):null),t.rows.map(i=>{let d=o&&Number.isFinite(i.model)?(i.model-i.fair)*100:null;return e("div.prob",{},e("span.name",{text:i.name,title:i.name}),e("span.odd",{text:K(i.odd)}),e("span.track",{},e("i",{style:`width:${Math.round((i.fair||0)*100)}%`}),Number.isFinite(i.model)?e("u",{style:`left:${Math.round(i.model*100)}%`}):null),e("span.pct",{},W(o&&Number.isFinite(i.model)?i.model:i.fair),d!=null&&Math.abs(d)>=.05?e(`small${d>0?".pos":".neg"}`,{text:`${mt(d)} п.п.`}):null))}),e("div.legend",{},e("span",{text:"шанс по линии без маржи"}),o?e("span.model",{text:"оценка модели"}):null))}function q(t){let o=t.analysis;if(o.status==="loading")return e("div.card",{},e("div.kicker",{},e("span",{text:"Разбор"}),e("span.badge.accent",{text:"собираю данные"})),e("div.steps",{},o.steps.map((b,M)=>e(`div.step${M===o.steps.length-1?".now":".done"}`,{},e("span.mark"),e("span",{text:b})))));if(o.status==="error")return e("div.card",{},e("div.note.warn",{},st("alert"),e("span",{text:o.error})),e("div.row",{style:"margin-top:10px"},o.needKey?e("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},st("gear"),"Открыть настройки"):null,e("button.btn.ghost",{type:"button","data-act":"report"},"Сообщить об ошибке")));if(o.status!=="done"||!o.result)return null;let i=o.result,d={home:t.match?.home,away:t.match?.away,draw:"ничья"}[i.lean],f=i.proposed?.lean&&i.proposed.lean!=="none"&&i.lean==="none"?{name:{home:t.match?.home,away:t.match?.away,draw:"ничью"}[i.proposed.lean],by:Math.abs(i.proposed.shift[i.proposed.lean]||0)}:null,x=new Map((i.facts||[]).map(b=>[b.id,b]));return e("div.card",{},e("div.kicker",{},e("span",{text:"Разбор"}),e("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${i.confidence||"низкая"}`})),e("div.verdict",{text:d?`Данные сдвигают оценку в сторону: ${d}`:f?`Данные слегка склоняют в сторону: ${f.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),f?e("div.note",{style:"margin-bottom:10px"},st("info"),e("span",{text:`Модель предложила сдвиг на ${f.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,i.summary?e("p.summary",{text:i.summary}):null,i.factors?.length?e("ul.factors",{},i.factors.map(b=>e(`li.factor${b.side==="home"?".home":b.side==="away"?".away":""}`,{},e("div",{},e("p",{text:b.text}),e("div.src",{},(b.facts||[]).map(M=>x.get(M)).filter(Boolean).map(M=>e("span.tag",{text:`${M.id} · ${M.source}`,title:M.text}))))))):null,i.scenarios?.length?e("div",{style:"margin-top:10px"},e("div.kicker",{},e("span",{text:"Как может пойти игра"})),e("ul.facts",{},i.scenarios.map(b=>e("li",{},e("span",{text:b.text})," ",e("em",{text:`— ${b.facts.join(", ")}`}))))):null,i.risks?.length?e("div.note",{style:"margin-top:10px"},st("info"),e("span",{text:`Что может сломать вывод: ${i.risks.join(" ")}`})):null,(i.full?.sections||[]).some(b=>b?.lines?.length)?e("details",{"data-key":"full",open:C.get("full")||!1,style:"margin-top:8px"},e("summary",{text:"Показать полностью: итог по всем рынкам, профили, факты"}),(i.full.sections||[]).filter(b=>b?.title&&b.lines?.length).map(b=>e("div",{style:"margin-top:6px"},e("div.kicker",{},e("span",{text:b.title})),e("ul.facts",{},b.lines.map(M=>e("li",{text:M})))))):null,e("div.row",{style:"margin-top:8px"},e("button.btn.ghost.small",{type:"button","data-act":"report",title:"Разбор выглядит неправильно — сообщить разработчику"},"Сообщить об ошибке")),e("details",{"data-key":"facts",open:C.get("facts")||!1},e("summary",{text:`Данные, на которых стоит разбор (${i.facts?.length||0})`}),e("ul.facts",{},(i.facts||[]).map(b=>e("li",{},e("b",{text:b.id}),e("span",{},b.text," ",e("em",{text:`— ${b.source}`})))))),G(i.research),e("div.hint",{style:"margin-top:8px",text:i.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function G(t){return t?t.skipped==="plan"?e("div.hint",{style:"margin-top:8px",text:"Поиск превью, травм и судей в прессе — в тарифах «Макс» и VIP."}):t.sources?.length?e("div.hint",{style:"margin-top:8px"},`${t.note} Прочитано: `,t.sources.map((o,i)=>[i?", ":"",e("a",{href:o.url,target:"_blank",rel:"noopener",text:o.domain})])):t.note?e("div.hint",{style:"margin-top:8px",text:t.note}):null:null}function J(t){let o=t.compare?.consensus||t.analysis?.result?.consensus||t.consensus;if(!o?.consensus||!t.line?.rows?.length)return null;let i=o.consensus.length===2&&t.line.rows.length===3;if(!i&&t.line.rows.length!==o.consensus.length)return null;let d=i?t.line.overtime:null,f=d?d.rows:i?[t.line.rows[0],t.line.rows[2]].map(M=>({...M,odd:null,fair:null})):t.line.rows,x=t.match?.sport==="mma",b=o.updated?new Date(o.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"";return e("div.card",{},e("div.kicker",{},e("span",{text:i?x?"Прогноз рынка · без ничьей":"Прогноз рынка · с овертаймом":"Прогноз рынка"}),e("span.badge",{text:`${o.count} контор`})),f.map((M,_)=>{let S=o.consensus[_],F=M.odd?M.odd*S-1:0,z=Number.isFinite(M.fair)?(M.fair-S)*100:0;return e("div.prob",{},e("span.name",{text:M.name,title:M.name}),e("span.odd",{text:K(1/S),title:"Кэф без маржи по консенсусу"}),e("span.track",{},e("i",{style:`width:${Math.round(S*100)}%`}),e("u",{style:`left:${Math.round((M.fair||0)*100)}%`,title:"Шанс по линии этой конторы"})),e("span.pct",{},W(S),F>.005?e("small.pos",{text:`кэф выше рынка ${mt(F*100)}%`}):Math.abs(z)>=2?e(`small${z>0?".neg":""}`,{text:`${mt(z)} п.п. к рынку`,title:z>0?"Контора оценивает этот исход выше рынка — кэф ниже":"Контора оценивает этот исход ниже рынка"}):null))}),e("div.legend",{},e("span",{text:"шанс по консенсусу"}),i&&!d?null:e("span.model",{text:d?`шанс по рынку «${d.title}» этой конторы`:"шанс по линии этой конторы"})),e("div.hint",{style:"margin-top:8px",text:`${i&&x?"Ничьи в ММА — доли процента, поэтому рынок двухисходный; ничья этой конторы не сравнивается. ":i?d?"Победитель с учётом овертайма и буллитов: сравнивается с одноимённым рынком этой конторы, а не с трёхисходным. ":"Победитель с учётом овертайма и буллитов; ничья в основное время сюда не входит, поэтому с трёхисходным рынком конторы напрямую не сравнивается. ":""}${o.pinnacle?`Pinnacle ${o.pinnacle.map(K).join(" / ")}. `:""}${o.betfair?`Betfair ${o.betfair.map(K).join(" / ")}. `:""}Цены ${o.count} контор без маржи${b?`, обновлено в ${b}`:""}${o.stale?" (данные старше шести часов)":""}. На проверке 1915 матчей фаворит по консенсусу выиграл 54% — точнее этого прогноза у нас нет.`}))}let X=new Map;function et(t,o){let i=t.match?.live;if(!i||!["cs","dota"].includes(o.game)||i.score?.length!==2)return null;let d=i.score.map(Number),f=Number(o.bo)||3;if(d.some(M=>!Number.isFinite(M)||M<0)||Math.max(...d)>=Math.ceil(f/2))return null;let x=o.game==="cs"&&i.rounds?.length===2&&i.rounds.every(M=>/^[0-9]{1,2}$/.test(String(M)))?i.rounds.map(Number):null,b=`${o.p1}|${f}|${d}|${x}`;return X.has(b)||(X.size>50&&X.clear(),X.set(b,{...bn({pre:o.p1,bo:f,maps:d,rounds:x,game:o.game}),bo:f,maps:d,rounds:x})),X.get(b)}function Y(t){let o=t.compare?.model||t.analysis?.result?.model||t.model;if(!o?.p1||!t.line?.rows?.length)return null;let i=t.line.rows.length===3&&(o.overtime||o.drawless);if(!i&&t.line.rows.length!==2)return null;let d=i?t.line.overtime:null,f=d?d.rows:i?[t.line.rows[0],t.line.rows[2]].map(j=>({...j,fair:null})):t.line.rows,x=et(t,o),b=x?[x.p,1-x.p]:[o.p1,o.p2],M=o.sport==="tennis"?`Рейтинги Линзы по покрытиям, форме, нагрузке и очным встречам (архив ATP/WTA, ${o.samples} матчей у менее опытного игрока)`:o.sport==="hockey"?`Рейтинги Линзы по матчам КХЛ: атака и оборона команд, дом, усталость (приложение КХЛ, 2023–2026; ${o.samples} игр у менее опытной команды)${o.regulation?`. Основное время: ${Math.round(o.regulation.p1*100)}% / ничья ${Math.round(o.regulation.px*100)}% / ${Math.round(o.regulation.p2*100)}%`:""}`:o.sport==="mma"?`Рейтинги Линзы по боям UFC: Elo с весом досрочных побед, форма, возраст, размах рук, простой (ESPN; ${o.samples} боёв в UFC у менее опытного бойца)`:o.sport==="basketball"?`Рейтинги Линзы по разнице очков, дому и усталости (НБА, Евролига, Еврокубок, АСВ, Серия А, Адриатическая лига, ВТБ, Лига чемпионов FIBA; ${o.samples} игр у менее опытной команды)`:o.game==="dota"?`Рейтинги Линзы по матчам, форме и очным встречам (bo3.gg, ${o.samples} ${zt(o.samples,"матч","матча","матчей")} у менее опытной команды)`:`Рейтинги Линзы по картам, форме и очным встречам (bo3.gg, ${o.samples} ${zt(o.samples,"карта","карты","карт")} у менее опытной команды)`,_=o.backtest,S=(_?.calibration||[]).filter(j=>[60,70,80].includes(j.threshold)),F=_?.labels?.[o.confidence],z=(F?`С подписью «${o.confidence}» на проверке сбывалось ${W(F.hit/100,1)} (${F.n} ${zt(F.n,"матч","матча","матчей")}). `:"")+(S.length?`На проверке ${_.test} сыгранных матчей: ${S.map(j=>`при уверенности ≥${j.threshold}% сбывалось ${j.hit}%`).join(", ")}`:_?`На проверке ${_.test} матчей угадано ${Math.round(_.acc*100)}%`:"Точность ещё измеряется");return e("div.card",{},e("div.kicker",{},e("span",{text:x?`Модель по счёту · bo${x.bo}`:i?o.drawless?"Прогноз модели · без ничьей":"Прогноз модели · с овертаймом":"Прогноз модели"}),e("span.badge",{text:x?`до матча: ${o.confidence}`:`уверенность: ${o.confidence}`})),f.map((j,U)=>{let Z=b[U],ot=Number.isFinite(j.fair)?(Z-j.fair)*100:0;return e("div.prob",{},e("span.name",{text:j.name,title:j.name}),e("span.odd",{text:K(1/Z),title:"Кэф без маржи по модели"}),e("span.track",{},e("i",{style:`width:${Math.round(Z*100)}%`}),e("u",{style:`left:${Math.round((j.fair||0)*100)}%`,title:"Шанс по линии конторы"})),e("span.pct",{},W(Z),Math.abs(ot)>=3?e(`small${ot>0?".pos":".neg"}`,{text:`${mt(ot)} п.п. к линии`}):null))}),e("div.legend",{},e("span",{text:x?"шанс серии по счёту":"оценка модели"}),e("span.model",{text:"шанс по линии конторы"})),x?e("div.hint",{style:"margin-top:6px",text:`Счёт по картам ${x.maps.join(":")}${x.rounds?`, на карте ${x.rounds.join(":")} — шанс текущей карты ${W(x.map??.5)}`:""}. До матча модель давала ${W(o.p1)} / ${W(o.p2)}.`}):null,it(o,f),o.factors?.length?e("ul.facts",{style:"margin-top:8px"},o.factors.slice(0,o.sport==="mma"?12:4).map(j=>e("li",{},e("span",{text:j})))):null,e("div.hint",{style:"margin-top:8px",text:x?`Шанс по ходу матча пересчитывается из прогноза до матча и счёта: выигранные карты${o.game==="cs"?" и раунды":""} уточняют силу команд. ${o.game==="cs"?"Проверка на сыгранных сериях CS: при 1:0 в bo3 модель давала в среднем 82%, сбылось 83% (2 905 серий)":"Проверка на сыгранных сериях Dota: при 1:1 модель давала в среднем 53%, сбылось 55% (516 серий)"}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`:`${M}. ${z}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`}))}function nt(t){let[o,i]=t.names,d=["0","15","30","40","Б"],f=t.tiebreak?t.points.join(":"):t.points.map(M=>d[Math.min(4,M)]||M).join(":"),x=t.sets.map(([M,_])=>`${M}:${_}`).concat(`${t.games[0]}:${t.games[1]}`).join(" "),b=t.serving==null?"":` · подаёт ${t.names[t.serving]}`;return e("div.card",{},e("div.kicker",{},e("span",{text:"Лайв по счёту"}),e("span.badge",{text:`${t.score.join(":")} по сетам · ${x} · ${f}${t.tiebreak?" (тай-брейк)":""}`})),t.names.map((M,_)=>{let S=t.probs[_],F=t.book?t.book[_]:null,z=t.compare&&Number.isFinite(F)?(S-F)*100:0;return e("div.prob",{},e("span.name",{text:M,title:M}),e("span.odd",{text:K(1/S),title:"Честный кэф на матч по счёту"}),e("span.track",{},e("i",{style:`width:${Math.round(S*100)}%`}),Number.isFinite(F)?e("u",{style:`left:${Math.round(F*100)}%`,title:"Шанс по цене этой конторы"}):null),e("span.pct",{},W(S),Math.abs(z)>=3?e(`small${z>0?".pos":".neg"}`,{text:`${mt(z)} п.п. к цене`}):null))}),e("div.legend",{},e("span",{text:"шанс матча по счёту"}),t.book?e("span.model",{text:"шанс по цене этой конторы"}):null),e("ul.facts",{style:"margin-top:8px"},e("li",{},e("span",{text:`Текущий сет: ${o} ${W(t.set[0])} (кэф ${K(1/t.set[0])}) · ${i} ${W(t.set[1])} (${K(1/t.set[1])})`})),e("li",{},e("span",{text:`Текущий ${t.tiebreak?"тай-брейк":"гейм"}${b}: ${o} ${W(t.game[0])} · ${i} ${W(t.game[1])}`})),e("li",{},e("span",{text:`Очко на своей подаче (под довоенную силу): ${o} ${t.serve[0]}%, ${i} ${t.serve[1]}%; матч до ${t.bestOf===5?"трёх":"двух"} выигранных сетов.`}))),e("div.hint",{style:"margin-top:8px",text:`Счёт, очки и подача — лайв Fonbet. Довоенная сила: ${t.prior.note}.${t.compare?"":" Без довоенной цены оценка подстроена под текущую цену Fonbet — как сигнал против конторы её не используйте."} Проверено на 10 064 моментах матчей ATP/WTA 2025–2026 (после каждого сета): при оценке 80–85% сбылось 82,9%, 85–90% — 87,8%. Это расчёт, а не обещание.`}))}function ft(t){let[o,i]=t.names,d=F=>F?K(F):"—",f=t.sport==="hockey"?"период":"тайм",x=`${t.minute}' · ${Math.min(t.period,t.periods)}-й ${f}`,b=[o,"Ничья",i],M=F=>F>0?`+${F}`:`${F}`,_=(F,z,j,U,Z,ot)=>z?.length?e("details",{"data-key":`live-${F}`,open:C.get(`live-${F}`)||!1},e("summary",{text:F}),e("ul.facts",{},z.map(ct=>e("li",{},e("span",{text:`${Z(ct)} — ${d(ct[j])} · ${ot(ct)} — ${d(ct[U])}`}))))):null,S=t.red[0]||t.red[1]?` · удаления ${t.red.join(":")}`:"";return e("div.card",{},e("div.kicker",{},e("span",{text:"Лайв по счёту"}),e("span.badge",{text:`${t.score.join(":")} · ${x}${S}`})),b.map((F,z)=>{let j=t.probs[z],U=t.book?t.book[z]:null,Z=t.compare&&Number.isFinite(U)?(j-U)*100:0;return e("div.prob",{},e("span.name",{text:F,title:F}),e("span.odd",{text:K(1/j),title:"Честный кэф по счёту"}),e("span.track",{},e("i",{style:`width:${Math.round(j*100)}%`}),Number.isFinite(U)?e("u",{style:`left:${Math.round(U*100)}%`,title:"Шанс по цене этой конторы"}):null),e("span.pct",{},W(j),Math.abs(Z)>=3?e(`small${Z>0?".pos":".neg"}`,{text:`${mt(Z)} п.п. к цене`}):null))}),e("div.legend",{},e("span",{text:"шанс по счёту (основное время)"}),t.book?e("span.model",{text:"шанс по цене этой конторы"}):null),e("ul.facts",{style:"margin-top:8px"},e("li",{},e("span",{text:`Следующий гол: ${o} ${W(t.nextGoal[0])} · не будет ${W(t.nextGoal[1])} · ${i} ${W(t.nextGoal[2])}. Ожидаемый итоговый тотал ≈${t.expTotal}.`})),t.bookLines?.total?e("li",{},e("span",{text:`Тотал ${t.bookLines.total.line}: Fonbet ${t.bookLines.total.odds.map(K).join(" / ")}, честно ${t.bookLines.total.fair.map(d).join(" / ")}`}),Math.abs(t.bookLines.total.gap)>=5?e(`small${t.bookLines.total.gap>0?".pos":".neg"}`,{text:` ${mt(t.bookLines.total.gap)} п.п. к «больше»`}):null):null),_("Тотал — честные кэфы",t.total,"over","under",F=>`больше ${F.line}`,F=>`меньше ${F.line}`),_("Фора — честные кэфы",t.handicap,"home","away",F=>`${o} ${M(F.line)}`,F=>`${i} ${M(-F.line)}`),e("div.hint",{style:"margin-top:8px",text:`Счёт, время${t.sport==="football"?" и удаления":""} — лайв Fonbet${t.clock==="timer"?"":" (время приблизительное)"}. Довоенная сила: ${t.prior.note}.${t.compare?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на ${t.sport==="hockey"?"1 407 играх НХЛ":"1 837 матчах 5 топ-лиг (11 тыс. точек)"}: при оценке 80–85% сбылось 82,5%. Это расчёт, а не обещание.`}))}function Mt(t,o,i,d){let f=t.bookLines;if(!f)return null;let x=M=>M>0?`+${M}`:`${M}`,b=(M,_,S,F)=>e("li",{},e("span",{text:`${M}: Fonbet ${_.map(K).join(" / ")}, честно ${S.map(z=>z?K(z):"—").join(" / ")}`}),d&&Math.abs(F)>=5?e(`small${F>0?".pos":".neg"}`,{text:` ${mt(F)} п.п. к первой стороне`}):null);return e("ul.facts",{style:"margin-top:8px"},f.handicap?b(`Фора ${o} ${x(f.handicap.line)} / ${i} ${x(-f.handicap.line)}`,f.handicap.odds,f.handicap.fair,f.handicap.gap):null,f.total?b(`Тотал ${f.total.line} больше / меньше`,f.total.odds,f.total.fair,f.total.gap):null)}function gt(t){let o=t.live;if(!o)return null;if(o.kind==="goals")return ft(o);if(o.kind==="tennis")return nt(o);if(o.error)return e("div.card",{},e("div.kicker",{},e("span",{text:"Лайв по счёту"})),e("div.hint",{text:o.error}));let[i,d]=o.names,f=z=>z?K(z):"—",x=o.book&&(o.prior.source==="line"||o.prior.source==="model"),b=o.left>0?`${o.period>o.format.periods?"ОТ":`${o.period}-я четв.`} · осталось ≈${Math.max(1,Math.round(o.left))} мин`:"конец игры",M=(z,j,U,Z,ot,ct)=>j.length?e("details",{"data-key":`live-${z}`,open:C.get(`live-${z}`)||!1},e("summary",{text:z}),e("ul.facts",{},j.map(jt=>e("li",{},e("span",{text:`${ot(jt)} — ${f(jt[U])} · ${ct(jt)} — ${f(jt[Z])}`}))))):null,_=z=>z>0?`+${z}`:`${z}`,S=o.quarter,F=S&&S.left>0?`${S.index}-я четверть (${S.score.join(":")}, осталось ≈${Math.max(1,Math.round(S.left))} мин): ${i} ${f(S.probs[0]?1/S.probs[0]:null)} · ничья ${f(S.draw?1/S.draw:null)} · ${d} ${f(S.probs[1]?1/S.probs[1]:null)}; разница ${S.expMargin>=0?i:d} ${Math.abs(S.expMargin).toFixed(1)}, тотал четверти ≈${S.projTotal}.`:"";return e("div.card",{},e("div.kicker",{},e("span",{text:"Лайв по счёту"}),e("span.badge",{text:`${o.score.join(":")} · ${b}`})),o.names.map((z,j)=>{let U=o.probs[j],Z=o.book?o.book[j]:null,ot=x&&Number.isFinite(Z)?(U-Z)*100:0;return e("div.prob",{},e("span.name",{text:z,title:z}),e("span.odd",{text:K(1/U),title:"Честный кэф по счёту"}),e("span.track",{},e("i",{style:`width:${Math.round(U*100)}%`}),Number.isFinite(Z)?e("u",{style:`left:${Math.round(Z*100)}%`,title:"Шанс по цене этой конторы"}):null),e("span.pct",{},W(U),Math.abs(ot)>=3?e(`small${ot>0?".pos":".neg"}`,{text:`${mt(ot)} п.п. к цене`}):null))}),e("div.legend",{},e("span",{text:"шанс по счёту (с ОТ)"}),o.book?e("span.model",{text:"шанс по цене этой конторы"}):null),Mt(o,i,d,x),e("ul.facts",{style:"margin-top:8px"},e("li",{},e("span",{text:`Ожидаемая итоговая разница: ${o.expMargin>=0?i:d} ${Math.abs(o.expMargin).toFixed(1)} (разброс ±${o.sd}). Тотал ≈${o.projTotal} (±${o.sdTotal}).`})),F?e("li",{},e("span",{text:F})):null),M("Фора — честные кэфы",o.handicap,"home","away",z=>`${i} ${_(z.line)}`,z=>`${d} ${_(-z.line)}`),M("Тотал матча — честные кэфы",o.total,"over","under",z=>`больше ${z.line}`,z=>`меньше ${z.line}`),M("Тотал четверти — честные кэфы",o.quarterTotal,"over","under",z=>`больше ${z.line}`,z=>`меньше ${z.line}`),e("div.hint",{style:"margin-top:8px",text:`Счёт и время — лайв Fonbet${o.clock==="timer"?"":" (время в четверти оценено по очкам — приблизительно)"}. Довоенная сила: ${o.prior.note}.${x?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на 8 923 играх Евролиги, Еврокубка и НБА: в перерыве при оценке 75–80% побеждали в 78% случаев. Это расчёт, а не обещание; задержка табло у конторы бывает до минуты.`}))}function pt(t){let o=t.verdict;return o?.lines?.length?e("div.card",{},e("div.kicker",{},e("span",{text:"Итог"}),e("span.badge",{text:o.best?`перевес ${Math.round(o.best.edge*100)}%`:"без перевеса"})),e("ul.facts",{},o.lines.map(i=>e("li",{},e("span",{text:i})))),o.track?e("div.hint",{style:"margin-top:6px",text:o.track}):null,t.analysis.status!=="done"?e("div.hint",{style:"margin-top:6px",text:"Доводы «за» и главный риск появятся после «Разобрать матч»."}):null):null}function it(t,o){let i=t.durations;if(t.sport!=="mma"||!i)return null;let d=x=>x?K(x):"—",f=o.map(x=>x.name);return e("div",{style:"margin-top:10px"},e("div.kicker",{},e("span",{text:"Честные кэфы"}),e("span.badge",{text:`${i.rounds} ${i.rounds===5?"раундов":"раунда"}`})),e("ul.facts",{},e("li",{},e("span",{text:`Победа: ${f[0]||"первый"} ${d(t.fair?.p1)} · ${f[1]||"второй"} ${d(t.fair?.p2)}`})),i.lines.map(x=>e("li",{},e("span",{text:`Тотал ${x.line} раунда: больше ${d(x.over)} · меньше ${d(x.under)}`}))),e("li",{},e("span",{text:`Дойдёт до решения: да ${d(i.decision.yes)} · нет ${d(i.decision.no)}`})),e("li",{},e("span",{text:`Конец боя: 1-й раунд ${Math.round(i.r1*100)}%, 2-й ${Math.round(i.r2*100)}%, позже ${Math.round(i.r3*100)}%, решение ${Math.round(i.dec*100)}%`}))),e("div.hint",{text:"Кэф конторы выше честного — ставка в плюс по модели, ниже — в минус. Длительность считается по всем боям бойцов в UFC и их весовой; проверка на 565 боях: точнее, чем средние цифры по весовой."}))}function lt(t){let i=((t.compare?.model||t.analysis?.result?.model||t.model)?.profiles||[]).filter(d=>d?.lines?.length);return i.length?e("div.card",{},e("div.kicker",{},e("span",{text:"Профили"}),e("span.badge",{text:"модель Линзы"})),i.map((d,f)=>e("details",{"data-key":`profile-${f}`,open:C.get(`profile-${f}`)??f===0},e("summary",{text:d.name}),e("ul.facts",{},d.lines.map(x=>e("li",{},e("span",{text:x})))))),e("div.hint",{style:"margin-top:8px",text:"Из рейтингов Линзы по открытым данным (ESPN, архив ATP/WTA, Евролига, bo3.gg). Это описание, а не прогноз."})):null}function Ot(t){let o=t.facts;if(!o?.facts?.length)return null;let i=o.facts.filter(b=>/травм|отсутств|не играет|стенд-ин|замен|дисквалиф/i.test(b.text)),d=o.facts.filter(b=>!i.includes(b)&&/состав|стартов/i.test(b.text)),f=o.facts.filter(b=>!i.includes(b)&&!d.includes(b)),x=(b,M,_)=>M.length?e("details",{"data-key":`facts-${b}`,open:_||C.get(`facts-${b}`)||!1},e("summary",{text:`${b} (${M.length})`}),e("ul.facts",{},M.map(S=>e("li",{},e("span",{text:S.text}))))):null;return e("div.card",{},e("div.kicker",{},e("span",{text:"Составы, травмы, форма"}),e("span.badge",{text:o.source||o.facts[0].source||"источник"})),x("Травмы и отсутствующие",i,!0),x("Составы",d,!0),x("Форма, таблица, очные встречи",f,!i.length&&!d.length),e("div.hint",{style:"margin-top:8px"},"Факты из открытых данных, как есть. ",o.url?e("a",{href:o.url,target:"_blank",rel:"noopener",text:"Источник"}):null))}let Ct=t=>`${Math.round(t).toLocaleString("ru-RU")} ₽`,zt=(t,o,i,d)=>{let f=t%100,x=t%10;return f>10&&f<20?d:x===1?o:x>=2&&x<=4?i:d},bt=t=>(t.erid?["Реклама",t.legal,`erid ${t.erid}`].filter(Boolean).join(" · "):["Партнёрская ссылка",t.legal].filter(Boolean).join(" · "))+" · 18+",St=(t,o)=>e("a.btn.ghost.small",{href:t.go?`${t.go}?s=panel`:t.url,target:"_blank",rel:"noopener sponsored"},st("link",13),o||`Открыть у ${t.name}`),_t=t=>t.code?e("button.btn.ghost.small",{type:"button","data-act":"copy-code","data-arg":t.code,title:t.bonus||"Скопировать промокод"},`Промокод ${t.code}`):null;function fe(t){let o=(t.partners||[]).filter(i=>i.url||i.code);return o.length?e("div.card.soft",{},e("div.kicker",{},e("span",{text:o.length===1?`Промокод ${o[0].name}`:"Промокоды контор"})),o.map(i=>e("div.partner",{},e("div.partner-text",{},e("b",{text:i.name}),i.bonus?e("span",{text:` — ${i.bonus}`}):null),e("div.partner-links",{},_t(i),i.url?St(i):null),e("div.hint",{text:bt(i)})))):null}function he(t,o={}){if(t.status==="idle")return null;if(t.status==="loading")return e("div.card",{},e("div.kicker",{},e("span",{text:"Цены других контор"})),e("div.hint",{text:"Смотрю открытые линии…"}));let i=t.labels||[];if(!t.rows?.length)return e("div.card",{},e("div.kicker",{},e("span",{text:"Цены других контор"})),e("div.hint",{text:t.note||"В открытых линиях этой пары нет."}));let d=i.map((z,j)=>Math.max(...t.rows.map(U=>U.odds[j]||0))),f=Object.fromEntries((o.partners||[]).map(z=>[z.id,z])),x=z=>z.book&&z.book!==o.bookId&&!z.sharp&&f[z.book]||null,b=o.stake||1e3,M=t.rows.find(z=>z.here)||t.rows[0],S=i.map((z,j)=>{let U=M?.odds?.[j],Z=t.rows.filter(ot=>ot!==M&&!ot.sharp&&ot.odds[j]).sort((ot,ct)=>ct.odds[j]-ot.odds[j])[0];return!U||!Z||Z.odds[j]<=U?null:{label:z,row:Z,odd:Z.odds[j],mine:U,gain:(Z.odds[j]-U)*b}}).filter(Boolean).sort((z,j)=>j.gain-z.gain)[0],F=t.rows.map(x).filter(Boolean);return e("div.card",{},e("div.kicker",{},e("span",{text:"Цены других контор"}),e("span.badge",{text:"лучшая цена выделена"})),e("table",{},e("tr",{},e("th",{text:"Контора"}),i.map(z=>e("th",{text:z}))),t.rows.map(z=>{let j=x(z);return e("tr",{},e("td.name",{title:z.sharp?"Цена с мирового рынка, для сравнения":""},z.name,j?e("div.partner-links",{},j.url?St(j):null,_t(j)):null),z.odds.map((U,Z)=>e(`td${U&&U===d[Z]&&t.rows.length>1?".best":""}`,{text:U?K(U):"—"})))})),S&&S.gain>=1?e("div.gain",{},`На «${S.label}» у ${S.row.name} кэф ${K(S.odd)} против ${K(S.mine)} здесь: со ставки ${Ct(b)} выигрыш больше на `,e("b",{text:Ct(S.gain)}),"."):null,F.length?e("div.hint",{style:"margin-top:6px",text:[...new Set(F.map(bt))].join(" ")}):null,t.note?e("div.hint",{style:"margin-top:8px",text:t.note}):null)}function ge(t){let o=[],i=(f,x,b)=>o.push(e("dt",{text:f}),e(`dd${b?"."+b:""}`,{text:x}));Number.isFinite(t.fair)?(i("Шанс по линии без маржи",W(t.fair,1)),i("Кэф без маржи конторы",K(t.fairOdd)),i("Маржа конторы в этом рынке",W(t.margin,1))):i("Заложено в кэфе (с маржой)",W(1/t.odd,1)),Number.isFinite(t.model)&&(i("Оценка модели",W(t.model,1)),i("Ожидание на рубль по модели",`${mt(t.ev*100)}%`,t.ev>.005?"pos":t.ev<-.005?"neg":"")),t.best&&i(`Лучшая цена: ${t.best.name}`,K(t.best.odd),t.best.odd>t.odd?"pos":"");let d=t.best?.partner&&(t.best.partner.url||t.best.partner.code)?t.best.partner:null;return e("div.card.accent",{},e("div.kicker",{},e("span",{text:t.market}),e("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},st("close",13))),e("div.pick-head",{},e("span.big",{text:K(t.odd)}),e("span.what",{text:t.label,title:t.label})),e("dl.kv",{},o),t.note?e("div.hint",{style:"margin-top:8px",text:t.note}):null,e("div.row",{style:"margin-top:10px"},e("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!t.canAdd,title:t.canAdd?"":"Нужен рынок с полным набором исходов"},st("plus",14),t.inExpress?"Уже в экспрессе":"В расчёт экспресса")),d?e("div.partner",{style:"margin-top:10px"},t.best.gain>=1?e("div.gain",{},`У ${d.name} этот кэф выше: со ставки ${Ct(t.stake||1e3)} выигрыш больше на `,e("b",{text:Ct(t.best.gain)}),"."):null,e("div.partner-links",{},d.url?St(d):null,_t(d)),e("div.hint",{text:bt(d)})):null)}function be(t){let o=(i,d)=>e("div",{style:"min-width:0"},e("b",{text:i,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),d.map(f=>e("div",{style:"display:flex;justify-content:space-between;gap:8px"},e("span",{text:f.nick}),e("span",{style:"color:var(--lz-muted)",text:f.numbers.slice(0,2).join(" / ")}))));return e("div.card",{},e("div.kicker",{},e("span",{text:"Игроки сейчас"}),e("span.badge",{text:"с табло конторы"})),e("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},o(t.homeName,t.home),o(t.awayName,t.away)))}function xe(t,o){return e("div.card",{},e("div.kicker",{},e("span",{text:"Статистика команд"}),e("span.badge",{text:"со страницы конторы"})),e("table",{},e("tr",{},e("th",{text:"Показатель"}),e("th",{text:o.home}),e("th",{text:o.away})),t.rows.map(i=>e("tr",{},e("td",{text:i.label}),e("td",{text:i.home}),e("td",{text:i.away})))),t.samples?.length===2?e("div.hint",{style:"margin-top:8px",text:`Выборка: ${t.samples[0]} и ${t.samples[1]} карт.`}):null)}function ve(t){let o=[];if(t.pick&&o.push(ge({...t.pick,stake:t.stake})),!t.match)return o.push(e("div.empty",{},e("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),o;o.push(P(t.match)),t.esports&&o.push(be(t.esports)),t.match.stats?.rows?.length&&o.push(xe(t.match.stats,t.match)),t.line&&o.push(I(t.line));let i=J(t);i&&o.push(i);let d=gt(t);d&&o.push(d);let f=Y(t);f&&o.push(f);let x=pt(t);x&&o.push(x);let b=lt(t);b&&o.push(b);let M=Ot(t);M&&o.push(M);let _=t.analysis.status==="loading";o.push(e("div.row",{},e("button.btn",{type:"button","data-act":"analyze",disabled:_},st("spark"),_?"Разбираю…":t.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),e("button.btn.ghost",{type:"button","data-act":"compare",disabled:t.compare.status==="loading"},st("scale"),"Сравнить цены"))),t.quota&&o.push(e("div.hint.center-text",{text:t.quota}));let S=fe(t);S&&o.push(S);let F=q(t);F&&o.push(F);let z=he(t.compare,t);return z&&o.push(z),o}function Wt(t){let o=t.margins;if(!o)return null;let i=[e("div",{},`Сегодня вы открыли ${o.n} ${zt(o.n,"матч","матча","матчей")} до начала: в основной исход ${t.bookName||"контора"} закладывает в среднем `,e("b",{text:W(o.here,1)})," маржи.")];return o.best?(i.push(e("div",{style:"margin-top:6px"},`На тех же ${o.best.n} ${zt(o.best.n,"матче","матчах","матчах")} у ${o.best.name} — `,e("b",{text:W(o.best.there,1)}),` против ${W(o.best.here,1)} здесь: с каждой ставки вы отдавали бы конторе меньше примерно на ${((o.best.here-o.best.there)*100).toFixed(1)} п.п.`)),o.partner&&i.push(e("div.partner-links",{style:"margin-top:8px"},o.partner.url?St(o.partner):null,_t(o.partner)),e("div.hint",{text:bt(o.partner)}))):i.push(e("div.hint",{style:"margin-top:6px",text:"Нажмите «Сравнить цены» на странице матча — Линза запомнит маржу других контор на тех же матчах и покажет, где отдаёте меньше."})),e("div.card",{},e("div.kicker",{},e("span",{text:"Сколько маржи вы отдаёте"}),e("span.badge",{text:"сегодня"})),...i)}function Kt(t){let o=t.scan,i=Wt(t);return o?.rows?.length?[i,e("div.card",{},e("div.kicker",{},e("span",{text:o.title}),e("span.badge",{text:`средняя маржа ${W(o.average,1)}`})),e("table",{},e("tr",{},e("th",{text:o.first}),e("th",{text:"Фаворит"}),e("th",{text:"Маржа"})),o.rows.map(d=>e("tr.click",{"data-act":"scan-go","data-arg":String(d.index),title:"Показать на странице"},e("td.name",{},d.name,d.sub?e("span.sub",{text:d.sub}):null),e("td",{},d.fav,e("span.sub",{text:W(d.favPct)})),e(`td${d.low?".best":""}`,{text:W(d.margin,1)})))),e("div.hint",{style:"margin-top:8px",text:o.note}))]:[i,e("div.empty",{},e("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function Zt(t){let o=t.express;if(!o.legs.length)return[e("div.empty",{},e("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let i=o.stats;return[e("div.card",{},e("div.kicker",{},e("span",{text:`Экспресс · ${o.legs.length}`}),e("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},st("trash",13),"Очистить")),o.legs.map(d=>e("div.leg",{},e("div.t",{},e("b",{text:d.label,title:d.label}),e("span",{text:d.title,title:d.title})),e("span.o",{text:K(d.odd)}),e("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":d.id,title:"Убрать",style:"width:24px;height:24px"},st("close",13))))),i?e("div.card.soft",{},e("dl.kv",{},e("dt",{text:"Итоговый коэффициент"}),e("dd",{text:K(i.odd)}),e("dt",{text:"Шанс, что зайдёт всё (по линии)"}),e("dd",{text:W(i.chance,1)}),e("dt",{text:"Кэф без маржи"}),e("dd",{text:K(i.fairOdd)}),e("dt",{text:"Маржа конторы на всём экспрессе"}),e("dd.neg",{text:W(i.margin,1)})),e("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Исходы одного матча считаются как независимые — на деле они связаны."})):null]}function ye(t){let o=t.edges||{status:"idle"},i=_=>e("div.kicker",{},e("span",{text:"Цена выше рынка"}),_?e("span.badge",{text:_}):null);if(o.status==="loading"&&!o.data)return[e("div.card",{},i("ищу сигналы"),e("div.hint",{text:"Сверяю открытую линию с консенсусом двадцати контор…"}))];if(o.status==="error"&&!o.data)return[e("div.card",{},i(),e("div.note.warn",{},st("alert"),e("span",{text:o.error})))];let d=o.data;if(!d)return[e("div.empty",{},e("b",{text:"Сигналы ещё не загружены"}),"Откройте вкладку ещё раз или нажмите «Обновить».")];let f=_=>_==null?"—":`${_>=0?"+":"−"}${(Math.abs(_)*100).toFixed(1)}%`,x=_=>new Date(_).toLocaleString("ru-RU",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"}),b=e("div.card.soft",{},e("dl.kv",{},e("dt",{text:"Открытых сигналов"}),e("dd",{text:String(d.open)}),e("dt",{text:"Закрыто за неделю"}),e("dd",{text:String(d.closedWeek)}),e("dt",{text:"Средний CLV за неделю"}),e("dd",{text:f(d.clvWeek)}),e("dt",{text:"Сигналов с плюсовым CLV"}),e("dd",{text:d.positiveWeek==null?"—":W(d.positiveWeek)})),e("div.hint",{style:"margin-top:8px",text:"CLV — насколько цена сигнала была выше цены закрытия линии. Плюсовой CLV на дистанции — единственный честный признак того, что сигналы опережают рынок. Это не обещание выигрыша."})),M=(d.signals||[]).map(_=>e("tr",{},e("td.name",{},`${_.home} — ${_.away}`,e("span.sub",{text:`${_.league} · ${x(_.start)}`})),e("td",{},_.label,e("span.sub",{text:_.book})),e("td",{text:K(_.odds)}),e("td",{text:K(1/_.p),title:`Честная цена по ${_.count} конторам`}),e("td.best",{text:`+${(_.edge*100).toFixed(1)}%`})));return[e("div.card",{},i(d.full?"тариф «Макс»":"витрина"),M.length?e("table",{},e("tr",{},e("th",{text:"Матч"}),e("th",{text:"Исход"}),e("th",{text:"Кэф"}),e("th",{text:"Рынок"}),e("th",{text:"Выше на"})),M):e("div.hint",{text:"Сейчас открытых сигналов нет: контора держится в рынке. Сканер проходит линию каждые полчаса."}),d.note?e("div.hint",{style:"margin-top:8px"},d.note," ",a.bot?e("a",{href:a.bot,target:"_blank",rel:"noopener",text:"Получить «Макс»"}):null):null,e("div.row",{style:"margin-top:10px"},e("button.btn.ghost.small",{type:"button","data-act":"edges-refresh"},"Обновить"))),b]}function ke(t){let o=t.settings,i=(d,f,x)=>e("div.seg",{},x.map(([b,M])=>e(`button${f===b?".on":""}`,{type:"button","data-act":d,"data-arg":b,text:M})));return[e("div.card",{},e("div.field",{},e("label",{text:"Отметки на странице"}),i("set-overlay",o.overlay,[["picks","Фавориты"],["all","Все шансы"],["off","Выкл"]]),e("div.hint",{text:"Рамка стоит на самом вероятном исходе каждого рынка. Число — шанс по линии без маржи конторы. Это не прогноз."})),e("div.field",{},e("label",{text:"Тема"}),i("set-theme",o.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]])),e("div.field",{},e("label",{for:"lz-stake",text:"Ставка для расчёта выгоды, ₽"}),e("div.row",{},e("input",{type:"number",id:"lz-stake",value:String(o.stake||1e3),min:"10",step:"10",inputmode:"numeric","data-enter":"set-stake",style:"max-width:140px"}),e("button.btn.small",{type:"button","data-act":"set-stake"},"Сохранить")),e("div.hint",{text:"Разницу лучшей цены Линза показывает в рублях от этой суммы. На ставку это не влияет."}))),e("div.card",{},e("div.kicker",{},e("span",{text:"Разбор матчей"}),e(`span.badge${o.ready?".pos":""}`,{text:o.ready?"подключён":"не подключён"})),o.proxy?e("div.field",{},e("label",{text:"Доступ"}),i("set-mode",o.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,o.mode==="license"&&o.proxy?e("div.field",{},e("label",{for:"lz-license",text:"Лицензионный ключ"}),e("input",{type:"text",id:"lz-license",placeholder:o.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),e("div.row",{},e("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),o.licenseMask?e("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),e("div.hint",{},[o.licenseMask?`Ключ ${o.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",o.plan,o.usage].filter(Boolean).join(" "),a.bot&&!o.licenseMask?[" ",e("a",{href:a.bot,target:"_blank",rel:"noopener",text:"Получить ключ «Про»"})]:null)):e("div.field",{},e("label",{for:"lz-key",text:"API-ключ Clodex"}),e("input",{type:"password",id:"lz-key",placeholder:o.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),e("div.row",{},e("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),o.hasKey?e("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),e("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${o.usage}`}))),e("div.card.soft",{},e("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной."))]}function Ht(t){E=t;let o=JSON.stringify(t);if(o===B)return;B=o;for(let M of m.querySelectorAll("details[data-key]"))C.set(M.dataset.key,M.open);let i=m.scrollTop;y.textContent=t.bookName?`· ${t.bookName}`:"",u.classList.toggle("off",t.settings.overlay==="off"),g.replaceChildren(st(t.theme==="dark"?"sun":"moon")),v.replaceChildren(st(t.settings.overlay==="off"?"eyeOff":"eye")),v.classList.toggle("on",t.settings.overlay!=="off"),k.classList.toggle("on",t.tab==="settings"),k.dataset.arg=t.tab==="settings"?t.backTab:"settings";let d=[["match","Матч"],["scan","Маржа"],["edges","Выше рынка"],["express","Экспресс"]];l.replaceChildren(...d.map(([M,_])=>e(`button.tab${t.tab===M?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":M},_,M==="express"&&t.express.legs.length?e("span.count",{text:String(t.express.legs.length)}):null)));let f=t.tab==="settings"?ke(t):t.tab==="scan"?Kt(t):t.tab==="express"?Zt(t):t.tab==="edges"?ye(t):ve(t),x=t.update?e("div.card.soft.update",{},e("b",{text:`Вышла Линза ${t.update.version}`})," — ",t.update.url?e("a",{href:t.update.url,target:"_blank",rel:"noopener",text:"скачать архив на сайте"}):"архив на сайте Линзы"," и заменить папку расширения."):null,b=t.whatsnew?.changes?.length&&t.tab!=="settings"?e("div.card.soft.update",{},e("b",{text:`Линза обновилась до ${t.whatsnew.version}`}),e("ul.facts",{style:"margin-top:6px"},t.whatsnew.changes.flatMap(M=>M.items).slice(0,6).map(M=>e("li",{},e("span",{text:M})))),e("div.row",{style:"margin-top:8px"},e("button.btn.ghost.small",{type:"button","data-act":"whatsnew-ok"},"Понятно"))):null;m.replaceChildren(...[x,b,...f].filter(Boolean)),m.scrollTop=i,h.replaceChildren(e("span",{text:"18+ · Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function Et(t){n.setAttribute("data-theme",t)}function Xt(){w.hidden=!1,r.opened?.()}function Pt(){w.hidden=!0}function Dt(){w.hidden?Xt():Pt()}function Yt(t){t?.fab&&N(c,t.fab.left,t.fab.top),t?.panel&&N(w,t.panel.left,t.panel.top)}let Nt=0;function Jt(t){p.querySelector(".toast")?.remove();let o=e("div.toast",{text:t,role:"status"});p.appendChild(o),clearTimeout(Nt),Nt=setTimeout(()=>o.remove(),2600)}return{render:Ht,setTheme:Et,open:Xt,close:Pt,toggle:Dt,restore:Yt,toast:Jt,shadow:p,rect:()=>w.hidden?null:w.getBoundingClientRect(),get isOpen(){return!w.hidden},get view(){return E}}}var vn="Расширение обновилось. Обновите эту вкладку (F5).";function zo(s){return/signal timed out|timeout|timed out/i.test(s)?"Сервер долго не отвечает — нажмите ещё раз.":/failed to fetch|networkerror|load failed|network request failed/i.test(s)?"Нет связи с сервером Линзы — проверьте интернет.":s}function kt(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function tt(s,r={}){if(!kt())return{ok:!1,error:vn,code:"reload"};try{return await chrome.runtime.sendMessage({type:s,...r})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(a){let n=String(a?.message||a);return/context invalidated/i.test(n)||!kt()?{ok:!1,error:vn,code:"reload"}:/message port closed|receiving end does not exist/i.test(n)?{ok:!1,error:"Связь с расширением прервалась — нажмите ещё раз.",code:"retry"}:{ok:!1,error:zo(n)}}}function yn(s){if(kt())try{chrome.runtime.onMessage.addListener(r=>{s(r)})}catch{}}async function Le(s){if(!kt())return{};try{return await chrome.storage.local.get(s)}catch{return{}}}function wt(s){if(kt())try{chrome.storage.local.set(s)}catch{}}var kn=(s=Date.now())=>new Date(s).toISOString().slice(0,10);function ue(s,r=Date.now()){return s&&s.day===kn(r)&&s.items&&typeof s.items=="object"?s:{day:kn(r),items:{}}}function wn(s,{key:r,book:a,margin:n}){if(!r||!Number.isFinite(n)||n<=0||n>.5)return!1;let p=Math.round(n*1e4)/1e4,u=s.items[r];return u&&u.here===p&&u.book===a?!1:(s.items[r]={book:a,here:p,others:u?.others||{}},!0)}function $n(s,r,a){let n=s.items[r];if(!n)return!1;let p=!1;for(let u of a||[]){if(u.here||u.sharp||!u.odds?.length||u.odds.some(m=>!(m>1)))continue;let c=vt(u.odds);if(c.kind!=="full"||!(c.margin>0))continue;let l=Math.round(c.margin*1e4)/1e4;n.others[u.name]!==l&&(n.others[u.name]=l,p=!0)}return p}function Mn(s,r){let a=Object.values(s?.items||{}).filter(c=>c.book===r);if(!a.length)return null;let n=c=>c.reduce((l,m)=>l+m,0)/c.length,u=[...new Set(a.flatMap(c=>Object.keys(c.others||{})))].map(c=>{let l=a.filter(m=>Number.isFinite(m.others?.[c]));return l.length>=2?{name:c,n:l.length,there:n(l.map(m=>m.others[c])),here:n(l.map(m=>m.here))}:null}).filter(Boolean).sort((c,l)=>c.there-l.there);return{n:a.length,here:n(a.map(c=>c.here)),best:u[0]||null,others:u}}var So=[{version:"1.0.16",items:["Новый адрес Линзы — linzabet.ru: сайт, мини-приложение и сервер разборов. Если он вдруг недоступен, расширение само переходит на запасной.","В разборе — «Прогноз Линзы»: кто, как и почему, до матча и в лайве.","Лайв CS и Dota: счёт карт и раундов с панели уходит в разбор, сервер учитывает, кто забирает текущую карту."]},{version:"1.0.15",items:["Разбор на сервере видит тоталы и форы этой страницы: в теннисе «Показать полностью» — итог и по геймам, по цене самой конторы."]},{version:"1.0.14",items:["«Лучшая цена» — только если цена выше честной на 3–12%. Больше 12% — строка «Проверьте данные»: чаще это ошибка в данных, чем подарок конторы.","Модель Линзы пока справочно: «по модели интересная цена от…». Перевес считается по ценам рынка, пока модель не докажет, что она точнее.","Карты в CS и Dota временно убраны из итога: вернём после проверки на честных ценах."]},{version:"1.0.13",items:["Под разбором — «Показать полностью»: итог по всем рынкам, доводы, как может пойти игра, профили и факты.","Итог по рынкам этой страницы: в теннисе — тотал и фора геймов, в CS и Dota — карты, по цене самой конторы на победу."]},{version:"1.0.12",items:["Под разбором — «Сообщить об ошибке»: что сломалось, уходит разработчику без личных данных.","Итог не строится по модели, которой нельзя верить как цене: если она сильно расходится с рынком или у неё мало матчей в архиве."]},{version:"1.0.11",items:["Разобрать матч: разбор идёт на сервере — видно, что происходит (цены, новости, модель), и он не обрывается на «Обновите вкладку».","Разбор работает на всех конторах: если матча нет в линии Fonbet, Линза разбирает по ценам страницы и свежим новостям.","Новости, травмы и составы из прессы — в разборе для всех тарифов; у «Макс» и VIP поиск подробнее.","Бесплатные 3 разбора в день считаются для вашего браузера, а не для всех с одного адреса; истёкший ключ не отключает бесплатные разборы.","Исправлено: счётчик «Разборов сегодня» больше не пропадает, ошибки связи — понятными словами."]},{version:"1.0.10",items:["Исправлено: в доводах моделей имена команд и игроков — как на странице конторы."]},{version:"1.0.9",items:["Лайв тенниса по счёту: шанс матча, текущего сета и гейма от очков и подачи.","Прогноз модели для КХЛ: атака и оборона команд, исход основного времени и победитель с ОТ; на проверке при уверенности от 65% сбылось 70%.","Итог: форы футбола и хоккея против честной цены по Fonbet."]},{version:"1.0.8",items:["Лайв по счёту для футбола и хоккея: шанс исхода основного времени, следующий гол, тоталы и форы по счёту, времени и удалениям; точное игровое время.","Итог для футбола и хоккея: тоталы этой конторы против честной цены по Fonbet без маржи на любой линии.","Журнал итогов: точность прошлых итогов — в карточке и в приложении."]},{version:"1.0.7",items:["ММА (UFC): прогноз модели по бойцам — возраст, размах рук, форма, простой; как скорее всего закончится бой и честные кэфы на тоталы раундов и решение судей; прогноз рынка 5+ контор.","Итог: в конце карточек — лучшая цена против честной, перевес и размер суммы, доводы и главный риск из разбора; каждый итог записывается и потом сверяется с результатом — точность видна в приложении.","Баскетбол: фора и тотал по модели — ожидаемая разница очков и тотал с разбросом, честные кэфы основных линий конторы в «Итоге».","Теннис: подача и приём в модели — шанс матча по доле выигранных очков на своей подаче и на приёме соперника.","Исправлено: бойцы и теннисисты в формате «Фамилия И.» находятся, если полное имя из трёх слов.","Одна палитра у панели, попапа, мини-приложения и сайта; в тёмной теме приложения — светлый акцент."]},{version:"1.0.6",items:["Лайв по счёту: в баскетболе — честный шанс, фора и тотал против цены конторы; в CS и Dota — шанс серии по счёту карт и раундов текущей карты.","Профили участников: теннисисты (покрытия, подача и приём, нагрузка, последние матчи), команды баскетбола и киберспорта (динамика рейтинга, форма, состав с рейтингом каждого игрока).","Баскетбол: Еврокубок, АСВ, Серия А, Адриатическая лига, Единая лига ВТБ и Лига чемпионов FIBA — в модели и в фактах.","Футбол: ход матча и судьи (УЕФА) в карточке «Составы, травмы, форма».","Киберспорт: у подписи уверенности — как часто такие прогнозы сбывались на проверке; модель Dota точнее.","Вкладка «Маржа»: сколько маржи вы отдаёте этой конторе по открытым сегодня матчам и сколько отдавали бы у других контор.","Новая версия подхватывается сама, когда вы заменили файлы в папке расширения."]},{version:"1.0.5",items:["Карточка «Составы, травмы, форма» на странице матча: травмы по именам, составы, форма и очные встречи (ESPN, bo3.gg) — без разбора и без лимита.","Подсказка в панели, когда на сайте вышла новая версия.","Dota 2: точнее вероятность победы в серии до двух побед."]}];function zn(s,r){let a=String(s||"").split(".").map(Number),n=String(r||"").split(".").map(Number);for(let p=0;p<Math.max(a.length,n.length);p++){let u=(a[p]||0)-(n[p]||0);if(u)return u>0}return!1}function Sn(s,r){return So.filter(a=>zn(a.version,s)&&!zn(a.version,r))}var $t=s=>Number.isFinite(s)?(Math.round(s*100)/100).toFixed(2):"—",de=s=>`${Math.round(s*100)}%`,_o=(s,r)=>s*r-1;function No(s){return s<.03?null:s<.06?"небольшая — примерно половина обычной":s<.12?"обычная":"перевес слишком большой — сначала проверьте травмы, замены и что это тот же матч"}function _n(s,{source:r="",reasons:a=[],risk:n=""}={}){let p=(s||[]).filter(w=>Number(w.odd)>1&&w.p>.01&&w.p<.99).map(w=>({...w,fairOdd:1/w.p,edge:_o(w.p,Number(w.odd))}));if(!p.length)return null;let u=[...p].sort((w,A)=>A.edge-w.edge),c=u.find(w=>w.edge>=.03&&w.edge<=.12)||null,l=c?{...c,size:No(c.edge)}:null,m=u.find(w=>w.edge>.12)||null,h=m?{...m}:null,y=p.filter(w=>w!==c&&w!==m).map(w=>({...w,note:w.edge>.12?`перевес ${de(w.edge)} — слишком большой, проверьте данные`:w.edge>=.03?`перевес ${de(w.edge)} к честной цене ${$t(w.fairOdd)}`:w.edge>-.02?`честная цена (${$t(w.fairOdd)}), перевеса нет`:`цена ниже честной (${$t(w.fairOdd)})`})),g=[],v=w=>w.source||r;if(l){let w=v(l);g.push(`Лучшая цена: ${l.label} по ${$t(l.odd)} — перевес около ${de(l.edge)} к честной цене ${$t(l.fairOdd)}${w?` (${w})`:""}. Сумма: ${l.size}.`),a.length&&g.push(`За: ${a.join(" ")}`),n&&g.push(`Главный риск: ${n}`)}else g.push(`${h?"Надёжного перевеса нет":"Перевеса нет"}: ${h?"остальные":"все"} цены близки к честным или ниже${r?` (${r})`:""} — разумнее пропустить.`);if(h){let w=v(h);g.push(`Проверьте данные: ${h.label} по ${$t(h.odd)} — перевес ${de(h.edge)} к честной цене ${$t(h.fairOdd)}${w?` (${w})`:""} слишком большой. Чаще это ошибка данных или модели (травма, состав, чужой матч), а не подарок конторы — лучшей ценой не считаем.`)}let k=[...y].sort((w,A)=>A.edge-w.edge).slice(0,6),T=y.length-k.length;return y.length&&g.push(`${l?"Остальное":"По рынкам"}: ${k.map(w=>`${w.label} по ${$t(w.odd)} — ${w.note}`).join("; ")}${T>0?`; ещё ${T} — с меньшим перевесом или без него`:""}.`),g.push("Это расчёт, а не обещание: проиграть можно и при перевесе в цене. 18+"),{best:l,suspect:h,others:y,lines:g}}function Vt(s){let r=n=>/^(б|больше|бол|over|o\b|тб)/i.test(String(n||"").trim()),a=n=>/^(м|меньше|мен|under|u\b|тм)/i.test(String(n||"").trim());return r(s[0])&&a(s[1])?0:a(s[0])&&r(s[1])?1:-1}var Fo=s=>{let r=s<0?-1:1,a=Math.abs(s),n=1/(1+.3275911*a);return r*(1-((((1.061405429*n-1.453152027)*n+1.421413741)*n-.284496736)*n+.254829592)*n*Math.exp(-a*a))},Te=s=>.5*(1+Fo(s/Math.SQRT2));function Nn(s,r,a){if(!(Math.abs(a-Math.round(a))<1e-9)){let c=1-Te((a-s)/r);return{win:c,push:0,lose:1-c}}let p=1-Te((a+.5-s)/r),u=Te((a-.5-s)/r);return{win:p,push:Math.max(0,1-p-u),lose:u}}function Lo(s,r,a){let n=Nn(s,r,-a);return{home:n.win,away:n.lose,push:n.push}}function To(s,r,a){let n=Nn(s,r,a);return{over:n.win,under:n.lose,push:n.push}}function Fn(s,{handicap:r=null,total:a=null}={},n=["Хозяева","Гости"]){let p=s?.lines;if(!p||!Number.isFinite(p.margin)||!(p.sigma>0))return[];let u=[],c=h=>h>0?`+${h}`:`${h}`,l=(h,y)=>h/(1-y||1),m=(h,y)=>1/h/(1/h+1/y);if(r&&Number.isFinite(r.line)&&Math.abs(r.line)<60&&r.home>1&&r.away>1){let h=Lo(p.margin,p.sigma,r.line);Math.abs(l(h.home,h.push)-m(r.home,r.away))<=.3&&u.push({label:`Фора ${n[0]} ${c(r.line)}`,odd:r.home,p:l(h.home,h.push),kind:"handicap",side:"home",source:"модель Линзы"}),u.length&&u.push({label:`Фора ${n[1]} ${c(-r.line)}`,odd:r.away,p:l(h.away,h.push),kind:"handicap",side:"away",source:"модель Линзы"})}if(a&&Number.isFinite(p.total)&&p.sigmaT>0&&Number.isFinite(a.line)&&a.line>50&&a.over>1&&a.under>1){let h=To(p.total,p.sigmaT,a.line);Math.abs(l(h.over,h.push)-m(a.over,a.under))<=.3&&(u.push({label:`Тотал больше ${a.line}`,odd:a.over,p:l(h.over,h.push),kind:"total",source:"модель Линзы"}),u.push({label:`Тотал меньше ${a.line}`,odd:a.under,p:l(h.under,h.push),kind:"total",source:"модель Линзы"}))}return u}var It={football:{periods:2,minutes:90,stoppage:[2,5],late:1,weights:[.12,.142,.184,.149,.167,.237],trail:.3,lead:.05,redOwn:-.4,redOpp:.45,total:2.7,homeShare:.555,maxGoals:12},hockey:{periods:3,minutes:60,weights:[.297,.344,.359],trail:0,lead:-.1,redOwn:0,redOpp:0,total:6,homeShare:.52,maxGoals:16}},Ae=[1];for(let s=1;s<=40;s+=1)Ae[s]=Ae[s-1]*s;var Ln=(s,r)=>r<=0?s===0?1:0:Math.exp(-r)*r**s/Ae[s];function Ao(s,r){let a=r.weights.length,n=r.minutes/a,p=Math.max(0,Math.min(r.minutes,s)),u=0;for(let l=0;l<a;l+=1){let m=l*n,h=m+n,y=a/(r.periods||1),g=(l+1)%y===0&&r.stoppage?.[Math.floor(l/y)]||0;p<=m?u+=r.weights[l]:p<h&&(u+=r.weights[l]*((h-p+g)/(n+g)))}let c=r.weights.reduce((l,m)=>l+m,0);return u/c}function Tn(s,r,a){let n=[];for(let p=0;p<=a;p+=1){n[p]=[];for(let u=0;u<=a;u+=1)n[p][u]=Ln(p,s)*Ln(u,r)}return n}function Oo(s,r,a,n=null){let p=Tn(s,r,a),u=0,c=0,l=0,m=0;for(let h=0;h<=a;h+=1)for(let y=0;y<=a;y+=1){let g=p[h][y];h>y?u+=g:h===y?c+=g:l+=g,n!=null&&h+y>n&&(m+=g)}return{p1:u,px:c,p2:l,over:m}}function An({p1:s,px:r,p2:a,line:n=null,pOver:p=null},u=It.football){let c=u.total,l=(h,y)=>{let g=Oo(h,y,u.maxGoals,n!=null&&p!=null?n:null),v=(g.p1-s)**2+(g.p2-a)**2+(r!=null?(g.px-r)**2:0);return n!=null&&p!=null?v+=(g.over-p)**2:v+=.02*((h+y-c)/c)**2,v},m={lh:c*u.homeShare,la:c*(1-u.homeShare),e:1/0};for(let h=.4;h>=.01;h/=2){let y=m;for(let g=-4;g<=4;g+=1)for(let v=-4;v<=4;v+=1){let k=Math.max(.03,y.lh+g*h),T=Math.max(.03,y.la+v*h),w=l(k,T);w<m.e&&(m={lh:k,la:T,e:w})}}return{lh:m.lh,la:m.la}}function Oe(s,r,a=It.football){let[n,p]=s.score.map(Number),u=Ao(Number(s.minute)||0,a),c=n-p,l=Math.sign(c),m=1+(a.late||0)*((Number(s.minute)||0)/a.minutes-.5),h=(Math.abs(c)>=2?.6:1)*Math.max(0,m),y=l<0?a.trail*h:l>0?a.lead*h:0,g=l>0?a.trail*h:l<0?a.lead*h:0,[v,k]=(s.red||[0,0]).map(q=>Math.min(2,Number(q)||0)),T=(q,G)=>(1+a.redOwn)**q*(1+a.redOpp)**G,w=Math.max(0,r.lh*u*(1+y)*T(v,k)),A=Math.max(0,r.la*u*(1+g)*T(k,v)),B=a.maxGoals,E=Tn(w,A,B),C=0,V=0,L=0;for(let q=0;q<=B;q+=1)for(let G=0;G<=B;G+=1){let J=n+q,X=p+G;J>X?C+=E[q][G]:J===X?V+=E[q][G]:L+=E[q][G]}let $=C+V+L||1,N=q=>{let G=0,J=0;for(let X=0;X<=B;X+=1)for(let et=0;et<=B;et+=1){let Y=n+p+X+et;Y>q?G+=E[X][et]:Y===q&&(J+=E[X][et])}return{over:G,push:J,under:Math.max(0,1-G-J)}},O=q=>{let G=0,J=0;for(let X=0;X<=B;X+=1)for(let et=0;et<=B;et+=1){let Y=n+X-(p+et)+q;Y>0?G+=E[X][et]:Y===0&&(J+=E[X][et])}return{home:G,push:J,away:Math.max(0,1-G-J)}},P=w+A,I=Math.exp(-P);return{p1:C/$,px:V/$,p2:L/$,lh:w,la:A,share:u,expTotal:n+p+P,nextGoal:{home:P>0?(1-I)*(w/P):0,away:P>0?(1-I)*(A/P):0,none:I},total:N,handicap:O}}var Ce=(s,r)=>1/s/(1/s+1/r);function Co(s,r){let a=It[r];if(!a||!s?.odds||s.odds.length!==3)return null;let n=vt(s.odds).fair;if(!n)return null;let p=s.total,u=p&&p.over>1&&p.under>1?Ce(p.over,p.under):null;return u==null?null:An({p1:n[0],px:n[1],p2:n[2],line:p.line,pOver:u},a)}function On(s,r,a,n=["Хозяева","Гости"]){let p=Co(s,a);if(!p)return[];let u=It[a],c=Oe({score:[0,0],minute:0},p,u),l=[],m=new Set,h=g=>g>0?`+${g}`:`${g}`,y=g=>{let v=String(g??"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?\d+(?:\.\d+)?/g);return v?Number(v[v.length-1]):NaN};for(let g of r||[]){if(g.kind!=="total"&&g.kind!=="handicap"||g.outcomes?.length!==2)continue;let v=`${g.title||""} ${g.period||""}`;if(/тайм|период|четверт|half|period|инд|команд|угл|карт|corner|card|овертайм|буллит|с уч[её]том|(^|[^а-яё])от([^а-яё]|$)/i.test(v.replace(/осн\.?\s*время/i,"")))continue;if(g.kind==="handicap"){let L=y(g.outcomes[0].label);if(Number.isFinite(L)||(L=y(g.line)),!Number.isFinite(L)||Math.abs(L)>4||m.has(`h${L}`))continue;let $=Number(g.outcomes[0].odd),N=Number(g.outcomes[1].odd);if(!($>1&&N>1))continue;let O=c.handicap(L),P=1-O.push||1;if(Math.abs(O.home/P-Ce($,N))>.15)continue;m.add(`h${L}`),l.push({label:`Фора ${n[0]} ${h(L)}`,odd:$,p:O.home/P,kind:"handicap",side:"home",line:L,source:"Fonbet без маржи"},{label:`Фора ${n[1]} ${h(-L)}`,odd:N,p:O.away/P,kind:"handicap",side:"away",line:-L,source:"Fonbet без маржи"});continue}let k=Number(String(g.line||"").replace(",","."));if(!Number.isFinite(k)||k<=0||k>(a==="hockey"?12:9)||m.has(k))continue;let T=Vt(g.outcomes.map(L=>L.label));if(T<0)continue;let w=c.total(k),A=1-w.push||1,B=w.over/A,E=w.under/A,C=Number(g.outcomes[T].odd),V=Number(g.outcomes[1-T].odd);!(C>1&&V>1)||Math.abs(B-Ce(C,V))>.2||(m.add(k),l.push({label:`Тотал больше ${k}`,odd:C,p:B,kind:"total",line:k,source:"Fonbet без маржи"},{label:`Тотал меньше ${k}`,odd:V,p:E,kind:"total",line:k,source:"Fonbet без маржи"}))}return l}function Eo(s){let r=(s||[]).map(Number);if(!r.length||!r.every(u=>u>1))return null;let a=r.map(u=>1/u),n=a.reduce((u,c)=>u+c,0),p=a.map(u=>u/n);return p.length===3?p[0]+p[1]/2:p[0]}function Cn(s,r){if(!s?.p1)return{ok:!1,reason:"нет прогноза"};if(s.confidence==="очень низкая")return{ok:!1,reason:"мало матчей в архиве — модель почти ничего не знает об участниках"};let a=Eo(r);return a!=null&&Math.abs(s.p1-a)>.2?{ok:!1,reason:`модель расходится с ценой конторы на ${Math.round(Math.abs(s.p1-a)*100)} п.п. — скорее всего, она чего-то не знает (квалификация, травма, состав)`}:{ok:!0,reason:""}}var Po={cs:!1,dota:!1,tennis:!1,basketball:!1,mma:!1,hockey:!1},En=s=>Po[s]===!0;function Ee(s,r){if(!s?.p1||!(s.p2>0))return"";let a=n=>n>.01&&n<.99?(1/n*1.03).toFixed(2):"—";return`По модели Линзы интересная цена от: ${r[0]} — ${a(s.p1)}, ${r[r.length-1]} — ${a(s.p2)} (справочно: модель пока не точнее цены конторы).`}var je={atp:{hard:.645,clay:.625,grass:.67},wta:{hard:.565,clay:.55,grass:.585}};function Tt(s,r=0,a=0){let n=1-s,p=s*s/(s*s+n*n),u=new Map,c=(l,m)=>{if(l>=4&&l-m>=2)return 1;if(m>=4&&m-l>=2)return 0;if(l>=3&&m>=3)return l===m?p:l>m?s+n*p:s*p;let h=l*16+m;return u.has(h)||u.set(h,s*c(l+1,m)+n*c(l,m+1)),u.get(h)};return c(r,a)}function pe(s,r,a=0,n=0,p=!0,u=7){let c=k=>k?s:1-r,l=s*(1-r)/(s*(1-r)+(1-s)*r),m=k=>k===0?0:Math.floor((k+1)/2),h=m(a+n)%2===0?p:!p,y=k=>m(k)%2===0?h:!h,g=new Map,v=(k,T)=>{if(k>=u&&k-T>=2)return 1;if(T>=u&&T-k>=2)return 0;if(k>=u-1&&T>=u-1&&k===T)return l;let w=k*64+T;if(!g.has(w)){let A=c(y(k+T));g.set(w,A*v(k+1,T)+(1-A)*v(k,T+1))}return g.get(w)};return v(a,n)}function Pe(s,r,a=0,n=0,p=!0,u=7){let c=Tt(s),l=1-Tt(r),m=new Map,h=(y,g,v)=>{if(y>=6&&y-g>=2||y===7)return 1;if(g>=6&&g-y>=2||g===7)return 0;if(y===6&&g===6)return pe(s,r,0,0,v,u);let k=y*32+g*2+(v?1:0);if(!m.has(k)){let T=v?c:l;m.set(k,T*h(y+1,g,!v)+(1-T)*h(y,g+1,!v))}return m.get(k)};return h(a,n,p)}function Pn(s,r,a,n=3,{finalTb:p=7}={}){let u=n>=5?3:2,c=(s.sets||[]).filter(([L,$])=>L>$).length,l=(s.sets||[]).length-c,[m,h]=s.games||[0,0],[y,g]=s.points||[0,0],v=s.aServes!==!1,T=c===u-1&&l===u-1?p:7,w=new Map,A=(L,$)=>{if(L>=u)return 1;if($>=u)return 0;let N=L*8+$;if(!w.has(N)){let O=L===u-1&&$===u-1?p:7,P=(Pe(r,a,0,0,!0,O)+Pe(r,a,0,0,!1,O))/2;w.set(N,P*A(L+1,$)+(1-P)*A(L,$+1))}return w.get(N)},B=m===6&&h===6,E,C;if(B)E=pe(r,a,y,g,v,T),C=E;else{C=v?Tt(r,y,g):1-Tt(a,g,y);let L=($,N)=>$>=6&&$-N>=2||$===7?1:N>=6&&N-$>=2||N===7?0:Pe(r,a,$,N,!v,T);E=C*L(m+1,h)+(1-C)*L(m,h+1)}return{match:E*A(c+1,l)+(1-E)*A(c,l+1),set:E,game:C,hold:v?C:1-C}}function jn(s,r,a=3){return(Pn({sets:[],games:[0,0],points:[0,0],aServes:!0},s,r,a).match+Pn({sets:[],games:[0,0],points:[0,0],aServes:!1},s,r,a).match)/2}var jo=.03,At=(s,r,a)=>s.set(r,(s.get(r)||0)+a);function Bo(s,r,a=!0){let n=Tt(s),p=Tt(r),u=new Map,c=new Map([[`0,0,${a?1:0}`,1]]);for(;c.size;){let l=new Map;for(let[m,h]of c){let[y,g,v]=m.split(",").map(Number),k=v===1;if(y===6&&g===6){let w=pe(s,r,0,0,k);At(u,`7,6,${k?0:1}`,h*w),At(u,`6,7,${k?0:1}`,h*(1-w));continue}let T=k?n:1-p;for(let[w,A,B]of[[y+1,g,T],[y,g+1,1-T]]){let E=(w>=6||A>=6)&&Math.abs(w-A)>=2||w===7||A===7,C=`${w},${A},${k?0:1}`;At(E?u:l,C,h*B)}}c=l}return[...u].map(([l,m])=>{let[h,y,g]=l.split(",").map(Number);return{ga:h,gb:y,nextA:g===1,p:m}})}function Bn(s,r,a=3){let n=a===5?3:2,p=new Map,u=g=>{let v=g?1:0;return p.has(v)||p.set(v,Bo(s,r,g)),p.get(v)},c=new Map,l=new Map,m=new Map,h=[{sa:0,sb:0,a:!0,t:0,d:0,p:.5},{sa:0,sb:0,a:!1,t:0,d:0,p:.5}];for(;h.length;){let g=new Map;for(let v of h)for(let k of u(v.a)){let T=v.sa+(k.ga>k.gb?1:0),w=v.sb+(k.gb>k.ga?1:0),A=v.t+k.ga+k.gb,B=v.d+k.ga-k.gb,E=v.p*k.p;if(T===n||w===n){At(c,`${T}:${w}`,E),At(l,A,E),At(m,B,E);continue}let C=`${T},${w},${k.nextA?1:0},${A},${B}`,V=g.get(C);V?V.p+=E:g.set(C,{sa:T,sb:w,a:k.nextA,t:A,d:B,p:E})}h=[...g.values()]}let y=(g,v)=>[...g].reduce((k,[T,w])=>k+(v(Number(T))?w:0),0);return{sets:Object.fromEntries(c),win:[...c].reduce((g,[v,k])=>g+(Number(v.split(":")[0])===n?k:0),0),total:l,diff:m,over:g=>({over:y(l,v=>v>g),push:y(l,v=>v===g)}),handicap:g=>({home:y(m,v=>v+g>0),push:y(m,v=>v+g===0)})}}var Io=0,Do=.04,Ro=[[-2.0201828705,.0199532421],[-.9585724646,.3936193232],[0,.9453087205],[.9585724646,.3936193232],[2.0201828705,.0199532421]].map(([s,r])=>[s*Math.SQRT2,r/Math.sqrt(Math.PI)]);function qo(s,{tour:r="atp",surface:a="hard",bestOf:n=3,serveShift:p=Io,daySd:u=Do}={}){let c=((je[r]||je.atp)[a]||.63)+p,l=L=>Math.max(-.3,Math.min(.3,L)),m=u>0?Ro:[[0,1]],h=L=>m.reduce(($,[N,O])=>$+O*jn(c+l(L+N*u),c-l(L+N*u),n),0),y=-.3,g=.3,v=Math.min(.995,Math.max(.005,s));for(let L=0;L<30;L+=1){let $=(y+g)/2;h($)<v?y=$:g=$}let k=(y+g)/2;if(m.length===1)return Bn(c+k,c-k,n);let T=m.map(([L,$])=>[$,Bn(c+l(k+L*u),c-l(k+L*u),n)]),w=L=>{let $=new Map;for(let[N,O]of T)for(let[P,I]of L(O))$.set(P,($.get(P)||0)+N*I);return $},A=w(L=>Object.entries(L.sets)),B=w(L=>L.total),E=w(L=>L.diff),C=(L,$)=>[...L].reduce((N,[O,P])=>N+($(Number(O))?P:0),0),V=n===5?3:2;return{sets:Object.fromEntries(A),win:[...A].reduce((L,[$,N])=>L+(Number($.split(":")[0])===V?N:0),0),total:B,diff:E,over:L=>({over:C(B,$=>$>L),push:C(B,$=>$===L)}),handicap:L=>({home:C(E,$=>$+L>0),push:C(E,$=>$+L===0)})}}var Go={cs:0,dota:0};function Uo(s,{pick:r=0}={}){let a=l=>Math.min(.999,Math.max(.001,l)),n=l=>{let m=a(l+r),h=a(l-r),y=a(l),g=m*h,v=(1-m)*(1-h),k=m*(1-h)+(1-m)*h;return{q:l,s20:g,s02:v,s21:k*y,s12:k*(1-y)}},p=0,u=1;for(let l=0;l<50;l+=1){let m=(p+u)/2,h=n(m);h.s20+h.s21<s?p=m:u=m}let c=n((p+u)/2);return{q:c.q,sets:{"2:0":c.s20,"2:1":c.s21,"1:2":c.s12,"0:2":c.s02},over25:c.s21+c.s12,homeMinus15:c.s20,awayMinus15:c.s02}}var Vo={tennis:!0,cs:!1,dota:!1};function Wo(s=""){let r=String(s),a=/wta|жен|women/i.test(r)?"wta":"atp",n=/грунт|clay/i.test(r)?"clay":/трав|grass/i.test(r)?"grass":"hard",p=/australian open|roland garros|ролан|уимблдон|wimbledon|us open|открытый чемпионат (австралии|сша)/i.test(r);return{tour:a,surface:n,bestOf:p&&a==="atp"?5:3}}function Be({sport:s,model:r=null,p:a=null,source:n="модель Линзы",markets:p,names:u=["Хозяева","Гости"],league:c=""}){let l=a??r?.p1;if(!Vo[s]||!(l>0&&l<1))return[];let m=s==="tennis",h=m?qo(l,Wo(c)):Uo(l,{pick:Go[s]||0}),y=E=>{let C=String(E??"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?\d+(?:\.\d+)?/g);return C?Number(C[C.length-1]):NaN},g=(E,C)=>1/E/(1/E+1/C),v=(E,C)=>C>0?E/(1-C):E,k=m?"гейма":"карты",T=E=>String(E||"").toLowerCase().replace(/ё/g,"е"),w=u.flatMap(E=>T(E).split(/[^a-zа-я0-9-]+/)).filter(E=>E.length>=4),A=[],B=new Set;for(let E of p||[]){if(E.scope==="list"||E.main===!1||E.kind!=="total"&&E.kind!=="handicap"||E.outcomes?.length!==2||!E.outcomes.every($=>$.odd>1))continue;let C=`${E.title||""} ${E.period||""}`;if(/сет|set|тай-?брейк|tie|инд|игрок|player|раунд|round|килл|kill|чет|нечет/i.test(C)||w.some($=>T(C).includes($))||!m&&/гейм|game/i.test(C))continue;let[V,L]=E.outcomes;if(E.kind==="total"){let $=Number.isFinite(y(E.line))?y(E.line):y(V.label);if(!Number.isFinite($)||B.has(`t${$}`)||(m?$<12||$>60:$!==2.5))continue;let N=!/меньш|under/i.test(V.label),O,P=0;if(m){let J=h.over($);O=J.over,P=J.push}else if($===2.5)O=h.over25;else continue;let I=N?V:L,q=N?L:V,G=v(O,P);if(Math.abs(G-g(I.odd,q.odd))>.2)continue;B.add(`t${$}`),A.push({label:`Тотал ${m?"геймов":"карт"} больше ${$}`,odd:I.odd,p:G,kind:"total",line:$,source:n}),A.push({label:`Тотал ${m?"геймов":"карт"} меньше ${$}`,odd:q.odd,p:1-G,kind:"total",line:$,source:n})}else{let $=Number.isFinite(y(V.label))?y(V.label):y(E.line);if(!Number.isFinite($)||B.has(`h${$}`)||(m?Math.abs($)>15:Math.abs($)!==1.5))continue;let N,O=0;if(m){let q=h.handicap($);N=q.home,O=q.push}else if($===-1.5)N=h.homeMinus15;else if($===1.5)N=1-h.awayMinus15;else continue;let P=v(N,O);if(Math.abs(P-g(V.odd,L.odd))>.2)continue;B.add(`h${$}`);let I=q=>q>0?`+${q}`:`${q}`;A.push({label:`Фора ${u[0]} ${I($)} ${k}`,odd:V.odd,p:P,kind:"handicap",side:"home",line:$,source:n}),A.push({label:`Фора ${u[1]} ${I(-$)} ${k}`,odd:L.odd,p:1-P,kind:"handicap",side:"away",line:-$,source:n})}}return A}function In({sport:s,model:r,markets:a,names:n,league:p=""}){let u=Be({sport:s,model:r,markets:a,names:n,league:p}).filter(l=>l.p>=.15&&l.p<=.85),c=new Map;for(let l of u){let m=`${l.kind}|${Math.abs(l.line)}`;(!c.has(m)||l.p*l.odd>c.get(m).p*c.get(m).odd)&&c.set(m,l)}return[...c.values()].sort((l,m)=>Math.abs(l.p-.5)-Math.abs(m.p-.5)).map(l=>({label:l.label,from:Math.round(1/l.p*(1+jo)*100)/100,odd:l.odd}))}var me=globalThis.__lzBus,Ie=me&&window.top===window?rn(location.hostname):null;Ie&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,Ho(Ie.adapter,Ie.book));async function Ho(s,r){let a=await Le(["lz.settings","lz.positions","lz.express","lz.margins","lz.whatsnew"]),n={settings:{...$e,...a["lz.settings"]||{}},positions:(a["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:Xo(a["lz.express"]),margins:ue(a["lz.margins"]),whatsnew:a["lz.whatsnew"]||null,analysis:new Map,compare:new Map,consensus:new Map,model:new Map,facts:new Map,fonbetRef:new Map,live:new Map,edges:{status:"idle",data:null,error:"",at:0},partners:{data:{},at:0},status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},p=new WeakMap,u=new WeakMap,c=un(),l=xn({bus:me,brand:ee,actions:ke()});l.restore(n.positions);function m(t){let o=t.outcomes.map(f=>f.odd).join("/"),i=p.get(t);if(i?.sig===o)return i.set;let d=vt(t.outcomes.map(f=>f.odd));return p.set(t,{sig:o,set:d}),d}function h(){return n.match?n.analysis.get(n.match.key):null}function y(t){let o=h()?.result;if(!o?.model||t.scope==="list"||!n.match||!Object.values(o.shift||{}).some(b=>Math.abs(b)>=.5))return null;let{home:i,draw:d,away:f}=o.model,x=t.outcomes.length;if(t.kind==="1x2"&&t.main&&x===3)return[i,d,f];if(t.kind==="12"&&t.main&&x===2&&d<.005)return[i,f];if(t.kind==="dc"&&t.main&&x===3)return[i+d,i+f,d+f];if(/^победит\s*\(осн\.?\s*время\)$/i.test(t.title)&&x===2){let b=t.period===n.match.home?i:t.period===n.match.away?f:null;if(b!=null)return[b,1-b]}return null}function g(){let t=n.markets.filter(o=>o.scope!=="list"&&o.main&&(o.kind==="1x2"||o.kind==="12"));return t.find(o=>o.scope==="top")||t[0]||null}function v(t,o){let i=t.outcomes[o].label;return t.scope==="list"?!t.event||!t.main?i:t.kind==="1x2"?[t.event.home,"Ничья",t.event.away][o]||i:t.kind==="12"&&[t.event.home,t.event.away][o]||i:n.match?t.kind==="1x2"?[n.match.home,"Ничья",n.match.away][o]||i:t.kind==="12"&&[n.match.home,n.match.away][o]||i:i}function k(){let t=n.settings.overlay,o=[];for(let d of n.markets){if(d.outcomes.forEach((F,z)=>u.set(F.el,{market:d,index:z})),t==="off")continue;let f=m(d);if(f.kind==="partial")continue;let x=y(d),b=x||f.fair,M=0;for(let F=1;F<f.fair.length;F+=1)f.fair[F]>f.fair[M]&&(M=F);let _="accent";if(x){let F=0;for(let z=1;z<x.length;z+=1)x[z]-f.fair[z]>x[F]-f.fair[F]&&(F=z);x[F]-f.fair[F]>=.015&&(M=F,_="pos")}let S=d.scope!=="list"||d.main&&(d.kind==="1x2"||d.kind==="12");d.outcomes.forEach((F,z)=>{let j=z===M&&S;!j&&t!=="all"||o.push({el:F.el,frame:j,chip:yt(b[z]),tone:j?_:"quiet"})})}let i=T();if(i){let d=o.find(f=>f.el===i.item.el);d?d.selected=!0:o.push({el:i.item.el,frame:!1,selected:!0,chip:null})}c.set(o)}function T(){if(!n.selected)return null;let t=n.markets.find(i=>i.id===n.selected.id),o=t?.outcomes[n.selected.index];return o?.el?.isConnected?{market:t,item:o,index:n.selected.index}:null}function w(){if(n.settings.theme!=="auto")return n.settings.theme;for(let t of[document.body,document.documentElement]){let i=(t?getComputedStyle(t).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!i||i[4]==="0")continue;return(.2126*i[1]+.7152*i[2]+.0722*i[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}let A=0;function B(){clearTimeout(A),A=setTimeout(()=>wt({"lz.margins":n.margins}),1500)}function E(){if(n.pageType!=="match"||!n.match||n.match.live)return;n.margins=ue(n.margins);let t=I();t&&wn(n.margins,{key:n.match.key,book:r.id,margin:t.margin})&&B()}function C(){location.href!==n.url&&(n.url=location.href,n.selected=null,c.hideTip());let t="other",o=[],i=null;try{t=s.pageType(document,location),o=s.collect(document,location),i=s.readMatch(document,location)}catch(f){console.error("[Линза] страница не прочитана",f)}t!==n.pageType&&(n.pageType=t,n.tab!=="settings"&&n.tab!=="express"&&(n.tab=t==="match"?"match":"scan")),n.markets=o,n.match=i,E();let d=w();d!==n.theme&&(n.theme=d),c.setTheme(n.theme),l.setTheme(n.theme),k(),bt(),$(),l.isOpen&&(St(),Wt(),Zt(),_t(),l.render(Y()))}let V=new Set,L=null;function $(){if(s.observeTargets)for(let t of s.observeTargets(document))V.has(t)||(V.add(t),L=L||new MutationObserver(P),L.observe(t,{childList:!0,subtree:!0,characterData:!0}))}let N=0,O=0;function P(){let t=Date.now();O||(O=t),clearTimeout(N);let o=t-O>900?0:220;N=setTimeout(()=>{O=0,!document.hidden&&C()},o)}function I(){let t=g();if(!t)return null;let o=m(t);if(o.kind!=="full")return null;let i=y(t);return{title:"Что заложено в цене",margin:o.margin,rows:t.outcomes.map((d,f)=>({name:v(t,f),odd:d.odd,fair:o.fair[f],model:i?i[f]:null})),overtime:q()}}function q(){if(!["hockey","basketball"].includes(n.match?.sport))return null;let t=n.markets.find(i=>i.scope!=="list"&&i.outcomes.length===2&&/овертайм|булл|(^|[^а-яё])от([^а-яё]|$)|\bot\b/i.test(`${i.title} ${i.period}`)&&!/тотал|фора|будет|перв|втор|трет|период|тайм/i.test(`${i.title} ${i.period}`));if(!t)return null;let o=m(t);return o.kind!=="full"?null:{title:[t.title,t.period].filter(Boolean).join(" · "),rows:t.outcomes.map((i,d)=>({name:v(t,d)||[n.match.home,n.match.away][d],odd:i.odd,fair:o.fair[d]}))}}function G(){let t=T();if(!t)return null;let{market:o,item:i,index:d}=t,f=m(o),x=y(o),b=f.fair?f.fair[d]:null,M=o.event?`${o.event.home} — ${o.event.away}`:n.match?`${n.match.home} — ${n.match.away}`:"",_=n.match?n.compare.get(n.match.key):null,S=null;if(_?.rows?.length&&o.main&&(o.kind==="1x2"||o.kind==="12")&&o.scope!=="list")for(let z of _.rows){let j=z.odds[d];j&&(!S||j>S.odd)&&(S={name:z.name,odd:j,book:z.book||""})}S&&(S.partner=S.book&&S.book!==r.id&&n.partners.data?.[S.book]||null,S.gain=Math.round((S.odd-i.odd)*(n.settings.stake||1e3)));let F=`${o.id}#${d}`;return{market:[o.title,o.period,o.line].filter(Boolean).join(" · "),label:[v(o,d),M].filter(Boolean).join(" · "),odd:i.odd,fair:b,margin:f.margin,fairOdd:b?1/b:null,model:x?x[d]:null,ev:x?We(x[d],i.odd):null,best:S,canAdd:Number.isFinite(b)&&!n.express.some(z=>z.id===F),inExpress:n.express.some(z=>z.id===F),note:f.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":x?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function J(){let t=Mn(ue(n.margins),r.id);if(!t)return null;let o=t.best&&t.best.there<t.best.here?t.best:null,i=o&&gt().find(d=>d.name===o.name&&(d.url||d.code))||null;return{...t,best:o,partner:i}}function X(){let t=[];if(n.pageType==="match"?n.markets.forEach((f,x)=>{if(f.scope==="list")return;let b=m(f);if(b.kind!=="full")return;let M=0;for(let _=1;_<b.fair.length;_+=1)b.fair[_]>b.fair[M]&&(M=_);t.push({index:x,name:f.title,sub:[f.period,f.line].filter(Boolean).join(" · "),margin:b.margin,fav:f.outcomes[M].label,favPct:b.fair[M]})}):n.markets.forEach((f,x)=>{if(!f.event||!f.main||f.kind!=="1x2"&&f.kind!=="12")return;let b=m(f);if(b.kind!=="full")return;let M=0;for(let S=1;S<b.fair.length;S+=1)b.fair[S]>b.fair[M]&&(M=S);let _=f.kind==="1x2"?[f.event.home,"Ничья",f.event.away][M]:[f.event.home,f.event.away][M];t.push({index:x,name:`${f.event.home} — ${f.event.away}`,sub:f.event.league||f.event.time,margin:b.margin,fav:_,favPct:b.fair[M]})}),!t.length)return null;let o=new Set;for(let f=t.length-1;f>=0;f-=1){let x=`${t[f].name}|${t[f].sub}`;o.has(x)?t.splice(f,1):o.add(x)}let i=t.reduce((f,x)=>f+x.margin,0)/t.length;t.sort((f,x)=>f.margin-x.margin);let d=t.slice(0,16);return d.forEach(f=>{f.low=f.margin<=i*.8}),{title:n.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:n.pageType==="match"?"Рынок":"Матч",average:i,rows:d,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${d.length} из ${t.length}, сначала самые дешёвые.`}}function et(){let t=n.status;return t.ready?t.limit?`Разборов сегодня: ${t.used} из ${t.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function Y(){let t=n.match?.key,o=t&&n.analysis.get(t)||{status:"idle",steps:[]},i=t&&n.compare.get(t)||{status:"idle"},d=n.match?.live&&s.readEsportsWidget?s.readEsportsWidget(document):null,f=n.status;return{tab:n.tab,backTab:n.backTab,theme:n.theme,bookName:r.name,pageType:n.pageType,match:n.match?{...n.match,sportName:Re[n.match.sport]||""}:null,esports:d?{...d,homeName:n.match.home,awayName:n.match.away}:null,line:I(),analysis:{status:o.status,steps:o.steps||[],result:o.result||null,error:o.error||"",needKey:!!o.needKey},compare:i,consensus:t&&n.consensus.get(t)||null,model:t&&n.model.get(t)||null,live:ve(t),verdict:ge(t),facts:t&&n.facts.get(t)||null,pick:G(),scan:n.tab==="scan"?X():null,margins:n.tab==="scan"?J():null,edges:n.edges,bookId:r.id,partners:gt(),stake:Number(n.settings.stake)||1e3,express:{legs:n.express,stats:Ve(n.express)},quota:et(),update:n.status.update?{version:n.status.update,url:ee.site?`${ee.site}#install`:""}:null,whatsnew:n.whatsnew?{version:n.whatsnew.to,changes:Sn(n.whatsnew.from,n.whatsnew.to)}:null,settings:{overlay:n.settings.overlay,theme:n.settings.theme,stake:Number(n.settings.stake)||1e3,mode:f.mode,proxy:f.proxy,ready:f.ready,hasKey:f.hasKey,keyMask:f.keyMask,licenseMask:f.licenseMask,plan:f.plan==="free"||!f.plan?"":`Тариф «${{max:"Макс",vip:"VIP",api:"API"}[f.plan]||"Про"}»${f.until?` до ${f.until.split("-").reverse().join(".")}`:""}.`,usage:f.limit?`Сегодня разборов: ${f.used} из ${f.limit}.`:""}}}let nt=()=>{l.isOpen&&l.render(Y())};function ft(t){Object.assign(n.settings,t),wt({"lz.settings":n.settings}),C(),l.render(Y())}async function Mt(t=!1){if(!t&&Date.now()-n.partners.at<3600*1e3)return;n.partners.at=Date.now();let o=await tt("lz:partners",{force:t});o.ok&&o.data&&typeof o.data=="object"&&(n.partners.data=o.data,l.isOpen&&l.render(Y()),pt())}let gt=()=>Object.values(n.partners.data||{}).filter(t=>t&&t.id!==r.id);function pt(){if(!l.isOpen||n.tab!=="match"||!n.match)return;let t=gt().filter(o=>o.url||o.code).map(o=>o.id);t.length&&tt("lz:partner-seen",{ids:t,s:"panel"})}async function it(){n.edges={...n.edges,status:"loading",error:""};let t=await tt("lz:edges",{sport:n.match?.sport||""});n.edges=t.ok?{status:"done",data:t.data,error:"",at:Date.now()}:{status:"error",data:n.edges.data,error:t.error,at:Date.now()},nt()}async function lt(){let t=await tt("lz:status");t.ok&&(n.status=t.data),nt()}function Ot(){let t=g(),o=t?m(t):null;return{book:r.name,match:n.match,market:t&&o?.kind==="full"?{kind:t.kind,labels:t.outcomes.map((i,d)=>v(t,d)),odds:t.outcomes.map(i=>i.odd)}:null}}function Ct(){return n.markets.filter(t=>t.scope!=="list"&&t.main!==!1&&(t.kind==="total"||t.kind==="handicap")&&t.outcomes?.length===2).slice(0,40).map(t=>({kind:t.kind,title:t.title||"",period:t.period||"",line:t.line??"",outcomes:t.outcomes.map(o=>({label:o.label||"",odd:Number(o.odd)}))}))}function zt(){let t=n.match?.live&&s.readEsportsWidget?s.readEsportsWidget(document):null;return t?{home:t.home.map(o=>o.nick),away:t.away.map(o=>o.nick)}:null}function bt(){if(!n.match||!kt())return;let t=Ot();if(!t.market)return;let o=`${n.match.key}|${t.market.odds.join("/")}`;o!==bt.last&&(bt.last=o,tt("lz:quote",t))}async function St(){let t=n.match;if(!t||t.live||n.consensus.has(t.key))return;let o=Ot();if(!o.market?.odds?.length)return;n.consensus.set(t.key,null);let i=await tt("lz:consensus",{match:t,size:o.market.odds.length});n.consensus.set(t.key,i.ok&&i.data?.consensus?i.data:null),n.match?.key===t.key&&l.isOpen&&l.render(Y())}async function _t(){let t=n.match;if(!t?.live||!["basketball","football","hockey","tennis"].includes(t.sport))return;let o=n.live.get(t.key);if(o&&(o.pending||Date.now()-o.at<3e4))return;n.live.set(t.key,{...o||{},pending:!0});let i=await tt("lz:live",{match:t});n.live.set(t.key,{at:Date.now(),data:i.ok&&i.data&&!i.data.error?i.data:null,error:i.ok?i.data?.error||"":i.error||""}),n.match?.key===t.key&&l.isOpen&&l.render(Y())}function fe(t,o){n.fonbetRef.set(t,null),tt("lz:fonbet-ref",{match:o}).then(i=>{n.fonbetRef.set(t,i.ok&&i.data?.odds?i.data:null),i.ok&&i.data?.odds&&n.match?.key===t&&l.isOpen&&l.render(Y())}).catch(()=>{})}function he(t,o,i){let d=n.match,f=`${t}|${[o.best,o.suspect,...o.others].filter(Boolean).map(b=>`${b.label}:${b.odd}`).join(",")}`;if(n.verdictSent===f)return;n.verdictSent=f;let x=[o.best,o.suspect,...o.others].filter(Boolean).map(b=>({label:b.label,odd:b.odd,p:b.p,kind:b.kind||"win",side:b.side||"",line:b.line??null,source:b.source||i,unit:b.unit||""}));tt("lz:verdict",{payload:{sport:d.sport,league:d.league||"",home:d.home,away:d.away,book:r.name,source:i,best:o.best?.label||"",options:x}}).then(b=>{b?.ok&&b.data?.track&&b.data.track!==n.verdictTrack&&(n.verdictTrack=b.data.track,l.isOpen&&l.render(Y()))}).catch(()=>{})}function ge(t){let o=n.match,i=t&&I();if(!o||!i||o.live)return null;let d=n.consensus.get(t),f=i.rows,x=n.model.get(t),b=x&&Cn(x,f.map(R=>R.odd)).ok?x:null,M=b&&En(o.sport)?b:null,_=n.analysis.get(t)?.result,S=[o.home,o.away],F=[],z="";if(d?.consensus?.length===f.length)f.forEach((R,Q)=>F.push({label:R.name,odd:R.odd,p:d.consensus[Q],side:f.length===3?["home","draw","away"][Q]:["home","away"][Q]})),z=`консенсус ${d.count} контор`;else if(!d?.consensus&&M?.sport==="hockey"&&M.regulation&&f.length===3){let R=[M.regulation.p1,M.regulation.px,M.regulation.p2];f.forEach((Q,at)=>F.push({label:Q.name,odd:Q.odd,p:R[at],side:["home","draw","away"][at]})),z="модель Линзы"}else{let R=f.length===2?f:o.sport==="mma"&&f.length===3?[f[0],f[2]]:i.overtime?.rows||null,Q=d?.consensus?.length===2?d.consensus:M?.p1?[M.p1,M.p2]:null;R&&Q&&(R.forEach((at,rt)=>F.push({label:S[rt],odd:at.odd,p:Q[rt],side:["home","away"][rt]})),z=d?.consensus?.length===2?`консенсус ${d.count} контор`:"модель Линзы")}let j=M?.sport==="mma"?M.durations:null;if(j)for(let R of n.markets){if(R.scope==="list"||R.kind!=="total"||R.outcomes.length!==2)continue;let Q=String(R.line||"").replace(",","."),at=Q==="1.5"?j.r1+j.r2/2:Q==="2.5"&&j.rounds===3?j.r1+j.r2+j.r3/2:null,rt=Vt(R.outcomes.map(ht=>ht.label));at==null||rt<0||F.some(ht=>ht.kind==="total"&&ht.line===Q)||(F.push({label:`Больше ${Q} раунда`,odd:R.outcomes[rt].odd,p:1-at,kind:"total",line:Q}),F.push({label:`Меньше ${Q} раунда`,odd:R.outcomes[1-rt].odd,p:at,kind:"total",line:Q}))}if(M?.sport==="basketball"&&M.lines){let R=Rt=>{let dt=String(Rt||"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?[0-9]+(?:[.][0-9]+)?/);return dt?Number(dt[0]):NaN},Q=Rt=>n.markets.filter(dt=>dt.scope!=="list"&&dt.main&&dt.kind===Rt&&dt.outcomes.length===2&&dt.outcomes.every(te=>te.odd>1)).sort((dt,te)=>Math.abs(dt.outcomes[0].odd-dt.outcomes[1].odd)-Math.abs(te.outcomes[0].odd-te.outcomes[1].odd))[0]||null,at=Q("handicap"),rt=Q("total"),ht=at?R(at.outcomes[0].label):NaN;at&&!Number.isFinite(ht)&&(ht=R(at.line));let Qt=rt?R(rt.line):NaN;rt&&!Number.isFinite(Qt)&&(Qt=R(rt.outcomes[0].label));let we=rt?Vt(rt.outcomes.map(Rt=>Rt.label)):-1;F.push(...Fn(M,{handicap:at&&Number.isFinite(ht)?{line:ht,home:at.outcomes[0].odd,away:at.outcomes[1].odd}:null,total:rt&&we>=0&&Number.isFinite(Qt)?{line:Qt,over:rt.outcomes[we].odd,under:rt.outcomes[1-we].odd}:null},S))}let U=n.markets.filter(R=>R.scope!=="list"),Z=f.length===2?vt(f.map(R=>R.odd)):null;Z?.fair&&["tennis","cs","dota"].includes(o.sport)&&F.push(...Be({sport:o.sport,p:Z.fair[0],source:"цена конторы на победу",markets:U,names:S,league:o.league||""}));let ot=b?.p1&&["tennis","cs","dota"].includes(o.sport)?In({sport:o.sport,model:b,markets:U,names:S,league:o.league||""}):[];if((o.sport==="football"||o.sport==="hockey")&&r.id!=="fonbet"){let R=n.fonbetRef.get(t);R===void 0?fe(t,o):R&&F.push(...On(R,n.markets.filter(Q=>Q.scope!=="list"),o.sport,S))}if(!F.length)return b?.p1?{best:null,suspect:null,others:[],lines:[Ee(b,S),"Это расчёт, а не обещание: проиграть можно и при перевесе в цене. 18+"],track:n.verdictTrack||""}:null;let ct=[...F].filter(R=>R.p*R.odd-1>=.03&&R.p*R.odd-1<=.12).sort((R,Q)=>Q.p*Q.odd-R.p*R.odd)[0]?.side,jt=(_?.factors||[]).filter(R=>ct&&R.side===ct).slice(0,2).map(R=>R.text),ut=_n(F,{source:z,reasons:jt,risk:_?.risks?.[0]||""});return ut&&b?.p1&&!M&&ut.lines.splice(ut.lines.length-1,0,Ee(b,S)),ut&&ot.length&&ut.lines.splice(ut.lines.length-1,0,`По модели Линзы интересная цена от: ${ot.slice(0,6).map(R=>`${R.label} — ${R.from.toFixed(2)}${R.odd>=R.from?" ✓ здесь выше":""}`).join(" · ")}.`),ut&&he(t,ut,z),ut&&{...ut,track:n.verdictTrack||""}}function be(t,o,i){let d=(M,_)=>o?[_,M]:[M,_],x=I()?.rows||[],b=x.length===2&&x.every(M=>Number.isFinite(M.fair))?x.map(M=>M.fair):null;return{kind:"tennis",names:[n.match.home,n.match.away],score:d(t.score[0],t.score[1]),sets:t.sets.map(([M,_])=>d(M,_)),games:d(t.games[0],t.games[1]),points:d(t.points[0],t.points[1]),tiebreak:t.tiebreak,serving:t.aServes==null?null:t.aServes!==o?0:1,bestOf:t.bestOf,prior:t.prior,serve:d(t.serve.a,t.serve.b),probs:d(t.p1,t.p2),set:d(t.set.p1,1-t.set.p1),game:d(t.game.p1,1-t.game.p1),book:b,compare:t.prior.source==="line"||t.prior.source==="model",at:i}}function xe(t,o,i){let d=(_,S)=>o?[S,_]:[_,S],f=_=>o?[_[2],_[1],_[0]]:_,b=I()?.rows||[],M=b.length===3&&b.every(_=>Number.isFinite(_.fair))?b.map(_=>_.fair):null;return{kind:"goals",sport:t.sport,names:[n.match.home,n.match.away],score:d(t.score[0],t.score[1]),red:d(t.red[0],t.red[1]),minute:t.minute,period:t.period,periods:t.periods,clock:t.clock,prior:t.prior,probs:f([t.p1,t.px,t.p2]),book:M,compare:t.prior.source==="line",expTotal:t.expTotal,nextGoal:f([t.nextGoal.home,t.nextGoal.none,t.nextGoal.away]),total:t.tables.total,handicap:t.tables.handicap.map(_=>o?{line:-_.line,home:_.away,away:_.home}:_).sort((_,S)=>_.line-S.line),bookLines:t.bookLines,at:i}}function ve(t){let o=t&&n.live.get(t);if(!o?.data)return o?.error?{error:o.error}:null;let i=o.data,d=!!i.flipped;if(i.kind==="goals")return xe(i,d,o.at);if(i.kind==="tennis")return be(i,d,o.at);let f=(S,F)=>d?[F,S]:[S,F],x=I(),b=x?.overtime?.rows||x?.rows||[],M=b.length===2?b.map(S=>S.fair):b.length===3&&b.every(S=>Number.isFinite(S.fair))?[b[0].fair+b[1].fair/2,b[2].fair+b[1].fair/2]:null,_=i.tables||{};return{names:[n.match.home,n.match.away],score:f(i.score[0],i.score[1]),periods:(i.periods||[]).map(([S,F])=>f(S,F)),period:i.period,elapsed:i.elapsed,left:i.left,clock:i.clock,format:i.format,probs:f(i.p1,i.p2),book:M,prior:i.prior,expMargin:d?-i.expMargin:i.expMargin,sd:i.sd,projTotal:i.projTotal,sdTotal:i.sdTotal,handicap:(_.handicap||[]).map(S=>d?{line:-S.line,home:S.away,away:S.home}:S).sort((S,F)=>S.line-F.line),total:_.total||[],quarterTotal:_.quarterTotal||[],bookLines:i.bookLines?{handicap:i.bookLines.handicap?d?{...i.bookLines.handicap,line:-i.bookLines.handicap.line,odds:[...i.bookLines.handicap.odds].reverse(),fair:[...i.bookLines.handicap.fair].reverse(),p:1-i.bookLines.handicap.p,book:1-i.bookLines.handicap.book,gap:-i.bookLines.handicap.gap}:i.bookLines.handicap:null,total:i.bookLines.total||null}:null,quarter:i.quarter?{...i.quarter,score:f(i.quarter.score[0],i.quarter.score[1]),expMargin:d?-i.quarter.expMargin:i.quarter.expMargin,probs:f(i.quarter.p1,i.quarter.p2)}:null,at:o.at}}async function Wt(){let t=n.match;if(!t||!["cs","dota","tennis","basketball","mma","hockey"].includes(t.sport)||n.model.has(t.key)||t.live&&(t.sport==="tennis"||t.sport==="basketball"||t.sport==="mma"||t.sport==="hockey"))return;n.model.set(t.key,null);let o=await tt("lz:model",{match:t});n.model.set(t.key,o.ok&&o.data?.p1?o.data:null),n.match?.key===t.key&&l.isOpen&&l.render(Y())}let Kt=new Map;async function Zt(){let t=n.match;if(!t||!["football","hockey","basketball","cs","dota"].includes(t.sport))return;let o=t.live&&Date.now()-(Kt.get(t.key)||0)>60*1e3;if(n.facts.has(t.key)&&!o)return;let i=n.facts.get(t.key)||null;Kt.set(t.key,Date.now()),n.facts.set(t.key,i);let d=await tt("lz:facts",{match:t});n.facts.set(t.key,d.ok&&d.data?.facts?.length?d.data:i),n.match?.key===t.key&&l.isOpen&&l.render(Y())}async function ye(){let t=n.match;if(!t||n.analysis.has(t.key))return;let o=await tt("lz:cached",{match:t});!o.ok||!o.data||n.analysis.has(t.key)||(n.analysis.set(t.key,{status:"done",steps:[],result:o.data}),C(),nt())}function ke(){return{opened(){lt(),C(),ye(),St(),Wt(),Zt(),_t(),Mt(),l.render(Y()),pt()},tab(t){t==="settings"&&(n.backTab=n.tab==="settings"?n.backTab:n.tab),n.tab=t||"match",t==="edges"&&n.edges.status!=="loading"&&Date.now()-n.edges.at>300*1e3&&it(),l.render(Y())},"edges-refresh"(){it(),l.render(Y())},theme(){ft({theme:n.theme==="dark"?"light":"dark"})},"overlay-toggle"(){ft({overlay:n.settings.overlay==="off"?"picks":"off"})},"set-overlay"(t){ft({overlay:t})},"set-theme"(t){ft({theme:t})},async"set-mode"(t){await tt("lz:settings",{mode:t}),lt()},"copy-code"(t){if(!t)return;let o=()=>l.toast("Промокод скопирован");navigator.clipboard?.writeText?navigator.clipboard.writeText(t).then(o,()=>l.toast(`Промокод: ${t}`)):l.toast(`Промокод: ${t}`)},"set-stake"(t,o,i){let d=Math.round(Number(i.getElementById("lz-stake")?.value));if(!Number.isFinite(d)||d<10||d>1e7)return l.toast("Введите сумму от 10 ₽");ft({stake:d}),l.toast("Сумма сохранена")},async"save-key"(t,o,i){let d=i.getElementById("lz-key"),f=(d?.value||"").trim();if(f.length<8)return l.toast("Вставьте ключ целиком");let x=await tt("lz:settings",{apiKey:f});l.toast(x.ok?"Ключ сохранён":x.error),d&&(d.value=""),lt()},async"clear-key"(){await tt("lz:settings",{apiKey:""}),l.toast("Ключ удалён"),lt()},async"save-license"(t,o,i){let d=i.getElementById("lz-license"),f=(d?.value||"").trim();if(f.length<6)return l.toast("Вставьте ключ целиком");let x=await tt("lz:settings",{licenseKey:f});l.toast(x.ok?"Ключ принят":x.error),d&&(d.value=""),lt()},async"clear-license"(){await tt("lz:settings",{licenseKey:""}),l.toast("Ключ удалён"),lt()},savePosition(t,o){n.positions[t]=o,Le(["lz.positions"]).then(i=>{let d=i["lz.positions"]||{};d[location.hostname]=n.positions,wt({"lz.positions":d})})},async analyze(){if(!n.match)return;let t=n.match.key,o={status:"loading",steps:[`${n.match.home} — ${n.match.away}`]};n.analysis.set(t,o),nt();let i=await tt("lz:analyze",{...Ot(),markets:Ct(),players:zt(),force:!0}),d=i.ok?i.data?.job:"",f=Date.now();for(;d&&i.ok&&i.data?.status==="running"&&Date.now()-f<420*1e3;){if(o.steps=[o.steps[0],...(i.data.steps||[]).map(x=>x.text)].slice(-8),nt(),await new Promise(x=>setTimeout(x,2e3)),n.analysis.get(t)!==o)return;i=await tt("lz:job",{job:d}),!i.ok&&i.code==="retry"&&(i=await tt("lz:job",{job:d}))}if(i.ok&&d){let x=i.data?.steps?.length?[o.steps[0],...i.data.steps.map(b=>b.text)].slice(-8):o.steps;i.data.status==="done"?n.analysis.set(t,{status:"done",steps:x,result:{...i.data.result,full:i.data.full||null}}):i.data.status==="error"?n.analysis.set(t,{status:"error",steps:x,error:i.data.error}):n.analysis.set(t,{status:"error",steps:x,error:"Разбор идёт дольше 7 минут. Нажмите ещё раз — собранное уже на сервере, второй раз будет быстрее."})}else i.ok?n.analysis.set(t,{status:"done",steps:o.steps,result:i.data}):n.analysis.set(t,{status:"error",steps:o.steps,error:i.error,needKey:i.code==="no-access"});lt(),C(),l.render(Y())},async report(){let t=n.match?n.analysis.get(n.match.key):null,o="";try{o=chrome.runtime.getManifest().version}catch{}let i=await tt("lz:report",{where:"panel",url:location.href,book:r.name,version:o,match:n.match?`${n.match.home} — ${n.match.away}`:"",step:t?.steps?.slice(-1)[0]||"",error:t?.error||(t?.status==="done"?"разбор выглядит неправильно":"страница матча не узнана")});l.toast(i.ok?"Спасибо! Сообщение ушло разработчику.":i.error)},async compare(){if(!n.match)return;let t=n.match.key;n.compare.set(t,{status:"loading"}),nt();let o=await tt("lz:compare",Ot());n.compare.set(t,o.ok?{status:"done",...o.data}:{status:"done",rows:[],labels:[],note:o.error}),o.ok&&$n(n.margins,t,o.data.rows)&&B(),nt()},"whatsnew-ok"(){n.whatsnew=null,wt({"lz.whatsnew":null}),nt()},"pick-clear"(){n.selected=null,k(),nt()},"leg-add"(){let t=G(),o=T();!t?.canAdd||!o||(n.express.push({id:`${o.market.id}#${o.index}`,title:t.market,label:t.label,odd:t.odd,fair:t.fair,at:Date.now()}),wt({"lz.express":n.express}),l.toast("Добавлено в расчёт экспресса"),nt())},"leg-remove"(t){n.express=n.express.filter(o=>o.id!==t),wt({"lz.express":n.express}),nt()},"leg-clear"(){n.express=[],wt({"lz.express":n.express}),nt()},"scan-go"(t){let o=n.markets[Number(t)],i=o?.outcomes[0]?.el;i?.isConnected&&(i.scrollIntoView({behavior:"smooth",block:"center"}),n.selected={id:o.id,index:0},setTimeout(k,400))}}}function Ht(t){let o=t.composedPath();for(let i=0;i<Math.min(o.length,6);i+=1){let d=o[i]instanceof Element?u.get(o[i]):null;if(d&&d.market.outcomes[d.index]?.el===o[i])return d}return null}let Et=new Map;function Xt(t){if(!t.event||!t.main||!["1x2","12"].includes(t.kind)||t.scope!=="list"||t.event.live)return console.debug("[lz] рынок для списка не запрашивается:",JSON.stringify({event:!!t.event,main:t.main,kind:t.kind,scope:t.scope,live:t.event?.live})),null;let o=t.event.key;if(Et.has(o))return Et.get(o);let i={home:t.event.home,away:t.event.away,sport:Pt(t),league:t.event.league||""},d=tt("lz:consensus",{match:i,size:t.outcomes.length}).then(f=>((!f.ok||!f.data?.consensus)&&console.debug("[lz] рынок для списка:",f.error||f.data?.error||"нет данных"),f.ok&&f.data?.consensus?f.data:null)).catch(f=>(console.debug("[lz] рынок для списка:",String(f?.message||f)),null));return Et.set(o,d),d.then(f=>Et.set(o,f)),d}let Pt=t=>t.event?.sport||n.match?.sport||Bt(location.pathname,document.title,t.event?.league);function Dt({market:t,index:o},i=null){let d=m(t),f=y(t),x=t.event?`${t.event.home} — ${t.event.away}`:"",b=t.outcomes.map((S,F)=>{let z=d.fair?d.fair[F]:1/S.odd;return e(`div.tip-row${F===o?".hot":""}`,{},e("span",{text:v(t,F)}),e("span.odd",{text:K(S.odd)}),e("span.pct",{text:yt(z,z<.1?1:0)}),e("span.tip-bar",{},e("i",{style:`width:${Math.round(z*100)}%`})))}),M=d.kind==="partial"?e("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):e("div.tip-foot",{},"Маржа конторы ",e("b",{text:yt(d.margin,1)}),f?e("span",{}," · модель: ",e("b",{text:yt(f[o],1)})):null),_=null;if(i?.consensus){let S=i.consensus.length===t.outcomes.length,F=!S&&i.consensus.length===2&&t.outcomes.length===3;if(S||F){let z=S?i.consensus[o]:null,j=z?t.outcomes[o].odd*z-1:0;_=e("div.tip-foot",{},`Рынок, ${i.count} контор${F?", с овертаймом":""}: `,e("b",{text:i.consensus.map(U=>yt(U,0)).join(" / ")}),j>.005?e("span.pos",{text:` · кэф выше рынка на ${(j*100).toFixed(1)}%`}):null)}}else i===void 0&&(_=e("div.tip-foot",{text:"Рынок: сверяю…"}));return e("div",{},e("div.tip-title",{text:[t.title,t.period,t.line].filter(Boolean).join(" · ")}),x?e("div.tip-sub",{text:x}):e("div.tip-sub",{text:"Шанс по линии без маржи"}),b.slice(0,8),M,_)}let Yt=0,Nt=null;me.on("page:pointerover",t=>{if(n.settings.overlay==="off")return;let o=Ht(t),i=o?o.market.outcomes[o.index].el:null;if(i!==Nt){if(Nt=i,clearTimeout(Yt),!o)return c.hideTip();Yt=setTimeout(()=>{if(Nt!==i||!i.isConnected)return;c.setAvoid(l.rect());let d=Xt(o.market);c.showTip(i,Dt(o,d instanceof Promise?void 0:d)),d instanceof Promise&&d.then(f=>{Nt===i&&i.isConnected&&c.showTip(i,Dt(o,f))})},280)}}),me.on("page:click",t=>{let o=Ht(t);o&&(n.selected={id:o.market.id,index:o.index},n.tab==="scan"&&(n.tab="match"),k(),nt())}),yn(t=>{if(t.type!=="lz:progress")return;let o=n.analysis.get(t.key);!o||o.status!=="loading"||(o.steps=[...o.steps,t.text].slice(-7),nt())});let Jt=()=>{C(),new MutationObserver(P).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||C()}),setInterval(()=>{!document.hidden&&location.href!==n.url&&C()},600),setInterval(()=>{!document.hidden&&l.isOpen&&P()},4e3),kt()&&chrome.storage.onChanged.addListener(t=>{t["lz.settings"]&&(n.settings={...$e,...t["lz.settings"].newValue||{}},C())}),lt()};document.body?Jt():document.addEventListener("DOMContentLoaded",Jt,{once:!0}),document.documentElement.setAttribute("data-lz",r.id),globalThis.__lz={state:n,view:Y,refresh:C,overlay:c,panel:l}}function Xo(s){let r=Date.now()-432e5;return(Array.isArray(s)?s:[]).filter(a=>a&&a.at>r&&a.odd>1)}})();
