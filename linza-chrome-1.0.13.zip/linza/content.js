(()=>{var Yt=o=>typeof o=="string"?o:"",Qt={name:"Линза",tagline:"Видно, что заложено в коэффициенте",site:Yt("https://efremen512218-lang.github.io/linza/"),telegram:Yt("https://t.me/linza_odds"),bot:Yt("https://t.me/linza_keys_bot?start=ext")},Go=Yt("https://185-72-145-3.sslip.io"),En={url:"https://clodex.xyz/v1/chat/completions",model:"gpt-6-astra",fallback:["gpt-6.1-sol","glm-5.3"],timeoutMs:9e4};var jn=[{id:"winline",name:"Winline",hosts:["winline.ru"],url:"https://winline.ru"},{id:"fonbet",name:"Fonbet",hosts:["fon.bet"],url:"https://fon.bet"},{id:"pari",name:"PARI",hosts:["pari.ru"],url:"https://pari.ru"},{id:"betboom",name:"BetBoom",hosts:["betboom.ru"],url:"https://betboom.ru"},{id:"liga",name:"Лига Ставок",hosts:["ligastavok.ru"],url:"https://www.ligastavok.ru"},{id:"betcity",name:"Бетсити",hosts:["betcity.ru"],url:"https://betcity.ru"},{id:"leon",name:"Leon",hosts:["leon.ru"],url:"https://leon.ru"},{id:"melbet",name:"Мелбет",hosts:["melbet.ru"],url:"https://melbet.ru"},{id:"olimp",name:"Олимп",hosts:["olimp.bet"],url:"https://www.olimp.bet"},{id:"marathon",name:"Марафон",hosts:["marathonbet.ru"],url:"https://www.marathonbet.ru"}];function Ee(o){let r=String(o||"").toLowerCase();return jn.find(a=>a.hosts.some(n=>r===n||r.endsWith(`.${n}`)))||null}var ve={overlay:"picks",theme:"auto",mode:"own",model:En.model,stake:1e3},je={football:"Футбол",tennis:"Теннис",basketball:"Баскетбол",hockey:"Хоккей",volleyball:"Волейбол",mma:"ММА",cs:"Counter-Strike",dota:"Dota 2",valorant:"Valorant",esports:"Киберспорт"};function vt(o){let r=String(o??"").replace(/[ \s]+/g,"");if(!/^\d{1,4}([.,]\d{1,3})?$/.test(r))return null;let a=parseFloat(r.replace(",","."));return a>=1.001&&a<=1e3?a:null}var Pe=o=>o.reduce((r,a)=>r+1/a,0);function yt(o){let r=(o||[]).filter(n=>Number.isFinite(n)&&n>1);if(r.length<2||r.length!==(o||[]).length)return{kind:"partial",margin:null,fair:null};let a=Pe(r);if(a>=.985&&a<=1.3)return{kind:"full",margin:a-1,fair:r.map(n=>1/n/a)};if(r.length===3&&a>=1.97&&a<=2.4){let n=a/2;return{kind:"double",margin:n-1,fair:r.map(p=>Math.min(.995,1/p/n))}}return{kind:"partial",margin:null,fair:null}}function Be(o){let r=(o||[]).map(m=>m||[]).filter(m=>m.length),a=r.flat().filter(Boolean);if(a.length<2)return{sets:[],rest:a};let n=m=>m.length>=2&&m.every(Boolean)&&yt(m.map(h=>h.odd)).kind!=="partial",p=m=>{let h=m.filter(g=>g.some(Boolean));if(!h.length)return null;let k=h.filter(n);if(k.length/h.length<.6)return null;let x=new Set(k.flat());return{sets:k,rest:a.filter(g=>!x.has(g))}},d=m=>{let h=[];for(let k=0;k<r.length;k+=m)h.push(r.slice(k,k+m).flat());return h},u=()=>{let m=[];for(let h=0;h+1<r.length;h+=2){let k=Math.max(r[h].length,r[h+1].length);for(let x=0;x<k;x+=1)m.push([r[h][x]??null,r[h+1][x]??null])}return m},c=[()=>d(1)];r.length>=2&&r.length%2===0&&c.push(u,()=>d(2)),r.length>=3&&r.length%3===0&&c.push(()=>d(3)),r.length>1&&c.push(()=>[r.flat()]);for(let m of c){let h=p(m());if(h)return h}return{sets:[],rest:a}}function Ie(o,r=1.13){let a=c=>{let m=Pe(c.map(h=>h.odd));return m>=.995&&m<=r?!0:c.length===3&&m>=1.99&&m<=r*2},n=c=>Math.abs(c*4-Math.round(c*4))<1e-9,p=[],d=[],u=0;for(;u<o.length;){let c=o.slice(u,u+3),m=o.slice(u,u+2);c.length===3&&a(c)?(p.push(c),u+=3):m.length===2&&a(m)?(p.push(m),u+=2):o[u+2]&&n(o[u+1].odd)&&a([o[u],o[u+2]])?(p.push([o[u],o[u+2]]),d.push(o[u+1]),u+=3):(d.push(o[u]),u+=1)}return{sets:p,rest:d}}function qe(o){let r=(o||[]).filter(p=>p&&p.odd>1&&p.fair>0&&p.fair<1);if(!r.length)return null;let a=r.reduce((p,d)=>p*d.odd,1),n=r.reduce((p,d)=>p*d.fair,1);return{legs:r.length,odd:a,chance:n,fairOdd:1/n,margin:1-a*n}}function Re(o,r){return o*r-1}function X(o){return Number.isFinite(o)?o>=100?o.toFixed(0):o>=10?o.toFixed(1):o.toFixed(2):"—"}function kt(o,r=0){if(!Number.isFinite(o))return"—";let a=o*100;return a>0&&a<1&&r===0?"<1%":`${a.toFixed(r)}%`}function ye(o){return String(o??"").toLowerCase().replace(/ё/g,"е").replace(/\([^)]*\)/g," ").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zа-я0-9]/g,"")}var Pn=new Set(["fc","cf","sc","fk","afc","club","team","esports","gaming","clan","фк","ск"]);function De(o){return String(o??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[\u0300-\u036f]/g,"").split(/[^a-zа-я0-9]+/).filter(r=>r.length>=2&&!Pn.has(r))}function Rt(o,r){let a=ye(o),n=ye(r);if(a.length<2||n.length<2)return 0;if(a===n)return 1;let p=a.length<=n.length?a:n,d=p===a?n:a;if(p.length>=4&&d.includes(p))return .85;let u=De(o),c=De(r),m=k=>String(k??"").toLowerCase().replace(/ё/g,"е").normalize("NFD").replace(/[̀-ͯ]/g,"").match(/^\s*([a-zа-я-]{3,})\s+([a-zа-я])\.?\s*$/);for(let[k,x]of[[o,c],[r,u]]){let g=m(k);if(g&&x.length>=2&&x.includes(g[1])&&x.some(y=>y!==g[1]&&y[0]===g[2]))return .8}if(u.length&&c.length){let x=u.filter(g=>c.some(y=>y===g||g.length>=5&&y.startsWith(g.slice(0,5)))).length/Math.max(u.length,c.length);if(x>=.5)return .6+.3*x}let h=0;for(;h<a.length&&h<n.length&&a[h]===n[h];)h+=1;return h>=5?Math.min(.8,.45+h*.04):0}function Bn(o){let r=String(o??"").toLowerCase(),a=[];return/\bu-?\s?\d{2}\b|до\s?\d{2}|\(\d{2}\)|молод/.test(r)&&a.push("youth"),/\(ж\)|\(жен|женщин|\(w\)|women/.test(r)&&a.push("women"),/\(рез|\(р\)|резерв|reserve/.test(r)&&a.push("reserve"),/люб/.test(r)&&a.push("amateur"),/кибер|esport|\d\s?[xх]\s?\d|\((?!u-?\s?\d{2}\))[a-z][a-z0-9_ .-]{2,}\)/.test(r)&&a.push("cyber"),a.join("+")}function Nt(o,r){let a=d=>{let u=ye(d),c=Bn(d);return u.length<2?"":c?`${u}~${c}`:u},n=a(o),p=a(r);return!n||!p?"":[n,p].sort().join("|")}var D=o=>(o?.textContent||"").replace(/[ \s]+/g," ").trim(),ke=o=>o.offsetParent===null&&o.tagName!=="BODY";function In(o){return/^(|матч|основное время|осн\.?\s*время)$/i.test(String(o||"").trim())}function qn(o){let r=String(o||"").match(/(\d+)\s*[-‑–]?\s*(?:го|й|м|ой|ий|я|ая|ья|ый)?\s+(период|тайм|сет|четверт|половин|карт|гейм|иннинг)/i);return r?r[0]:""}function Dt(o,r){let a=String(o||"").toLowerCase();return/двойной шанс/.test(a)?"dc":/[+и]\s*(тотал|обе)|\/|комбо/.test(a)?"other":/фор[аы]|гандикап/.test(a)?"handicap":/тотал/.test(a)?"total":/обе забьют/.test(a)?"btts":/исход|1x2|1х2|победитель|победа в матче/.test(a)?r===3?"1x2":r===2?"12":"other":"other"}var Rn=[[/футбол|soccer|football/i,"football"],[/теннис|tennis/i,"tennis"],[/баскетбол|basketball/i,"basketball"],[/хоккей|hockey/i,"hockey"],[/(^|[^а-яёa-z])(мма|mma|ufc|юфс)([^а-яёa-z]|$)|смешанн|единоборств|mixed martial|бои без правил/i,"mma"],[/волейбол|volleyball/i,"volleyball"],[/counter-?strike|\bcs2?\b/i,"cs"],[/dota/i,"dota"],[/valorant/i,"valorant"],[/киберспорт|esports?/i,"esports"]];function jt(...o){let r=o.filter(Boolean).join(" ");for(let[a,n]of Rn)if(a.test(r))return n;return""}function we(o){if(!o)return null;let r=vt(D(o));if(r)return r;let a=D(o).split(" ");return vt(a[a.length-1])}var Dn=0;function Ft({scope:o,title:r,period:a="",line:n="",kind:p,outcomes:d,event:u=null,anchor:c=null,eventKey:m=""}){let h=d.length;return{id:`${o}|${m}|${r}|${a}|${n}|${d.map(k=>k.label).join("/")}`,serial:Dn+=1,scope:o,title:r,period:a,line:n,kind:p||Dt(r,h),main:In(a)&&!qn(r),outcomes:d,event:u,anchor:c||d[0]?.el||null}}var Y=(o,r)=>[...o.querySelectorAll(r)];function Ke(o){return(String(o||"").match(/(\d{6,})(?:\/)?(?:[?#].*)?$/)||[])[1]||""}function $e(o){return o.querySelector("ww-feature-marketbook-dsk, .ww-markets")?"match":o.querySelector(".card")?"list":"other"}var Ge={win:"В",loose:"П",lose:"П",draw:"Н"};function Ve(o){return Y(o,".competitor-form__value").map(r=>Ge[[...r.classList].find(a=>Ge[a])]||D(r).slice(0,1)).filter(Boolean).join("")}function Gn(o){let r=o.querySelector(".marketbook-header--live");if(r){let n=Y(r,".game-scoring__item").map(u=>D(u)),p=Y(r,".game-periods .period").map(u=>{let c=Y(u,"span");return{label:D(u.querySelector("i")),home:D(c[0]),away:D(c[1])}}).filter(u=>u.home!==""&&u.away!==""),d=Y(r,".game-specials > div").map(u=>{let c=Y(u,"span"),m=u.querySelector("i"),h=m?.classList.contains("yellow-card")?"жёлтые":m?.classList.contains("red-card")?"красные":m?.classList.contains("penalty-card")?"угловые":"";return h?{kind:h,home:D(c[0]),away:D(c[1])}:null}).filter(Boolean);return{state:D(r.querySelector(".game-timing-state")),score:n.length===2?n:[],periods:p,extras:d}}let a=o.querySelector(".match-card");if(a&&!a.querySelector(".match-card__timer--prematch")){let n=D(a.querySelector(".match-card__main-score")).replace(/\s/g,""),p=Y(a,".match-card__score").map(u=>D(u)).filter(u=>/^\d{1,2}$/.test(u)),d=Y(o,'.maps .map, .maps [class*="map-item"], .maps > div > div').map(u=>D(u)).filter(u=>/\d\s*:\s*\d/.test(u)).slice(0,5);return{state:D(a.querySelector(".match-card__timer")),score:/^\d+:\d+$/.test(n)?n.split(":"):[],rounds:p.length>=2?p.slice(0,2):[],periods:d.map((u,c)=>({label:`${c+1} карта`,raw:u})),extras:[]}}return null}function Ue(o,r){if($e(o)!=="match")return null;let a=Y(o,".breadcrumbs .breadcrumbs__item").map(h=>D(h)).filter(Boolean),n=D(o.querySelector(".event-breadcrumbs")),p=Y(o,".marketbook-header--prematch .competitor-name").map(h=>D(h));if(p.length<2&&(p=Y(o,".marketbook-header--live .competitors-desc__name").map(h=>D(h))),p.length<2&&(p=Y(o,".match-card .match-card__team-name").map(h=>D(h))),p.length<2||!p[0]||!p[1])return null;let d=jt(a[1]&&/киберспорт/i.test(a[0])?a[1]:"",a[0],n),u=/киберспорт/i.test(a[0]||"")?a.slice(2).join(", ")||n.split(",").slice(1).join(",").trim():a.slice(1).join(", "),c=[D(o.querySelector(".prematch-date")),D(o.querySelector(".prematch-time"))].filter(Boolean).join(" ")||D(o.querySelector(".match-card__timer--prematch")).replace(/\s*:\s*/,":"),m=Gn(o);return{book:"Winline",id:Ke(r?.pathname),key:Nt(p[0],p[1]),home:p[0],away:p[1],sport:d,league:u,start:m?"":c,live:m,form:{home:Ve(o.querySelector(".competitor-form--left")||o.createElement("div")),away:Ve(o.querySelector(".competitor-form--right")||o.createElement("div"))},stats:Hn(Xn(o),p[0],p[1]),url:r?.href||""}}function Vn(o,r){let a=[];for(let n of Y(o,".bet-line")){if(ke(n))continue;let p=D(n.querySelector(".bet-line__market-name")),d=D(n.querySelector(".bet-line__period")),u=Y(n,".odd-btn"),c=u.map((h,k)=>{let x=D(h.querySelector(".odd-btn__label")),g=Y(h,"span").map(y=>vt(D(y))).find(Boolean)||null;return g?{el:h,odd:g,label:x||Me(u.length,k,p),locked:!1}:null});if(c.length<2||c.some(h=>!h))continue;let m=D(n.querySelector(".coef-btn")).replace(/\s+/g," ");a.push(Ft({scope:"top",title:p,period:d,line:m,outcomes:c,anchor:n,eventKey:r}))}return a}function Me(o,r,a){return/тотал/i.test(a)?["Меньше","Больше"][r]||"":o===3?["П1","Х","П2"][r]:o===2?["1","2"][r]:String(r+1)}function Un(o,r){let a=[];for(let n of Y(o,".market")){let p=Y(n,".market__row");if(!p.length)continue;let d=D(n.querySelector(".market-title")),u=p.map(m=>{let h=D(m.querySelector(".market__row-text"));return Y(m,".market-row-btn").map(k=>{let x=vt(D(k.querySelector(".market-row-btn__coef")));if(!x||k.hasAttribute("disabled"))return null;let g=k.getAttribute("title")||D(k.querySelector(".market-row-btn__text"));return{el:k,odd:x,label:g.replace(/\s+/g," ").trim(),rowLabel:h,locked:!1}})}),{sets:c}=Be(u);for(let m of c){let h=[...new Set(m.map(y=>y.rowLabel).filter(Boolean))],k=h.length<=1,x=k?"":(m[0].label.match(/[+\-−]?\d+(?:[.,]\d+)?/)||[""])[0],g=m.map(y=>({el:y.el,odd:y.odd,label:k?y.label:y.rowLabel||y.label,locked:!1}));a.push(Ft({scope:"board",title:d,period:k&&h[0]||"",line:x,kind:Dt(d,g.length),outcomes:g,anchor:n,eventKey:r}))}}return a}var Wn=[[/coefficient-button_generic3/,"1x2"],[/coefficient-button_generic2/,"12"],[/coefficient-button_handicap/,"handicap"],[/coefficient-button_total/,"total"]];function Kn(o){let r=Y(o,".card__competitors .name .name, .half__names .name").map(n=>D(n));if(r.length<2)return null;let a=o.querySelector('a[href*="/event/"]')?.getAttribute("href")||"";return{id:Ke(a),key:Nt(r[0],r[1]),home:r[0],away:r[1],href:a,live:/card--live/.test(o.className)||!!o.querySelector(".card__body-live"),time:D(o.querySelector(".header-left__time, .footer__time")),league:D(o.closest(".block-tournament")?.querySelector(".block-tournament-header__title")),card:o}}function We(o){let r=[];for(let a of Y(o,".card")){if(ke(a))continue;let n=Kn(a);if(n){for(let p of Y(a,".card__body")){let d=D(p.querySelector(".match-row-label, .period-name"))||(/card__body--second/.test(p.className)?"отрезок":"");for(let u of Y(p,".card__market")){let c=Y(u,".coefficient-button");if(c.length<2)continue;let m=(Wn.find(([k])=>k.test(c[0].className))||[])[1]||"other",h=c.map((k,x)=>{let g=/--is-blank/.test(k.className)?null:we(k);return g?{el:k,odd:g,label:m==="total"?["Меньше","Больше"][x]:Me(c.length,x,""),locked:/coefficient-button_locked/.test(k.className)}:null});h.some(k=>!k)||r.push(Ft({scope:"list",title:{"1x2":"Исход",12:"Победитель",handicap:"Фора",total:"Тотал"}[m]||"Рынок",period:/^матч$/i.test(d)?"":d,line:D(u.querySelector(".coefficient-middle")).replace(/\s+/g," "),kind:m,outcomes:h,event:n,anchor:a,eventKey:n.key}))}}for(let p of Y(a,".half__coef-buttons")){let d=Y(p,".coef-buttons__button"),u=d.map((c,m)=>{let h=we(c.querySelector(".button__coef-title")||c);return h?{el:c,odd:h,label:Me(d.length,m,""),locked:!1}:null});u.length<2||u.some(c=>!c)||r.push(Ft({scope:"list",title:u.length===3?"Исход":"Победитель",kind:u.length===3?"1x2":"12",outcomes:u,event:n,anchor:a,eventKey:n.key}))}}}return r}function Zn(o){if(!o?.body)return null;let r=m=>/^\d{1,3}\s?%$/.test(m),a=Y(o,"h4").map(m=>{let h=[...m.nextElementSibling?.children||[]],k=D(h[0]),x=D(h[h.length-1]);return r(k)&&r(x)?{label:D(m),home:k.replace(/\s/g,""),away:x.replace(/\s/g,"")}:null}).filter(Boolean);if(!a.length)return null;let n=(o.body.innerText||o.body.textContent||"").replace(/\s+/g," "),p=[...n.matchAll(/Выборка:\s*(\d+)\s*карт/g)].map(m=>Number(m[1])),u=[...(n.split(/Форма/)[1]||"").matchAll(/((?:[ВПН]\s+){2,6})(\d{1,3})\s?%/g)].map(m=>m[1].replace(/\s/g,""));return{names:D(o.querySelector("h3")).split(/\s+vs\s+/i).map(m=>m.trim()).filter(Boolean),rows:a,samples:p.slice(0,2),form:u.length>=2?{home:u[0],away:u[1]}:null}}function Hn(o,r,a){if(!o||o.names.length<2)return o;let n=Rt(o.names[0],r)+Rt(o.names[1],a);return Rt(o.names[0],a)+Rt(o.names[1],r)<=n?o:{names:[o.names[1],o.names[0]],rows:o.rows.map(d=>({label:d.label,home:d.away,away:d.home})),samples:o.samples.slice().reverse(),form:o.form?{home:o.form.away,away:o.form.home}:null}}function Xn(o){let r=o.querySelector("iframe.stats__iframe");if(!r)return null;try{return Zn(r.contentDocument)}catch{return null}}function Yn(o){let r=["one","two"].map(d=>o.querySelector(`.event-live-center__team-widget--${d}`));if(!r[0]||!r[1])return null;let a=d=>{let u=d;try{u=d.querySelector("iframe")?.contentDocument?.body||d}catch{u=d}let c=Y(u,'[class*="player"]').filter(h=>!Y(h,'[class*="player"]').length||/player(__|-)?(row|item|card)?$/.test(h.className)),m=[];for(let h of c){let k=D(h).split(" ").filter(Boolean),x=k.find(y=>/^[A-Za-z0-9][A-Za-z0-9_.-]{1,15}$/.test(y)&&/[A-Za-z]/.test(y));if(!x||m.some(y=>y.nick===x))continue;let g=k.filter(y=>/^\d{1,3}$/.test(y)).map(Number);m.push({nick:x,numbers:g.slice(0,4)})}return m.slice(0,5)},n=a(r[0]),p=a(r[1]);return n.length<3||p.length<3?null:{home:n,away:p}}var Ze={id:"winline",name:"Winline",hosts:["winline.ru"],pageType:$e,readMatch:Ue,readEsportsWidget:Yn,observeTargets(o){try{let r=o.querySelector("iframe.stats__iframe")?.contentDocument?.body;return r?[r]:[]}catch{return[]}},collect(o,r){if($e(o)==="match"){let p=Ue(o,r)?.key||"";return[...Vn(o,p),...Un(o,p),...We(o)]}return We(o)}};var te=(o,r)=>{try{return[...o.querySelectorAll(r)]}catch{return[]}};function He(o,r){let a=[o];if(r.shadow)for(let n of te(o,r.shadow))n.shadowRoot&&a.push(n.shadowRoot);return a}var Jt=o=>(o.defaultView?.innerWidth||0)>0,Qn='button, a, td, [role="button"], [class*="odd" i], [class*="coef" i], [class*="factor" i], [class*="price" i], [class*="outcome" i], [class*="selection" i], [class*="bet" i]';function Jn(o){let r=[],a=o.ownerDocument.createTreeWalker(o,4);for(;a.nextNode();){let n=a.currentNode.textContent.replace(/[ \s]+/g," ").trim();if(n&&r.push(...n.split(" ")),r.length>5)return null}return r}function to(o,r){if(r.label){let a=o.querySelector(r.label),n=a?a.textContent.replace(/[ \s]+/g," ").trim():"";if(n&&!/^\d{1,3}[.,]\d{1,3}$/.test(n))return n}if(r.cell&&r.headerRow){let a=o.closest(r.cell),n=a?.parentElement,p=n?.parentElement?.querySelector(r.headerRow);if(p&&p!==n){let d=[...n.children].indexOf(a),u=p.children[d]?.textContent.replace(/[ \s]+/g," ").trim()||"";if(u)return u.charAt(0).toUpperCase()+u.slice(1).toLowerCase()}}return""}function eo(o,r){if(!r.cell||!r.lineCell)return"";let a=o.closest(r.cell);for(;a&&(a=a.previousElementSibling);){if(!a.matches?.(r.lineCell))continue;let n=a.textContent.replace(/[ \s]+/g," ").trim().match(/([+\-−–]?\d+(?:[.,]\d+)?)\s*\)?\s*$/);return n?n[1].replace(",",".").replace(/[−–]/,"-"):""}return""}function no(o,r){if(o.disabled||o.hasAttribute?.("disabled"))return null;let a=r.value&&o.querySelector(r.value)||o,n=Jn(a);if(!n||!n.length||n.join(" ").length>28)return null;let p=n[n.length-1];if(!(r.integers?/^\d{1,3}([.,]\d{1,3})?$/:/^\d{1,3}[.,]\d{1,3}$/).test(p))return null;let d=vt(p);if(!d||d>500||n.slice(0,-1).some(c=>/^\d{1,3}[.,]\d{1,3}$/.test(c)))return null;let u=n.slice(0,-1).join(" ");return!r.outcome&&/[+−]|^-/.test(u)?null:{odd:d,label:u}}function oo(o,r){let a=[],n=new Set,p=He(o,r).flatMap(d=>te(d,r.outcome||Qn));for(let d of p){if(n.has(d)||r.skip&&d.closest(r.skip)||d.closest("#lz-root, #lz-marks"))continue;let u=no(d,r);if(u){if(!r.outcome&&Jt(o)){let c=d.getBoundingClientRect();if(c.width<26||c.width>320||c.height<16||c.height>90)continue}n.add(d),a.push({el:d,odd:u.odd,label:u.label||to(d,r),line:eo(d,r),locked:!1})}}return r.outcome?a:a.filter(d=>!a.some(u=>u.el!==d.el&&u.el.contains(d.el)))}function so(o,r,a){if(r.row)return o.closest(r.row);let n=o.parentElement;for(let p=0;p<6&&n&&n!==n.ownerDocument.body;p+=1){let d=a(n);if(d>=2&&d<=16){if(!Jt(n.ownerDocument))return n;let u=n.getBoundingClientRect();if(u.height<=130&&u.width>=120)return n}if(d>16)break;n=n.parentElement}return null}var Xe=/^(п1|п2|х|x|1х|х2|1x|x2|12|live|лайв|б|м|да|нет|фора|тотал|исход|матч|перерыв|сегодня|завтра|событие не началось|окко|okko|матч тв|match tv|кинопоиск|трансляция|видео|статистика|stats)$/i;function ro(o,r){let a=r.length,n=o;for(let k=0;k<7;k+=1){let x=n.parentElement;if(!x||r.some(T=>!x.contains(T.el))||x.querySelectorAll("*").length>400||[...x.querySelectorAll('button, a, td, [role="button"]')].filter(T=>!r.some(F=>F.el===T||F.el.contains(T)||T.contains(F.el))&&/^\d{1,3}[.,]\d{1,3}$/.test(D(T))).length>a)break;n=x}let p=r[0].el,d=[],u=n.ownerDocument.createTreeWalker(n,4);for(;u.nextNode();){let k=u.currentNode;if(p.contains(k))break;let x=k.textContent.replace(/[ \s]+/g," ").trim();x.length<2||x.length>44||!/[A-Za-zА-Яа-яЁё]{2}/.test(x)||/\d{1,2}:\d{2}|^\d|['′]$/.test(x)||Xe.test(x)||d.push(x)}let c=d.slice(-2),m=d.map(k=>k.split(/\s+[—–-]\s+/)).filter(k=>k.length===2).pop();if(m&&(c=m),c.length<2||c[0]===c[1])return null;let h=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:Nt(c[0],c[1]),home:c[0],away:c[1],href:h,live:!1,time:"",league:"",card:n}}function ao(o,r,a){if(!r.names)return ro(o,a);let n=r.event&&o.closest(r.event)||o,p=[...new Set(te(n,r.names).map(c=>D(c)).filter(Boolean))],d=p;if(p.length===1&&(d=p[0].split(/\s+[—–-]\s+/)),d.length<2||!d[0]||!d[1])return null;let u=n.querySelector("a[href]")?.getAttribute("href")||"";return{id:"",key:Nt(d[0],d[1]),home:d[0],away:d[1],href:u,live:!1,time:"",league:"",card:n}}function io(o){let a=String(o.title||"").replace(/^\s*(ставки на (матч|игру|бой)|матч)\s+/i,"").match(/^(.{2,40}?)\s+(?:[—–-]|x|vs|против)\s+(.{2,40}?)(?=\s*[:,|.(📅]|\s+[—–-]\s|\s+ставк|\s+прогноз|\s+коэффиц|\s+live\b|\s+лайв\b|\s+\d{1,2}(?:[./]\d|\s+[а-я]{3,})|$)/i);if(!a)return null;let n=[a[1].trim(),a[2].trim()];return n.some(p=>/ставк|контор|онлайн|букмекер|прогноз|коэффиц|!$/i.test(p))?null:n}function Ye(o,r={}){function a(g,y){return r.matchUrl&&r.matchUrl.test(y?.pathname||"")||r.matchPage&&g.querySelector(r.matchPage)?"match":"list"}function n(g){let y=g.defaultView;if(!y||!Jt(g))return[];let T=[];for(let F of g.querySelectorAll("h1, h2, h3, div, span, p, a")){if(F.children.length)continue;let O=D(F);if(O.length<3||O.length>40||!/[A-Za-zА-Яа-яЁё]{3}/.test(O)||/\d{1,2}[:.]\d{2}/.test(O)||Xe.test(O))continue;let I=F.getBoundingClientRect();if(!(I.top<60||I.top>450||I.width<30||parseFloat(y.getComputedStyle(F).fontSize)<15)&&(T.includes(O)||T.push(O),T.length===2))break}return T}function p(g,y){if(a(g,y)!=="match")return null;let T=r.matchNames?te(g,r.matchNames).map(O=>D(O)).filter(Boolean):[];if(T.length===1&&(T=T[0].split(/\s+[—–-]\s+/)),T.length<2&&(T=io(g)||[]),T.length<2&&(T=n(g)),T.length<2)return null;let F=r.matchLeague?D(g.querySelector(r.matchLeague)):"";return{book:o.name,id:(String(y?.pathname||"").match(/(\d{5,})/)||[])[1]||"",key:Nt(T[0],T[1]),home:T[0],away:T[1],sport:jt(y?.pathname,F,g.title,D(g.querySelector('[class*="breadcrumb" i], nav[aria-label*="крошк" i]'))),league:F,start:"",live:/(^|\/)live(\/|$)/i.test(y?.pathname||"")?!0:null,form:{home:"",away:""},url:y?.href||""}}function d(g,y){return!g||!y?"":y.startsWith("attr:")?String(g.getAttribute(y.slice(5))||"").trim():D(g.querySelector(y))}function u(g,y){if(!Jt(y))return[g];let T=g.map(O=>{let I=O.el.getBoundingClientRect();return{cell:O,top:I.top,left:I.left}}).sort((O,I)=>Math.abs(O.top-I.top)>8?O.top-I.top:O.left-I.left),F=[];for(let O of T){let I=F[F.length-1];I&&Math.abs(I.top-O.top)<=8?I.cells.push(O.cell):F.push({top:O.top,cells:[O.cell]})}return F.map(O=>O.cells)}let c=[[/^(п1|1)\/(х|x|ничья)\/(п2|2)$/i,"1x2"],[/^(п1|1)\/(п2|2)$/i,"12"],[/^(1х|1x)\/12\/(х2|x2)$/i,"dc"]],m=g=>(c.find(([y])=>y.test(g.join("/").toLowerCase()))||[])[1]||"other";function h(g,y){let T=a(g,y),F=T==="match"&&r.match?{...r,...r.match}:r;return k(g,y,T,F)}function k(g,y,T,F){let O=oo(g,F);if(O.length<2)return[];let I=new Set(O.map(M=>M.el)),j=M=>{let S=0;for(let C of I)M.contains(C)&&(S+=1);return S},E=new Map;for(let M of O){let S=so(M.el,F,j);S&&(E.has(S)||E.set(S,[]),E.get(S).push(M))}let W=T==="match"?p(g,y):null,_=[];for(let[M,S]of E){let C=T==="match"?null:ao(M,F,S),P=F.group?M.closest(F.group):null,q=d(P,F.groupTitle),V=d(P,F.groupPeriod),U=F.visualRows?u(S,g):[S],nt=0;for(let Q of U)for(let st of Ie(Q).sets){let J=nt===0,rt=st.length,ft=rt===3?["П1","Х","П2"]:["1","2"],Mt=st.map((ct,ut)=>({...ct,label:ct.label||ft[ut]||String(ut+1)})),gt=J&&rt===3?"Исход":J?"Победитель":`Рынок ${nt+1}`,pt=J?rt===3?"1x2":"12":"other";q&&(gt=q,pt=Dt(q,rt),pt==="other"&&(pt=m(Mt.map(ct=>ct.label)))),rt===3&&Mt.every(ct=>/\sили\s/i.test(ct.label))&&(pt="dc"),_.push(Ft({scope:T==="match"?"board":"list",title:gt,period:V,line:st[0].line&&st.every(ct=>ct.line===st[0].line)?st[0].line:"",kind:pt,outcomes:Mt,event:C,anchor:M,eventKey:C?.key||W?.key||`row${_.length}`})),nt+=1}}return _}let x=g=>He(g,r).slice(1);return{id:o.id,name:o.name,hosts:o.hosts,generic:!0,pageType:a,readMatch:p,collect:h,observeTargets:x,readEsportsWidget:()=>null}}var Qe={outcome:'[class*="factor-value--"][class*="_value--"], [class*="factor--"][class*="factor-normal--"]',value:'[class*="value--"]',row:'[class*="sport-base-event--"], [class*="normal-row--"]',names:'a[class*="sport-event__name--"]',matchUrl:/\/(sports|live)\/[^/]+\/\d+\/\d+/,matchNames:'[class*="scoreboard-compact__main__team__name--"], [class*="scoreboard"] [class*="team__name--"]',match:{group:'[class*="market-group-box--"]',groupTitle:'[class*="header--"] [class*="text--"]',label:'[class*="text--"]',cell:'[class*="cell--"]',headerRow:'[class*="header-row--"]',lineCell:'[class*="_align-left--"]'}},Je={fonbet:Qe,pari:Qe,melbet:{shadow:"sport-european-view",outcome:"button.dg_odd, .dg_euv_stake",value:".dg_euv_stake_factor_new",row:".euv_event_home, .dg_euv_stake_grid",names:".euv_event_name_team",integers:!0,matchUrl:/\/sport\/event-details\//,matchNames:"h1"},marathon:{outcome:"td.price",value:".selection-link",row:"tr",names:".member-link, .member-name",matchUrl:/\/su\/betting\/.*vs.*\d{5,}/i},leon:{matchUrl:/\/bets\/.+\/\d{10,}-/},olimp:{matchUrl:/\/line\/[^/]+\/[^/]+-\d{4,}\/[^/]+/,match:{outcome:'[data-testid^="bet-button"]',row:'[data-testid="accordion-content"]',group:'[data-testid="accordion"]',groupTitle:'[class*="title--"]',visualRows:!0}},betcity:{matchUrl:/\/ru\/(live|line)\/[^/]+\/\d+\/\d+/},betboom:{matchUrl:/\/sport\/(?:live\/)?[^/]+\/\d+\/\d+\/\d+/},liga:{matchUrl:/\/sports\/[^/]+\/.+-id-\d+/,match:{outcome:"button[outcomeid]",row:"[data-t-market]",group:"[data-t-market]",groupTitle:"attr:data-t-market",groupPeriod:'[class*="header__description"]',visualRows:!0}}};function tn(o){let r=Ee(o);return r?r.id==="winline"?{adapter:Ze,book:r}:{adapter:Ye(r,Je[r.id]||{}),book:r}:null}var ee=`/* Цвета, шрифт и радиусы панели — из design/tokens.json (node tools/tokens.mjs). Блоки между метками руками не править. */
:host {
  /* tokens:light */
  --lz-accent: #5b4be6;
  --lz-accent-strong: #4a3bd1;
  --lz-accent-soft: rgba(91, 75, 230, 0.14);
  --lz-accent-ink: #ffffff;
  --lz-pos: #0b8a4d;
  --lz-pos-soft: rgba(11, 138, 77, 0.14);
  --lz-neg: #c93636;
  --lz-neg-soft: rgba(201, 54, 54, 0.12);
  --lz-warn: #b45309;
  --lz-bg: #ffffff;
  --lz-surface: #f5f6fa;
  --lz-surface-2: #eef0f5;
  --lz-border: #e1e4ea;
  --lz-text: #14161b;
  --lz-muted: #555c6b;
  --lz-faint: #666b7f;
  --lz-shadow: 0 18px 48px rgba(16, 20, 32, 0.18), 0 2px 8px rgba(16, 20, 32, 0.08);
  --lz-radius: 14px;
  --lz-radius-sm: 10px;
  --lz-font: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
  /* /tokens */
  color-scheme: light;
}

:host([data-theme="dark"]) {
  /* tokens:dark */
  --lz-accent: #8f82ff;
  --lz-accent-strong: #a094ff;
  --lz-accent-soft: rgba(143, 130, 255, 0.18);
  --lz-accent-ink: #0f1017;
  --lz-pos: #45d08f;
  --lz-pos-soft: rgba(69, 208, 143, 0.16);
  --lz-neg: #ff7676;
  --lz-neg-soft: rgba(255, 118, 118, 0.14);
  --lz-warn: #f0b429;
  --lz-bg: #171a23;
  --lz-surface: #1f2330;
  --lz-surface-2: #272b34;
  --lz-border: #2c3040;
  --lz-text: #eef0f6;
  --lz-muted: #a4a8bb;
  --lz-faint: #8e92a8;
  --lz-shadow: 0 18px 48px rgba(0, 0, 0, 0.55), 0 2px 8px rgba(0, 0, 0, 0.4);
  /* /tokens */
  color-scheme: dark;
}
`;var en=`.layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  pointer-events: none;
  font-family: var(--lz-font);
  font-variant-numeric: tabular-nums;
}

.mark {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.16s ease;
  will-change: transform;
}

.mark.on {
  opacity: 1;
}

.mark.frame {
  border: 2px solid var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.mark.frame.pos {
  border-color: var(--lz-pos);
  box-shadow: 0 0 0 3px var(--lz-pos-soft);
}

.mark.selected {
  border: 2px solid var(--lz-accent-strong);
  box-shadow: 0 0 0 4px var(--lz-accent-soft), 0 0 0 1px var(--lz-accent-strong) inset;
}

.chip {
  position: absolute;
  top: -8px;
  right: 6px;
  height: 15px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--lz-accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  line-height: 15px;
  letter-spacing: 0.01em;
  white-space: nowrap;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
}

.mark.small .chip {
  top: -9px;
  right: 2px;
  height: 11px;
  padding: 0 3px;
  border-radius: 4px;
  font-size: 8.5px;
  line-height: 11px;
}

.chip.pos {
  background: var(--lz-pos);
}

.chip.neg {
  background: var(--lz-neg);
}

.chip.quiet {
  background: rgba(40, 44, 56, 0.78);
  color: #fff;
  font-weight: 600;
}

.tip {
  position: absolute;
  top: 0;
  left: 0;
  width: 264px;
  box-sizing: border-box;
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: 12px;
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: var(--lz-shadow);
  font-size: 12px;
  line-height: 1.4;
  pointer-events: none;
  opacity: 0;
  transform-origin: top left;
  transition: opacity 0.12s ease;
}

.tip.on {
  opacity: 1;
}

.tip-title {
  font-weight: 650;
  font-size: 12.5px;
  margin-bottom: 2px;
}

.tip-sub {
  color: var(--lz-muted);
  margin-bottom: 8px;
}

.tip-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 10px;
  align-items: center;
  padding: 3px 0;
}

.tip-row.hot {
  font-weight: 650;
}

.tip-row .odd {
  color: var(--lz-muted);
}

.tip-row .pct {
  min-width: 38px;
  text-align: right;
}

.tip-bar {
  grid-column: 1 / -1;
  height: 3px;
  border-radius: 2px;
  background: var(--lz-surface-2);
  overflow: hidden;
}

.tip-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: var(--lz-accent);
}

.tip-foot {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--lz-border);
  color: var(--lz-muted);
}

.tip-foot b {
  color: var(--lz-text);
  font-weight: 650;
}

.tip-foot .pos {
  color: var(--lz-pos);
  font-weight: 600;
}
`;function t(o,r,...a){let[n,...p]=o.split("."),d=document.createElement(n||"div");p.length&&(d.className=p.join(" "));for(let[u,c]of Object.entries(r||{}))if(!(c==null||c===!1))if(u==="class")d.className=[d.className,c].filter(Boolean).join(" ");else if(u==="style")d.style.cssText=c;else if(u==="text")d.textContent=c;else{if(u==="html")throw new Error("html запрещён");u.startsWith("data-")||u.startsWith("aria-")||u==="role"||u==="title"||u==="type"||u==="href"||u==="target"||u==="rel"||u==="placeholder"||u==="value"||u==="for"||u==="name"||u==="maxlength"||u==="autocomplete"||u==="spellcheck"||u==="tabindex"?d.setAttribute(u,c===!0?"":String(c)):u==="disabled"||u==="hidden"||u==="checked"||u==="selected"?d[u]=!!c:d[u]=c}return on(d,a),d}function on(o,r){for(let a of r)a==null||a===!1||(Array.isArray(a)?on(o,a):o.appendChild(a instanceof Node?a:document.createTextNode(String(a))))}var nn="http://www.w3.org/2000/svg";function at(o,r=16){let a=document.createElementNS(nn,"svg");a.setAttribute("viewBox","0 0 20 20"),a.setAttribute("width",r),a.setAttribute("height",r),a.setAttribute("fill","none"),a.setAttribute("stroke","currentColor"),a.setAttribute("stroke-width","1.7"),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),a.setAttribute("aria-hidden","true");for(let n of uo[o]||[]){let p=document.createElementNS(nn,"path");p.setAttribute("d",n),a.appendChild(p)}return a}var uo={lens:["M9 3.2a5.8 5.8 0 1 0 0 11.6A5.8 5.8 0 0 0 9 3.2Z","m13.3 13.3 3.5 3.5","M6.6 9.6 8.3 11.3 11.6 7.4"],close:["m5 5 10 10","M15 5 5 15"],gear:["M3.5 6h6.2M13.3 6h3.2M3.5 14h3.2M10.3 14h6.2","M11.5 7.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z","M8.5 15.8a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z"],sun:["M10 13.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M10 2.5v1.6M10 15.9v1.6M2.5 10h1.6M15.9 10h1.6M4.7 4.7l1.1 1.1M14.2 14.2l1.1 1.1M4.7 15.3l1.1-1.1M14.2 5.8l1.1-1.1"],moon:["M16.5 11.4A6.8 6.8 0 0 1 8.6 3.5a6.8 6.8 0 1 0 7.9 7.9Z"],spark:["M10 2.8 11.7 8l5.3 2-5.3 2L10 17.2 8.3 12 3 10l5.3-2L10 2.8Z"],scale:["M10 3v14","M5 17h10","M4 6h12","M4 6 2.2 10.4a2.3 2.3 0 0 0 4.4 0L4.8 6","M16 6l-1.8 4.4a2.3 2.3 0 0 0 4.4 0L16.8 6"],layers:["m10 3 7 3.6-7 3.6-7-3.6L10 3Z","m3 10.4 7 3.6 7-3.6","m3 14 7 3.6 7-3.6"],eye:["M2.5 10S5.2 4.8 10 4.8 17.5 10 17.5 10 14.8 15.2 10 15.2 2.5 10 2.5 10Z","M10 12.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4Z"],eyeOff:["M3 3l14 14","M8.2 5.1A7 7 0 0 1 10 4.8c4.8 0 7.5 5.2 7.5 5.2a13 13 0 0 1-2.2 2.9M12.6 14.6a6.6 6.6 0 0 1-2.6.6C5.2 15.2 2.5 10 2.5 10a12.6 12.6 0 0 1 3-3.6"],plus:["M10 4.5v11M4.5 10h11"],trash:["M4.5 6h11","M8 6V4.4h4V6","m6 6 .7 9.6h6.6L14 6"],link:["M8.4 11.6a3 3 0 0 0 4.2 0l2.6-2.6a3 3 0 1 0-4.2-4.2l-.8.8","M11.6 8.4a3 3 0 0 0-4.2 0l-2.6 2.6a3 3 0 1 0 4.2 4.2l.8-.8"],back:["M11.5 5 6.5 10l5 5"],info:["M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14Z","M10 9.2v4.3","M10 6.6v.2"],alert:["M10 3.2 17.4 16H2.6L10 3.2Z","M10 8.2v3.6","M10 13.9v.2"],check:["m4.5 10.4 3.4 3.4 7.6-8"],list:["M7 5.5h9.5M7 10h9.5M7 14.5h9.5","M3.6 5.5h.2M3.6 10h.2M3.6 14.5h.2"],refresh:["M16.2 10a6.2 6.2 0 1 1-1.9-4.5","M16.4 3.4v3.4H13"]};function sn(){let o=document.createElement("div");o.id="lz-marks",o.style.cssText="position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;overflow:hidden!important;margin:0!important;padding:0!important;border:0!important;pointer-events:none!important;z-index:2147483600!important;";let r=o.attachShadow({mode:"open"});r.appendChild(t("style",{text:ee+en}));let a=t("div.layer"),n=t("div.tip");r.append(a,n);let p=new Map,d=new Set,u=0,c=null,m=null,h=new IntersectionObserver(M=>{for(let S of M)S.isIntersecting?d.add(S.target):(d.delete(S.target),p.get(S.target)?.node.classList.remove("on"));x()},{rootMargin:"120px"});function k(){o.isConnected||document.documentElement.appendChild(o)}function x(){u||(u=requestAnimationFrame(()=>{u=0,T()}))}let g=(M,S)=>{for(let C=S;C;C=C.parentNode||C.host)if(C===M)return!0;return!1};function y(M,S){let C=S.left+S.width/2,P=S.top+S.height/2;if(C<0||P<0||C>window.innerWidth||P>window.innerHeight)return!1;let q=document.elementFromPoint(C,P);for(;q?.shadowRoot?.elementFromPoint;){let V=q.shadowRoot.elementFromPoint(C,P);if(!V||V===q)break;q=V}return!!q&&q!==M&&!g(M,q)&&!g(q,M)}function T(){for(let M of d){let S=p.get(M);if(!S)continue;if(!M.isConnected){F(M);continue}let C=M.getBoundingClientRect();if(C.width<6||C.height<6||y(M,C)){S.node.classList.remove("on");continue}let P=Math.round(C.left),q=Math.round(C.top),V=Math.round(C.width),U=Math.round(C.height);(S.x!==P||S.y!==q)&&(S.node.style.transform=`translate3d(${P}px, ${q}px, 0)`,S.x=P,S.y=q),(S.w!==V||S.h!==U)&&(S.node.style.width=`${V}px`,S.node.style.height=`${U}px`,S.w=V,S.h=U,S.node.classList.toggle("small",U<26)),S.node.classList.add("on")}c&&I()}function F(M){let S=p.get(M);S&&(h.unobserve(M),d.delete(M),S.node.remove(),p.delete(M))}function O(M){k();let S=new Map;for(let C of M)C.el?.isConnected&&S.set(C.el,C);for(let C of[...p.keys()])S.has(C)||F(C);for(let[C,P]of S){let q=p.get(C);if(!q){let U=t("div.mark"),nt=parseFloat(getComputedStyle(C).borderTopLeftRadius);U.style.borderRadius=`${Number.isFinite(nt)&&nt>0?Math.min(nt,16):6}px`;let Q=t("span.chip");U.appendChild(Q),a.appendChild(U),q={node:U,chip:Q,sig:""},p.set(C,q),h.observe(C)}let V=`${P.frame?1:0}|${P.selected?1:0}|${P.tone||""}|${P.chip||""}`;V!==q.sig&&(q.sig=V,q.node.classList.toggle("frame",!!P.frame),q.node.classList.toggle("selected",!!P.selected),q.node.classList.toggle("pos",P.tone==="pos"&&!!P.frame),q.chip.hidden=!P.chip,q.chip.textContent=P.chip||"",q.chip.className=`chip${P.tone&&P.tone!=="accent"?" "+P.tone:""}`)}x()}function I(){if(!c?.isConnected)return E();let M=c.getBoundingClientRect(),S=264,C=n.offsetHeight||140,P=M.left+M.width/2-S/2;P=Math.max(8,Math.min(P,window.innerWidth-S-8)),m&&P+S>m.left-8&&P<m.right&&(P=Math.max(8,m.left-S-10));let q=M.bottom+10;q+C>window.innerHeight-8&&(q=M.top-C-10),q<8&&(q=8),n.style.transform=`translate3d(${Math.round(P)}px, ${Math.round(q)}px, 0)`}function j(M,S){k(),c=M,n.replaceChildren(S),I(),n.classList.add("on")}function E(){c=null,n.classList.remove("on")}function W(M){m=M}function _(M){o.setAttribute("data-theme",M)}return window.addEventListener("scroll",x,{capture:!0,passive:!0}),window.addEventListener("resize",x,{passive:!0}),setInterval(()=>{p.size&&!document.hidden&&x()},700),{set:O,schedule:x,showTip:j,hideTip:E,setTheme:_,setAvoid:W,get tipTarget(){return c},count:()=>p.size}}var rn=`* {
  box-sizing: border-box;
}

:host {
  all: initial;
  font-family: var(--lz-font);
  font-size: 13px;
  line-height: 1.45;
  color: var(--lz-text);
  font-variant-numeric: tabular-nums;
  -webkit-font-smoothing: antialiased;
}

button {
  font: inherit;
  color: inherit;
  cursor: pointer;
  border: 0;
  background: none;
  padding: 0;
}

button:focus-visible,
input:focus-visible,
a:focus-visible {
  outline: 2px solid var(--lz-accent);
  outline-offset: 2px;
}

/* Кнопка-запуск */
.fab {
  position: fixed;
  right: 14px;
  top: 42vh;
  z-index: 2147483640;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px 0 11px;
  border-radius: 20px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  letter-spacing: 0.01em;
  box-shadow: 0 8px 24px rgba(77, 62, 214, 0.38), 0 1px 3px rgba(0, 0, 0, 0.2);
  touch-action: none;
  user-select: none;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}

.fab:hover {
  background: var(--lz-accent-strong);
  transform: translateY(-1px);
}

.fab.dragging {
  transition: none;
  cursor: grabbing;
}

.fab .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #7cf0b5;
  box-shadow: 0 0 0 3px rgba(124, 240, 181, 0.25);
}

.fab .dot.off {
  background: rgba(255, 255, 255, 0.45);
  box-shadow: none;
}

/* Панель */
.panel {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483641;
  width: 376px;
  max-width: calc(100vw - 16px);
  max-height: calc(100vh - 28px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--lz-border);
  border-radius: 18px;
  background: var(--lz-bg);
  box-shadow: var(--lz-shadow);
  overflow: hidden;
  animation: lz-in 0.18s ease;
}

.panel[hidden] {
  display: none;
}

@keyframes lz-in {
  from { opacity: 0; transform: translateY(6px) scale(0.985); }
  to { opacity: 1; transform: none; }
}

.head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 10px 14px;
  cursor: grab;
  user-select: none;
  touch-action: none;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14.5px;
  letter-spacing: -0.01em;
}

.brand .logo {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--lz-accent);
  color: #fff;
}

.brand small {
  font-weight: 500;
  font-size: 11.5px;
  color: var(--lz-muted);
  letter-spacing: 0;
}

.head .grow {
  flex: 1;
}

.iconbtn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--lz-muted);
  transition: background 0.12s ease, color 0.12s ease;
}

.iconbtn:hover,
.iconbtn.on {
  background: var(--lz-surface-2);
  color: var(--lz-text);
}

.tabs {
  display: flex;
  gap: 4px;
  margin: 0 12px 10px;
  padding: 3px;
  border-radius: 11px;
  background: var(--lz-surface);
}

.tab {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12.5px;
  transition: background 0.12s ease, color 0.12s ease;
}

.tab:hover {
  color: var(--lz-text);
}

.tab.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

.tab .count {
  margin-left: 5px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--lz-accent-soft);
  color: var(--lz-accent);
  font-size: 11px;
}

.body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  scrollbar-width: thin;
  scrollbar-color: var(--lz-border) transparent;
}

.card {
  padding: 12px;
  border: 1px solid var(--lz-border);
  border-radius: var(--lz-radius);
  background: var(--lz-bg);
}

.card.soft {
  border-color: transparent;
  background: var(--lz-surface);
}

.card.accent {
  border-color: var(--lz-accent);
  box-shadow: 0 0 0 3px var(--lz-accent-soft);
}

.kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}

.badge.accent { background: var(--lz-accent-soft); color: var(--lz-accent); }
.badge.pos { background: var(--lz-pos-soft); color: var(--lz-pos); }
.badge.neg { background: var(--lz-neg-soft); color: var(--lz-neg); }
.badge.live { background: var(--lz-neg-soft); color: var(--lz-neg); }

/* Шапка матча */
.league {
  color: var(--lz-muted);
  font-size: 11.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.teams {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 10px;
  align-items: center;
}

.team {
  min-width: 0;
}

.team.away {
  text-align: right;
}

.team b {
  display: block;
  font-size: 14.5px;
  font-weight: 680;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.form {
  display: inline-flex;
  gap: 3px;
  margin-top: 5px;
}

.form i {
  display: grid;
  place-items: center;
  width: 15px;
  height: 15px;
  border-radius: 4px;
  font-style: normal;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: var(--lz-faint);
}

.form i.w { background: var(--lz-pos); }
.form i.l { background: var(--lz-neg); }

.center {
  text-align: center;
  color: var(--lz-muted);
  font-size: 11.5px;
  line-height: 1.25;
}

.center .score {
  display: block;
  color: var(--lz-text);
  font-size: 20px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.periods {
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
  text-align: center;
}

/* Полоски вероятностей */
.prob {
  display: grid;
  grid-template-columns: minmax(64px, 1fr) 46px 72px minmax(60px, max-content);
  gap: 8px;
  align-items: center;
  padding: 5px 0;
}

.prob .name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

.prob .odd {
  color: var(--lz-muted);
  text-align: right;
}

.prob .pct {
  text-align: right;
  font-weight: 680;
}

.prob .pct small {
  display: block;
  white-space: nowrap;
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.prob .pct small.pos { color: var(--lz-pos); }
.prob .pct small.neg { color: var(--lz-neg); }

.track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--lz-surface-2);
}

.track i {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 3px;
  background: var(--lz-accent);
  transition: width 0.25s ease;
}

.track u {
  position: absolute;
  top: -3px;
  width: 3px;
  height: 12px;
  margin-left: -1.5px;
  border-radius: 2px;
  background: var(--lz-text);
  box-shadow: 0 0 0 2px var(--lz-bg);
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  margin-top: 8px;
  color: var(--lz-muted);
  font-size: 11.5px;
}

.legend span::before {
  content: "";
  display: inline-block;
  width: 9px;
  height: 4px;
  margin-right: 5px;
  border-radius: 2px;
  background: var(--lz-accent);
  vertical-align: middle;
}

.legend span.model::before {
  width: 3px;
  height: 10px;
  background: var(--lz-text);
}

/* Кнопки */
.row {
  display: flex;
  gap: 8px;
}

.btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  background: var(--lz-accent);
  color: #fff;
  font-weight: 650;
  font-size: 13px;
  transition: background 0.12s ease, transform 0.08s ease, opacity 0.12s ease;
}

.btn:hover { background: var(--lz-accent-strong); }
.btn:active { transform: scale(0.985); }
.btn[disabled] { opacity: 0.55; cursor: default; }

.btn.ghost {
  background: var(--lz-surface);
  color: var(--lz-text);
}

.btn.ghost:hover { background: var(--lz-surface-2); }

.partner { margin-top: 8px; }
.partner-text { font-size: 12px; margin-bottom: 4px; }
.partner-links { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
.partner-links a.btn { text-decoration: none; }
.gain { margin-top: 8px; font-size: 12px; color: var(--lz-text); }
.gain b { color: var(--lz-pos); }
td.name .partner-links { margin-top: 3px; }

.btn.small {
  flex: none;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 12px;
}

.hint {
  color: var(--lz-muted);
  font-size: 12px;
}

.hint.center-text {
  text-align: center;
}

/* Разбор */
.steps {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.step {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  color: var(--lz-muted);
  font-size: 12.5px;
}

.step .mark {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border-radius: 50%;
  border: 2px solid var(--lz-border);
}

.step.done .mark {
  border-color: var(--lz-pos);
  background: var(--lz-pos);
}

.step.now {
  color: var(--lz-text);
}

.step.now .mark {
  border-color: var(--lz-accent);
  border-top-color: transparent;
  animation: lz-spin 0.8s linear infinite;
}

@keyframes lz-spin {
  to { transform: rotate(360deg); }
}

.verdict {
  font-size: 14px;
  font-weight: 650;
  letter-spacing: -0.005em;
  margin-bottom: 4px;
}

.summary {
  color: var(--lz-text);
  margin: 0 0 10px;
}

.factors {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.factor {
  display: grid;
  grid-template-columns: 4px 1fr;
  gap: 9px;
}

.factor::before {
  content: "";
  border-radius: 2px;
  background: var(--lz-faint);
}

.factor.home::before { background: var(--lz-accent); }
.factor.away::before { background: var(--lz-warn); }

.factor p {
  margin: 0;
}

.factor .src {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 4px;
}

.src .tag {
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  border-radius: 5px;
  background: var(--lz-surface-2);
  color: var(--lz-muted);
  font-size: 10.5px;
  font-weight: 600;
}

.note {
  display: flex;
  gap: 8px;
  padding: 9px 10px;
  border-radius: var(--lz-radius-sm);
  background: var(--lz-surface);
  color: var(--lz-muted);
  font-size: 12px;
}

.note svg {
  flex: none;
  margin-top: 1px;
}

.note.warn {
  background: var(--lz-neg-soft);
  color: var(--lz-neg);
}

details {
  border-top: 1px solid var(--lz-border);
  margin-top: 10px;
  padding-top: 8px;
}

summary {
  cursor: pointer;
  color: var(--lz-muted);
  font-size: 12px;
  font-weight: 600;
  list-style: none;
  user-select: none;
}

summary::-webkit-details-marker { display: none; }
summary::after { content: " ▾"; }
details[open] summary::after { content: " ▴"; }

.facts {
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
}

.facts li {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 6px;
}

.card.update { font-size: 12.5px; }
.card.update b { color: var(--lz-accent); }
/* Строка без номера (факторы модели, факты о составах) занимает обе колонки, иначе текст ломается по словам в узкой. */
.facts li > span:only-child { grid-column: 1 / -1; }
.facts li b {
  color: var(--lz-faint);
  font-weight: 650;
  font-size: 11px;
}

.facts li span em {
  font-style: normal;
  color: var(--lz-faint);
}

/* Таблицы */
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

th {
  padding: 0 0 6px;
  color: var(--lz-muted);
  font-size: 11px;
  font-weight: 650;
  text-align: right;
}

th,
td {
  padding-left: 10px;
}

th:first-child,
td:first-child {
  padding-left: 0;
  text-align: left;
}

td {
  padding: 6px 0;
  border-top: 1px solid var(--lz-border);
  text-align: right;
}

td.best {
  color: var(--lz-pos);
  font-weight: 700;
}

td .sub {
  display: block;
  color: var(--lz-muted);
  font-size: 11px;
}

tr.click {
  cursor: pointer;
}

tr.click:hover td {
  background: var(--lz-surface);
}

td.name {
  max-width: 190px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
}

/* Выбранный исход */
.pick-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 8px;
}

.pick-head .big {
  font-size: 22px;
  font-weight: 720;
  letter-spacing: -0.02em;
}

.pick-head .what {
  min-width: 0;
  flex: 1;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 10px;
  font-size: 12.5px;
}

.kv dt {
  color: var(--lz-muted);
}

.kv dd {
  margin: 0;
  font-weight: 650;
  text-align: right;
}

.kv dd.pos { color: var(--lz-pos); }
.kv dd.neg { color: var(--lz-neg); }

/* Экспресс */
.leg {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-top: 1px solid var(--lz-border);
}

.leg:first-of-type {
  border-top: 0;
}

.leg .t {
  min-width: 0;
}

.leg .t b,
.leg .t span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.leg .t span {
  color: var(--lz-muted);
  font-size: 11.5px;
}

.leg .o {
  font-weight: 680;
}

/* Настройки */
.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
}

.field:last-child {
  margin-bottom: 0;
}

.field label {
  font-weight: 600;
  font-size: 12.5px;
}

.seg {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 10px;
  background: var(--lz-surface);
}

.seg button {
  flex: 1;
  height: 28px;
  border-radius: 8px;
  color: var(--lz-muted);
  font-weight: 600;
  font-size: 12px;
}

.seg button.on {
  background: var(--lz-bg);
  color: var(--lz-text);
  box-shadow: 0 1px 2px rgba(16, 20, 32, 0.12);
}

input[type="text"],
input[type="password"] {
  width: 100%;
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--lz-border);
  border-radius: 10px;
  background: var(--lz-bg);
  color: var(--lz-text);
  font: inherit;
}

input::placeholder {
  color: var(--lz-faint);
}

.foot {
  padding: 9px 14px 11px;
  border-top: 1px solid var(--lz-border);
  /* 18+ и предупреждение о зависимости должны читаться: не бледный, а обычный второстепенный цвет. */
  color: var(--lz-muted);
  font-size: 10.5px;
  line-height: 1.4;
}

.foot a {
  color: var(--lz-muted);
  text-decoration: underline;
  text-underline-offset: 2px;
}

.empty {
  padding: 18px 8px;
  text-align: center;
  color: var(--lz-muted);
}

.empty b {
  display: block;
  margin-bottom: 4px;
  color: var(--lz-text);
  font-size: 13.5px;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  z-index: 2147483642;
  transform: translateX(-50%);
  padding: 9px 14px;
  border-radius: 11px;
  background: var(--lz-text);
  color: var(--lz-bg);
  font-size: 12.5px;
  font-weight: 600;
  box-shadow: var(--lz-shadow);
  animation: lz-in 0.18s ease;
}

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
`;var re=o=>Math.min(.999,Math.max(.001,o));function ze(o,r,a=0,n=0){let p=Math.ceil(r/2),d=new Map,u=(c,m)=>{if(c>=p)return 1;if(m>=p)return 0;let h=c*16+m;return d.has(h)||d.set(h,o*u(c+1,m)+(1-o)*u(c,m+1)),d.get(h)};return u(a,n)}function ae(o,r){let a=.001,n=.999;for(let p=0;p<50;p++){let d=(a+n)/2;o(d)<r?a=d:n=d}return(a+n)/2}function mo(o,r){let a=re(o);return Math.ceil(r/2)<=1?a:ae(n=>ze(n,r),a)}function oe(o,r,a,n=new Map){if(r>=4)return[1,0];if(a>=4)return[0,0];if(r===3&&a===3)return[0,1];let p=r*8+a;if(!n.has(p)){let[d,u]=oe(o,r+1,a,n),[c,m]=oe(o,r,a+1,n);n.set(p,[o*d+(1-o)*c,o*u+(1-o)*m])}return n.get(p)}function an(o){let[r,a]=oe(o,0,0);return r/(1-a)}function ne(o,r,a){if(r=Math.max(0,Math.floor(r)),a=Math.max(0,Math.floor(a)),Math.min(r,a)>=12){let d=Math.floor((Math.min(r,a)-12)/3),u=r-12-3*d,c=a-12-3*d,[m,h]=oe(o,u,c);return m+h*an(o)}let n=new Map,p=(d,u)=>{if(d>=13)return 1;if(u>=13)return 0;if(d===12&&u===12)return an(o);let c=d*32+u;return n.has(c)||n.set(c,o*p(d+1,u)+(1-o)*p(d,u+1)),n.get(c)};return p(r,a)}function fo(o){return ae(r=>ne(r,0,0),re(o))}var ho=24,se=Array.from({length:101},(o,r)=>(r+.5)/101),ln=null;function cn(o,r){let a=se.map(u=>(o-1)*Math.log(u)+(r-1)*Math.log(1-u)),n=Math.max(...a),p=a.map(u=>Math.exp(u-n)),d=p.reduce((u,c)=>u+c,0);return p.map(u=>u/d)}function un(o,r,a=0,n=0){if(!Number.isFinite(r))return ne(o,a,n);let p=cn(o*r+a,(1-o)*r+n);return!a&&!n?(ln||=se.map(d=>ne(d,0,0)),p.reduce((d,u,c)=>d+u*ln[c],0)):p.reduce((d,u,c)=>d+u*ne(se[c],a,n),0)}function go(o,r){return Number.isFinite(r)?ae(a=>un(a,r),re(o)):fo(o)}var bo={cs:8,dota:1/0};function dn(o,r,a,n=0,p=0){return Number.isFinite(r)?cn(o*r+n,(1-o)*r+p).reduce((u,c,m)=>u+c*ze(se[m],a,n,p),0):ze(o,a,n,p)}function xo(o,r,a){return Number.isFinite(a)?ae(n=>dn(n,a,r),re(o)):mo(o,r)}function vo(o,r){let a=Math.max(o,r),n=Math.min(o,r);return n<12?a>=13:a-12-3*Math.floor((n-12)/3)>=4}function pn({pre:o,bo:r=3,maps:a=[0,0],rounds:n=null,game:p="cs",kappa:d=ho,kappaMap:u=bo[p]??1/0}){let c=Math.ceil(r/2),[m,h]=(a||[0,0]).map(O=>Math.max(0,Number(O)||0));if(m>=c)return{p:1,map:null};if(h>=c)return{p:0,map:null};let k=xo(o,r,u),x=(O,I)=>dn(k,u,r,O,I),[g,y]=Array.isArray(n)&&n.length===2?n.map(Number):[NaN,NaN];if(!Number.isFinite(g)||!Number.isFinite(y)||g===0&&y===0||vo(g,y))return{p:x(m,h),map:null};let T=Number.isFinite(u)?(k*u+m)/(u+m+h):k,F=un(go(T,d),d,g,y);return{p:F*x(m+1,h)+(1-F)*x(m,h+1),map:F}}var K=(o,r=0)=>kt(o,r),mt=o=>`${o>0?"+":o<0?"−":""}${Math.abs(o).toFixed(1)}`;function mn({bus:o,actions:r,brand:a}){let n=document.createElement("div");n.id=o.rootId,n.style.cssText="position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important;z-index:2147483640!important;display:block!important;";let p=n.attachShadow({mode:"open"});p.appendChild(t("style",{text:ee+rn}));let d=t("span.dot"),u=t("button.fab",{type:"button","data-act":"toggle",title:`${a.name}: открыть панель`,"aria-label":`${a.name}: открыть панель`},at("lens",18),t("span",{text:a.name}),d),c=t("div.tabs",{role:"tablist"}),m=t("div.body"),h=t("div.foot"),k=t("small"),x=t("button.iconbtn",{type:"button","data-act":"theme",title:"Светлая или тёмная тема","aria-label":"Сменить тему"}),g=t("button.iconbtn",{type:"button","data-act":"overlay-toggle",title:"Отметки на странице","aria-label":"Отметки на странице"}),y=t("button.iconbtn",{type:"button","data-act":"tab","data-arg":"settings",title:"Настройки","aria-label":"Настройки"},at("gear")),T=t("div.head",{},t("div.brand",{},t("span.logo",{},at("lens",15)),t("span",{text:a.name}),k),t("span.grow"),g,x,y,t("button.iconbtn",{type:"button","data-act":"close",title:"Закрыть","aria-label":"Закрыть"},at("close"))),F=t("section.panel",{hidden:!0,role:"dialog","aria-label":a.name},T,c,m,h);p.append(u,F);let O=()=>{n.isConnected||document.documentElement.appendChild(n)};O(),new MutationObserver(O).observe(document.documentElement,{childList:!0});let I="",j=null,E=new Map,W=e=>{for(let s of e.composedPath()){if(s===n)break;if(s?.dataset?.act)return s}return null},_=null;o.on("ui:pointerdown",e=>{if(e.button!==0)return;let s=e.composedPath(),l=s.includes(u),b=s.includes(T)&&!s.some($=>$?.dataset?.act);if(!l&&!b)return;let v=l?u:F,z=v.getBoundingClientRect();_={target:v,key:l?"fab":"panel",sx:e.clientX,sy:e.clientY,ox:z.left,oy:z.top,moved:!1},o.setDragging(!0)}),o.on("drag:move",e=>{if(!_)return;let s=e.clientX-_.sx,l=e.clientY-_.sy;!_.moved&&Math.hypot(s,l)<5||(_.moved=!0,_.target.classList.add("dragging"),S(_.target,_.ox+s,_.oy+l))}),o.on("drag:end",()=>{if(_){if(o.setDragging(!1),_.target.classList.remove("dragging"),_.moved){let e=_.target.getBoundingClientRect();r.savePosition(_.key,{left:e.left,top:e.top}),M=!0,setTimeout(()=>{M=!1},60)}_=null}});let M=!1;function S(e,s,l){let b=e.offsetWidth||120,v=e.offsetHeight||40,z=Math.max(6,Math.min(s,window.innerWidth-b-6)),$=Math.max(6,Math.min(l,window.innerHeight-Math.min(v,60)-6));e.style.left=`${Math.round(z)}px`,e.style.top=`${Math.round($)}px`,e.style.right="auto"}o.on("ui:click",e=>{if(M)return;let s=W(e);if(!s||s.disabled)return;e.preventDefault();let l=s.dataset.act;if(l==="toggle")return _t();if(l==="close")return St();let b=r[l];b&&b(s.dataset.arg,s,p)}),o.on("ui:keydown",e=>{if(e.key==="Escape"&&St(),e.key==="Enter"){let s=e.composedPath()[0];s?.dataset?.enter&&r[s.dataset.enter]?.(s.value,s,p)}});let C=(e,s)=>t("span.form",{},[...String(e||"")].slice(0,5).map(l=>t(`i${l==="В"?".w":l==="П"?".l":""}`,{text:l,title:{В:"Победа",Н:"Ничья",П:"Поражение"}[l]||""})),s);function P(e){let s=e.live,l=s?t("div.center",{},s.score?.length===2?t("span.score",{text:`${s.score[0]} : ${s.score[1]}`}):null,t("span.badge.live",{text:s.state||"Лайв"})):t("div.center",{},t("span",{text:e.start||"до матча"})),b=s?.periods?.length?t("div.periods",{text:s.periods.map(z=>z.raw?`${z.label} ${z.raw}`:`${/^\d+$/.test(z.label)?`${z.label}-й отрезок`:z.label} ${z.home}:${z.away}`).join(" · ")}):null,v=s?.extras?.length?t("div.periods",{text:s.extras.map(z=>`${z.kind} ${z.home}:${z.away}`).join(" · ")}):null;return t("div.card",{},t("div.league",{text:e.league||e.sportName||"",title:e.league||""}),t("div.teams",{},t("div.team",{},t("b",{text:e.home,title:e.home}),e.form?.home?C(e.form.home):null),l,t("div.team.away",{},t("b",{text:e.away,title:e.away}),e.form?.away?C(e.form.away):null)),b,v)}function q(e){let s=e.rows.some(l=>Number.isFinite(l.model));return t("div.card",{},t("div.kicker",{},t("span",{text:e.title}),Number.isFinite(e.margin)?t("span.badge",{title:"Сколько контора закладывает себе в этот рынок",text:`маржа ${K(e.margin,1)}`}):null),e.rows.map(l=>{let b=s&&Number.isFinite(l.model)?(l.model-l.fair)*100:null;return t("div.prob",{},t("span.name",{text:l.name,title:l.name}),t("span.odd",{text:X(l.odd)}),t("span.track",{},t("i",{style:`width:${Math.round((l.fair||0)*100)}%`}),Number.isFinite(l.model)?t("u",{style:`left:${Math.round(l.model*100)}%`}):null),t("span.pct",{},K(s&&Number.isFinite(l.model)?l.model:l.fair),b!=null&&Math.abs(b)>=.05?t(`small${b>0?".pos":".neg"}`,{text:`${mt(b)} п.п.`}):null))}),t("div.legend",{},t("span",{text:"шанс по линии без маржи"}),s?t("span.model",{text:"оценка модели"}):null))}function V(e){let s=e.analysis;if(s.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge.accent",{text:"собираю данные"})),t("div.steps",{},s.steps.map(($,w)=>t(`div.step${w===s.steps.length-1?".now":".done"}`,{},t("span.mark"),t("span",{text:$})))));if(s.status==="error")return t("div.card",{},t("div.note.warn",{},at("alert"),t("span",{text:s.error})),t("div.row",{style:"margin-top:10px"},s.needKey?t("button.btn.ghost",{type:"button","data-act":"tab","data-arg":"settings"},at("gear"),"Открыть настройки"):null,t("button.btn.ghost",{type:"button","data-act":"report"},"Сообщить об ошибке")));if(s.status!=="done"||!s.result)return null;let l=s.result,b={home:e.match?.home,away:e.match?.away,draw:"ничья"}[l.lean],v=l.proposed?.lean&&l.proposed.lean!=="none"&&l.lean==="none"?{name:{home:e.match?.home,away:e.match?.away,draw:"ничью"}[l.proposed.lean],by:Math.abs(l.proposed.shift[l.proposed.lean]||0)}:null,z=new Map((l.facts||[]).map($=>[$.id,$]));return t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор"}),t("span.badge",{title:"Насколько данных хватает для вывода",text:`уверенность: ${l.confidence||"низкая"}`})),t("div.verdict",{text:b?`Данные сдвигают оценку в сторону: ${b}`:v?`Данные слегка склоняют в сторону: ${v.name}`:"Модель согласна с линией: причин спорить с ценой нет"}),v?t("div.note",{style:"margin-bottom:10px"},at("info"),t("span",{text:`Модель предложила сдвиг на ${v.by.toFixed(1)} п.п. На проверке такие сдвиги не делали оценку точнее линии, поэтому проценты оставлены рыночными.`})):null,l.summary?t("p.summary",{text:l.summary}):null,l.factors?.length?t("ul.factors",{},l.factors.map($=>t(`li.factor${$.side==="home"?".home":$.side==="away"?".away":""}`,{},t("div",{},t("p",{text:$.text}),t("div.src",{},($.facts||[]).map(w=>z.get(w)).filter(Boolean).map(w=>t("span.tag",{text:`${w.id} · ${w.source}`,title:w.text}))))))):null,l.scenarios?.length?t("div",{style:"margin-top:10px"},t("div.kicker",{},t("span",{text:"Как может пойти игра"})),t("ul.facts",{},l.scenarios.map($=>t("li",{},t("span",{text:$.text})," ",t("em",{text:`— ${$.facts.join(", ")}`}))))):null,l.risks?.length?t("div.note",{style:"margin-top:10px"},at("info"),t("span",{text:`Что может сломать вывод: ${l.risks.join(" ")}`})):null,(l.full?.sections||[]).some($=>$?.lines?.length)?t("details",{"data-key":"full",open:E.get("full")||!1,style:"margin-top:8px"},t("summary",{text:"Показать полностью: итог по всем рынкам, профили, факты"}),(l.full.sections||[]).filter($=>$?.title&&$.lines?.length).map($=>t("div",{style:"margin-top:6px"},t("div.kicker",{},t("span",{text:$.title})),t("ul.facts",{},$.lines.map(w=>t("li",{text:w})))))):null,t("div.row",{style:"margin-top:8px"},t("button.btn.ghost.small",{type:"button","data-act":"report",title:"Разбор выглядит неправильно — сообщить разработчику"},"Сообщить об ошибке")),t("details",{"data-key":"facts",open:E.get("facts")||!1},t("summary",{text:`Данные, на которых стоит разбор (${l.facts?.length||0})`}),t("ul.facts",{},(l.facts||[]).map($=>t("li",{},t("b",{text:$.id}),t("span",{},$.text," ",t("em",{text:`— ${$.source}`})))))),U(l.research),t("div.hint",{style:"margin-top:8px",text:l.meta?.note||"Модель двигает оценку линии не больше чем на несколько пунктов и только по данным выше."}))}function U(e){return e?e.skipped==="plan"?t("div.hint",{style:"margin-top:8px",text:"Поиск превью, травм и судей в прессе — в тарифах «Макс» и VIP."}):e.sources?.length?t("div.hint",{style:"margin-top:8px"},`${e.note} Прочитано: `,e.sources.map((s,l)=>[l?", ":"",t("a",{href:s.url,target:"_blank",rel:"noopener",text:s.domain})])):e.note?t("div.hint",{style:"margin-top:8px",text:e.note}):null:null}function nt(e){let s=e.compare?.consensus||e.analysis?.result?.consensus||e.consensus;if(!s?.consensus||!e.line?.rows?.length)return null;let l=s.consensus.length===2&&e.line.rows.length===3;if(!l&&e.line.rows.length!==s.consensus.length)return null;let b=l?e.line.overtime:null,v=b?b.rows:l?[e.line.rows[0],e.line.rows[2]].map(w=>({...w,odd:null,fair:null})):e.line.rows,z=e.match?.sport==="mma",$=s.updated?new Date(s.updated).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"";return t("div.card",{},t("div.kicker",{},t("span",{text:l?z?"Прогноз рынка · без ничьей":"Прогноз рынка · с овертаймом":"Прогноз рынка"}),t("span.badge",{text:`${s.count} контор`})),v.map((w,N)=>{let A=s.consensus[N],B=w.odd?w.odd*A-1:0,L=Number.isFinite(w.fair)?(w.fair-A)*100:0;return t("div.prob",{},t("span.name",{text:w.name,title:w.name}),t("span.odd",{text:X(1/A),title:"Кэф без маржи по консенсусу"}),t("span.track",{},t("i",{style:`width:${Math.round(A*100)}%`}),t("u",{style:`left:${Math.round((w.fair||0)*100)}%`,title:"Шанс по линии этой конторы"})),t("span.pct",{},K(A),B>.005?t("small.pos",{text:`кэф выше рынка ${mt(B*100)}%`}):Math.abs(L)>=2?t(`small${L>0?".neg":""}`,{text:`${mt(L)} п.п. к рынку`,title:L>0?"Контора оценивает этот исход выше рынка — кэф ниже":"Контора оценивает этот исход ниже рынка"}):null))}),t("div.legend",{},t("span",{text:"шанс по консенсусу"}),l&&!b?null:t("span.model",{text:b?`шанс по рынку «${b.title}» этой конторы`:"шанс по линии этой конторы"})),t("div.hint",{style:"margin-top:8px",text:`${l&&z?"Ничьи в ММА — доли процента, поэтому рынок двухисходный; ничья этой конторы не сравнивается. ":l?b?"Победитель с учётом овертайма и буллитов: сравнивается с одноимённым рынком этой конторы, а не с трёхисходным. ":"Победитель с учётом овертайма и буллитов; ничья в основное время сюда не входит, поэтому с трёхисходным рынком конторы напрямую не сравнивается. ":""}${s.pinnacle?`Pinnacle ${s.pinnacle.map(X).join(" / ")}. `:""}${s.betfair?`Betfair ${s.betfair.map(X).join(" / ")}. `:""}Цены ${s.count} контор без маржи${$?`, обновлено в ${$}`:""}${s.stale?" (данные старше шести часов)":""}. На проверке 1915 матчей фаворит по консенсусу выиграл 54% — точнее этого прогноза у нас нет.`}))}let Q=new Map;function st(e,s){let l=e.match?.live;if(!l||!["cs","dota"].includes(s.game)||l.score?.length!==2)return null;let b=l.score.map(Number),v=Number(s.bo)||3;if(b.some(w=>!Number.isFinite(w)||w<0)||Math.max(...b)>=Math.ceil(v/2))return null;let z=s.game==="cs"&&l.rounds?.length===2&&l.rounds.every(w=>/^[0-9]{1,2}$/.test(String(w)))?l.rounds.map(Number):null,$=`${s.p1}|${v}|${b}|${z}`;return Q.has($)||(Q.size>50&&Q.clear(),Q.set($,{...pn({pre:s.p1,bo:v,maps:b,rounds:z,game:s.game}),bo:v,maps:b,rounds:z})),Q.get($)}function J(e){let s=e.compare?.model||e.analysis?.result?.model||e.model;if(!s?.p1||!e.line?.rows?.length)return null;let l=e.line.rows.length===3&&(s.overtime||s.drawless);if(!l&&e.line.rows.length!==2)return null;let b=l?e.line.overtime:null,v=b?b.rows:l?[e.line.rows[0],e.line.rows[2]].map(G=>({...G,fair:null})):e.line.rows,z=st(e,s),$=z?[z.p,1-z.p]:[s.p1,s.p2],w=s.sport==="tennis"?`Рейтинги Линзы по покрытиям, форме, нагрузке и очным встречам (архив ATP/WTA, ${s.samples} матчей у менее опытного игрока)`:s.sport==="hockey"?`Рейтинги Линзы по матчам КХЛ: атака и оборона команд, дом, усталость (приложение КХЛ, 2023–2026; ${s.samples} игр у менее опытной команды)${s.regulation?`. Основное время: ${Math.round(s.regulation.p1*100)}% / ничья ${Math.round(s.regulation.px*100)}% / ${Math.round(s.regulation.p2*100)}%`:""}`:s.sport==="mma"?`Рейтинги Линзы по боям UFC: Elo с весом досрочных побед, форма, возраст, размах рук, простой (ESPN; ${s.samples} боёв в UFC у менее опытного бойца)`:s.sport==="basketball"?`Рейтинги Линзы по разнице очков, дому и усталости (НБА, Евролига, Еврокубок, АСВ, Серия А, Адриатическая лига, ВТБ, Лига чемпионов FIBA; ${s.samples} игр у менее опытной команды)`:s.game==="dota"?`Рейтинги Линзы по матчам, форме и очным встречам (bo3.gg, ${s.samples} ${xt(s.samples,"матч","матча","матчей")} у менее опытной команды)`:`Рейтинги Линзы по картам, форме и очным встречам (bo3.gg, ${s.samples} ${xt(s.samples,"карта","карты","карт")} у менее опытной команды)`,N=s.backtest,A=(N?.calibration||[]).filter(G=>[60,70,80].includes(G.threshold)),B=N?.labels?.[s.confidence],L=(B?`С подписью «${s.confidence}» на проверке сбывалось ${K(B.hit/100,1)} (${B.n} ${xt(B.n,"матч","матча","матчей")}). `:"")+(A.length?`На проверке ${N.test} сыгранных матчей: ${A.map(G=>`при уверенности ≥${G.threshold}% сбывалось ${G.hit}%`).join(", ")}`:N?`На проверке ${N.test} матчей угадано ${Math.round(N.acc*100)}%`:"Точность ещё измеряется");return t("div.card",{},t("div.kicker",{},t("span",{text:z?`Модель по счёту · bo${z.bo}`:l?s.drawless?"Прогноз модели · без ничьей":"Прогноз модели · с овертаймом":"Прогноз модели"}),t("span.badge",{text:z?`до матча: ${s.confidence}`:`уверенность: ${s.confidence}`})),v.map((G,Z)=>{let tt=$[Z],et=Number.isFinite(G.fair)?(tt-G.fair)*100:0;return t("div.prob",{},t("span.name",{text:G.name,title:G.name}),t("span.odd",{text:X(1/tt),title:"Кэф без маржи по модели"}),t("span.track",{},t("i",{style:`width:${Math.round(tt*100)}%`}),t("u",{style:`left:${Math.round((G.fair||0)*100)}%`,title:"Шанс по линии конторы"})),t("span.pct",{},K(tt),Math.abs(et)>=3?t(`small${et>0?".pos":".neg"}`,{text:`${mt(et)} п.п. к линии`}):null))}),t("div.legend",{},t("span",{text:z?"шанс серии по счёту":"оценка модели"}),t("span.model",{text:"шанс по линии конторы"})),z?t("div.hint",{style:"margin-top:6px",text:`Счёт по картам ${z.maps.join(":")}${z.rounds?`, на карте ${z.rounds.join(":")} — шанс текущей карты ${K(z.map??.5)}`:""}. До матча модель давала ${K(s.p1)} / ${K(s.p2)}.`}):null,ct(s,v),s.factors?.length?t("ul.facts",{style:"margin-top:8px"},s.factors.slice(0,s.sport==="mma"?12:4).map(G=>t("li",{},t("span",{text:G})))):null,t("div.hint",{style:"margin-top:8px",text:z?`Шанс по ходу матча пересчитывается из прогноза до матча и счёта: выигранные карты${s.game==="cs"?" и раунды":""} уточняют силу команд. ${s.game==="cs"?"Проверка на сыгранных сериях CS: при 1:0 в bo3 модель давала в среднем 82%, сбылось 83% (2 905 серий)":"Проверка на сыгранных сериях Dota: при 1:1 модель давала в среднем 53%, сбылось 55% (516 серий)"}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`:`${w}. ${L}. Это оценка, а не обещание: линия конторы остаётся ориентиром.`}))}function rt(e){let[s,l]=e.names,b=["0","15","30","40","Б"],v=e.tiebreak?e.points.join(":"):e.points.map(w=>b[Math.min(4,w)]||w).join(":"),z=e.sets.map(([w,N])=>`${w}:${N}`).concat(`${e.games[0]}:${e.games[1]}`).join(" "),$=e.serving==null?"":` · подаёт ${e.names[e.serving]}`;return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"}),t("span.badge",{text:`${e.score.join(":")} по сетам · ${z} · ${v}${e.tiebreak?" (тай-брейк)":""}`})),e.names.map((w,N)=>{let A=e.probs[N],B=e.book?e.book[N]:null,L=e.compare&&Number.isFinite(B)?(A-B)*100:0;return t("div.prob",{},t("span.name",{text:w,title:w}),t("span.odd",{text:X(1/A),title:"Честный кэф на матч по счёту"}),t("span.track",{},t("i",{style:`width:${Math.round(A*100)}%`}),Number.isFinite(B)?t("u",{style:`left:${Math.round(B*100)}%`,title:"Шанс по цене этой конторы"}):null),t("span.pct",{},K(A),Math.abs(L)>=3?t(`small${L>0?".pos":".neg"}`,{text:`${mt(L)} п.п. к цене`}):null))}),t("div.legend",{},t("span",{text:"шанс матча по счёту"}),e.book?t("span.model",{text:"шанс по цене этой конторы"}):null),t("ul.facts",{style:"margin-top:8px"},t("li",{},t("span",{text:`Текущий сет: ${s} ${K(e.set[0])} (кэф ${X(1/e.set[0])}) · ${l} ${K(e.set[1])} (${X(1/e.set[1])})`})),t("li",{},t("span",{text:`Текущий ${e.tiebreak?"тай-брейк":"гейм"}${$}: ${s} ${K(e.game[0])} · ${l} ${K(e.game[1])}`})),t("li",{},t("span",{text:`Очко на своей подаче (под довоенную силу): ${s} ${e.serve[0]}%, ${l} ${e.serve[1]}%; матч до ${e.bestOf===5?"трёх":"двух"} выигранных сетов.`}))),t("div.hint",{style:"margin-top:8px",text:`Счёт, очки и подача — лайв Fonbet. Довоенная сила: ${e.prior.note}.${e.compare?"":" Без довоенной цены оценка подстроена под текущую цену Fonbet — как сигнал против конторы её не используйте."} Проверено на 10 064 моментах матчей ATP/WTA 2025–2026 (после каждого сета): при оценке 80–85% сбылось 82,9%, 85–90% — 87,8%. Это расчёт, а не обещание.`}))}function ft(e){let[s,l]=e.names,b=B=>B?X(B):"—",v=e.sport==="hockey"?"период":"тайм",z=`${e.minute}' · ${Math.min(e.period,e.periods)}-й ${v}`,$=[s,"Ничья",l],w=B=>B>0?`+${B}`:`${B}`,N=(B,L,G,Z,tt,et)=>L?.length?t("details",{"data-key":`live-${B}`,open:E.get(`live-${B}`)||!1},t("summary",{text:B}),t("ul.facts",{},L.map(R=>t("li",{},t("span",{text:`${tt(R)} — ${b(R[G])} · ${et(R)} — ${b(R[Z])}`}))))):null,A=e.red[0]||e.red[1]?` · удаления ${e.red.join(":")}`:"";return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"}),t("span.badge",{text:`${e.score.join(":")} · ${z}${A}`})),$.map((B,L)=>{let G=e.probs[L],Z=e.book?e.book[L]:null,tt=e.compare&&Number.isFinite(Z)?(G-Z)*100:0;return t("div.prob",{},t("span.name",{text:B,title:B}),t("span.odd",{text:X(1/G),title:"Честный кэф по счёту"}),t("span.track",{},t("i",{style:`width:${Math.round(G*100)}%`}),Number.isFinite(Z)?t("u",{style:`left:${Math.round(Z*100)}%`,title:"Шанс по цене этой конторы"}):null),t("span.pct",{},K(G),Math.abs(tt)>=3?t(`small${tt>0?".pos":".neg"}`,{text:`${mt(tt)} п.п. к цене`}):null))}),t("div.legend",{},t("span",{text:"шанс по счёту (основное время)"}),e.book?t("span.model",{text:"шанс по цене этой конторы"}):null),t("ul.facts",{style:"margin-top:8px"},t("li",{},t("span",{text:`Следующий гол: ${s} ${K(e.nextGoal[0])} · не будет ${K(e.nextGoal[1])} · ${l} ${K(e.nextGoal[2])}. Ожидаемый итоговый тотал ≈${e.expTotal}.`})),e.bookLines?.total?t("li",{},t("span",{text:`Тотал ${e.bookLines.total.line}: Fonbet ${e.bookLines.total.odds.map(X).join(" / ")}, честно ${e.bookLines.total.fair.map(b).join(" / ")}`}),Math.abs(e.bookLines.total.gap)>=5?t(`small${e.bookLines.total.gap>0?".pos":".neg"}`,{text:` ${mt(e.bookLines.total.gap)} п.п. к «больше»`}):null):null),N("Тотал — честные кэфы",e.total,"over","under",B=>`больше ${B.line}`,B=>`меньше ${B.line}`),N("Фора — честные кэфы",e.handicap,"home","away",B=>`${s} ${w(B.line)}`,B=>`${l} ${w(-B.line)}`),t("div.hint",{style:"margin-top:8px",text:`Счёт, время${e.sport==="football"?" и удаления":""} — лайв Fonbet${e.clock==="timer"?"":" (время приблизительное)"}. Довоенная сила: ${e.prior.note}.${e.compare?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на ${e.sport==="hockey"?"1 407 играх НХЛ":"1 837 матчах 5 топ-лиг (11 тыс. точек)"}: при оценке 80–85% сбылось 82,5%. Это расчёт, а не обещание.`}))}function Mt(e,s,l,b){let v=e.bookLines;if(!v)return null;let z=w=>w>0?`+${w}`:`${w}`,$=(w,N,A,B)=>t("li",{},t("span",{text:`${w}: Fonbet ${N.map(X).join(" / ")}, честно ${A.map(L=>L?X(L):"—").join(" / ")}`}),b&&Math.abs(B)>=5?t(`small${B>0?".pos":".neg"}`,{text:` ${mt(B)} п.п. к первой стороне`}):null);return t("ul.facts",{style:"margin-top:8px"},v.handicap?$(`Фора ${s} ${z(v.handicap.line)} / ${l} ${z(-v.handicap.line)}`,v.handicap.odds,v.handicap.fair,v.handicap.gap):null,v.total?$(`Тотал ${v.total.line} больше / меньше`,v.total.odds,v.total.fair,v.total.gap):null)}function gt(e){let s=e.live;if(!s)return null;if(s.kind==="goals")return ft(s);if(s.kind==="tennis")return rt(s);if(s.error)return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"})),t("div.hint",{text:s.error}));let[l,b]=s.names,v=L=>L?X(L):"—",z=s.book&&(s.prior.source==="line"||s.prior.source==="model"),$=s.left>0?`${s.period>s.format.periods?"ОТ":`${s.period}-я четв.`} · осталось ≈${Math.max(1,Math.round(s.left))} мин`:"конец игры",w=(L,G,Z,tt,et,R)=>G.length?t("details",{"data-key":`live-${L}`,open:E.get(`live-${L}`)||!1},t("summary",{text:L}),t("ul.facts",{},G.map(H=>t("li",{},t("span",{text:`${et(H)} — ${v(H[Z])} · ${R(H)} — ${v(H[tt])}`}))))):null,N=L=>L>0?`+${L}`:`${L}`,A=s.quarter,B=A&&A.left>0?`${A.index}-я четверть (${A.score.join(":")}, осталось ≈${Math.max(1,Math.round(A.left))} мин): ${l} ${v(A.probs[0]?1/A.probs[0]:null)} · ничья ${v(A.draw?1/A.draw:null)} · ${b} ${v(A.probs[1]?1/A.probs[1]:null)}; разница ${A.expMargin>=0?l:b} ${Math.abs(A.expMargin).toFixed(1)}, тотал четверти ≈${A.projTotal}.`:"";return t("div.card",{},t("div.kicker",{},t("span",{text:"Лайв по счёту"}),t("span.badge",{text:`${s.score.join(":")} · ${$}`})),s.names.map((L,G)=>{let Z=s.probs[G],tt=s.book?s.book[G]:null,et=z&&Number.isFinite(tt)?(Z-tt)*100:0;return t("div.prob",{},t("span.name",{text:L,title:L}),t("span.odd",{text:X(1/Z),title:"Честный кэф по счёту"}),t("span.track",{},t("i",{style:`width:${Math.round(Z*100)}%`}),Number.isFinite(tt)?t("u",{style:`left:${Math.round(tt*100)}%`,title:"Шанс по цене этой конторы"}):null),t("span.pct",{},K(Z),Math.abs(et)>=3?t(`small${et>0?".pos":".neg"}`,{text:`${mt(et)} п.п. к цене`}):null))}),t("div.legend",{},t("span",{text:"шанс по счёту (с ОТ)"}),s.book?t("span.model",{text:"шанс по цене этой конторы"}):null),Mt(s,l,b,z),t("ul.facts",{style:"margin-top:8px"},t("li",{},t("span",{text:`Ожидаемая итоговая разница: ${s.expMargin>=0?l:b} ${Math.abs(s.expMargin).toFixed(1)} (разброс ±${s.sd}). Тотал ≈${s.projTotal} (±${s.sdTotal}).`})),B?t("li",{},t("span",{text:B})):null),w("Фора — честные кэфы",s.handicap,"home","away",L=>`${l} ${N(L.line)}`,L=>`${b} ${N(-L.line)}`),w("Тотал матча — честные кэфы",s.total,"over","under",L=>`больше ${L.line}`,L=>`меньше ${L.line}`),w("Тотал четверти — честные кэфы",s.quarterTotal,"over","under",L=>`больше ${L.line}`,L=>`меньше ${L.line}`),t("div.hint",{style:"margin-top:8px",text:`Счёт и время — лайв Fonbet${s.clock==="timer"?"":" (время в четверти оценено по очкам — приблизительно)"}. Довоенная сила: ${s.prior.note}.${z?"":" Без довоенной цены оценка подстроена под текущие цены Fonbet — как сигнал против конторы её не используйте."} Проверено на 8 923 играх Евролиги, Еврокубка и НБА: в перерыве при оценке 75–80% побеждали в 78% случаев. Это расчёт, а не обещание; задержка табло у конторы бывает до минуты.`}))}function pt(e){let s=e.verdict;return s?.lines?.length?t("div.card",{},t("div.kicker",{},t("span",{text:"Итог"}),t("span.badge",{text:s.best?`перевес ${Math.round(s.best.edge*100)}%`:"без перевеса"})),t("ul.facts",{},s.lines.map(l=>t("li",{},t("span",{text:l})))),s.track?t("div.hint",{style:"margin-top:6px",text:s.track}):null,e.analysis.status!=="done"?t("div.hint",{style:"margin-top:6px",text:"Доводы «за» и главный риск появятся после «Разобрать матч»."}):null):null}function ct(e,s){let l=e.durations;if(e.sport!=="mma"||!l)return null;let b=z=>z?X(z):"—",v=s.map(z=>z.name);return t("div",{style:"margin-top:10px"},t("div.kicker",{},t("span",{text:"Честные кэфы"}),t("span.badge",{text:`${l.rounds} ${l.rounds===5?"раундов":"раунда"}`})),t("ul.facts",{},t("li",{},t("span",{text:`Победа: ${v[0]||"первый"} ${b(e.fair?.p1)} · ${v[1]||"второй"} ${b(e.fair?.p2)}`})),l.lines.map(z=>t("li",{},t("span",{text:`Тотал ${z.line} раунда: больше ${b(z.over)} · меньше ${b(z.under)}`}))),t("li",{},t("span",{text:`Дойдёт до решения: да ${b(l.decision.yes)} · нет ${b(l.decision.no)}`})),t("li",{},t("span",{text:`Конец боя: 1-й раунд ${Math.round(l.r1*100)}%, 2-й ${Math.round(l.r2*100)}%, позже ${Math.round(l.r3*100)}%, решение ${Math.round(l.dec*100)}%`}))),t("div.hint",{text:"Кэф конторы выше честного — ставка в плюс по модели, ниже — в минус. Длительность считается по всем боям бойцов в UFC и их весовой; проверка на 565 боях: точнее, чем средние цифры по весовой."}))}function ut(e){let l=((e.compare?.model||e.analysis?.result?.model||e.model)?.profiles||[]).filter(b=>b?.lines?.length);return l.length?t("div.card",{},t("div.kicker",{},t("span",{text:"Профили"}),t("span.badge",{text:"модель Линзы"})),l.map((b,v)=>t("details",{"data-key":`profile-${v}`,open:E.get(`profile-${v}`)??v===0},t("summary",{text:b.name}),t("ul.facts",{},b.lines.map(z=>t("li",{},t("span",{text:z})))))),t("div.hint",{style:"margin-top:8px",text:"Из рейтингов Линзы по открытым данным (ESPN, архив ATP/WTA, Евролига, bo3.gg). Это описание, а не прогноз."})):null}function Lt(e){let s=e.facts;if(!s?.facts?.length)return null;let l=s.facts.filter($=>/травм|отсутств|не играет|стенд-ин|замен|дисквалиф/i.test($.text)),b=s.facts.filter($=>!l.includes($)&&/состав|стартов/i.test($.text)),v=s.facts.filter($=>!l.includes($)&&!b.includes($)),z=($,w,N)=>w.length?t("details",{"data-key":`facts-${$}`,open:N||E.get(`facts-${$}`)||!1},t("summary",{text:`${$} (${w.length})`}),t("ul.facts",{},w.map(A=>t("li",{},t("span",{text:A.text}))))):null;return t("div.card",{},t("div.kicker",{},t("span",{text:"Составы, травмы, форма"}),t("span.badge",{text:s.source||s.facts[0].source||"источник"})),z("Травмы и отсутствующие",l,!0),z("Составы",b,!0),z("Форма, таблица, очные встречи",v,!l.length&&!b.length),t("div.hint",{style:"margin-top:8px"},"Факты из открытых данных, как есть. ",s.url?t("a",{href:s.url,target:"_blank",rel:"noopener",text:"Источник"}):null))}let bt=e=>`${Math.round(e).toLocaleString("ru-RU")} ₽`,xt=(e,s,l,b)=>{let v=e%100,z=e%10;return v>10&&v<20?b:z===1?s:z>=2&&z<=4?l:b},zt=e=>(e.erid?["Реклама",e.legal,`erid ${e.erid}`].filter(Boolean).join(" · "):["Партнёрская ссылка",e.legal].filter(Boolean).join(" · "))+" · 18+",Ot=(e,s)=>t("a.btn.ghost.small",{href:e.go?`${e.go}?s=panel`:e.url,target:"_blank",rel:"noopener sponsored"},at("link",13),s||`Открыть у ${e.name}`),Ct=e=>e.code?t("button.btn.ghost.small",{type:"button","data-act":"copy-code","data-arg":e.code,title:e.bonus||"Скопировать промокод"},`Промокод ${e.code}`):null;function ue(e){let s=(e.partners||[]).filter(l=>l.url||l.code);return s.length?t("div.card.soft",{},t("div.kicker",{},t("span",{text:s.length===1?`Промокод ${s[0].name}`:"Промокоды контор"})),s.map(l=>t("div.partner",{},t("div.partner-text",{},t("b",{text:l.name}),l.bonus?t("span",{text:` — ${l.bonus}`}):null),t("div.partner-links",{},Ct(l),l.url?Ot(l):null),t("div.hint",{text:zt(l)})))):null}function de(e,s={}){if(e.status==="idle")return null;if(e.status==="loading")return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:"Смотрю открытые линии…"}));let l=e.labels||[];if(!e.rows?.length)return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"})),t("div.hint",{text:e.note||"В открытых линиях этой пары нет."}));let b=l.map((L,G)=>Math.max(...e.rows.map(Z=>Z.odds[G]||0))),v=Object.fromEntries((s.partners||[]).map(L=>[L.id,L])),z=L=>L.book&&L.book!==s.bookId&&!L.sharp&&v[L.book]||null,$=s.stake||1e3,w=e.rows.find(L=>L.here)||e.rows[0],A=l.map((L,G)=>{let Z=w?.odds?.[G],tt=e.rows.filter(et=>et!==w&&!et.sharp&&et.odds[G]).sort((et,R)=>R.odds[G]-et.odds[G])[0];return!Z||!tt||tt.odds[G]<=Z?null:{label:L,row:tt,odd:tt.odds[G],mine:Z,gain:(tt.odds[G]-Z)*$}}).filter(Boolean).sort((L,G)=>G.gain-L.gain)[0],B=e.rows.map(z).filter(Boolean);return t("div.card",{},t("div.kicker",{},t("span",{text:"Цены других контор"}),t("span.badge",{text:"лучшая цена выделена"})),t("table",{},t("tr",{},t("th",{text:"Контора"}),l.map(L=>t("th",{text:L}))),e.rows.map(L=>{let G=z(L);return t("tr",{},t("td.name",{title:L.sharp?"Цена с мирового рынка, для сравнения":""},L.name,G?t("div.partner-links",{},G.url?Ot(G):null,Ct(G)):null),L.odds.map((Z,tt)=>t(`td${Z&&Z===b[tt]&&e.rows.length>1?".best":""}`,{text:Z?X(Z):"—"})))})),A&&A.gain>=1?t("div.gain",{},`На «${A.label}» у ${A.row.name} кэф ${X(A.odd)} против ${X(A.mine)} здесь: со ставки ${bt($)} выигрыш больше на `,t("b",{text:bt(A.gain)}),"."):null,B.length?t("div.hint",{style:"margin-top:6px",text:[...new Set(B.map(zt))].join(" ")}):null,e.note?t("div.hint",{style:"margin-top:8px",text:e.note}):null)}function pe(e){let s=[],l=(v,z,$)=>s.push(t("dt",{text:v}),t(`dd${$?"."+$:""}`,{text:z}));Number.isFinite(e.fair)?(l("Шанс по линии без маржи",K(e.fair,1)),l("Кэф без маржи конторы",X(e.fairOdd)),l("Маржа конторы в этом рынке",K(e.margin,1))):l("Заложено в кэфе (с маржой)",K(1/e.odd,1)),Number.isFinite(e.model)&&(l("Оценка модели",K(e.model,1)),l("Ожидание на рубль по модели",`${mt(e.ev*100)}%`,e.ev>.005?"pos":e.ev<-.005?"neg":"")),e.best&&l(`Лучшая цена: ${e.best.name}`,X(e.best.odd),e.best.odd>e.odd?"pos":"");let b=e.best?.partner&&(e.best.partner.url||e.best.partner.code)?e.best.partner:null;return t("div.card.accent",{},t("div.kicker",{},t("span",{text:e.market}),t("button.iconbtn",{type:"button","data-act":"pick-clear",title:"Убрать",style:"width:22px;height:22px"},at("close",13))),t("div.pick-head",{},t("span.big",{text:X(e.odd)}),t("span.what",{text:e.label,title:e.label})),t("dl.kv",{},s),e.note?t("div.hint",{style:"margin-top:8px",text:e.note}):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"leg-add",disabled:!e.canAdd,title:e.canAdd?"":"Нужен рынок с полным набором исходов"},at("plus",14),e.inExpress?"Уже в экспрессе":"В расчёт экспресса")),b?t("div.partner",{style:"margin-top:10px"},e.best.gain>=1?t("div.gain",{},`У ${b.name} этот кэф выше: со ставки ${bt(e.stake||1e3)} выигрыш больше на `,t("b",{text:bt(e.best.gain)}),"."):null,t("div.partner-links",{},b.url?Ot(b):null,Ct(b)),t("div.hint",{text:zt(b)})):null)}function me(e){let s=(l,b)=>t("div",{style:"min-width:0"},t("b",{text:l,style:"display:block;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}),b.map(v=>t("div",{style:"display:flex;justify-content:space-between;gap:8px"},t("span",{text:v.nick}),t("span",{style:"color:var(--lz-muted)",text:v.numbers.slice(0,2).join(" / ")}))));return t("div.card",{},t("div.kicker",{},t("span",{text:"Игроки сейчас"}),t("span.badge",{text:"с табло конторы"})),t("div",{style:"display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:12.5px"},s(e.homeName,e.home),s(e.awayName,e.away)))}function Vt(e,s){return t("div.card",{},t("div.kicker",{},t("span",{text:"Статистика команд"}),t("span.badge",{text:"со страницы конторы"})),t("table",{},t("tr",{},t("th",{text:"Показатель"}),t("th",{text:s.home}),t("th",{text:s.away})),e.rows.map(l=>t("tr",{},t("td",{text:l.label}),t("td",{text:l.home}),t("td",{text:l.away})))),e.samples?.length===2?t("div.hint",{style:"margin-top:8px",text:`Выборка: ${e.samples[0]} и ${e.samples[1]} карт.`}):null)}function Ut(e){let s=[];if(e.pick&&s.push(pe({...e.pick,stake:e.stake})),!e.match)return s.push(t("div.empty",{},t("b",{text:"Откройте матч"}),"На странице матча Линза покажет, что заложено в цене, сравнит конторы и разберёт матч по данным.")),s;s.push(P(e.match)),e.esports&&s.push(me(e.esports)),e.match.stats?.rows?.length&&s.push(Vt(e.match.stats,e.match)),e.line&&s.push(q(e.line));let l=nt(e);l&&s.push(l);let b=gt(e);b&&s.push(b);let v=J(e);v&&s.push(v);let z=pt(e);z&&s.push(z);let $=ut(e);$&&s.push($);let w=Lt(e);w&&s.push(w);let N=e.analysis.status==="loading";s.push(t("div.row",{},t("button.btn",{type:"button","data-act":"analyze",disabled:N},at("spark"),N?"Разбираю…":e.analysis.status==="done"?"Разобрать заново":"Разобрать матч"),t("button.btn.ghost",{type:"button","data-act":"compare",disabled:e.compare.status==="loading"},at("scale"),"Сравнить цены"))),e.quota&&s.push(t("div.hint.center-text",{text:e.quota}));let A=ue(e);A&&s.push(A);let B=V(e);B&&s.push(B);let L=de(e.compare,e);return L&&s.push(L),s}function Wt(e){let s=e.margins;if(!s)return null;let l=[t("div",{},`Сегодня вы открыли ${s.n} ${xt(s.n,"матч","матча","матчей")} до начала: в основной исход ${e.bookName||"контора"} закладывает в среднем `,t("b",{text:K(s.here,1)})," маржи.")];return s.best?(l.push(t("div",{style:"margin-top:6px"},`На тех же ${s.best.n} ${xt(s.best.n,"матче","матчах","матчах")} у ${s.best.name} — `,t("b",{text:K(s.best.there,1)}),` против ${K(s.best.here,1)} здесь: с каждой ставки вы отдавали бы конторе меньше примерно на ${((s.best.here-s.best.there)*100).toFixed(1)} п.п.`)),s.partner&&l.push(t("div.partner-links",{style:"margin-top:8px"},s.partner.url?Ot(s.partner):null,Ct(s.partner)),t("div.hint",{text:zt(s.partner)}))):l.push(t("div.hint",{style:"margin-top:6px",text:"Нажмите «Сравнить цены» на странице матча — Линза запомнит маржу других контор на тех же матчах и покажет, где отдаёте меньше."})),t("div.card",{},t("div.kicker",{},t("span",{text:"Сколько маржи вы отдаёте"}),t("span.badge",{text:"сегодня"})),...l)}function fe(e){let s=e.scan,l=Wt(e);return s?.rows?.length?[l,t("div.card",{},t("div.kicker",{},t("span",{text:s.title}),t("span.badge",{text:`средняя маржа ${K(s.average,1)}`})),t("table",{},t("tr",{},t("th",{text:s.first}),t("th",{text:"Фаворит"}),t("th",{text:"Маржа"})),s.rows.map(b=>t("tr.click",{"data-act":"scan-go","data-arg":String(b.index),title:"Показать на странице"},t("td.name",{},b.name,b.sub?t("span.sub",{text:b.sub}):null),t("td",{},b.fav,t("span.sub",{text:K(b.favPct)})),t(`td${b.low?".best":""}`,{text:K(b.margin,1)})))),t("div.hint",{style:"margin-top:8px",text:s.note}))]:[l,t("div.empty",{},t("b",{text:"Рынков на экране нет"}),"Откройте линию или матч — здесь появится маржа по каждому рынку.")]}function he(e){let s=e.express;if(!s.legs.length)return[t("div.empty",{},t("b",{text:"Экспресс пуст"}),"Нажмите на коэффициент на странице и добавьте его сюда. Линза посчитает общий шанс и сколько маржи вы отдаёте конторе.")];let l=s.stats;return[t("div.card",{},t("div.kicker",{},t("span",{text:`Экспресс · ${s.legs.length}`}),t("button.btn.ghost.small",{type:"button","data-act":"leg-clear"},at("trash",13),"Очистить")),s.legs.map(b=>t("div.leg",{},t("div.t",{},t("b",{text:b.label,title:b.label}),t("span",{text:b.title,title:b.title})),t("span.o",{text:X(b.odd)}),t("button.iconbtn",{type:"button","data-act":"leg-remove","data-arg":b.id,title:"Убрать",style:"width:24px;height:24px"},at("close",13))))),l?t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Итоговый коэффициент"}),t("dd",{text:X(l.odd)}),t("dt",{text:"Шанс, что зайдёт всё (по линии)"}),t("dd",{text:K(l.chance,1)}),t("dt",{text:"Кэф без маржи"}),t("dd",{text:X(l.fairOdd)}),t("dt",{text:"Маржа конторы на всём экспрессе"}),t("dd.neg",{text:K(l.margin,1)})),t("div.hint",{style:"margin-top:8px",text:"Маржа ног перемножается: чем длиннее экспресс, тем больше доля конторы. Исходы одного матча считаются как независимые — на деле они связаны."})):null]}function Kt(e){let s=e.edges||{status:"idle"},l=N=>t("div.kicker",{},t("span",{text:"Цена выше рынка"}),N?t("span.badge",{text:N}):null);if(s.status==="loading"&&!s.data)return[t("div.card",{},l("ищу сигналы"),t("div.hint",{text:"Сверяю открытую линию с консенсусом двадцати контор…"}))];if(s.status==="error"&&!s.data)return[t("div.card",{},l(),t("div.note.warn",{},at("alert"),t("span",{text:s.error})))];let b=s.data;if(!b)return[t("div.empty",{},t("b",{text:"Сигналы ещё не загружены"}),"Откройте вкладку ещё раз или нажмите «Обновить».")];let v=N=>N==null?"—":`${N>=0?"+":"−"}${(Math.abs(N)*100).toFixed(1)}%`,z=N=>new Date(N).toLocaleString("ru-RU",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"}),$=t("div.card.soft",{},t("dl.kv",{},t("dt",{text:"Открытых сигналов"}),t("dd",{text:String(b.open)}),t("dt",{text:"Закрыто за неделю"}),t("dd",{text:String(b.closedWeek)}),t("dt",{text:"Средний CLV за неделю"}),t("dd",{text:v(b.clvWeek)}),t("dt",{text:"Сигналов с плюсовым CLV"}),t("dd",{text:b.positiveWeek==null?"—":K(b.positiveWeek)})),t("div.hint",{style:"margin-top:8px",text:"CLV — насколько цена сигнала была выше цены закрытия линии. Плюсовой CLV на дистанции — единственный честный признак того, что сигналы опережают рынок. Это не обещание выигрыша."})),w=(b.signals||[]).map(N=>t("tr",{},t("td.name",{},`${N.home} — ${N.away}`,t("span.sub",{text:`${N.league} · ${z(N.start)}`})),t("td",{},N.label,t("span.sub",{text:N.book})),t("td",{text:X(N.odds)}),t("td",{text:X(1/N.p),title:`Честная цена по ${N.count} конторам`}),t("td.best",{text:`+${(N.edge*100).toFixed(1)}%`})));return[t("div.card",{},l(b.full?"тариф «Макс»":"витрина"),w.length?t("table",{},t("tr",{},t("th",{text:"Матч"}),t("th",{text:"Исход"}),t("th",{text:"Кэф"}),t("th",{text:"Рынок"}),t("th",{text:"Выше на"})),w):t("div.hint",{text:"Сейчас открытых сигналов нет: контора держится в рынке. Сканер проходит линию каждые полчаса."}),b.note?t("div.hint",{style:"margin-top:8px"},b.note," ",a.bot?t("a",{href:a.bot,target:"_blank",rel:"noopener",text:"Получить «Макс»"}):null):null,t("div.row",{style:"margin-top:10px"},t("button.btn.ghost.small",{type:"button","data-act":"edges-refresh"},"Обновить"))),$]}function Et(e){let s=e.settings,l=(b,v,z)=>t("div.seg",{},z.map(([$,w])=>t(`button${v===$?".on":""}`,{type:"button","data-act":b,"data-arg":$,text:w})));return[t("div.card",{},t("div.field",{},t("label",{text:"Отметки на странице"}),l("set-overlay",s.overlay,[["picks","Фавориты"],["all","Все шансы"],["off","Выкл"]]),t("div.hint",{text:"Рамка стоит на самом вероятном исходе каждого рынка. Число — шанс по линии без маржи конторы. Это не прогноз."})),t("div.field",{},t("label",{text:"Тема"}),l("set-theme",s.theme,[["auto","Как у сайта"],["light","Светлая"],["dark","Тёмная"]])),t("div.field",{},t("label",{for:"lz-stake",text:"Ставка для расчёта выгоды, ₽"}),t("div.row",{},t("input",{type:"number",id:"lz-stake",value:String(s.stake||1e3),min:"10",step:"10",inputmode:"numeric","data-enter":"set-stake",style:"max-width:140px"}),t("button.btn.small",{type:"button","data-act":"set-stake"},"Сохранить")),t("div.hint",{text:"Разницу лучшей цены Линза показывает в рублях от этой суммы. На ставку это не влияет."}))),t("div.card",{},t("div.kicker",{},t("span",{text:"Разбор матчей"}),t(`span.badge${s.ready?".pos":""}`,{text:s.ready?"подключён":"не подключён"})),s.proxy?t("div.field",{},t("label",{text:"Доступ"}),l("set-mode",s.mode,[["license","Ключ Линзы"],["own","Свой API-ключ"]])):null,s.mode==="license"&&s.proxy?t("div.field",{},t("label",{for:"lz-license",text:"Лицензионный ключ"}),t("input",{type:"text",id:"lz-license",placeholder:s.licenseMask||"LZ-XXXX-XXXX-XXXX",autocomplete:"off",spellcheck:"false","data-enter":"save-license"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-license"},"Сохранить"),s.licenseMask?t("button.btn.ghost.small",{type:"button","data-act":"clear-license"},"Удалить ключ"):null),t("div.hint",{},[s.licenseMask?`Ключ ${s.licenseMask} сохранён.`:"Без ключа работают бесплатные разборы с дневным лимитом. Ключ тарифа «Про» поднимает лимит.",s.plan,s.usage].filter(Boolean).join(" "),a.bot&&!s.licenseMask?[" ",t("a",{href:a.bot,target:"_blank",rel:"noopener",text:"Получить ключ «Про»"})]:null)):t("div.field",{},t("label",{for:"lz-key",text:"API-ключ Clodex"}),t("input",{type:"password",id:"lz-key",placeholder:s.keyMask||"sk-…",autocomplete:"off",spellcheck:"false","data-enter":"save-key"}),t("div.row",{},t("button.btn.small",{type:"button","data-act":"save-key"},"Сохранить"),s.hasKey?t("button.btn.ghost.small",{type:"button","data-act":"clear-key"},"Удалить ключ"):null),t("div.hint",{text:`Ключ хранится только в этом браузере и уходит только на clodex.xyz. ${s.usage}`}))),t("div.card.soft",{},t("div.hint",{},"Линза считает вероятности из коэффициентов самой конторы и показывает, сколько в них маржи. Разбор добавляет открытые данные о командах. ","Ни то, ни другое не делает ставку выигрышной."))]}function ge(e){j=e;let s=JSON.stringify(e);if(s===I)return;I=s;for(let w of m.querySelectorAll("details[data-key]"))E.set(w.dataset.key,w.open);let l=m.scrollTop;k.textContent=e.bookName?`· ${e.bookName}`:"",d.classList.toggle("off",e.settings.overlay==="off"),x.replaceChildren(at(e.theme==="dark"?"sun":"moon")),g.replaceChildren(at(e.settings.overlay==="off"?"eyeOff":"eye")),g.classList.toggle("on",e.settings.overlay!=="off"),y.classList.toggle("on",e.tab==="settings"),y.dataset.arg=e.tab==="settings"?e.backTab:"settings";let b=[["match","Матч"],["scan","Маржа"],["edges","Выше рынка"],["express","Экспресс"]];c.replaceChildren(...b.map(([w,N])=>t(`button.tab${e.tab===w?".on":""}`,{type:"button",role:"tab","data-act":"tab","data-arg":w},N,w==="express"&&e.express.legs.length?t("span.count",{text:String(e.express.legs.length)}):null)));let v=e.tab==="settings"?Et(e):e.tab==="scan"?fe(e):e.tab==="express"?he(e):e.tab==="edges"?Kt(e):Ut(e),z=e.update?t("div.card.soft.update",{},t("b",{text:`Вышла Линза ${e.update.version}`})," — ",e.update.url?t("a",{href:e.update.url,target:"_blank",rel:"noopener",text:"скачать архив на сайте"}):"архив на сайте Линзы"," и заменить папку расширения."):null,$=e.whatsnew?.changes?.length&&e.tab!=="settings"?t("div.card.soft.update",{},t("b",{text:`Линза обновилась до ${e.whatsnew.version}`}),t("ul.facts",{style:"margin-top:6px"},e.whatsnew.changes.flatMap(w=>w.items).slice(0,6).map(w=>t("li",{},t("span",{text:w})))),t("div.row",{style:"margin-top:8px"},t("button.btn.ghost.small",{type:"button","data-act":"whatsnew-ok"},"Понятно"))):null;m.replaceChildren(...[z,$,...v].filter(Boolean)),m.scrollTop=l,h.replaceChildren(t("span",{text:"18+ · Линза не принимает ставки и не обещает выигрыш. Азартные игры могут вызывать зависимость."}))}function be(e){n.setAttribute("data-theme",e)}function It(){F.hidden=!1,r.opened?.()}function St(){F.hidden=!0}function _t(){F.hidden?It():St()}function Zt(e){e?.fab&&S(u,e.fab.left,e.fab.top),e?.panel&&S(F,e.panel.left,e.panel.top)}let i=0;function f(e){p.querySelector(".toast")?.remove();let s=t("div.toast",{text:e,role:"status"});p.appendChild(s),clearTimeout(i),i=setTimeout(()=>s.remove(),2600)}return{render:ge,setTheme:be,open:It,close:St,toggle:_t,restore:Zt,toast:f,shadow:p,rect:()=>F.hidden?null:F.getBoundingClientRect(),get isOpen(){return!F.hidden},get view(){return j}}}var fn="Расширение обновилось. Обновите эту вкладку (F5).";function yo(o){return/signal timed out|timeout|timed out/i.test(o)?"Сервер долго не отвечает — нажмите ещё раз.":/failed to fetch|networkerror|load failed|network request failed/i.test(o)?"Нет связи с сервером Линзы — проверьте интернет.":o}function wt(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}async function ot(o,r={}){if(!wt())return{ok:!1,error:fn,code:"reload"};try{return await chrome.runtime.sendMessage({type:o,...r})||{ok:!1,error:"Фоновый скрипт не ответил."}}catch(a){let n=String(a?.message||a);return/context invalidated/i.test(n)||!wt()?{ok:!1,error:fn,code:"reload"}:/message port closed|receiving end does not exist/i.test(n)?{ok:!1,error:"Связь с расширением прервалась — нажмите ещё раз.",code:"retry"}:{ok:!1,error:yo(n)}}}function hn(o){if(wt())try{chrome.runtime.onMessage.addListener(r=>{o(r)})}catch{}}async function Se(o){if(!wt())return{};try{return await chrome.storage.local.get(o)}catch{return{}}}function $t(o){if(wt())try{chrome.storage.local.set(o)}catch{}}var gn=(o=Date.now())=>new Date(o).toISOString().slice(0,10);function ie(o,r=Date.now()){return o&&o.day===gn(r)&&o.items&&typeof o.items=="object"?o:{day:gn(r),items:{}}}function bn(o,{key:r,book:a,margin:n}){if(!r||!Number.isFinite(n)||n<=0||n>.5)return!1;let p=Math.round(n*1e4)/1e4,d=o.items[r];return d&&d.here===p&&d.book===a?!1:(o.items[r]={book:a,here:p,others:d?.others||{}},!0)}function xn(o,r,a){let n=o.items[r];if(!n)return!1;let p=!1;for(let d of a||[]){if(d.here||d.sharp||!d.odds?.length||d.odds.some(m=>!(m>1)))continue;let u=yt(d.odds);if(u.kind!=="full"||!(u.margin>0))continue;let c=Math.round(u.margin*1e4)/1e4;n.others[d.name]!==c&&(n.others[d.name]=c,p=!0)}return p}function vn(o,r){let a=Object.values(o?.items||{}).filter(u=>u.book===r);if(!a.length)return null;let n=u=>u.reduce((c,m)=>c+m,0)/u.length,d=[...new Set(a.flatMap(u=>Object.keys(u.others||{})))].map(u=>{let c=a.filter(m=>Number.isFinite(m.others?.[u]));return c.length>=2?{name:u,n:c.length,there:n(c.map(m=>m.others[u])),here:n(c.map(m=>m.here))}:null}).filter(Boolean).sort((u,c)=>u.there-c.there);return{n:a.length,here:n(a.map(u=>u.here)),best:d[0]||null,others:d}}var ko=[{version:"1.0.13",items:["Под разбором — «Показать полностью»: итог по всем рынкам, доводы, как может пойти игра, профили и факты.","Итог по рынкам этой страницы: в теннисе — тотал и фора геймов, в CS и Dota — карты, по цене самой конторы на победу."]},{version:"1.0.12",items:["Под разбором — «Сообщить об ошибке»: что сломалось, уходит разработчику без личных данных.","Итог не строится по модели, которой нельзя верить как цене: если она сильно расходится с рынком или у неё мало матчей в архиве."]},{version:"1.0.11",items:["Разобрать матч: разбор идёт на сервере — видно, что происходит (цены, новости, модель), и он не обрывается на «Обновите вкладку».","Разбор работает на всех конторах: если матча нет в линии Fonbet, Линза разбирает по ценам страницы и свежим новостям.","Новости, травмы и составы из прессы — в разборе для всех тарифов; у «Макс» и VIP поиск подробнее.","Бесплатные 3 разбора в день считаются для вашего браузера, а не для всех с одного адреса; истёкший ключ не отключает бесплатные разборы.","Исправлено: счётчик «Разборов сегодня» больше не пропадает, ошибки связи — понятными словами."]},{version:"1.0.10",items:["Исправлено: в доводах моделей имена команд и игроков — как на странице конторы."]},{version:"1.0.9",items:["Лайв тенниса по счёту: шанс матча, текущего сета и гейма от очков и подачи.","Прогноз модели для КХЛ: атака и оборона команд, исход основного времени и победитель с ОТ; на проверке при уверенности от 65% сбылось 70%.","Итог: форы футбола и хоккея против честной цены по Fonbet."]},{version:"1.0.8",items:["Лайв по счёту для футбола и хоккея: шанс исхода основного времени, следующий гол, тоталы и форы по счёту, времени и удалениям; точное игровое время.","Итог для футбола и хоккея: тоталы этой конторы против честной цены по Fonbet без маржи на любой линии.","Журнал итогов: точность прошлых итогов — в карточке и в приложении."]},{version:"1.0.7",items:["ММА (UFC): прогноз модели по бойцам — возраст, размах рук, форма, простой; как скорее всего закончится бой и честные кэфы на тоталы раундов и решение судей; прогноз рынка 5+ контор.","Итог: в конце карточек — лучшая цена против честной, перевес и размер суммы, доводы и главный риск из разбора; каждый итог записывается и потом сверяется с результатом — точность видна в приложении.","Баскетбол: фора и тотал по модели — ожидаемая разница очков и тотал с разбросом, честные кэфы основных линий конторы в «Итоге».","Теннис: подача и приём в модели — шанс матча по доле выигранных очков на своей подаче и на приёме соперника.","Исправлено: бойцы и теннисисты в формате «Фамилия И.» находятся, если полное имя из трёх слов.","Одна палитра у панели, попапа, мини-приложения и сайта; в тёмной теме приложения — светлый акцент."]},{version:"1.0.6",items:["Лайв по счёту: в баскетболе — честный шанс, фора и тотал против цены конторы; в CS и Dota — шанс серии по счёту карт и раундов текущей карты.","Профили участников: теннисисты (покрытия, подача и приём, нагрузка, последние матчи), команды баскетбола и киберспорта (динамика рейтинга, форма, состав с рейтингом каждого игрока).","Баскетбол: Еврокубок, АСВ, Серия А, Адриатическая лига, Единая лига ВТБ и Лига чемпионов FIBA — в модели и в фактах.","Футбол: ход матча и судьи (УЕФА) в карточке «Составы, травмы, форма».","Киберспорт: у подписи уверенности — как часто такие прогнозы сбывались на проверке; модель Dota точнее.","Вкладка «Маржа»: сколько маржи вы отдаёте этой конторе по открытым сегодня матчам и сколько отдавали бы у других контор.","Новая версия подхватывается сама, когда вы заменили файлы в папке расширения."]},{version:"1.0.5",items:["Карточка «Составы, травмы, форма» на странице матча: травмы по именам, составы, форма и очные встречи (ESPN, bo3.gg) — без разбора и без лимита.","Подсказка в панели, когда на сайте вышла новая версия.","Dota 2: точнее вероятность победы в серии до двух побед."]}];function yn(o,r){let a=String(o||"").split(".").map(Number),n=String(r||"").split(".").map(Number);for(let p=0;p<Math.max(a.length,n.length);p++){let d=(a[p]||0)-(n[p]||0);if(d)return d>0}return!1}function kn(o,r){return ko.filter(a=>yn(a.version,o)&&!yn(a.version,r))}var Pt=o=>Number.isFinite(o)?(Math.round(o*100)/100).toFixed(2):"—",wn=o=>`${Math.round(o*100)}%`,wo=(o,r)=>o*r-1;function $o(o){return o<.03?null:o<.06?"небольшая — примерно половина обычной":o<.12?"обычная":"перевес слишком большой — сначала проверьте травмы, замены и что это тот же матч"}function $n(o,{source:r="",reasons:a=[],risk:n=""}={}){let p=(o||[]).filter(g=>Number(g.odd)>1&&g.p>.01&&g.p<.99).map(g=>({...g,fairOdd:1/g.p,edge:wo(g.p,Number(g.odd))}));if(!p.length)return null;let u=[...p].sort((g,y)=>y.edge-g.edge)[0],c=u.edge>=.03?{...u,size:$o(u.edge)}:null,m=p.filter(g=>g!==u||!c).map(g=>({...g,note:g.edge>=.03?`перевес ${wn(g.edge)} к честной цене ${Pt(g.fairOdd)}`:g.edge>-.02?`честная цена (${Pt(g.fairOdd)}), перевеса нет`:`цена ниже честной (${Pt(g.fairOdd)})`})),h=[];if(c){let g=c.source||r;h.push(`Лучшая цена: ${c.label} по ${Pt(c.odd)} — перевес около ${wn(c.edge)} к честной цене ${Pt(c.fairOdd)}${g?` (${g})`:""}. Сумма: ${c.size}.`),a.length&&h.push(`За: ${a.join(" ")}`),n&&h.push(`Главный риск: ${n}`)}else h.push(`Перевеса нет: все цены близки к честным или ниже${r?` (${r})`:""} — разумнее пропустить.`);let k=[...m].sort((g,y)=>y.edge-g.edge).slice(0,6),x=m.length-k.length;return m.length&&h.push(`${c?"Остальное":"По рынкам"}: ${k.map(g=>`${g.label} по ${Pt(g.odd)} — ${g.note}`).join("; ")}${x>0?`; ещё ${x} — с меньшим перевесом или без него`:""}.`),h.push("Это расчёт, а не обещание: проиграть можно и при перевесе в цене. 18+"),{best:c,others:m,lines:h}}function Gt(o){let r=n=>/^(б|больше|бол|over|o\b|тб)/i.test(String(n||"").trim()),a=n=>/^(м|меньше|мен|under|u\b|тм)/i.test(String(n||"").trim());return r(o[0])&&a(o[1])?0:a(o[0])&&r(o[1])?1:-1}var Mo=o=>{let r=o<0?-1:1,a=Math.abs(o),n=1/(1+.3275911*a);return r*(1-((((1.061405429*n-1.453152027)*n+1.421413741)*n-.284496736)*n+.254829592)*n*Math.exp(-a*a))},_e=o=>.5*(1+Mo(o/Math.SQRT2));function Mn(o,r,a){if(!(Math.abs(a-Math.round(a))<1e-9)){let u=1-_e((a-o)/r);return{win:u,push:0,lose:1-u}}let p=1-_e((a+.5-o)/r),d=_e((a-.5-o)/r);return{win:p,push:Math.max(0,1-p-d),lose:d}}function zo(o,r,a){let n=Mn(o,r,-a);return{home:n.win,away:n.lose,push:n.push}}function So(o,r,a){let n=Mn(o,r,a);return{over:n.win,under:n.lose,push:n.push}}function zn(o,{handicap:r=null,total:a=null}={},n=["Хозяева","Гости"]){let p=o?.lines;if(!p||!Number.isFinite(p.margin)||!(p.sigma>0))return[];let d=[],u=h=>h>0?`+${h}`:`${h}`,c=(h,k)=>h/(1-k||1),m=(h,k)=>1/h/(1/h+1/k);if(r&&Number.isFinite(r.line)&&Math.abs(r.line)<60&&r.home>1&&r.away>1){let h=zo(p.margin,p.sigma,r.line);Math.abs(c(h.home,h.push)-m(r.home,r.away))<=.3&&d.push({label:`Фора ${n[0]} ${u(r.line)}`,odd:r.home,p:c(h.home,h.push),kind:"handicap",side:"home",source:"модель Линзы"}),d.length&&d.push({label:`Фора ${n[1]} ${u(-r.line)}`,odd:r.away,p:c(h.away,h.push),kind:"handicap",side:"away",source:"модель Линзы"})}if(a&&Number.isFinite(p.total)&&p.sigmaT>0&&Number.isFinite(a.line)&&a.line>50&&a.over>1&&a.under>1){let h=So(p.total,p.sigmaT,a.line);Math.abs(c(h.over,h.push)-m(a.over,a.under))<=.3&&(d.push({label:`Тотал больше ${a.line}`,odd:a.over,p:c(h.over,h.push),kind:"total",source:"модель Линзы"}),d.push({label:`Тотал меньше ${a.line}`,odd:a.under,p:c(h.under,h.push),kind:"total",source:"модель Линзы"}))}return d}var Bt={football:{periods:2,minutes:90,stoppage:[2,5],late:1,weights:[.12,.142,.184,.149,.167,.237],trail:.3,lead:.05,redOwn:-.4,redOpp:.45,total:2.7,homeShare:.555,maxGoals:12},hockey:{periods:3,minutes:60,weights:[.297,.344,.359],trail:0,lead:-.1,redOwn:0,redOpp:0,total:6,homeShare:.52,maxGoals:16}},Ne=[1];for(let o=1;o<=40;o+=1)Ne[o]=Ne[o-1]*o;var Sn=(o,r)=>r<=0?o===0?1:0:Math.exp(-r)*r**o/Ne[o];function _o(o,r){let a=r.weights.length,n=r.minutes/a,p=Math.max(0,Math.min(r.minutes,o)),d=0;for(let c=0;c<a;c+=1){let m=c*n,h=m+n,k=a/(r.periods||1),x=(c+1)%k===0&&r.stoppage?.[Math.floor(c/k)]||0;p<=m?d+=r.weights[c]:p<h&&(d+=r.weights[c]*((h-p+x)/(n+x)))}let u=r.weights.reduce((c,m)=>c+m,0);return d/u}function _n(o,r,a){let n=[];for(let p=0;p<=a;p+=1){n[p]=[];for(let d=0;d<=a;d+=1)n[p][d]=Sn(p,o)*Sn(d,r)}return n}function No(o,r,a,n=null){let p=_n(o,r,a),d=0,u=0,c=0,m=0;for(let h=0;h<=a;h+=1)for(let k=0;k<=a;k+=1){let x=p[h][k];h>k?d+=x:h===k?u+=x:c+=x,n!=null&&h+k>n&&(m+=x)}return{p1:d,px:u,p2:c,over:m}}function Nn({p1:o,px:r,p2:a,line:n=null,pOver:p=null},d=Bt.football){let u=d.total,c=(h,k)=>{let x=No(h,k,d.maxGoals,n!=null&&p!=null?n:null),g=(x.p1-o)**2+(x.p2-a)**2+(r!=null?(x.px-r)**2:0);return n!=null&&p!=null?g+=(x.over-p)**2:g+=.02*((h+k-u)/u)**2,g},m={lh:u*d.homeShare,la:u*(1-d.homeShare),e:1/0};for(let h=.4;h>=.01;h/=2){let k=m;for(let x=-4;x<=4;x+=1)for(let g=-4;g<=4;g+=1){let y=Math.max(.03,k.lh+x*h),T=Math.max(.03,k.la+g*h),F=c(y,T);F<m.e&&(m={lh:y,la:T,e:F})}}return{lh:m.lh,la:m.la}}function Fe(o,r,a=Bt.football){let[n,p]=o.score.map(Number),d=_o(Number(o.minute)||0,a),u=n-p,c=Math.sign(u),m=1+(a.late||0)*((Number(o.minute)||0)/a.minutes-.5),h=(Math.abs(u)>=2?.6:1)*Math.max(0,m),k=c<0?a.trail*h:c>0?a.lead*h:0,x=c>0?a.trail*h:c<0?a.lead*h:0,[g,y]=(o.red||[0,0]).map(V=>Math.min(2,Number(V)||0)),T=(V,U)=>(1+a.redOwn)**V*(1+a.redOpp)**U,F=Math.max(0,r.lh*d*(1+k)*T(g,y)),O=Math.max(0,r.la*d*(1+x)*T(y,g)),I=a.maxGoals,j=_n(F,O,I),E=0,W=0,_=0;for(let V=0;V<=I;V+=1)for(let U=0;U<=I;U+=1){let nt=n+V,Q=p+U;nt>Q?E+=j[V][U]:nt===Q?W+=j[V][U]:_+=j[V][U]}let M=E+W+_||1,S=V=>{let U=0,nt=0;for(let Q=0;Q<=I;Q+=1)for(let st=0;st<=I;st+=1){let J=n+p+Q+st;J>V?U+=j[Q][st]:J===V&&(nt+=j[Q][st])}return{over:U,push:nt,under:Math.max(0,1-U-nt)}},C=V=>{let U=0,nt=0;for(let Q=0;Q<=I;Q+=1)for(let st=0;st<=I;st+=1){let J=n+Q-(p+st)+V;J>0?U+=j[Q][st]:J===0&&(nt+=j[Q][st])}return{home:U,push:nt,away:Math.max(0,1-U-nt)}},P=F+O,q=Math.exp(-P);return{p1:E/M,px:W/M,p2:_/M,lh:F,la:O,share:d,expTotal:n+p+P,nextGoal:{home:P>0?(1-q)*(F/P):0,away:P>0?(1-q)*(O/P):0,none:q},total:S,handicap:C}}var Te=(o,r)=>1/o/(1/o+1/r);function Fo(o,r){let a=Bt[r];if(!a||!o?.odds||o.odds.length!==3)return null;let n=yt(o.odds).fair;if(!n)return null;let p=o.total,d=p&&p.over>1&&p.under>1?Te(p.over,p.under):null;return d==null?null:Nn({p1:n[0],px:n[1],p2:n[2],line:p.line,pOver:d},a)}function Fn(o,r,a,n=["Хозяева","Гости"]){let p=Fo(o,a);if(!p)return[];let d=Bt[a],u=Fe({score:[0,0],minute:0},p,d),c=[],m=new Set,h=x=>x>0?`+${x}`:`${x}`,k=x=>{let g=String(x??"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?\d+(?:\.\d+)?/g);return g?Number(g[g.length-1]):NaN};for(let x of r||[]){if(x.kind!=="total"&&x.kind!=="handicap"||x.outcomes?.length!==2)continue;let g=`${x.title||""} ${x.period||""}`;if(/тайм|период|четверт|half|period|инд|команд|угл|карт|corner|card|овертайм|буллит|с уч[её]том|(^|[^а-яё])от([^а-яё]|$)/i.test(g.replace(/осн\.?\s*время/i,"")))continue;if(x.kind==="handicap"){let _=k(x.outcomes[0].label);if(Number.isFinite(_)||(_=k(x.line)),!Number.isFinite(_)||Math.abs(_)>4||m.has(`h${_}`))continue;let M=Number(x.outcomes[0].odd),S=Number(x.outcomes[1].odd);if(!(M>1&&S>1))continue;let C=u.handicap(_),P=1-C.push||1;if(Math.abs(C.home/P-Te(M,S))>.15)continue;m.add(`h${_}`),c.push({label:`Фора ${n[0]} ${h(_)}`,odd:M,p:C.home/P,kind:"handicap",side:"home",line:_,source:"Fonbet без маржи"},{label:`Фора ${n[1]} ${h(-_)}`,odd:S,p:C.away/P,kind:"handicap",side:"away",line:-_,source:"Fonbet без маржи"});continue}let y=Number(String(x.line||"").replace(",","."));if(!Number.isFinite(y)||y<=0||y>(a==="hockey"?12:9)||m.has(y))continue;let T=Gt(x.outcomes.map(_=>_.label));if(T<0)continue;let F=u.total(y),O=1-F.push||1,I=F.over/O,j=F.under/O,E=Number(x.outcomes[T].odd),W=Number(x.outcomes[1-T].odd);!(E>1&&W>1)||Math.abs(I-Te(E,W))>.2||(m.add(y),c.push({label:`Тотал больше ${y}`,odd:E,p:I,kind:"total",line:y,source:"Fonbet без маржи"},{label:`Тотал меньше ${y}`,odd:W,p:j,kind:"total",line:y,source:"Fonbet без маржи"}))}return c}function To(o){let r=(o||[]).map(Number);if(!r.length||!r.every(d=>d>1))return null;let a=r.map(d=>1/d),n=a.reduce((d,u)=>d+u,0),p=a.map(d=>d/n);return p.length===3?p[0]+p[1]/2:p[0]}function Tn(o,r){if(!o?.p1)return{ok:!1,reason:"нет прогноза"};if(o.confidence==="очень низкая")return{ok:!1,reason:"мало матчей в архиве — модель почти ничего не знает об участниках"};let a=To(r);return a!=null&&Math.abs(o.p1-a)>.2?{ok:!1,reason:`модель расходится с ценой конторы на ${Math.round(Math.abs(o.p1-a)*100)} п.п. — скорее всего, она чего-то не знает (квалификация, травма, состав)`}:{ok:!0,reason:""}}var Le={atp:{hard:.645,clay:.625,grass:.67},wta:{hard:.565,clay:.55,grass:.585}};function Tt(o,r=0,a=0){let n=1-o,p=o*o/(o*o+n*n),d=new Map,u=(c,m)=>{if(c>=4&&c-m>=2)return 1;if(m>=4&&m-c>=2)return 0;if(c>=3&&m>=3)return c===m?p:c>m?o+n*p:o*p;let h=c*16+m;return d.has(h)||d.set(h,o*u(c+1,m)+n*u(c,m+1)),d.get(h)};return u(r,a)}function le(o,r,a=0,n=0,p=!0,d=7){let u=y=>y?o:1-r,c=o*(1-r)/(o*(1-r)+(1-o)*r),m=y=>y===0?0:Math.floor((y+1)/2),h=m(a+n)%2===0?p:!p,k=y=>m(y)%2===0?h:!h,x=new Map,g=(y,T)=>{if(y>=d&&y-T>=2)return 1;if(T>=d&&T-y>=2)return 0;if(y>=d-1&&T>=d-1&&y===T)return c;let F=y*64+T;if(!x.has(F)){let O=u(k(y+T));x.set(F,O*g(y+1,T)+(1-O)*g(y,T+1))}return x.get(F)};return g(a,n)}function Ae(o,r,a=0,n=0,p=!0,d=7){let u=Tt(o),c=1-Tt(r),m=new Map,h=(k,x,g)=>{if(k>=6&&k-x>=2||k===7)return 1;if(x>=6&&x-k>=2||x===7)return 0;if(k===6&&x===6)return le(o,r,0,0,g,d);let y=k*32+x*2+(g?1:0);if(!m.has(y)){let T=g?u:c;m.set(y,T*h(k+1,x,!g)+(1-T)*h(k,x+1,!g))}return m.get(y)};return h(a,n,p)}function An(o,r,a,n=3,{finalTb:p=7}={}){let d=n>=5?3:2,u=(o.sets||[]).filter(([_,M])=>_>M).length,c=(o.sets||[]).length-u,[m,h]=o.games||[0,0],[k,x]=o.points||[0,0],g=o.aServes!==!1,T=u===d-1&&c===d-1?p:7,F=new Map,O=(_,M)=>{if(_>=d)return 1;if(M>=d)return 0;let S=_*8+M;if(!F.has(S)){let C=_===d-1&&M===d-1?p:7,P=(Ae(r,a,0,0,!0,C)+Ae(r,a,0,0,!1,C))/2;F.set(S,P*O(_+1,M)+(1-P)*O(_,M+1))}return F.get(S)},I=m===6&&h===6,j,E;if(I)j=le(r,a,k,x,g,T),E=j;else{E=g?Tt(r,k,x):1-Tt(a,x,k);let _=(M,S)=>M>=6&&M-S>=2||M===7?1:S>=6&&S-M>=2||S===7?0:Ae(r,a,M,S,!g,T);j=E*_(m+1,h)+(1-E)*_(m,h+1)}return{match:j*O(u+1,c)+(1-j)*O(u,c+1),set:j,game:E,hold:g?E:1-E}}function Ln(o,r,a=3){return(An({sets:[],games:[0,0],points:[0,0],aServes:!0},o,r,a).match+An({sets:[],games:[0,0],points:[0,0],aServes:!1},o,r,a).match)/2}var Ao=.03,At=(o,r,a)=>o.set(r,(o.get(r)||0)+a);function Lo(o,r,a=!0){let n=Tt(o),p=Tt(r),d=new Map,u=new Map([[`0,0,${a?1:0}`,1]]);for(;u.size;){let c=new Map;for(let[m,h]of u){let[k,x,g]=m.split(",").map(Number),y=g===1;if(k===6&&x===6){let F=le(o,r,0,0,y);At(d,`7,6,${y?0:1}`,h*F),At(d,`6,7,${y?0:1}`,h*(1-F));continue}let T=y?n:1-p;for(let[F,O,I]of[[k+1,x,T],[k,x+1,1-T]]){let j=(F>=6||O>=6)&&Math.abs(F-O)>=2||F===7||O===7,E=`${F},${O},${y?0:1}`;At(j?d:c,E,h*I)}}u=c}return[...d].map(([c,m])=>{let[h,k,x]=c.split(",").map(Number);return{ga:h,gb:k,nextA:x===1,p:m}})}function On(o,r,a=3){let n=a===5?3:2,p=new Map,d=x=>{let g=x?1:0;return p.has(g)||p.set(g,Lo(o,r,x)),p.get(g)},u=new Map,c=new Map,m=new Map,h=[{sa:0,sb:0,a:!0,t:0,d:0,p:.5},{sa:0,sb:0,a:!1,t:0,d:0,p:.5}];for(;h.length;){let x=new Map;for(let g of h)for(let y of d(g.a)){let T=g.sa+(y.ga>y.gb?1:0),F=g.sb+(y.gb>y.ga?1:0),O=g.t+y.ga+y.gb,I=g.d+y.ga-y.gb,j=g.p*y.p;if(T===n||F===n){At(u,`${T}:${F}`,j),At(c,O,j),At(m,I,j);continue}let E=`${T},${F},${y.nextA?1:0},${O},${I}`,W=x.get(E);W?W.p+=j:x.set(E,{sa:T,sb:F,a:y.nextA,t:O,d:I,p:j})}h=[...x.values()]}let k=(x,g)=>[...x].reduce((y,[T,F])=>y+(g(Number(T))?F:0),0);return{sets:Object.fromEntries(u),win:[...u].reduce((x,[g,y])=>x+(Number(g.split(":")[0])===n?y:0),0),total:c,diff:m,over:x=>({over:k(c,g=>g>x),push:k(c,g=>g===x)}),handicap:x=>({home:k(m,g=>g+x>0),push:k(m,g=>g+x===0)})}}var Oo=0,Co=.04,Eo=[[-2.0201828705,.0199532421],[-.9585724646,.3936193232],[0,.9453087205],[.9585724646,.3936193232],[2.0201828705,.0199532421]].map(([o,r])=>[o*Math.SQRT2,r/Math.sqrt(Math.PI)]);function jo(o,{tour:r="atp",surface:a="hard",bestOf:n=3,serveShift:p=Oo,daySd:d=Co}={}){let u=((Le[r]||Le.atp)[a]||.63)+p,c=_=>Math.max(-.3,Math.min(.3,_)),m=d>0?Eo:[[0,1]],h=_=>m.reduce((M,[S,C])=>M+C*Ln(u+c(_+S*d),u-c(_+S*d),n),0),k=-.3,x=.3,g=Math.min(.995,Math.max(.005,o));for(let _=0;_<30;_+=1){let M=(k+x)/2;h(M)<g?k=M:x=M}let y=(k+x)/2;if(m.length===1)return On(u+y,u-y,n);let T=m.map(([_,M])=>[M,On(u+c(y+_*d),u-c(y+_*d),n)]),F=_=>{let M=new Map;for(let[S,C]of T)for(let[P,q]of _(C))M.set(P,(M.get(P)||0)+S*q);return M},O=F(_=>Object.entries(_.sets)),I=F(_=>_.total),j=F(_=>_.diff),E=(_,M)=>[..._].reduce((S,[C,P])=>S+(M(Number(C))?P:0),0),W=n===5?3:2;return{sets:Object.fromEntries(O),win:[...O].reduce((_,[M,S])=>_+(Number(M.split(":")[0])===W?S:0),0),total:I,diff:j,over:_=>({over:E(I,M=>M>_),push:E(I,M=>M===_)}),handicap:_=>({home:E(j,M=>M+_>0),push:E(j,M=>M+_===0)})}}var Po={cs:.1,dota:.14};function Bo(o,{pick:r=0}={}){let a=c=>Math.min(.999,Math.max(.001,c)),n=c=>{let m=a(c+r),h=a(c-r),k=a(c),x=m*h,g=(1-m)*(1-h),y=m*(1-h)+(1-m)*h;return{q:c,s20:x,s02:g,s21:y*k,s12:y*(1-k)}},p=0,d=1;for(let c=0;c<50;c+=1){let m=(p+d)/2,h=n(m);h.s20+h.s21<o?p=m:d=m}let u=n((p+d)/2);return{q:u.q,sets:{"2:0":u.s20,"2:1":u.s21,"1:2":u.s12,"0:2":u.s02},over25:u.s21+u.s12,homeMinus15:u.s20,awayMinus15:u.s02}}var Io={tennis:!0,cs:!0,dota:!0};function qo(o=""){let r=String(o),a=/wta|жен|women/i.test(r)?"wta":"atp",n=/грунт|clay/i.test(r)?"clay":/трав|grass/i.test(r)?"grass":"hard",p=/australian open|roland garros|ролан|уимблдон|wimbledon|us open|открытый чемпионат (австралии|сша)/i.test(r);return{tour:a,surface:n,bestOf:p&&a==="atp"?5:3}}function Oe({sport:o,model:r=null,p:a=null,source:n="модель Линзы",markets:p,names:d=["Хозяева","Гости"],league:u=""}){let c=a??r?.p1;if(!Io[o]||!(c>0&&c<1))return[];let m=o==="tennis",h=m?jo(c,qo(u)):Bo(c,{pick:Po[o]||0}),k=j=>{let E=String(j??"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?\d+(?:\.\d+)?/g);return E?Number(E[E.length-1]):NaN},x=(j,E)=>1/j/(1/j+1/E),g=(j,E)=>E>0?j/(1-E):j,y=m?"гейма":"карты",T=j=>String(j||"").toLowerCase().replace(/ё/g,"е"),F=d.flatMap(j=>T(j).split(/[^a-zа-я0-9-]+/)).filter(j=>j.length>=4),O=[],I=new Set;for(let j of p||[]){if(j.scope==="list"||j.main===!1||j.kind!=="total"&&j.kind!=="handicap"||j.outcomes?.length!==2||!j.outcomes.every(M=>M.odd>1))continue;let E=`${j.title||""} ${j.period||""}`;if(/сет|set|тай-?брейк|tie|инд|игрок|player|раунд|round|килл|kill|чет|нечет/i.test(E)||F.some(M=>T(E).includes(M))||!m&&/гейм|game/i.test(E))continue;let[W,_]=j.outcomes;if(j.kind==="total"){let M=Number.isFinite(k(j.line))?k(j.line):k(W.label);if(!Number.isFinite(M)||I.has(`t${M}`)||(m?M<12||M>60:M!==2.5))continue;let S=!/меньш|under/i.test(W.label),C,P=0;if(m){let nt=h.over(M);C=nt.over,P=nt.push}else if(M===2.5)C=h.over25;else continue;let q=S?W:_,V=S?_:W,U=g(C,P);if(Math.abs(U-x(q.odd,V.odd))>.2)continue;I.add(`t${M}`),O.push({label:`Тотал ${m?"геймов":"карт"} больше ${M}`,odd:q.odd,p:U,kind:"total",line:M,source:n}),O.push({label:`Тотал ${m?"геймов":"карт"} меньше ${M}`,odd:V.odd,p:1-U,kind:"total",line:M,source:n})}else{let M=Number.isFinite(k(W.label))?k(W.label):k(j.line);if(!Number.isFinite(M)||I.has(`h${M}`)||(m?Math.abs(M)>15:Math.abs(M)!==1.5))continue;let S,C=0;if(m){let V=h.handicap(M);S=V.home,C=V.push}else if(M===-1.5)S=h.homeMinus15;else if(M===1.5)S=1-h.awayMinus15;else continue;let P=g(S,C);if(Math.abs(P-x(W.odd,_.odd))>.2)continue;I.add(`h${M}`);let q=V=>V>0?`+${V}`:`${V}`;O.push({label:`Фора ${d[0]} ${q(M)} ${y}`,odd:W.odd,p:P,kind:"handicap",side:"home",line:M,source:n}),O.push({label:`Фора ${d[1]} ${q(-M)} ${y}`,odd:_.odd,p:1-P,kind:"handicap",side:"away",line:-M,source:n})}}return O}function Cn({sport:o,model:r,markets:a,names:n,league:p=""}){let d=Oe({sport:o,model:r,markets:a,names:n,league:p}).filter(c=>c.p>=.15&&c.p<=.85),u=new Map;for(let c of d){let m=`${c.kind}|${Math.abs(c.line)}`;(!u.has(m)||c.p*c.odd>u.get(m).p*u.get(m).odd)&&u.set(m,c)}return[...u.values()].sort((c,m)=>Math.abs(c.p-.5)-Math.abs(m.p-.5)).map(c=>({label:c.label,from:Math.round(1/c.p*(1+Ao)*100)/100,odd:c.odd}))}var ce=globalThis.__lzBus,Ce=ce&&window.top===window?tn(location.hostname):null;Ce&&!globalThis.__lzStarted&&(globalThis.__lzStarted=!0,Ro(Ce.adapter,Ce.book));async function Ro(o,r){let a=await Se(["lz.settings","lz.positions","lz.express","lz.margins","lz.whatsnew"]),n={settings:{...ve,...a["lz.settings"]||{}},positions:(a["lz.positions"]||{})[location.hostname]||{},tab:"match",backTab:"match",url:location.href,pageType:"other",match:null,markets:[],selected:null,express:Do(a["lz.express"]),margins:ie(a["lz.margins"]),whatsnew:a["lz.whatsnew"]||null,analysis:new Map,compare:new Map,consensus:new Map,model:new Map,facts:new Map,fonbetRef:new Map,live:new Map,edges:{status:"idle",data:null,error:"",at:0},partners:{data:{},at:0},status:{ready:!1,mode:"own",hasKey:!1,keyMask:"",licenseMask:"",used:0,limit:0,proxy:!1},theme:"light"},p=new WeakMap,d=new WeakMap,u=sn(),c=mn({bus:ce,brand:Qt,actions:he()});c.restore(n.positions);function m(i){let f=i.outcomes.map(l=>l.odd).join("/"),e=p.get(i);if(e?.sig===f)return e.set;let s=yt(i.outcomes.map(l=>l.odd));return p.set(i,{sig:f,set:s}),s}function h(){return n.match?n.analysis.get(n.match.key):null}function k(i){let f=h()?.result;if(!f?.model||i.scope==="list"||!n.match||!Object.values(f.shift||{}).some(v=>Math.abs(v)>=.5))return null;let{home:e,draw:s,away:l}=f.model,b=i.outcomes.length;if(i.kind==="1x2"&&i.main&&b===3)return[e,s,l];if(i.kind==="12"&&i.main&&b===2&&s<.005)return[e,l];if(i.kind==="dc"&&i.main&&b===3)return[e+s,e+l,s+l];if(/^победит\s*\(осн\.?\s*время\)$/i.test(i.title)&&b===2){let v=i.period===n.match.home?e:i.period===n.match.away?l:null;if(v!=null)return[v,1-v]}return null}function x(){let i=n.markets.filter(f=>f.scope!=="list"&&f.main&&(f.kind==="1x2"||f.kind==="12"));return i.find(f=>f.scope==="top")||i[0]||null}function g(i,f){let e=i.outcomes[f].label;return i.scope==="list"?!i.event||!i.main?e:i.kind==="1x2"?[i.event.home,"Ничья",i.event.away][f]||e:i.kind==="12"&&[i.event.home,i.event.away][f]||e:n.match?i.kind==="1x2"?[n.match.home,"Ничья",n.match.away][f]||e:i.kind==="12"&&[n.match.home,n.match.away][f]||e:e}function y(){let i=n.settings.overlay,f=[];for(let s of n.markets){if(s.outcomes.forEach((N,A)=>d.set(N.el,{market:s,index:A})),i==="off")continue;let l=m(s);if(l.kind==="partial")continue;let b=k(s),v=b||l.fair,z=0;for(let N=1;N<l.fair.length;N+=1)l.fair[N]>l.fair[z]&&(z=N);let $="accent";if(b){let N=0;for(let A=1;A<b.length;A+=1)b[A]-l.fair[A]>b[N]-l.fair[N]&&(N=A);b[N]-l.fair[N]>=.015&&(z=N,$="pos")}let w=s.scope!=="list"||s.main&&(s.kind==="1x2"||s.kind==="12");s.outcomes.forEach((N,A)=>{let B=A===z&&w;!B&&i!=="all"||f.push({el:N.el,frame:B,chip:kt(v[A]),tone:B?$:"quiet"})})}let e=T();if(e){let s=f.find(l=>l.el===e.item.el);s?s.selected=!0:f.push({el:e.item.el,frame:!1,selected:!0,chip:null})}u.set(f)}function T(){if(!n.selected)return null;let i=n.markets.find(e=>e.id===n.selected.id),f=i?.outcomes[n.selected.index];return f?.el?.isConnected?{market:i,item:f,index:n.selected.index}:null}function F(){if(n.settings.theme!=="auto")return n.settings.theme;for(let i of[document.body,document.documentElement]){let e=(i?getComputedStyle(i).backgroundColor:"").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!e||e[4]==="0")continue;return(.2126*e[1]+.7152*e[2]+.0722*e[3])/255<.42?"dark":"light"}return matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}let O=0;function I(){clearTimeout(O),O=setTimeout(()=>$t({"lz.margins":n.margins}),1500)}function j(){if(n.pageType!=="match"||!n.match||n.match.live)return;n.margins=ie(n.margins);let i=q();i&&bn(n.margins,{key:n.match.key,book:r.id,margin:i.margin})&&I()}function E(){location.href!==n.url&&(n.url=location.href,n.selected=null,u.hideTip());let i="other",f=[],e=null;try{i=o.pageType(document,location),f=o.collect(document,location),e=o.readMatch(document,location)}catch(l){console.error("[Линза] страница не прочитана",l)}i!==n.pageType&&(n.pageType=i,n.tab!=="settings"&&n.tab!=="express"&&(n.tab=i==="match"?"match":"scan")),n.markets=f,n.match=e,j();let s=F();s!==n.theme&&(n.theme=s),u.setTheme(n.theme),c.setTheme(n.theme),y(),bt(),M(),c.isOpen&&(xt(),Vt(),Wt(),zt(),c.render(J()))}let W=new Set,_=null;function M(){if(o.observeTargets)for(let i of o.observeTargets(document))W.has(i)||(W.add(i),_=_||new MutationObserver(P),_.observe(i,{childList:!0,subtree:!0,characterData:!0}))}let S=0,C=0;function P(){let i=Date.now();C||(C=i),clearTimeout(S);let f=i-C>900?0:220;S=setTimeout(()=>{C=0,!document.hidden&&E()},f)}function q(){let i=x();if(!i)return null;let f=m(i);if(f.kind!=="full")return null;let e=k(i);return{title:"Что заложено в цене",margin:f.margin,rows:i.outcomes.map((s,l)=>({name:g(i,l),odd:s.odd,fair:f.fair[l],model:e?e[l]:null})),overtime:V()}}function V(){if(!["hockey","basketball"].includes(n.match?.sport))return null;let i=n.markets.find(e=>e.scope!=="list"&&e.outcomes.length===2&&/овертайм|булл|(^|[^а-яё])от([^а-яё]|$)|\bot\b/i.test(`${e.title} ${e.period}`)&&!/тотал|фора|будет|перв|втор|трет|период|тайм/i.test(`${e.title} ${e.period}`));if(!i)return null;let f=m(i);return f.kind!=="full"?null:{title:[i.title,i.period].filter(Boolean).join(" · "),rows:i.outcomes.map((e,s)=>({name:g(i,s)||[n.match.home,n.match.away][s],odd:e.odd,fair:f.fair[s]}))}}function U(){let i=T();if(!i)return null;let{market:f,item:e,index:s}=i,l=m(f),b=k(f),v=l.fair?l.fair[s]:null,z=f.event?`${f.event.home} — ${f.event.away}`:n.match?`${n.match.home} — ${n.match.away}`:"",$=n.match?n.compare.get(n.match.key):null,w=null;if($?.rows?.length&&f.main&&(f.kind==="1x2"||f.kind==="12")&&f.scope!=="list")for(let A of $.rows){let B=A.odds[s];B&&(!w||B>w.odd)&&(w={name:A.name,odd:B,book:A.book||""})}w&&(w.partner=w.book&&w.book!==r.id&&n.partners.data?.[w.book]||null,w.gain=Math.round((w.odd-e.odd)*(n.settings.stake||1e3)));let N=`${f.id}#${s}`;return{market:[f.title,f.period,f.line].filter(Boolean).join(" · "),label:[g(f,s),z].filter(Boolean).join(" · "),odd:e.odd,fair:v,margin:l.margin,fairOdd:v?1/v:null,model:b?b[s]:null,ev:b?Re(b[s],e.odd):null,best:w,canAdd:Number.isFinite(v)&&!n.express.some(A=>A.id===N),inExpress:n.express.some(A=>A.id===N),note:l.kind==="partial"?"Набор исходов неполный, поэтому маржу этого рынка посчитать нельзя.":b?"":"Запас в цене появляется, только если ваш шанс выше шанса линии. Сама линия запаса не даёт."}}function nt(){let i=vn(ie(n.margins),r.id);if(!i)return null;let f=i.best&&i.best.there<i.best.here?i.best:null,e=f&&gt().find(s=>s.name===f.name&&(s.url||s.code))||null;return{...i,best:f,partner:e}}function Q(){let i=[];if(n.pageType==="match"?n.markets.forEach((l,b)=>{if(l.scope==="list")return;let v=m(l);if(v.kind!=="full")return;let z=0;for(let $=1;$<v.fair.length;$+=1)v.fair[$]>v.fair[z]&&(z=$);i.push({index:b,name:l.title,sub:[l.period,l.line].filter(Boolean).join(" · "),margin:v.margin,fav:l.outcomes[z].label,favPct:v.fair[z]})}):n.markets.forEach((l,b)=>{if(!l.event||!l.main||l.kind!=="1x2"&&l.kind!=="12")return;let v=m(l);if(v.kind!=="full")return;let z=0;for(let w=1;w<v.fair.length;w+=1)v.fair[w]>v.fair[z]&&(z=w);let $=l.kind==="1x2"?[l.event.home,"Ничья",l.event.away][z]:[l.event.home,l.event.away][z];i.push({index:b,name:`${l.event.home} — ${l.event.away}`,sub:l.event.league||l.event.time,margin:v.margin,fav:$,favPct:v.fair[z]})}),!i.length)return null;let f=new Set;for(let l=i.length-1;l>=0;l-=1){let b=`${i[l].name}|${i[l].sub}`;f.has(b)?i.splice(l,1):f.add(b)}let e=i.reduce((l,b)=>l+b.margin,0)/i.length;i.sort((l,b)=>l.margin-b.margin);let s=i.slice(0,16);return s.forEach(l=>{l.low=l.margin<=e*.8}),{title:n.pageType==="match"?"Рынки этого матча":"Матчи на странице",first:n.pageType==="match"?"Рынок":"Матч",average:e,rows:s,note:`Чем ниже маржа, тем меньше контора забирает с каждой ставки. Показаны ${s.length} из ${i.length}, сначала самые дешёвые.`}}function st(){let i=n.status;return i.ready?i.limit?`Разборов сегодня: ${i.used} из ${i.limit}`:"":"Чтобы разбирать матчи, подключите доступ в настройках. Отметки и маржа работают без него."}function J(){let i=n.match?.key,f=i&&n.analysis.get(i)||{status:"idle",steps:[]},e=i&&n.compare.get(i)||{status:"idle"},s=n.match?.live&&o.readEsportsWidget?o.readEsportsWidget(document):null,l=n.status;return{tab:n.tab,backTab:n.backTab,theme:n.theme,bookName:r.name,pageType:n.pageType,match:n.match?{...n.match,sportName:je[n.match.sport]||""}:null,esports:s?{...s,homeName:n.match.home,awayName:n.match.away}:null,line:q(),analysis:{status:f.status,steps:f.steps||[],result:f.result||null,error:f.error||"",needKey:!!f.needKey},compare:e,consensus:i&&n.consensus.get(i)||null,model:i&&n.model.get(i)||null,live:me(i),verdict:ue(i),facts:i&&n.facts.get(i)||null,pick:U(),scan:n.tab==="scan"?Q():null,margins:n.tab==="scan"?nt():null,edges:n.edges,bookId:r.id,partners:gt(),stake:Number(n.settings.stake)||1e3,express:{legs:n.express,stats:qe(n.express)},quota:st(),update:n.status.update?{version:n.status.update,url:Qt.site?`${Qt.site}#install`:""}:null,whatsnew:n.whatsnew?{version:n.whatsnew.to,changes:kn(n.whatsnew.from,n.whatsnew.to)}:null,settings:{overlay:n.settings.overlay,theme:n.settings.theme,stake:Number(n.settings.stake)||1e3,mode:l.mode,proxy:l.proxy,ready:l.ready,hasKey:l.hasKey,keyMask:l.keyMask,licenseMask:l.licenseMask,plan:l.plan==="free"||!l.plan?"":`Тариф «${{max:"Макс",vip:"VIP",api:"API"}[l.plan]||"Про"}»${l.until?` до ${l.until.split("-").reverse().join(".")}`:""}.`,usage:l.limit?`Сегодня разборов: ${l.used} из ${l.limit}.`:""}}}let rt=()=>{c.isOpen&&c.render(J())};function ft(i){Object.assign(n.settings,i),$t({"lz.settings":n.settings}),E(),c.render(J())}async function Mt(i=!1){if(!i&&Date.now()-n.partners.at<3600*1e3)return;n.partners.at=Date.now();let f=await ot("lz:partners",{force:i});f.ok&&f.data&&typeof f.data=="object"&&(n.partners.data=f.data,c.isOpen&&c.render(J()),pt())}let gt=()=>Object.values(n.partners.data||{}).filter(i=>i&&i.id!==r.id);function pt(){if(!c.isOpen||n.tab!=="match"||!n.match)return;let i=gt().filter(f=>f.url||f.code).map(f=>f.id);i.length&&ot("lz:partner-seen",{ids:i,s:"panel"})}async function ct(){n.edges={...n.edges,status:"loading",error:""};let i=await ot("lz:edges",{sport:n.match?.sport||""});n.edges=i.ok?{status:"done",data:i.data,error:"",at:Date.now()}:{status:"error",data:n.edges.data,error:i.error,at:Date.now()},rt()}async function ut(){let i=await ot("lz:status");i.ok&&(n.status=i.data),rt()}function Lt(){let i=x(),f=i?m(i):null;return{book:r.name,match:n.match,market:i&&f?.kind==="full"?{kind:i.kind,labels:i.outcomes.map((e,s)=>g(i,s)),odds:i.outcomes.map(e=>e.odd)}:null}}function bt(){if(!n.match||!wt())return;let i=Lt();if(!i.market)return;let f=`${n.match.key}|${i.market.odds.join("/")}`;f!==bt.last&&(bt.last=f,ot("lz:quote",i))}async function xt(){let i=n.match;if(!i||i.live||n.consensus.has(i.key))return;let f=Lt();if(!f.market?.odds?.length)return;n.consensus.set(i.key,null);let e=await ot("lz:consensus",{match:i,size:f.market.odds.length});n.consensus.set(i.key,e.ok&&e.data?.consensus?e.data:null),n.match?.key===i.key&&c.isOpen&&c.render(J())}async function zt(){let i=n.match;if(!i?.live||!["basketball","football","hockey","tennis"].includes(i.sport))return;let f=n.live.get(i.key);if(f&&(f.pending||Date.now()-f.at<3e4))return;n.live.set(i.key,{...f||{},pending:!0});let e=await ot("lz:live",{match:i});n.live.set(i.key,{at:Date.now(),data:e.ok&&e.data&&!e.data.error?e.data:null,error:e.ok?e.data?.error||"":e.error||""}),n.match?.key===i.key&&c.isOpen&&c.render(J())}function Ot(i,f){n.fonbetRef.set(i,null),ot("lz:fonbet-ref",{match:f}).then(e=>{n.fonbetRef.set(i,e.ok&&e.data?.odds?e.data:null),e.ok&&e.data?.odds&&n.match?.key===i&&c.isOpen&&c.render(J())}).catch(()=>{})}function Ct(i,f,e){let s=n.match,l=`${i}|${[f.best,...f.others].filter(Boolean).map(v=>`${v.label}:${v.odd}`).join(",")}`;if(n.verdictSent===l)return;n.verdictSent=l;let b=[f.best,...f.others].filter(Boolean).map(v=>({label:v.label,odd:v.odd,p:v.p,kind:v.kind||"win",side:v.side||"",line:v.line??null}));ot("lz:verdict",{payload:{sport:s.sport,league:s.league||"",home:s.home,away:s.away,book:r.name,source:e,options:b}}).then(v=>{v?.ok&&v.data?.track&&v.data.track!==n.verdictTrack&&(n.verdictTrack=v.data.track,c.isOpen&&c.render(J()))}).catch(()=>{})}function ue(i){let f=n.match,e=i&&q();if(!f||!e||f.live)return null;let s=n.consensus.get(i),l=e.rows,b=n.model.get(i),v=b&&Tn(b,l.map(R=>R.odd)).ok?b:null,z=n.analysis.get(i)?.result,$=[f.home,f.away],w=[],N="";if(s?.consensus?.length===l.length)l.forEach((R,H)=>w.push({label:R.name,odd:R.odd,p:s.consensus[H],side:l.length===3?["home","draw","away"][H]:["home","away"][H]})),N=`консенсус ${s.count} контор`;else if(!s?.consensus&&v?.sport==="hockey"&&v.regulation&&l.length===3){let R=[v.regulation.p1,v.regulation.px,v.regulation.p2];l.forEach((H,lt)=>w.push({label:H.name,odd:H.odd,p:R[lt],side:["home","draw","away"][lt]})),N="модель Линзы"}else{let R=l.length===2?l:f.sport==="mma"&&l.length===3?[l[0],l[2]]:e.overtime?.rows||null,H=s?.consensus?.length===2?s.consensus:v?.p1?[v.p1,v.p2]:null;R&&H&&(R.forEach((lt,it)=>w.push({label:$[it],odd:lt.odd,p:H[it],side:["home","away"][it]})),N=s?.consensus?.length===2?`консенсус ${s.count} контор`:"модель Линзы")}let A=v?.sport==="mma"?v.durations:null;if(A)for(let R of n.markets){if(R.scope==="list"||R.kind!=="total"||R.outcomes.length!==2)continue;let H=String(R.line||"").replace(",","."),lt=H==="1.5"?A.r1+A.r2/2:H==="2.5"&&A.rounds===3?A.r1+A.r2+A.r3/2:null,it=Gt(R.outcomes.map(ht=>ht.label));lt==null||it<0||w.some(ht=>ht.kind==="total"&&ht.line===H)||(w.push({label:`Больше ${H} раунда`,odd:R.outcomes[it].odd,p:1-lt,kind:"total",line:H}),w.push({label:`Меньше ${H} раунда`,odd:R.outcomes[1-it].odd,p:lt,kind:"total",line:H}))}if(v?.sport==="basketball"&&v.lines){let R=qt=>{let dt=String(qt||"").replace(/[−–]/g,"-").replace(",",".").match(/[-+]?[0-9]+(?:[.][0-9]+)?/);return dt?Number(dt[0]):NaN},H=qt=>n.markets.filter(dt=>dt.scope!=="list"&&dt.main&&dt.kind===qt&&dt.outcomes.length===2&&dt.outcomes.every(Xt=>Xt.odd>1)).sort((dt,Xt)=>Math.abs(dt.outcomes[0].odd-dt.outcomes[1].odd)-Math.abs(Xt.outcomes[0].odd-Xt.outcomes[1].odd))[0]||null,lt=H("handicap"),it=H("total"),ht=lt?R(lt.outcomes[0].label):NaN;lt&&!Number.isFinite(ht)&&(ht=R(lt.line));let Ht=it?R(it.line):NaN;it&&!Number.isFinite(Ht)&&(Ht=R(it.outcomes[0].label));let xe=it?Gt(it.outcomes.map(qt=>qt.label)):-1;w.push(...zn(v,{handicap:lt&&Number.isFinite(ht)?{line:ht,home:lt.outcomes[0].odd,away:lt.outcomes[1].odd}:null,total:it&&xe>=0&&Number.isFinite(Ht)?{line:Ht,over:it.outcomes[xe].odd,under:it.outcomes[1-xe].odd}:null},$))}let B=n.markets.filter(R=>R.scope!=="list"),L=l.length===2?yt(l.map(R=>R.odd)):null;L?.fair&&["tennis","cs","dota"].includes(f.sport)&&w.push(...Oe({sport:f.sport,p:L.fair[0],source:"цена конторы на победу",markets:B,names:$,league:f.league||""}));let G=v?.p1&&["tennis","cs","dota"].includes(f.sport)?Cn({sport:f.sport,model:v,markets:B,names:$,league:f.league||""}):[];if((f.sport==="football"||f.sport==="hockey")&&r.id!=="fonbet"){let R=n.fonbetRef.get(i);R===void 0?Ot(i,f):R&&w.push(...Fn(R,n.markets.filter(H=>H.scope!=="list"),f.sport,$))}if(!w.length)return null;let Z=[...w].sort((R,H)=>H.p*H.odd-R.p*R.odd)[0]?.side,tt=(z?.factors||[]).filter(R=>Z&&R.side===Z).slice(0,2).map(R=>R.text),et=$n(w,{source:N,reasons:tt,risk:z?.risks?.[0]||""});return et&&G.length&&et.lines.splice(et.lines.length-1,0,`По модели Линзы интересная цена от: ${G.slice(0,6).map(R=>`${R.label} — ${R.from.toFixed(2)}${R.odd>=R.from?" ✓ здесь выше":""}`).join(" · ")}.`),et&&Ct(i,et,N),et&&{...et,track:n.verdictTrack||""}}function de(i,f,e){let s=(z,$)=>f?[$,z]:[z,$],b=q()?.rows||[],v=b.length===2&&b.every(z=>Number.isFinite(z.fair))?b.map(z=>z.fair):null;return{kind:"tennis",names:[n.match.home,n.match.away],score:s(i.score[0],i.score[1]),sets:i.sets.map(([z,$])=>s(z,$)),games:s(i.games[0],i.games[1]),points:s(i.points[0],i.points[1]),tiebreak:i.tiebreak,serving:i.aServes==null?null:i.aServes!==f?0:1,bestOf:i.bestOf,prior:i.prior,serve:s(i.serve.a,i.serve.b),probs:s(i.p1,i.p2),set:s(i.set.p1,1-i.set.p1),game:s(i.game.p1,1-i.game.p1),book:v,compare:i.prior.source==="line"||i.prior.source==="model",at:e}}function pe(i,f,e){let s=($,w)=>f?[w,$]:[$,w],l=$=>f?[$[2],$[1],$[0]]:$,v=q()?.rows||[],z=v.length===3&&v.every($=>Number.isFinite($.fair))?v.map($=>$.fair):null;return{kind:"goals",sport:i.sport,names:[n.match.home,n.match.away],score:s(i.score[0],i.score[1]),red:s(i.red[0],i.red[1]),minute:i.minute,period:i.period,periods:i.periods,clock:i.clock,prior:i.prior,probs:l([i.p1,i.px,i.p2]),book:z,compare:i.prior.source==="line",expTotal:i.expTotal,nextGoal:l([i.nextGoal.home,i.nextGoal.none,i.nextGoal.away]),total:i.tables.total,handicap:i.tables.handicap.map($=>f?{line:-$.line,home:$.away,away:$.home}:$).sort(($,w)=>$.line-w.line),bookLines:i.bookLines,at:e}}function me(i){let f=i&&n.live.get(i);if(!f?.data)return f?.error?{error:f.error}:null;let e=f.data,s=!!e.flipped;if(e.kind==="goals")return pe(e,s,f.at);if(e.kind==="tennis")return de(e,s,f.at);let l=(w,N)=>s?[N,w]:[w,N],b=q(),v=b?.overtime?.rows||b?.rows||[],z=v.length===2?v.map(w=>w.fair):v.length===3&&v.every(w=>Number.isFinite(w.fair))?[v[0].fair+v[1].fair/2,v[2].fair+v[1].fair/2]:null,$=e.tables||{};return{names:[n.match.home,n.match.away],score:l(e.score[0],e.score[1]),periods:(e.periods||[]).map(([w,N])=>l(w,N)),period:e.period,elapsed:e.elapsed,left:e.left,clock:e.clock,format:e.format,probs:l(e.p1,e.p2),book:z,prior:e.prior,expMargin:s?-e.expMargin:e.expMargin,sd:e.sd,projTotal:e.projTotal,sdTotal:e.sdTotal,handicap:($.handicap||[]).map(w=>s?{line:-w.line,home:w.away,away:w.home}:w).sort((w,N)=>w.line-N.line),total:$.total||[],quarterTotal:$.quarterTotal||[],bookLines:e.bookLines?{handicap:e.bookLines.handicap?s?{...e.bookLines.handicap,line:-e.bookLines.handicap.line,odds:[...e.bookLines.handicap.odds].reverse(),fair:[...e.bookLines.handicap.fair].reverse(),p:1-e.bookLines.handicap.p,book:1-e.bookLines.handicap.book,gap:-e.bookLines.handicap.gap}:e.bookLines.handicap:null,total:e.bookLines.total||null}:null,quarter:e.quarter?{...e.quarter,score:l(e.quarter.score[0],e.quarter.score[1]),expMargin:s?-e.quarter.expMargin:e.quarter.expMargin,probs:l(e.quarter.p1,e.quarter.p2)}:null,at:f.at}}async function Vt(){let i=n.match;if(!i||!["cs","dota","tennis","basketball","mma","hockey"].includes(i.sport)||n.model.has(i.key)||i.live&&(i.sport==="tennis"||i.sport==="basketball"||i.sport==="mma"||i.sport==="hockey"))return;n.model.set(i.key,null);let f=await ot("lz:model",{match:i});n.model.set(i.key,f.ok&&f.data?.p1?f.data:null),n.match?.key===i.key&&c.isOpen&&c.render(J())}let Ut=new Map;async function Wt(){let i=n.match;if(!i||!["football","hockey","basketball","cs","dota"].includes(i.sport))return;let f=i.live&&Date.now()-(Ut.get(i.key)||0)>60*1e3;if(n.facts.has(i.key)&&!f)return;let e=n.facts.get(i.key)||null;Ut.set(i.key,Date.now()),n.facts.set(i.key,e);let s=await ot("lz:facts",{match:i});n.facts.set(i.key,s.ok&&s.data?.facts?.length?s.data:e),n.match?.key===i.key&&c.isOpen&&c.render(J())}async function fe(){let i=n.match;if(!i||n.analysis.has(i.key))return;let f=await ot("lz:cached",{match:i});!f.ok||!f.data||n.analysis.has(i.key)||(n.analysis.set(i.key,{status:"done",steps:[],result:f.data}),E(),rt())}function he(){return{opened(){ut(),E(),fe(),xt(),Vt(),Wt(),zt(),Mt(),c.render(J()),pt()},tab(i){i==="settings"&&(n.backTab=n.tab==="settings"?n.backTab:n.tab),n.tab=i||"match",i==="edges"&&n.edges.status!=="loading"&&Date.now()-n.edges.at>300*1e3&&ct(),c.render(J())},"edges-refresh"(){ct(),c.render(J())},theme(){ft({theme:n.theme==="dark"?"light":"dark"})},"overlay-toggle"(){ft({overlay:n.settings.overlay==="off"?"picks":"off"})},"set-overlay"(i){ft({overlay:i})},"set-theme"(i){ft({theme:i})},async"set-mode"(i){await ot("lz:settings",{mode:i}),ut()},"copy-code"(i){if(!i)return;let f=()=>c.toast("Промокод скопирован");navigator.clipboard?.writeText?navigator.clipboard.writeText(i).then(f,()=>c.toast(`Промокод: ${i}`)):c.toast(`Промокод: ${i}`)},"set-stake"(i,f,e){let s=Math.round(Number(e.getElementById("lz-stake")?.value));if(!Number.isFinite(s)||s<10||s>1e7)return c.toast("Введите сумму от 10 ₽");ft({stake:s}),c.toast("Сумма сохранена")},async"save-key"(i,f,e){let s=e.getElementById("lz-key"),l=(s?.value||"").trim();if(l.length<8)return c.toast("Вставьте ключ целиком");let b=await ot("lz:settings",{apiKey:l});c.toast(b.ok?"Ключ сохранён":b.error),s&&(s.value=""),ut()},async"clear-key"(){await ot("lz:settings",{apiKey:""}),c.toast("Ключ удалён"),ut()},async"save-license"(i,f,e){let s=e.getElementById("lz-license"),l=(s?.value||"").trim();if(l.length<6)return c.toast("Вставьте ключ целиком");let b=await ot("lz:settings",{licenseKey:l});c.toast(b.ok?"Ключ принят":b.error),s&&(s.value=""),ut()},async"clear-license"(){await ot("lz:settings",{licenseKey:""}),c.toast("Ключ удалён"),ut()},savePosition(i,f){n.positions[i]=f,Se(["lz.positions"]).then(e=>{let s=e["lz.positions"]||{};s[location.hostname]=n.positions,$t({"lz.positions":s})})},async analyze(){if(!n.match)return;let i=n.match.key,f={status:"loading",steps:[`${n.match.home} — ${n.match.away}`]};n.analysis.set(i,f),rt();let e=await ot("lz:analyze",{...Lt(),force:!0}),s=e.ok?e.data?.job:"",l=Date.now();for(;s&&e.ok&&e.data?.status==="running"&&Date.now()-l<420*1e3;){if(f.steps=[f.steps[0],...(e.data.steps||[]).map(b=>b.text)].slice(-8),rt(),await new Promise(b=>setTimeout(b,2e3)),n.analysis.get(i)!==f)return;e=await ot("lz:job",{job:s}),!e.ok&&e.code==="retry"&&(e=await ot("lz:job",{job:s}))}if(e.ok&&s){let b=e.data?.steps?.length?[f.steps[0],...e.data.steps.map(v=>v.text)].slice(-8):f.steps;e.data.status==="done"?n.analysis.set(i,{status:"done",steps:b,result:{...e.data.result,full:e.data.full||null}}):e.data.status==="error"?n.analysis.set(i,{status:"error",steps:b,error:e.data.error}):n.analysis.set(i,{status:"error",steps:b,error:"Разбор идёт дольше 7 минут. Нажмите ещё раз — собранное уже на сервере, второй раз будет быстрее."})}else e.ok?n.analysis.set(i,{status:"done",steps:f.steps,result:e.data}):n.analysis.set(i,{status:"error",steps:f.steps,error:e.error,needKey:e.code==="no-access"});ut(),E(),c.render(J())},async report(){let i=n.match?n.analysis.get(n.match.key):null,f="";try{f=chrome.runtime.getManifest().version}catch{}let e=await ot("lz:report",{where:"panel",url:location.href,book:r.name,version:f,match:n.match?`${n.match.home} — ${n.match.away}`:"",step:i?.steps?.slice(-1)[0]||"",error:i?.error||(i?.status==="done"?"разбор выглядит неправильно":"страница матча не узнана")});c.toast(e.ok?"Спасибо! Сообщение ушло разработчику.":e.error)},async compare(){if(!n.match)return;let i=n.match.key;n.compare.set(i,{status:"loading"}),rt();let f=await ot("lz:compare",Lt());n.compare.set(i,f.ok?{status:"done",...f.data}:{status:"done",rows:[],labels:[],note:f.error}),f.ok&&xn(n.margins,i,f.data.rows)&&I(),rt()},"whatsnew-ok"(){n.whatsnew=null,$t({"lz.whatsnew":null}),rt()},"pick-clear"(){n.selected=null,y(),rt()},"leg-add"(){let i=U(),f=T();!i?.canAdd||!f||(n.express.push({id:`${f.market.id}#${f.index}`,title:i.market,label:i.label,odd:i.odd,fair:i.fair,at:Date.now()}),$t({"lz.express":n.express}),c.toast("Добавлено в расчёт экспресса"),rt())},"leg-remove"(i){n.express=n.express.filter(f=>f.id!==i),$t({"lz.express":n.express}),rt()},"leg-clear"(){n.express=[],$t({"lz.express":n.express}),rt()},"scan-go"(i){let f=n.markets[Number(i)],e=f?.outcomes[0]?.el;e?.isConnected&&(e.scrollIntoView({behavior:"smooth",block:"center"}),n.selected={id:f.id,index:0},setTimeout(y,400))}}}function Kt(i){let f=i.composedPath();for(let e=0;e<Math.min(f.length,6);e+=1){let s=f[e]instanceof Element?d.get(f[e]):null;if(s&&s.market.outcomes[s.index]?.el===f[e])return s}return null}let Et=new Map;function ge(i){if(!i.event||!i.main||!["1x2","12"].includes(i.kind)||i.scope!=="list"||i.event.live)return console.debug("[lz] рынок для списка не запрашивается:",JSON.stringify({event:!!i.event,main:i.main,kind:i.kind,scope:i.scope,live:i.event?.live})),null;let f=i.event.key;if(Et.has(f))return Et.get(f);let e={home:i.event.home,away:i.event.away,sport:be(i),league:i.event.league||""},s=ot("lz:consensus",{match:e,size:i.outcomes.length}).then(l=>((!l.ok||!l.data?.consensus)&&console.debug("[lz] рынок для списка:",l.error||l.data?.error||"нет данных"),l.ok&&l.data?.consensus?l.data:null)).catch(l=>(console.debug("[lz] рынок для списка:",String(l?.message||l)),null));return Et.set(f,s),s.then(l=>Et.set(f,l)),s}let be=i=>i.event?.sport||n.match?.sport||jt(location.pathname,document.title,i.event?.league);function It({market:i,index:f},e=null){let s=m(i),l=k(i),b=i.event?`${i.event.home} — ${i.event.away}`:"",v=i.outcomes.map((w,N)=>{let A=s.fair?s.fair[N]:1/w.odd;return t(`div.tip-row${N===f?".hot":""}`,{},t("span",{text:g(i,N)}),t("span.odd",{text:X(w.odd)}),t("span.pct",{text:kt(A,A<.1?1:0)}),t("span.tip-bar",{},t("i",{style:`width:${Math.round(A*100)}%`})))}),z=s.kind==="partial"?t("div.tip-foot",{text:"Набор исходов неполный: проценты включают маржу конторы."}):t("div.tip-foot",{},"Маржа конторы ",t("b",{text:kt(s.margin,1)}),l?t("span",{}," · модель: ",t("b",{text:kt(l[f],1)})):null),$=null;if(e?.consensus){let w=e.consensus.length===i.outcomes.length,N=!w&&e.consensus.length===2&&i.outcomes.length===3;if(w||N){let A=w?e.consensus[f]:null,B=A?i.outcomes[f].odd*A-1:0;$=t("div.tip-foot",{},`Рынок, ${e.count} контор${N?", с овертаймом":""}: `,t("b",{text:e.consensus.map(L=>kt(L,0)).join(" / ")}),B>.005?t("span.pos",{text:` · кэф выше рынка на ${(B*100).toFixed(1)}%`}):null)}}else e===void 0&&($=t("div.tip-foot",{text:"Рынок: сверяю…"}));return t("div",{},t("div.tip-title",{text:[i.title,i.period,i.line].filter(Boolean).join(" · ")}),b?t("div.tip-sub",{text:b}):t("div.tip-sub",{text:"Шанс по линии без маржи"}),v.slice(0,8),z,$)}let St=0,_t=null;ce.on("page:pointerover",i=>{if(n.settings.overlay==="off")return;let f=Kt(i),e=f?f.market.outcomes[f.index].el:null;if(e!==_t){if(_t=e,clearTimeout(St),!f)return u.hideTip();St=setTimeout(()=>{if(_t!==e||!e.isConnected)return;u.setAvoid(c.rect());let s=ge(f.market);u.showTip(e,It(f,s instanceof Promise?void 0:s)),s instanceof Promise&&s.then(l=>{_t===e&&e.isConnected&&u.showTip(e,It(f,l))})},280)}}),ce.on("page:click",i=>{let f=Kt(i);f&&(n.selected={id:f.market.id,index:f.index},n.tab==="scan"&&(n.tab="match"),y(),rt())}),hn(i=>{if(i.type!=="lz:progress")return;let f=n.analysis.get(i.key);!f||f.status!=="loading"||(f.steps=[...f.steps,i.text].slice(-7),rt())});let Zt=()=>{E(),new MutationObserver(P).observe(document.body,{childList:!0,subtree:!0,characterData:!0}),document.addEventListener("visibilitychange",()=>{document.hidden||E()}),setInterval(()=>{!document.hidden&&location.href!==n.url&&E()},600),setInterval(()=>{!document.hidden&&c.isOpen&&P()},4e3),wt()&&chrome.storage.onChanged.addListener(i=>{i["lz.settings"]&&(n.settings={...ve,...i["lz.settings"].newValue||{}},E())}),ut()};document.body?Zt():document.addEventListener("DOMContentLoaded",Zt,{once:!0}),document.documentElement.setAttribute("data-lz",r.id),globalThis.__lz={state:n,view:J,refresh:E,overlay:u,panel:c}}function Do(o){let r=Date.now()-432e5;return(Array.isArray(o)?o:[]).filter(a=>a&&a.at>r&&a.odd>1)}})();
